# CYBER HOUSE — modulli tuzilma

Asl `main-19-fixed-6.html` (bitta fayl) funksionallik va kodga tegmasdan modullarga ajratildi.

## Ishga tushirish
- `index.html` ni brauzerda oching (qo'shimcha server yoki build shart emas).
- Faqat `three.js r128` CDN'dan yuklanadi (internet kerak). Oflayn ishlatish uchun `three.min.js` ni yuklab olib, `index.html` dagi CDN havolasini lokal yo'lga almashtiring.

## Papka tuzilmasi
```
index.html        — faqat markup + CSS/JS ulanishlari
css/              — 8 ta stil fayli (tartib bo'yicha ulangan)
js/<guruh>/       — 94 ta modul (har biri bitta mas'uliyat)
```

## Muhim qoida: yuklanish tartibi
Modullar oddiy (classic) `<script>` sifatida ulangan va **bitta umumiy global scope** ni bo'lishadi — asl koddagi kabi.
Shuning uchun `index.html` ichidagi `<script>` **tartibini o'zgartirmang**: keyingi modullar oldingilarida e'lon qilingan o'zgaruvchilarga tayanadi.

Yangi modul qo'shish: faylni `js/` ichida yarating va `index.html` da tegishli joyga `<script src="...">` qo'shing.

## Eslatma (hoisting)
Asl faylda funksiya e'lonlari butun skript bo'ylab ko'rinardi. Bo'lingach, yuklanish paytida erta chaqiriladigan 3 funksiya
(`lab`, `wrapT` → `js/core/text-utils.js`, `mkOsh` → `js/kitchen/osh-model.js`) oldinroq yuklanadigan modullarga ko'chirildi. Kodning o'zi o'zgarmagan.

## Modullar (yuklanish tartibida)

### Yadro
1. `js/core/globals.js` — Global o'zgaruvchilar: THREE, $ yordamchisi, mobil aniqlash, o'lchamlar
2. `js/core/renderer.js` — Sahna, kamera, renderer va sifat (AVTO/YUQORI/PAST) rejimlari
3. `js/core/helpers.js` — Material, canvas, tekstura va box() yordamchi funksiyalari
4. `js/core/text-utils.js` — Matn yordamchilari: lab() yorliq teksturasi va wrapT() matn o'rash (erta chaqirilgani uchun shu yerda e'lon qilingan)

### 3D dunyo (xona, jihozlar)
5. `js/world/textures.js` — Pol, devor teksturalari va plakat
6. `js/world/lights.js` — Yoritgichlar (lampa, nuqtaviy yorug'lik)
7. `js/world/room.js` — Xona: devorlar, pol, shift, eshik, oyna
8. `js/world/server-rack.js` — Server rack
9. `js/world/desk-chair.js` — Stol va stul
10. `js/world/monitor-base.js` — Monitor: asosiy korpus va ekran teksturasi
11. `js/world/part-registry.js` — Qismlarni nomi bilan topish (part, partAt), fan geometriyasi
12. `js/world/monitor-details.js` — Monitor detallari: bezel, panel, stand, HDMI/DP, ventilyatsiya
13. `js/world/keyboard-mouse.js` — Klaviatura va sichqoncha modellari
14. `js/world/desk-props.js` — Stol ustidagi buyumlar: lampa, krujka, daftar
15. `js/world/computer-tower.js` — Kompyuter korpusi (tower) modeli
16. `js/world/sockets.js` — Rozetka va kabel boshlang'ich nuqtalari

### Kabellar
17. `js/cables/cable-routes.js` — Kabel yo'llari (aylana yoylar, stol qirrasidan oshib o'tish)
18. `js/cables/collision-boxes.js` — Kabel va buyumlar uchun to'qnashuv qutilari
19. `js/cables/cable-simulation.js` — Kabel simulyatsiyasi (cableInit, cable)

### Portlar va nishonga olish
20. `js/interaction/ports-aim.js` — Portlar ro'yxati va nigoh nuri (aim)
21. `js/interaction/port-picking.js` — Port tanlash va yonib-o'chish effekti

### Kali Linux ekrani (XFCE, terminal, fayllar)
22. `js/kali/window-manager.js` — Kali ekran holati, oynalar, ilovalarni ochish/yopish
23. `js/kali/settings-state.js` — Foydalanuvchi, sozlamalar va menyu holatlari
24. `js/kali/wallpapers.js` — Fon rasmlari va beep ovozi
25. `js/kali/filesystem.js` — Fayl tizimi (ruxsatlar, saqlash, yuklash)
26. `js/kali/fs-helpers.js` — Fayl tizimi yordamchilari (format, ikonka, sarlavha)
27. `js/kali/simulation.js` — Jarayonlar, CPU, RAM, tarmoq simulyatsiyasi
28. `js/kali/apps-menu.js` — Applications menyusi va Places
29. `js/kali/context-menu.js` — Kontekst menyu
30. `js/kali/panel.js` — Panel: tarmoq, ovoz, kalendar
31. `js/kali/desktop.js` — Ish stoli: yorliqlar, Sozdat menyusi, dialoglar
32. `js/kali/thunar.js` — Thunar fayl menejeri
33. `js/kali/system-monitor.js` — System Monitor ilovasi
34. `js/kali/settings-app.js` — Settings ilovasi
35. `js/kali/terminal-commands.js` — Terminal: buyruqlar, pipe, grep, ls, run
36. `js/kali/scrolling.js` — Skroll tizimi va terminal/editor chizish
37. `js/kali/attack-monitor.js` — Attack Monitor oynasi
38. `js/kali/screen-render.js` — Ekran render: draw, drawWin, blit
39. `js/kali/python-ide.js` — Python interpretatori va IDE
40. `js/kali/text-input.js` — Matn kiritish, saqlash va login
41. `js/kali/screen-input.js` — Ekran bilan ishlash (bosish, oyna harakatlari)

### O'yinchi va boshqaruv
42. `js/player/player-physics.js` — O'yinchi harakati, to'qnashuv va kamera
43. `js/player/interaction.js` — O'zaro ta'sir: o'tirish, turish, E tugmasi, ko'rsatmalar
44. `js/player/touch-controls.js` — Mobil joystick va qarash boshqaruvi

### Grafika
45. `js/graphics/graphics-plus.js` — Qo'shimcha grafika
46. `js/graphics/pc-case.js` — Kompyuter korpusi: ichki qismlar

### Xavfsizlik (hujum/himoya)
47. `js/security/security-state.js` — Xavfsizlik: holat va doimiylar
48. `js/security/alerts-logging.js` — Sirena, ogohlantirish, loglar
49. `js/security/attacks.js` — Hujumlar: yaratish, buzib kirish, hujum sikli
50. `js/security/defense.js` — Himoya: trace, patch va qarshi hujum
51. `js/security/ids-ui.js` — IDS oynasi interfeysi

### Hayot tizimi (suv, uyqu)
52. `js/life/life-state.js` — Hayot tizimi holati: karavot, uyqu
71. `js/life/life-actions.js` — Stakan, ichish, uyqu, vitals va lifeTick
74. `js/life/desk-cup.js` — Stakanni stolga qo'yish va olish

### Kompyuter ta'mirlash stoli
53. `js/repair/bench-helpers.js` — Ta'mirlash stoli: yordamchi funksiyalar
54. `js/repair/bench-table.js` — Ta'mirlash stoli modeli
55. `js/repair/bench-tools.js` — Otvyorkalar, pasta, idishlar
56. `js/repair/case-shell.js` — Yonboshlab yotgan korpus va qism ro'yxatga olish
57. `js/repair/motherboard.js` — Anakart
58. `js/repair/cpu-cooler.js` — Protsessor va kuller
59. `js/repair/ram.js` — RAM modullari
60. `js/repair/gpu.js` — Video karta
61. `js/repair/psu-cables.js` — Blok pitaniya va kabellar
62. `js/repair/fans.js` — Fanlar
63. `js/repair/side-panel-bolts.js` — Yon qopqoq (shisha) va boltlar
64. `js/repair/bench-sync.js` — Holatni ko'rinishga yozish
65. `js/repair/bench-raycast.js` — Nur bo'yicha tanlash
66. `js/repair/bench-actions.js` — Harakatlar: olish, qo'yish, o'rnatish
67. `js/repair/main-pc-link.js` — Asosiy kompyuter bilan bog'lanish
68. `js/repair/part-operations.js` — Burash, kabel, tutqich, qism olish/qo'yish qoidalari
69. `js/repair/bench-target.js` — Asosiy nishon funksiyasi (benchTarget)
70. `js/repair/bench-update.js` — Ta'mirlash stoli yangilanishi

### O'rgatuvchi qism
72. `js/education/lessons-data.js` — O'rgatuvchi auditlar (LESSONS)
73. `js/education/notebook-ui.js` — Blaknot interfeysi
76. `js/education/mentor-coach.js` — Mentor: kompyuter o'zi o'rgatadi

### Klaviatura kiritish
75. `js/input/keyboard-auto.js` — Klaviatura yozish tuyg'usi va avtomatik klaviatura
77. `js/input/keyboard-refocus.js` — Brauzer oynasidan qaytganda klaviatura

### Oshxona
78. `js/kitchen/kitchen-helpers.js` — Oshxona: silindr yordamchisi va asosiy qiymatlar
79. `js/kitchen/counter-sink.js` — Ish stoli oshxona: tokcha, kran
80. `js/kitchen/stove.js` — Gaz plita
81. `js/kitchen/cabinets-hood.js` — Dimohod va shkaflar
82. `js/kitchen/pantry.js` — Ziravorlar va masalliqlar
83. `js/kitchen/dining.js` — Idish-tovoq, meva, ovqatlanish stoli, ushlangan narsa
84. `js/kitchen/osh-model.js` — mkOsh() modeli (likopchalar yaratilishidan oldin e'lon qilinishi kerak)
85. `js/kitchen/plate.js` — Likopcha
86. `js/kitchen/bowl.js` — Sho'rva kosasi
87. `js/kitchen/cookware.js` — Taxta, pichoq, suvli kosa, guruch
88. `js/kitchen/osh.js` — Osh: likopcha, retsept, qozon bo'laklari
89. `js/kitchen/eating.js` — Sirt tanlash va ovqat yeyish
90. `js/kitchen/kitchen-target.js` — Oshxona nishon funksiyasi
91. `js/kitchen/kitchen-update.js` — Oshxona yangilanishi

### Effektlar
92. `js/effects/smoke.js` — Tutun va hid

### Asosiy sikl
93. `js/main/loop.js` — Asosiy o'yin sikli

### CSS
8 ta fayl: base → hud → start-screen → mobile-controls → responsive → overlays → notebook → overrides (kaskad tartibi asl bilan bir xil).

## So'nggi tuzatishlar
- `js/core/monitor-layout.js` (yangi): ikki monitor stol markazida simmetrik turadi (1-monitor chapda, 2-monitor o'ngda, ichkariga biroz burilgan). Karnaylar, chiroq, kitoblar chetga surildi; to'qnashuv qutilari shu joylashuvdan hisoblanadi.
- `js/kali/screen-input.js`: sichqoncha monitor ramkasi/oralig'iga tushsa ham kursor yaqin ekran chetiga qisiladi — monitorlar orasida uzluksiz o'tadi.
- `js/kali/displays.js`: 2-ekran ishlaganda ikkala monitor birdan ko'rinadi; F2 — yaqinlashtirish.
- SSD/HDD: har biriga 2 ta kabel — blok pitaniyadan quvvat kabeli va anakartdan ma'lumot (SATA data) kabeli (`psu-cables.js`, `motherboard.js`, `storage.js`).

## Yangi bosh menyu (Hacker House Simulator)
- `index.html`: eski "KIRISH" ekrani o'rniga yangi menyu (`#start`). `#enter` id si saqlangan — o'yinni boshlash `js/player/touch-controls.js` dagi eski ishlovchi orqali ishlaydi (o'yin kodiga tegilmagan).
- `css/start-screen.css`: menyu uslublari (barcha klasslar `hh-` bilan boshlanadi, o'yin CSS'i bilan to'qnashmaydi).
- `js/ui/main-menu.js` (yangi): Sozlamalar (grafika sifati AVTO/YUQORI/PAST — `setQ()` orqali, localStorage'da saqlanadi; to'liq ekran), Yo'riqnoma, Chiqish (oyna yopilmasa xayrlashuv ekrani).
- `img/intro.png`: menyu foni.
- Menyu tugmalari: BOSHLASH · SOZLAMALAR · YO'RIQNOMA · CHIQISH.


---
## 🆕 Iqtisod, qurilish, do'kon va joylashtirish tizimi (js/game/)

**O'yin oqimi:** bo'sh uy (karavot + oshxona) → eshikdan **Qurilish zonasi**ga chiqish → pul ishlash → **Do'kon**da xarid → uyga qaytib buyumlarni **joylashtirish** → montaj stolida **kompyuter yig'ish** → stol ostiga o'rnatish → asl Kali/hacker o'yini.

| Fayl | Vazifasi |
|---|---|
| `game/marks.js` | modullar orasidagi obyektlarni belgilash (index.html dagi `GM.mark`) |
| `game/core.js` | holat (pul, inventar, joylashtirilganlar, qurilish), sozlamalar, saqlash (`localStorage hs_eco_v1`) |
| `game/catalog.js` | 20 mahsulot: nomi, narxi, past poligonli 3D model, 3D ko'rinish rasmi |
| `game/regions.js` | UY / QURILISH / DO'KON hududlari, fade teleport, to'qnashuv ro'yxatini almashtirish, xavfsiz paydo bo'lish |
| `game/build-zone.js` | 5 ta ish: g'isht tashish, sement tashish, g'isht terish, devor ko'tarish, material yetkazish |
| `game/shop.js` | 3D do'kon zali + do'kon oynasi (pul yetmasa xarid bloklanadi) |
| `game/placement.js` | inventar, joylashtirish (ghost, aylantirish, collision, sirtlar), ko'chirish/olib tashlash, stulga o'tirish |
| `game/rig.js` | asl ish stansiyasi va montaj stolini yangi oqimga ulash, bench holatini saqlash |
| `game/ui.js`, `game/main.js`, `css/economy.css` | interfeys, o'ramlar (wrapper), klaviatura, tiklash |

**Boshqaruv:** `E` — o'zaro ta'sir · `I` — inventar · joylashtirishda `R`/`Q` aylantirish, `Enter` tasdiq, `Esc` bekor · `G` yoki ✎ — joylashtirilgan buyum menyusi (ko'chirish / inventarga olish / o'tirish).

**Sozlanadigan qiymatlar:** Inventar → *Sozlamalar* (ish haqlari va do'kon narxlari koeffitsiyenti). Standart: g'isht 15$, sement 25$, terish 40$ (qator), devor 60$, yetkazish 30$.

**Muhim qoidalar:**
- *Kompyuter stoli* istalgan joyga qo'yiladi (ustiga buyum qo'yish mumkin). Rozetka va kabellar o'tkazilgan yashil belgili **ish stansiyasi joyi**ga yaqinlashtirilsa, avtomatik o'rnatiladi va 2 monitor, klaviatura, sichqoncha, kabellar, server rack paydo bo'ladi.
- *Montaj stoli* — istalgan joyga; qismlar shu yerda asl 3D mexanika bilan yig'iladi. *PC Case* ichida blok pitaniya, 2 ventilyator va yon qopqoq bor; *RAM* 2 dona kerak; termopasta surtilmasa korpusni o'rnatib bo'lmaydi.
- *Gaming stul / Oddiy stul* — istalgan joyda; stol oldiga (qarab) qo'yilsa o'tirganda ish stansiyasi (Kali) ochiladi.
- *Headphones* — stol o'rnatilgach stol ustiga o'zi qo'yiladi.
- Hujum (security) tizimi kompyuter o'rnatilgandan keyingina ishga tushadi.
- Saqlanadi: pul, inventar, joylashtirilgan buyumlar, qurilish (devor, ombor), montaj stoli va yig'ilgan kompyuter holati.

## Yangilanish: eman stollar, qurilish zonasi buyumlari
- `js/world/wood.js` — eman (oak) tekstura/materiallari: kompyuter stoli (chap tortma bilan), ovqatlanish stoli (tortmasiz), montaj stoli.
- `js/world/build-props.js` — 10 ta tik sement qopi, 200 ta g'isht uyumi (gisht.html dizayni, devor g'ishtlari ham shu material), daraxt fabrikasi.
- `js/world/tree-data.js` — stylized-tree.zip (oak 01.fbx) dan avtomatik soddalashtirilgan geometriya (~182k → ~39k uchburchak, FBXLoader kerak emas).

## Yangilanish: bo'sh stol + sotib olinadigan jihozlar
- Kompyuter stoli istalgan joyga qo'yiladi va **bo'sh** bo'ladi. Do'kondan (Aksessuar): Monitor, Klaviatura (simsiz), Quvvat kabeli (10 m).
- Monitor/klaviatura faqat stol ustiga qo'yiladi. Monitorga qarab **E → «Kabel ulash»**: kabel eng yaqin **bo'sh** rozetkaga ulanadi (bitta rozetkaga bitta kabel; band rozetka LED i qizil).
- Xonaga 12 ta yangi devor rozetkasi qo'shilgan (`js/game/desk-gear.js`). Eski ish stansiyasi (yashil belgi) mexanikasi o'zgarmagan.

## Yangilanish: qurilish zonasida o't
- `js/world/grass.js` — ~10 sm tabiiy o't: shamolda silliq chayqaladi, o'yinchi bosib yurganda egiladi va ~2 s da qaytadi; bino, pallet, plita, iskala, xandaq, darvozada o'smaydi. Masofaga qarab 2 daraja detal (zaif qurilmalarda siyrakroq).

## Yangilanish: yangi yer (realistic_first_person_construction_site.html asosida)
- `js/world/terrain.js` — tuproq (clay) teksturali yer, yumshoq relyef (0–4.5 sm), g'ildirak izlari, balchiqlar, realistik toshlar (825 dona: yirik/o'rta/shag'al, qisman ko'milgan, yirik toshlar to'qnashuvli).
- Relyef bino, pallet, plita, iskala, xandaq, darvoza, daraxt, balchiq va vazifa halqalari atrofida 0 ga tushadi — modellar havoda qolmaydi. O't faqat chetlarda zich, o'rtada siyrak.

## Yangilanish: qum bilan ishlash (preview.html asosida)
- `js/world/sand-work.js` — qum uyumi (qiyalik burchagi ~34° bilan o'z-o'zidan to'kiladi, asta to'ldiriladi), belkurak, fizik zarralar bilan qopga to'kish, qop to'lganda qo'lda ko'tarish.
- Oqim: belkurakni oling (E) → qum uyumiga qarab E (qum olish) → qopga qarab E (to'kish) → qop 100% bo'lgach E (ko'tarish) → buyurtma halqasiga olib boring (E). Eski "qum qopini olish" o'rniga.

## Yangilanish: Laptop (do'kon, 150$)
- `js/world/laptop-data.js` + `laptop-model.js` — laptop_alienpredator.glb dan: butun geometriya (45 ming uchburchak), qopqoq ochiladi/yopiladi, PBR materiallar, metall uchun yorug'lik muhiti. Teksturalar 1024/512 ga moslangan.
- `js/game/laptop.js` — ishlash rejimi (kamera ekran oldiga o'tadi), ekran PC monitori bilan bir xil, qo'lda ko'tarish.
- Do'kondan sotib oling → kompyuter stoliga qo'ying → alohida «Quvvat kabeli» sotib oling → laptopga qarab ✎ yoki E → «Kabel ulash» (eng yaqin bo'sh rozetka) → E: «Laptopda ishlash».

## Yangilanish: Gaming stul (kompyuter stuli)
- `js/world/chair-data.js` + `chair-model.js` — red_gaming_chair_highquality.glb (kanesk06, CC-BY-4.0): 185 ming → 40 ming uchburchak (kvadrik soddalashtirish, UV/normal saqlangan), PBR charm teksturasi (rang + AO + g'adir-budurlik + normal).
- Do'kon → Mebel → «Gaming stul (qizil)» (90$). Kompyuter stoli oldiga qo'ying, E bilan o'tiring (monitor/laptop bilan ishlaydi).
- Model muallifi: kanesk06 (Sketchfab), litsenziya CC-BY-4.0.

## Yangilanish: bo'sh stol + qo'lda joylashtirish
- Kompyuter stoli istalgan joyga qo'yiladi va **bo'm-bo'sh** turadi (avtomatik monitor/klaviatura/kabel/server paydo bo'lmaydi; yashil "ish stansiyasi" belgisi olib tashlandi).
- Monitor, klaviatura, naushnik, korpus — do'kondan olinib, inventardan istalgan joyga (stol ustiga yoki polga) qo'lda joylashtiriladi.
- Quvvat kabeli: monitorga qarab E → «Kabel ulash» → ulamoqchi bo'lgan rozetkaga qarang (kabel yo'li chiziq bilan ko'rinadi) → E / ✔. Esc / ✖ — bekor. «Boshqa rozetkaga ko'chirish» ham bor.
- Eski saqlashlar: avtomatik ish stansiyasi o'chiriladi, naushnik inventarga qaytadi, stol ostiga qo'yilgan yig'ilgan korpus montaj stoliga qaytadi.
- **Kompyuter ish joyi (qo'lda):** montaj stolida yig'ilgan korpus (E — «inventarga olish») inventarda «Yig'ilgan kompyuter» bo'ladi → polga, stol ostiga yoki stol ustiga qo'yiladi.
  - Kompyuter: ✎ menyu → 🔌 Kabel ulash (rozetkani o'zingiz tanlaysiz) → korpusga qarab E — power.
  - Monitor: quvvat kabeli (rozetkaga) + **video kabel** (do'konda 15$): monitorga qarab ✎ → «Kompyuterga video ulash» → kompyuter korpusiga qarab E. Bitta kompyuterga **4 tagacha** monitor.
  - Klaviatura (USB, kabeli o'zida): ✎ → «Kompyuterga ulash» → korpusga qarab E.
  - Hammasi ulangach monitor/klaviaturaga qarab E → «Kompyuterda ishlash». Kali ish stoli ulangan monitorlarda chapdan o'ngga kengayadi (Settings > Displays yoki `xrandr`), Esc — turish.
  - Vilka uzilsa kompyuter o'chadi; ko'chirish/olishda kabellar qayta yotqiziladi yoki inventarga qaytadi.
  - Ta'mirlash uchun: korpusga ✎ → «Montaj stoliga olib borish».
- Eski qat'iy ish stansiyasi (asl Kali ekranli 2 monitor va stol ostidagi PC) o'chirilgan — uning o'rnini yuqoridagi qo'lda ulanadigan tizim egalladi.

## Yangilanish: kresloda ishlash, hayotdagidek qarash, yaqinlashtirish, stakan
- `js/game/work-seat.js` (yangi). Kompyuter/laptop oldidagi stulga o'tirsangiz ish rejimi o'zi yoqiladi; laptop va kompyuterda ishlash faqat kresloda o'tirib mumkin. Esc: ish rejimidan kreslogacha, yana Esc: turish.
- Sichqonchani ko'rish zonasi chetiga yoki oynadan tashqariga olib chiqsangiz personaj o'sha tomonga qaraydi.
- Ctrl+F2 (yoki 🔍 tugma, Ctrl+g'ildirak): sichqoncha turgan monitorga yaqinlashtirish.
- Stakan: istalgan stol/yuza yoki stul o'rindig'iga qo'yiladi (ustida stakan bo'lsa buyumni ko'chirib bo'lmaydi).

## Yangilanish: haqiqiy o'lchamdagi monitor (32") va korpus (ATX mid-tower)
- `js/world/pc-models.js` (yangi): Monitor 32" — ekran 0.708 x 0.398 m, jami 0.72 x 0.53 m, ingichka ramka, metall tayanch. Korpus 0.22 x 0.46 x 0.45 m: tarmoqli old panel + RGB ventilyatorlar, tempered glass yon panel, ichida anakart, sovutgich, RAM, videokarta, blok pitaniya, kabellar.
- Port joylari (`catalog.js`: MON_PORT, MON_VPORT, PC_PW, PC_VID, PC_USB) yangi modelga moslandi; `pc-setup.js` da ekran o'lchamlari va RGB yorug'lik yangilandi.

## Yangilanish: klaviatura (UGREEN K371) va kattaroq monitor
- `js/world/keyboard-data.js` + `keyboard-model.js` — Keyboard UGREEN K371 (ILya Gamzayev, CC-BY-4.0, Sketchfab). Model O'ZGARTIRILMAGAN: geometriya, UV, teksturalar asl holida; faqat bir tekis masshtab `KB_K=1.2` (asl 29×10 sm → 35×12 sm).
- Monitor: `MON_K=1.2` — butun model bir tekis kattalashtirildi (ekran 0.85×0.48 m, ≈38"). Port, kabel yo'li, kamera, kompyuter stoli yuzasi (4 monitor sig'adi) moslandi.
- Model muallifi: ILya Gamzayev (https://sketchfab.com/ilyagum), litsenziya CC-BY-4.0.

## Yangilanish: kabellar, javon, silliq qarash, caret, vaqt, yorug'lik, tortma
- Kabellar ingichkalashtirildi (CR=.0055; video .8x, USB .6x), vilkalar kichraytirildi. Klaviatura USB-C porti modeldagi haqiqiy joyga (orqa chap) qo'yildi.
- Kompyuter korpusi stol ostidagi kulrang javonga qarab qo'yilsa o'zi moslashadi (markaz + stol yo'nalishi). Kabellar ulangan holda ko'chirish mumkin (avtomatik qayta yotadi); javondagi korpus kabellari javon orqasidan o'tadi.
- Ish rejimi: ko'rsatkich xaritasi doimiy ishchi kameradan olinadi (monitorlar orasida to'xtab qolmaydi); ko'rinadigan kamera sichqoncha turgan monitorga silliq (spring) burilib, uni kattaroq ko'rsatadi va biroz oldinga suriladi (kreslo ko'rinmaydi). Ctrl+F2 — yaqinlashtirish.
- Terminal/muharrirdagi caret ingichka (2 px), kiritilgan matnning haqiqiy joyiga yopishadi, chap/o'ng/Home/End/Delete ishlaydi.
- O'yin kuni soati kompyuterdan mustaqil yuradi (SEC.t0 start); hujum simulyatsiyasi kompyuter yoqilganda ishlaydi.
- Devorlar sut rangida, xona biroz qoraroq, shiftda 3 ta iliq panel nuri; yoqilgan monitor/laptop oldida yumshoq ekran yorug'ligi (js/world/monitor-glow.js).
- Tortma: js/game/desk-drawer.js — istalgan joydagi stol tortmasiga qarab E: silliq ochiladi/yopiladi.

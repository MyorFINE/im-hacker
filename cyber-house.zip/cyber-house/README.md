# CYBER HOUSE — modulli tuzilma

Asl `main-19-fixed-6.html` (bitta fayl) funksionallik va kodga tegmasdan modullarga ajratildi.

## Ishga tushirish
- `index.html` ni brauzerda oching (qo'shimcha server yoki build shart emas).
- Faqat `three.js r128` CDN'dan yuklanadi (internet kerak). Oflayn ishlatish uchun `three.min.js` ni yuklab olib, `index.html` dagi CDN havolasini lokal yo'lga almashtiring.

## Papka tuzilmasi
```
index.html        — faqat markup + CSS/JS ulanishlari
css/              — 8 ta stil fayli (tartib bo'yicha ulangan)
js/<guruh>/       — 94 ta modul (har biri bitta mas'uliyat)
```

## Muhim qoida: yuklanish tartibi
Modullar oddiy (classic) `<script>` sifatida ulangan va **bitta umumiy global scope** ni bo'lishadi — asl koddagi kabi.
Shuning uchun `index.html` ichidagi `<script>` **tartibini o'zgartirmang**: keyingi modullar oldingilarida e'lon qilingan o'zgaruvchilarga tayanadi.

Yangi modul qo'shish: faylni `js/` ichida yarating va `index.html` da tegishli joyga `<script src="...">` qo'shing.

## Eslatma (hoisting)
Asl faylda funksiya e'lonlari butun skript bo'ylab ko'rinardi. Bo'lingach, yuklanish paytida erta chaqiriladigan 3 funksiya
(`lab`, `wrapT` → `js/core/text-utils.js`, `mkOsh` → `js/kitchen/osh-model.js`) oldinroq yuklanadigan modullarga ko'chirildi. Kodning o'zi o'zgarmagan.

## Modullar (yuklanish tartibida)

### Yadro
1. `js/core/globals.js` — Global o'zgaruvchilar: THREE, $ yordamchisi, mobil aniqlash, o'lchamlar
2. `js/core/renderer.js` — Sahna, kamera, renderer va sifat (AVTO/YUQORI/PAST) rejimlari
3. `js/core/helpers.js` — Material, canvas, tekstura va box() yordamchi funksiyalari
4. `js/core/text-utils.js` — Matn yordamchilari: lab() yorliq teksturasi va wrapT() matn o'rash (erta chaqirilgani uchun shu yerda e'lon qilingan)

### 3D dunyo (xona, jihozlar)
5. `js/world/textures.js` — Pol, devor teksturalari va plakat
6. `js/world/lights.js` — Yoritgichlar (lampa, nuqtaviy yorug'lik)
7. `js/world/room.js` — Xona: devorlar, pol, shift, eshik, oyna
8. `js/world/server-rack.js` — Server rack
9. `js/world/oak-desk.js` — Eman stol quruvchisi (preview.html dagi stol): yog'och teksturasi, rbox(), buildOakDesk()
   `js/world/desk-chair.js` — Kompyuter stoli (eman) va stul
10. `js/world/monitor-base.js` — Monitor: asosiy korpus va ekran teksturasi
11. `js/world/part-registry.js` — Qismlarni nomi bilan topish (part, partAt), fan geometriyasi
12. `js/world/monitor-details.js` — Monitor detallari: bezel, panel, stand, HDMI/DP, ventilyatsiya
13. `js/world/keyboard-mouse.js` — Klaviatura va sichqoncha modellari
14. `js/world/desk-props.js` — Stol ustidagi buyumlar: lampa, krujka, daftar
15. `js/world/computer-tower.js` — Kompyuter korpusi (tower) modeli
16. `js/world/sockets.js` — Rozetka va kabel boshlang'ich nuqtalari

### Kabellar
17. `js/cables/cable-routes.js` — Kabel yo'llari (aylana yoylar, stol qirrasidan oshib o'tish)
18. `js/cables/collision-boxes.js` — Kabel va buyumlar uchun to'qnashuv qutilari
19. `js/cables/cable-simulation.js` — Kabel simulyatsiyasi (cableInit, cable)

### Portlar va nishonga olish
20. `js/interaction/ports-aim.js` — Portlar ro'yxati va nigoh nuri (aim)
21. `js/interaction/port-picking.js` — Port tanlash va yonib-o'chish effekti

### Kali Linux ekrani (XFCE, terminal, fayllar)
22. `js/kali/window-manager.js` — Kali ekran holati, oynalar, ilovalarni ochish/yopish
23. `js/kali/settings-state.js` — Foydalanuvchi, sozlamalar va menyu holatlari
24. `js/kali/wallpapers.js` — Fon rasmlari va beep ovozi
25. `js/kali/filesystem.js` — Fayl tizimi (ruxsatlar, saqlash, yuklash)
26. `js/kali/fs-helpers.js` — Fayl tizimi yordamchilari (format, ikonka, sarlavha)
27. `js/kali/simulation.js` — Jarayonlar, CPU, RAM, tarmoq simulyatsiyasi
28. `js/kali/apps-menu.js` — Applications menyusi va Places
29. `js/kali/context-menu.js` — Kontekst menyu
30. `js/kali/panel.js` — Panel: tarmoq, ovoz, kalendar
31. `js/kali/desktop.js` — Ish stoli: yorliqlar, Sozdat menyusi, dialoglar
32. `js/kali/thunar.js` — Thunar fayl menejeri
33. `js/kali/system-monitor.js` — System Monitor ilovasi
34. `js/kali/settings-app.js` — Settings ilovasi
35. `js/kali/terminal-commands.js` — Terminal: buyruqlar, pipe, grep, ls, run
36. `js/kali/scrolling.js` — Skroll tizimi va terminal/editor chizish
37. `js/kali/attack-monitor.js` — Attack Monitor oynasi
38. `js/kali/screen-render.js` — Ekran render: draw, drawWin, blit
39. `js/kali/python-ide.js` — Python interpretatori va IDE
40. `js/kali/text-input.js` — Matn kiritish, saqlash va login
41. `js/kali/screen-input.js` — Ekran bilan ishlash (bosish, oyna harakatlari)

### O'yinchi va boshqaruv
42. `js/player/player-physics.js` — O'yinchi harakati, to'qnashuv va kamera
43. `js/player/interaction.js` — O'zaro ta'sir: o'tirish, turish, E tugmasi, ko'rsatmalar
44. `js/player/touch-controls.js` — Mobil joystick va qarash boshqaruvi

### Grafika
45. `js/graphics/graphics-plus.js` — Qo'shimcha grafika
46. `js/graphics/pc-case.js` — Kompyuter korpusi: ichki qismlar

### Xavfsizlik (hujum/himoya)
47. `js/security/security-state.js` — Xavfsizlik: holat va doimiylar
48. `js/security/alerts-logging.js` — Sirena, ogohlantirish, loglar
49. `js/security/attacks.js` — Hujumlar: yaratish, buzib kirish, hujum sikli
50. `js/security/defense.js` — Himoya: trace, patch va qarshi hujum
51. `js/security/ids-ui.js` — IDS oynasi interfeysi

### Hayot tizimi (suv, uyqu)
52. `js/life/life-state.js` — Hayot tizimi holati: karavot, uyqu
71. `js/life/life-actions.js` — Stakan, ichish, uyqu, vitals va lifeTick
74. `js/life/desk-cup.js` — Stakanni stolga qo'yish va olish

### Kompyuter ta'mirlash stoli
53. `js/repair/bench-helpers.js` — Ta'mirlash stoli: yordamchi funksiyalar
54. `js/repair/bench-table.js` — Ta'mirlash stoli modeli
55. `js/repair/bench-tools.js` — Otvyorkalar, pasta, idishlar
56. `js/repair/case-shell.js` — Yonboshlab yotgan korpus va qism ro'yxatga olish
57. `js/repair/motherboard.js` — Anakart
58. `js/repair/cpu-cooler.js` — Protsessor va kuller
59. `js/repair/ram.js` — RAM modullari
60. `js/repair/gpu.js` — Video karta
61. `js/repair/psu-cables.js` — Blok pitaniya va kabellar
62. `js/repair/fans.js` — Fanlar
63. `js/repair/side-panel-bolts.js` — Yon qopqoq (shisha) va boltlar
64. `js/repair/bench-sync.js` — Holatni ko'rinishga yozish
65. `js/repair/bench-raycast.js` — Nur bo'yicha tanlash
66. `js/repair/bench-actions.js` — Harakatlar: olish, qo'yish, o'rnatish
67. `js/repair/main-pc-link.js` — Asosiy kompyuter bilan bog'lanish
68. `js/repair/part-operations.js` — Burash, kabel, tutqich, qism olish/qo'yish qoidalari
69. `js/repair/bench-target.js` — Asosiy nishon funksiyasi (benchTarget)
70. `js/repair/bench-update.js` — Ta'mirlash stoli yangilanishi

### O'rgatuvchi qism
72. `js/education/lessons-data.js` — O'rgatuvchi auditlar (LESSONS)
73. `js/education/notebook-ui.js` — Blaknot interfeysi
76. `js/education/mentor-coach.js` — Mentor: kompyuter o'zi o'rgatadi

### Klaviatura kiritish
75. `js/input/keyboard-auto.js` — Klaviatura yozish tuyg'usi va avtomatik klaviatura
77. `js/input/keyboard-refocus.js` — Brauzer oynasidan qaytganda klaviatura

### Oshxona
78. `js/kitchen/kitchen-helpers.js` — Oshxona: silindr yordamchisi va asosiy qiymatlar
79. `js/kitchen/counter-sink.js` — Ish stoli oshxona: tokcha, kran
80. `js/kitchen/stove.js` — Gaz plita
81. `js/kitchen/cabinets-hood.js` — Dimohod va shkaflar
82. `js/kitchen/pantry.js` — Ziravorlar va masalliqlar
83. `js/kitchen/dining.js` — Idish-tovoq, meva, ovqatlanish stoli, ushlangan narsa
84. `js/kitchen/osh-model.js` — mkOsh() modeli (likopchalar yaratilishidan oldin e'lon qilinishi kerak)
85. `js/kitchen/plate.js` — Likopcha
86. `js/kitchen/bowl.js` — Sho'rva kosasi
87. `js/kitchen/cookware.js` — Taxta, pichoq, suvli kosa, guruch
88. `js/kitchen/osh.js` — Osh: likopcha, retsept, qozon bo'laklari
89. `js/kitchen/eating.js` — Sirt tanlash va ovqat yeyish
90. `js/kitchen/kitchen-target.js` — Oshxona nishon funksiyasi
91. `js/kitchen/kitchen-update.js` — Oshxona yangilanishi

### Effektlar
92. `js/effects/smoke.js` — Tutun va hid

### Asosiy sikl
93. `js/main/loop.js` — Asosiy o'yin sikli

### CSS
8 ta fayl: base → hud → start-screen → mobile-controls → responsive → overlays → notebook → overrides (kaskad tartibi asl bilan bir xil).

## So'nggi tuzatishlar
- `js/core/monitor-layout.js` (yangi): ikki monitor stol markazida simmetrik turadi (1-monitor chapda, 2-monitor o'ngda, ichkariga biroz burilgan). Karnaylar, chiroq, kitoblar chetga surildi; to'qnashuv qutilari shu joylashuvdan hisoblanadi.
- `js/kali/screen-input.js`: sichqoncha monitor ramkasi/oralig'iga tushsa ham kursor yaqin ekran chetiga qisiladi — monitorlar orasida uzluksiz o'tadi.
- `js/kali/displays.js`: 2-ekran ishlaganda ikkala monitor birdan ko'rinadi; F2 — yaqinlashtirish.
- SSD/HDD: har biriga 2 ta kabel — blok pitaniyadan quvvat kabeli va anakartdan ma'lumot (SATA data) kabeli (`psu-cables.js`, `motherboard.js`, `storage.js`).

## Yangi bosh menyu (Hacker House Simulator)
- `index.html`: eski "KIRISH" ekrani o'rniga yangi menyu (`#start`). `#enter` id si saqlangan — o'yinni boshlash `js/player/touch-controls.js` dagi eski ishlovchi orqali ishlaydi (o'yin kodiga tegilmagan).
- `css/start-screen.css`: menyu uslublari (barcha klasslar `hh-` bilan boshlanadi, o'yin CSS'i bilan to'qnashmaydi).
- `js/ui/main-menu.js` (yangi): Sozlamalar (grafika sifati AVTO/YUQORI/PAST — `setQ()` orqali, localStorage'da saqlanadi; to'liq ekran), Yo'riqnoma, Chiqish (oyna yopilmasa xayrlashuv ekrani).
- `img/intro.png`: menyu foni.
- Menyu tugmalari: BOSHLASH · SOZLAMALAR · YO'RIQNOMA · CHIQISH.

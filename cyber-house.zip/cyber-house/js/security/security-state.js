/* ==========================================================
 * Modul: js/security/security-state.js
 * Xavfsizlik: holat va doimiylar
 * ========================================================== */
/* ---------- xavfsizlik: botlar, himoya, qarshi hujum ---------- */
const SEC={blocked:[],strong:false,patched:false,deny80:false,svc:{ssh:true,apache2:true,mysql:true},pw:"kali",snap:null,lastBackup:0,score:300,vault:0,vaultT:0,loot:{},c2cash:{},cwin:{},wasAct:{},t0:0,k:0,off:{d:-1,n:0},breaches:0,blocks:0,list:[],hist:{},traced:{},cracked:{},c2dead:{},recon:{},tracing:{},nextAt:0,alarm:0,srvAlert:false,n:0,encrypted:false};
const C2S=[{ip:"203.0.113.77",name:"mirai-x C2",pool:"198.51.100."},{ip:"203.0.113.99",name:"darkwave C2",pool:"192.0.2."}];
const TG={pc:{n:"kali (PC)",ip:()=>SET.ip},web:{n:"web-srv",ip:()=>"192.168.1.20"},db:{n:"db-srv",ip:()=>"192.168.1.21"}};
const ATYP={scan:{n:"Port skanerlash",sev:1,rate:100/60,tg:["pc","web","db"]},ssh:{n:"SSH brute-force",sev:2,rate:100/60,tg:["pc","web","db"]},web:{n:"Web zaiflik (CVE)",sev:3,rate:100/60,tg:["web"]},ransom:{n:"Ransomware",sev:3,rate:100/60,tg:["pc"]}};

/* ---------- o'yin vaqti: 1 o'yin kuni = 1 real soat ---------- */
const DAY_MS=3600000,ATK_PER_DAY=5,ATK_SLOT=DAY_MS/ATK_PER_DAY,OFF_MAX=4,OFF_BONUS=20;
/* kuniga ATK_PER_DAY ta hujum: kun teng bo'laklarga bo'linadi, har bo'lakda bitta hujum tasodifiy vaqtda */
function schedAtk(now){const t=(SEC.t0||now)+(SEC.k||0)*ATK_SLOT+Math.random()*ATK_SLOT;SEC.k=(SEC.k||0)+1;return Math.max(t,now+60000)}
function gameDayNo(){return Math.floor((Date.now()-(SEC.t0||Date.now()))/DAY_MS)}
/* o'yinchining boshqa IP larga hujumi: kuniga OFF_MAX marta (hujumchi faol bo'lmasa ham mumkin) */
function offLeft(){const d=gameDayNo();if(SEC.off.d!==d){SEC.off.d=d;SEC.off.n=0}return OFF_MAX-SEC.off.n}
function offCheck(){if(offLeft()<=0){const m=Math.ceil((DAY_MS-(Date.now()-(SEC.t0||Date.now()))%DAY_MS)/60000);throw new Error("Bugungi hujum limiti tugadi ("+OFF_MAX+"/"+OFF_MAX+"). Yangi kun ~"+m+" daqiqadan keyin")}}
function offUse(){offLeft();SEC.off.n++}

/* jonli hujum bonusi: hujum davomida (yoki himoya qilingan zahoti, 60 s ichida) aniqlab qarshi hujum qilinsa +30 */
const LIVE_BONUS=30,LIVE_WIN=60000;
function liveBonus(host){const a=SEC.list.find(x=>x.c2===host);if(!a||a.livePaid||!SEC.traced[host])return 0;
 const ok=a.state==="active"||(["blocked","failed","stopped"].includes(a.state)&&Date.now()-(a.endT||0)<=LIVE_WIN);
 if(!ok)return 0;a.livePaid=true;SEC.score+=LIVE_BONUS;logLine("/var/log/ids.log","[IDS] LIVE COUNTER +"+LIVE_BONUS+" -> "+host);return LIVE_BONUS}

/* ==========================================================
 * Modul: js/security/security-state.js
 * Xavfsizlik: holat va doimiylar
 * ========================================================== */
/* ---------- xavfsizlik: botlar, himoya, qarshi hujum ---------- */
const SEC={blocked:[],strong:false,patched:false,deny80:false,svc:{ssh:true,apache2:true,mysql:true},pw:"kali",snap:null,lastBackup:0,score:300,vault:0,vaultT:0,loot:{},c2cash:{},cwin:{},wasAct:{},breaches:0,blocks:0,list:[],hist:{},traced:{},cracked:{},c2dead:{},recon:{},tracing:{},nextAt:0,alarm:0,srvAlert:false,n:0,encrypted:false};
const C2S=[{ip:"203.0.113.77",name:"mirai-x C2",pool:"198.51.100."},{ip:"203.0.113.99",name:"darkwave C2",pool:"192.0.2."}];
const TG={pc:{n:"kali (PC)",ip:()=>SET.ip},web:{n:"web-srv",ip:()=>"192.168.1.20"},db:{n:"db-srv",ip:()=>"192.168.1.21"}};
const ATYP={scan:{n:"Port skanerlash",sev:1,rate:100/60,tg:["pc","web","db"]},ssh:{n:"SSH brute-force",sev:2,rate:100/60,tg:["pc","web","db"]},web:{n:"Web zaiflik (CVE)",sev:3,rate:100/60,tg:["web"]},ransom:{n:"Ransomware",sev:3,rate:100/60,tg:["pc"]}};

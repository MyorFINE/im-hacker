/* ==========================================================
 * Modul: js/security/attacks.js
 * Hujumlar: yaratish, buzib kirish, hujum sikli
 * ========================================================== */
function encryptDocs(ip){const d=nd(HOME+"/Documents");let n=0;Object.keys(d.k).forEach(k=>{const f=d.k[k];if(f.t==="f"){f.c="[ENCRYPTED by "+ip+"]\nFayllaringiz shifrlandi (o'yin ichidagi simulyatsiya). 'restore' bilan zaxiradan tiklang.\n";n++}});d.k["README_DECRYPT.txt"]={t:"f",o:USER,m:"644",mt:Date.now(),c:"Fayllaringiz shifrlandi. Zaxira bo'lmasa — yo'qotildi.\n"};SEC.encrypted=true;fsSave();return n}
function spawnAtk(){if(SEC.list.filter(a=>a.state==="active").length>=2)return;const now=Date.now(),alive=C2S.filter(c=>(SEC.c2dead[c.ip]||0)<=now);if(!alive.length)return;const c2=alive[Math.random()*alive.length|0],ip=c2.pool+(2+(Math.random()*250|0));
 const ts=["scan","ssh","web"];if(SEC.n>=3)ts.push("ransom");let ty=ts[Math.random()*ts.length|0],tg=ATYP[ty].tg.filter(t=>t!=="pc"||(S.on&&S.plug));if(!tg.length){ty="ssh";tg=["web","db"]}
 const a={id:++SEC.n,ip,c2:c2.ip,ty,tg:tg[Math.random()*tg.length|0],prog:0,state:"active",t0:now,bp:Math.random()};SEC.list.unshift(a);if(SEC.list.length>40)SEC.list.pop();SEC.hist[ip]=c2.ip;logAtk(a,"start");notify(a);atkShow(a)}
const bypass=a=>a.bp<Math.min(.8,.35+SEC.n*.04);
function defReason(a){const ty=a.ty;
 if(ty==="scan")return SET.fw&&!bypass(a)?["blocked","ufw rad etdi"]:null;
 if(ty==="ssh"){if(!SEC.svc.ssh)return["failed","SSH o'chiq"];return SET.fw&&!bypass(a)?["blocked","ufw rad etdi"]:null}
 if(ty==="web"){if(!SEC.svc.apache2)return["failed","apache2 o'chiq"];if(SEC.deny80)return["blocked","80-port yopiq"];return SEC.patched&&!bypass(a)?["failed","zaiflik yamalgan"]:null}
 if(ty==="ransom")return SEC.patched&&!bypass(a)?["failed","yamalgan"]:null;return null}
function breach(a){const ty=ATYP[a.ty];
 if(a.ty==="scan"){a.state="done";a.why="razvedka tugadi";SEC.recon[a.tg]=true;logAtk(a,"recon-done");void("👁 "+TG[a.tg].n+" portlari ko'rindi — keyingi hujum tezroq bo'ladi");return}
 SEC.breaches++;{const op=Math.max(0,SEC.score),st=op?Math.min(op,Math.max(25,Math.round(op*(a.tg==="pc"?.35:.2)))):0;SEC.score-=st;a.loot=st;SEC.loot[a.c2]=(SEC.loot[a.c2]||0)+st;if(st)logLine("/var/log/ids.log","[IDS] THEFT "+st+" ball -> "+a.c2)}a.state="breached";logAtk(a,"breached");let m;
 if(a.ty==="ransom"){const n=encryptDocs(a.ip);LF.integ-=25;m="🔒 Ransomware: "+n+" ta hujjat shifrlandi! 'restore' bilan tiklang"}
 else if(a.tg==="pc"){LF.integ-=30;m="⛔ Kompyuteringiz buzildi ("+ty.n+")"}
 else{LF.srv-=35;m="⛔ "+TG[a.tg].n+" buzildi ("+ty.n+")"}
 alertMsg(m);
 if(LF.integ<=0){LF.integ=50;S.on=false;S.stage=0;wins.length=0;focusId=null;alertMsg("💥 Kompyuter butunlay buzildi — majburan o'chdi. Qayta yoqing")}
 if(LF.srv<=0){LF.srv=40;SEC.score-=50;alertMsg("💥 Serverlar ishdan chiqdi!")}dirty=true}
function atkTick(dt){if(!started)return;const now=Date.now();
 if(!SEC.nextAt)SEC.nextAt=now+90000;
 if(now>=SEC.nextAt){spawnAtk();SEC.nextAt=now+75000+Math.random()*60000}
 C2S.forEach(c=>{if(SEC.c2dead[c.ip]&&SEC.c2dead[c.ip]<=now){SEC.c2dead[c.ip]=0;alertMsg("☠ "+c.name+" qayta ishga tushdi!")}});
 let alarm=0,srv=false,act=0;
 SEC.list.forEach(a=>{if(a.state!=="active")return;const ty=ATYP[a.ty];
  if((SEC.c2dead[a.c2]||0)>now){a.state="stopped";logAtk(a,"stopped");return}
  if(SEC.blocked.includes(a.ip)){a.state="blocked";a.why="IP bloklandi";SEC.blocks++;logAtk(a,"blocked");void("🛡 Bloklandi: "+a.ip);return}
  const r=defReason(a);if(r){a.state=r[0];a.why=r[1];logAtk(a,r[0]);void("🛡 "+ty.n+" to'xtatildi ("+r[1]+")");return}
  a.prog+=ty.rate*(a.ty!=="scan"&&SEC.recon[a.tg]?1.2:1)*dt;
  if(a.ty==="ssh"&&SEC.strong&&!bypass(a)&&a.prog>=40){a.state="failed";a.why="kuchli parol";logAtk(a,"failed");void("🛡 Brute-force kuchli parolga urildi");return}
  if(a.prog>=100){a.prog=100;breach(a);return}
  act++;if(ty.sev>=2)alarm++;if(a.tg!=="pc")srv=true});
 C2S.forEach(c=>{SEC.c2cash[c.ip]=Math.min(600,(SEC.c2cash[c.ip]==null?500:SEC.c2cash[c.ip])+dt*1.5);const ac=SEC.list.some(a=>a.c2===c.ip&&a.state==="active");if(ac){SEC.wasAct[c.ip]=1;SEC.cwin[c.ip]=0}else if(SEC.wasAct[c.ip]){SEC.wasAct[c.ip]=0;SEC.cwin[c.ip]=now+30000}else if(SEC.cwin[c.ip]&&now>SEC.cwin[c.ip]){SEC.cwin[c.ip]=0;const lost=SEC.loot[c.ip]||0;SEC.loot[c.ip]=0;delete SEC.traced[c.ip];delete SEC.cracked[c.ip];delete HOSTS[c.ip];logLine("/var/log/ids.log","[IDS] COUNTER WINDOW CLOSED "+c.ip+(lost?" loot lost "+lost:""))}});
 SEC.alarm=0;SEC.srvAlert=LF.srv<65;
 if(!act){LF.integ=Math.min(100,LF.integ+dt*.6);LF.srv=Math.min(100,LF.srv+dt*.6)}}

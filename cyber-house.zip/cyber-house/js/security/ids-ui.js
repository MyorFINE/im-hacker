/* ==========================================================
 * Modul: js/security/ids-ui.js
 * IDS oynasi interfeysi
 * ========================================================== */
function drawIds(w,cx,top){const X=w.x,Y=top,Wd=w.w,Ht=w.h-33,hits=w.hits=[],bw=Wd-32;rr(X+2,Y,Wd-4,Ht,0,"#161b22");
 tx("Security Center · IDS",cx,Y+22,"#ff7b72","bold 14px monospace");tx("Ball "+SEC.score+"  ·  bloklangan "+SEC.blocks+"  ·  buzilgan "+SEC.breaches,cx+230,Y+22,"#8fa3b5","12px monospace");
 const cl=[["VAQT",0],["MANBA IP",66],["TURI",180],["MAQSAD",326],["JARAYON",410],["HOLAT",500]];rr(cx,Y+32,bw,18,0,"#1d2230");cl.forEach(c0=>tx(c0[0],cx+c0[1]+4,Y+45,"#8fa3b5","11px monospace"));
 const rows=SEC.list.slice(0,7);if(!rows.length)tx("Hozircha hujum yo'q — botlar kuzatuvda...",cx+8,Y+74,"#6b7a8a","12px monospace");
 const ST={active:["FAOL","#ff7b72"],blocked:["BLOKLANDI","#3dd8a0"],failed:["YENGILDI","#3dd8a0"],breached:["BUZILDI","#ff4d4d"],done:["RAZVEDKA","#e5c15d"],stopped:["TO'XTADI","#3dd8a0"]};
 rows.forEach((a,i)=>{const y=Y+54+i*24,s=ST[a.state];tx(new Date(a.t0).toTimeString().slice(0,8),cx+4,y+16,"#8fa3b5","11px monospace");tx(a.ip,cx+70,y+16,"#e6edf3","12px monospace");tx(ATYP[a.ty].n,cx+184,y+16,"#c5d3e0","12px monospace");tx(TG[a.tg].n,cx+330,y+16,"#c5d3e0","12px monospace");rr(cx+414,y+6,70,8,3,"#0e1218");rr(cx+414,y+6,Math.max(2,70*a.prog/100),8,3,a.state==="breached"?"#ff4d4d":"#e5c15d");tx(s[0],cx+504,y+16,s[1],"bold 11px monospace");
  if(a.state==="active"){rr(cx+bw-112,y+2,50,20,4,"#7a2b2b");tx("Block",cx+bw-104,y+16,"#fff","11px monospace");hits.push({x:cx+bw-112,y:y+2,w:50,h:20,fn:()=>{if(!SEC.blocked.includes(a.ip))SEC.blocked.push(a.ip);toast("IP bloklandi: "+a.ip)}})}
  if(a.state!=="stopped"){rr(cx+bw-56,y+2,52,20,4,"#2b4a7a");tx("Trace",cx+bw-48,y+16,"#fff","11px monospace");hits.push({x:cx+bw-56,y:y+2,w:52,h:20,fn:()=>uiTry(()=>startTrace(a.ip))})}});
 const y0=Y+226;c.fillStyle="#2a3340";c.fillRect(cx,y0-8,bw,1);tx("HIMOYA",cx,y0+8,"#7fd4ff","bold 12px monospace");
 const sw=(x,y,on,lab,fn)=>{rr(x,y,16,16,3,on?"#2b8a5a":"#2b3347");if(on)tx("✓",x+2,y+13,"#fff","bold 13px monospace");tx(lab,x+24,y+13,"#e6edf3","12px monospace");hits.push({x,y:y-2,w:230,h:20,fn})};
 const bt=(x,y,wd,lab,fn,col)=>{rr(x,y,wd,20,4,col||"#2b3347");tx(lab,x+8,y+14,"#fff","11px monospace");hits.push({x,y,w:wd,h:20,fn})};
 sw(cx,y0+18,SET.fw,"Firewall (ufw)",()=>{SET.fw=!SET.fw;saveSet()});sw(cx,y0+42,SEC.deny80,"80-port yopiq (web)",()=>{SEC.deny80=!SEC.deny80});sw(cx,y0+66,SEC.svc.ssh,"SSH xizmati yoqiq",()=>{SEC.svc.ssh=!SEC.svc.ssh});sw(cx,y0+90,SEC.svc.apache2,"apache2 (web-srv)",()=>{SEC.svc.apache2=!SEC.svc.apache2});
 tx("Parol: "+(SEC.strong?"kuchli ✓":"zaif ✗"),cx+250,y0+30,SEC.strong?"#3dd8a0":"#ff9a5f","12px monospace");bt(cx+400,y0+16,124,"Parol o'zgartirish",()=>uiTry(()=>C.passwd([])));
 tx("Yamoqlar: "+(SEC.patched?"yangi ✓":"eskirgan ✗"),cx+250,y0+54,SEC.patched?"#3dd8a0":"#ff9a5f","12px monospace");bt(cx+400,y0+40,124,"Yangilash (apt)",()=>uiTry(()=>asRoot(()=>C.apt(["upgrade"]))));
 tx("Zaxira: "+(SEC.lastBackup?Math.round((Date.now()-SEC.lastBackup)/1000)+"s oldin":"yo'q"),cx+250,y0+78,SEC.lastBackup?"#3dd8a0":"#ff9a5f","12px monospace");bt(cx+400,y0+64,58,"Zaxira",()=>uiTry(()=>C.backup([])),"#2b6b4a");bt(cx+464,y0+64,60,"Tiklash",()=>uiTry(()=>C.restore([])),"#6b4b2b");
 const cy=y0+118;c.fillStyle="#2a3340";c.fillRect(cx,cy-8,bw,1);tx("QARSHI HUJUM",cx,cy+8,"#ffb84a","bold 12px monospace");const tr=C2S.filter(c2=>SEC.traced[c2.ip]);
 if(!tr.length)tx("Hujumchini aniqlash: qatordagi 'Trace' ni bosing (~8s). So'ng terminalda: nmap → hydra → ssh.",cx,cy+26,"#8fa3b5","11px monospace");
 tr.forEach((c2,i)=>{const dead=(SEC.c2dead[c2.ip]||0)>Date.now();tx("🎯 "+c2.name+" "+c2.ip+" — "+(dead?"YO'Q QILINDI":SEC.cracked[c2.ip]?'parol topildi → ssh admin@'+c2.ip+' "pkill botnetd"':"nmap "+c2.ip+" → hydra -l admin -P ~/Wordlists/common.txt ssh://"+c2.ip),cx,cy+26+i*16,dead?"#3dd8a0":"#e5c15d","11px monospace")});}

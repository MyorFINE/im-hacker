/* ==========================================================
 * Modul: js/kitchen/bowl.js
 * Sho'rva kosasi
 * ========================================================== */
/* ---- kosa (sho'rva kosasi): qozondan solish, yeyish, stolga / muzlatkichga qo'yish ---- */
Object.assign(KN,{kosa:"kosani",kosaf:"kosani"});
const kbm=L(0xeeeae0,{side:T.DoubleSide}),kbPts=[[0,0],[.034,0],[.05,.012],[.068,.046],[.078,.066],[.073,.068]].map(a=>new T.Vector2(a[0],a[1])),kbG=new T.LatheGeometry(kbPts,18);
function mkKosa(food){const g=new T.Group(),b=new T.Mesh(kbG,kbm),r=new T.Mesh(new T.TorusGeometry(.0755,.004,6,18),kpr);r.rotation.x=Math.PI/2;r.position.y=.066;g.add(b,r);
 const f=new T.Mesh(new T.CircleGeometry(.064,18),new T.MeshLambertMaterial({color:0xb5651d}));f.rotation.x=-Math.PI/2;f.position.y=.051;f.visible=!!food;g.add(f);g.userData.f=f;return g}
const kfill=(g,p)=>{const f=g.userData.f;f.visible=p>0;f.position.y=.03+.007*p;f.scale.setScalar(.55+.15*p)};
const hk=mkKosa(false),hf=mkKosa(true);hk.name="kosa";hf.name="kosaf";KH.add(hk,hf);
KP.kosa=new V(-6.1,1.0,-13.45);const KSK=[0,1,2,3].map(i=>{const m=new T.Mesh(kbG,kbm);m.position.set(-6.1,.945+i*.016,-13.45);scene.add(m);return m});
const BWM=[0,1,2,3].map(()=>{const g=mkKosa(true);g.visible=false;scene.add(g);return g});
const FZP=[[-7.17,.81,-13.27],[-7.02,.81,-13.27],[-6.87,.81,-13.27],[-6.72,.81,-13.27]],FZM=FZP.map(p=>{const g=mkKosa(true);g.scale.setScalar(.92);g.position.set(p[0],p[1],p[2]);g.visible=false;scene.add(g);return g});
KP.fz=FZP.map(p=>new V(p[0],p[1]+.045,p[2]));
function eatSpoon(){const tb=Math.hypot(P.x+3.6,P.z+10.4)<2.6,g=Math.round(15*(tb?1:.7));LF.hunger=Math.max(0,LF.hunger-g);KT.kp--;toast("🥣 Sho'rvadan yedingiz (−"+g+" ochlik) · "+(KT.kp>0?KT.kp+" qoshiq qoldi":"kosa bo'shadi"));if(KT.kp<=0){KT.item="kosa";KT.kp=0}}

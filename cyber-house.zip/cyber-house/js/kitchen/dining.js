/* ==========================================================
 * Modul: js/kitchen/dining.js
 * Idish-tovoq, meva, ovqatlanish stoli, ushlangan narsa
 * ========================================================== */
/* idish-tovoq */
for(let i=0;i<5;i++)kcyl(.1,.1,.012,kpl,-1.6,.96+i*.014,-13.5,16);{const rt=new T.Mesh(new T.TorusGeometry(.085,.007,6,18),kpr);rt.rotation.x=Math.PI/2;rt.position.set(-1.6,.96+4*.014+.009,-13.5);scene.add(rt)}kcyl(.07,.05,.06,kwh,-1.15,.98,-13.5,12);kcyl(.07,.05,.06,L(0x4a78c2),-1.0,.98,-13.4,12);kcyl(.035,.03,.08,kwh,-1.3,.99,-13.3,10);box(-2.05,.95,-13.45,.3,.02,.2,L(0xc9a46a));
box(-4.0,2.05,-13.7,.8,.02,.3,L(0x59636e));for(let i=0;i<3;i++)kcyl(.08,.07,.04,kwh,-4.2+i*.2,2.1,-13.7,14);
/* meva idishi */
kcyl(.12,.08,.07,L(0xb4783a),-.6,.97,-13.5,14);const KAP=[];[[-.64,-13.5],[-.57,-13.47],[-.6,-13.55]].forEach(a=>{const m=new T.Mesh(new T.SphereGeometry(.04,8,6),L(0xc92f2f));m.position.set(a[0],1.02,a[1]);scene.add(m);KAP.push(m)});
/* ovqatlanadigan stol va stullar */
box(-3.6,.76,-10.4,2.2,.06,1.1,WOOD.top);[[-1.0,-.45],[1.0,-.45],[-1.0,.45],[1.0,.45]].forEach(a=>box(-3.6+a[0],.37,-10.4+a[1],.08,.74,.08,WOOD.leg));[-.45,.45].forEach(z=>box(-3.6,.69,-10.4+z,1.92,.07,.03,WOOD.dark));[-1.0,1.0].forEach(x=>box(-3.6+x,.69,-10.4,.03,.07,.87,WOOD.dark));cols.push({x:-3.6,z:-10.4,hw:1.1,hd:.55});
[[-4.3,-9.55,0],[-2.9,-9.55,0],[-4.3,-11.25,1],[-2.9,-11.25,1]].forEach(a=>{box(a[0],.45,a[1],.42,.05,.42,L(0x7b5a3a));box(a[0],.7,a[1]+(a[2]?-.2:.2),.42,.45,.04,L(0x7b5a3a));[[-.17,-.17],[.17,-.17],[-.17,.17],[.17,.17]].forEach(b=>box(a[0]+b[0],.22,a[1]+b[1],.04,.44,.04,L(0x5a3f26)));cols.push({x:a[0],z:a[1],hw:.22,hd:.22})});
[-4.1,-3.1].forEach(x=>kcyl(.11,.08,.015,kwh,x,.81,-10.4,16));kcyl(.035,.03,.08,L(0xd23b3b),-3.6,.83,-10.2,10);kcyl(.14,.1,.07,L(0xc9b48a),-3.6,.83,-10.6,14);
/* ushlangan narsa */
const KH=new T.Group();{const e=new T.Mesh(new T.SphereGeometry(.03,8,6),L(0xf2e6cf));e.scale.y=1.25;e.name="egg";const b=new T.Mesh(new T.BoxGeometry(.14,.06,.07),L(0xd9a85b));b.name="bread";const f=new T.Group();f.name="fried";const f1=new T.Mesh(new T.CylinderGeometry(.06,.06,.01,14),kwh),f2=new T.Mesh(new T.SphereGeometry(.022,8,6),L(0xffb800));f2.position.y=.015;f.add(f1,f2);const ap=new T.Mesh(new T.SphereGeometry(.04,8,6),L(0xc92f2f));ap.name="apple";KH.add(e,b,f,ap);KH.visible=false;scene.add(KH)}
{const tm=new T.Mesh(new T.SphereGeometry(.045,10,8),L(0xd8392b));tm.name="tomato";KH.add(tm)}

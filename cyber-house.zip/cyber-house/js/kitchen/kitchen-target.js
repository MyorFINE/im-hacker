/* ==========================================================
 * Modul: js/kitchen/kitchen-target.js
 * Oshxona nishon funksiyasi
 * ========================================================== */
function kitchenTarget(){const free=!S.hold&&!LF.cup&&!KT.item,inK=P.z<-7.0,zone=P.z<-5.6&&P.z>-6.95&&P.x>-4.25&&P.x<-2.95,it=KT.item;
 if(KT.wash)return["🧽 Likopcha yuvilmoqda…",null];
 const doorT=()=>{if(S.hold)return null;let b=null,ba=.3;for(const c of KC)for(const d of c.doors){d.hd.getWorldPosition(_hp);if(pick(_hp,.11,1.55)){b=d;break}}return b?["E — ruchkani bosib shkaf eshigini "+(b.o?"yopish":"ochish"),()=>{b.o=b.o?0:1}]:null};
 if([.06,-.06].some(z=>{KDOOR.localToWorld(_hq.set(.95,1.05,z));return pick(_hq,.17,1.6)})){if(zone&&KT.open)return["Eshik yo'lida turibsiz — chetga o'ting",null];return["E — ruchkani bosib eshikni "+(KT.open?"yopish":"ochish"),()=>{KT.open=!KT.open}]}
 if(it&&!S.hold){
  const pl=it==="plate"||it==="pdirty"||it==="pfried"||it==="posh";
  if((it==="pfried"||it==="posh")&&Math.hypot(P.x+3.6,P.z+10.4)<2.4)return[it==="posh"?"E — stulga o'tirib osh yeyish":"E — stulga o'tirib likopchadan yeyish",startEat];
  if(pl){const hint=[it==="pdirty"?"Likopcha kir — lavaboga olib borib yuving":it==="pfried"?"Likopchani stolga olib boring — o'tirib yeysiz":it==="posh"?"Osh likopchada — stolga olib boring, o'tirib yeysiz":"Qo'lingizda likopcha — pishgan tuxumni skovorodadan soling",null];if(!inK)return hint;
   if(it==="pdirty"&&pick(KSp,.27,1.55))return["E — likopchani yuvish",()=>{KT.wash={t:0};KT.tapT=2.6}];
   if(it==="plate"&&KT.potP>0&&inK&&pick(KP.pot,.17,1.55)&&aim(KP.pot)<aim(KP.pan)){
    if(KT.dish!=="osh")return["Bu taom likopchaga emas — kosa bilan soling",null];
    if(!KT.lid)return["Avval qozon qopqog'ini qo'lga oling (likopchani stolga qo'yib turing)",null];
    return["E — likopchaga osh solish ("+KT.potP+" porsiya qoldi)",()=>{potServe();KT.item="posh";toast(KT.potP>0?"🍚 Osh likopchada — stolga olib borib o'tirib yeng ("+KT.potP+" porsiya qoldi)":"🍚 Osh likopchada — qozon bo'shadi, stolga olib boring")}]}
   if(it==="plate"){const q=KT.pan;if(q&&q.cooked&&!q.burnt&&pick(KP.pan,.18,1.55))return["E — tuxumni likopchaga solish",()=>{eggPaint(pX,q.t);pTx.needsUpdate=true;pYM.color.copy(yolk(q.t));KT.pan=null;KT.item="pfried";toast("Tuxum likopchada — stolga olib borib o'tirib yeng")}];
    if(pick(KP.plate,.18,1.55))return["E — likopchani joyiga qo'yish",()=>{KT.item=null}]}
   const h=surfHit();if(h)return["E — likopchani shu yerga qo'yish",()=>{if(KT.pls.length>=4)KT.pls.shift();KT.pls.push({x:h.x,y:h.y,z:h.z,k:it});KT.item=null}];
   return doorT()||hint}
  if(it==="kosaw"){
   if(inK&&pick(KP.pot,.17,1.55)&&aim(KP.pot)<aim(KP.pan)){
    if(KT.potP>0)return["Qozonda tayyor taom bor",null];
    if(!KT.lid)return["Avval qozon qopqog'ini oling (suvli kosani stolga qo'yib, qopqoqni qo'lga oling)",null];
    if(KT.water>=3)return["Qozonda suv yetarli (3/3 kosa)",null];
    return["E — qozonga suv quyish ("+KT.water+"/3 kosa)",()=>{KT.water++;KT.item="kosa";KT.kp=0;toast("💧 Qozonga suv quyildi — "+KT.water+"/3 kosa")}]}
   if(inK&&pick(KSp,.27,1.55))return["E — suvni lavaboga to'kish",()=>{KT.item="kosa";KT.kp=0}];
   if(inK){const dd=doorT();if(dd)return dd}
   {const hh=surfHit();if(hh)return["E — suvli kosani shu yerga qo'yish",()=>{if(KT.bws.length>=4)KT.bws.shift();KT.bws.push({x:hh.x,y:hh.y,z:hh.z,p:0,w:1});KT.item=null}]}
   return["Qo'lingizda suvli kosa — qozonga quying (jami 3 kosa kerak)",null]}
  if(it==="lid"){
   if(inK&&pick(KP.pot,.17,1.55)&&aim(KP.pot)<aim(KP.pan))return["E — qopqoqni qozonga yopish",()=>{KT.item=null;KT.ld={w:"pot"}}];
   {const hh=surfHit();if(hh&&!KT.pls.some(p=>Math.hypot(p.x-hh.x,p.z-hh.z)<.28)&&!KT.bws.some(p=>Math.hypot(p.x-hh.x,p.z-hh.z)<.25))return["E — qopqoqni stol ustiga qo'yish",()=>{KT.ld={w:"surf",x:hh.x,y:hh.y-.0075,z:hh.z};KT.item=null}]}
   if(inK){const dd=doorT();if(dd)return dd}
   return["Qo'lingizda qozon qopqog'i — stol yoki ish tokchasiga qo'ying yoki qozonga yoping",null]}
  if((RAWV.includes(it)||it==="chop")&&inK&&pick(KP.board,.14,1.5)){
   if(KT.bd||KT.cutT)return["Taxta band — avval undagi mahsulotni oling",null];
   return[it==="chop"?"E — mahsulotni taxtaga qaytarib qo'yish":"E — "+KN[it]+" taxtaga qo'yish (mayda to'g'rash uchun)",()=>{KT.bd={k:it==="chop"?KT.chop:it,cut:it==="chop",n:it==="chop"?6:0};KT.item=null}]}
  if(it==="kosa"||it==="kosaf"){const f=it==="kosaf";
   if(inK&&pick(KP.pot,.17,1.55)&&aim(KP.pot)<aim(KP.pan)){
    if(f)return["Kosa to'la — avval yeng yoki muzlatkichga qo'ying",null];
    if(!KT.lid)return["Avval qozon qopqog'ini oling (kosani stolga qo'yib, qopqoqni qo'lga oling)",null];
    if(KT.potP>0)return["E — qozondan kosaga solish ("+KT.potP+" porsiya qoldi)",()=>{potServe();KT.item="kosaf";KT.kp=3;if(KT.potP<=0){toast("🥣 Kosa to'ldi — qozon bo'shadi")}else toast("🥣 Kosaga solindi — qozonda "+KT.potP+" porsiya qoldi")}];
    return[potInfo(),null]}
   if(inK&&!f&&pick(KP.kosa,.13,1.5))return["E — kosani joyiga qo'yish",()=>{KT.item=null}];
   if(inK&&!f&&pick(KSp,.27,1.55))return["E — kosaga suv quyish (kran)",()=>{KT.item="kosaw";KT.tapT=1.6}];
   if(inK&&KFH.getWorldPosition(_hp)&&pick(_hp,.2,1.55))return["E — ruchkani bosib muzlatkichni "+(KT.fr?"yopish":"ochish"),()=>{KT.fr=!KT.fr}];
   if(inK&&f&&KT.fr&&frOK()){let bi=-1,ba=9;KT.fz.forEach((s,i)=>{if(!s&&pick(KP.fz[i],.075,1.5)){const a=aim(KP.fz[i]);if(a<ba){ba=a;bi=i}}});if(bi>=0)return["E — kosani muzlatkichga qo'yish",()=>{KT.fz[bi]=KT.kp;KT.item=null;toast("🧊 Kosa muzlatkichga qo'yildi — keyin olib yeyish mumkin")}]}
   if(inK){const dd=doorT();if(dd)return dd}
   {const hh=surfHit();if(hh)return["E — kosani shu yerga qo'yish"+(f?" (yeyish uchun yuqoriga qarang)":""),()=>{if(KT.bws.length>=4)KT.bws.shift();KT.bws.push({x:hh.x,y:hh.y,z:hh.z,p:f?KT.kp:0});KT.item=null}]}
   if(f)return["E — kosadan yeyish ("+KT.kp+" qoshiq qoldi)",eatSpoon];
   return["Qo'lingizda bo'sh kosa — qozondan sho'rva soling yoki joyiga qo'ying",null]}
  const sr=SRC[it];
  if(inK&&sr&&pick(sr[0],.13,1.5)&&dOpen(sr[1],sr[0].x))return["E — "+KN[it]+" joyiga qaytarish",()=>{KT.item=null}];
  if(inK&&dOpen(3,KP.cfl.x)&&pick(KP.cfl,.15,1.5)){if(it==="bowl")return["E — piyolaga un solish",()=>{KT.item="bowlflour"}];if(it==="bowlflour")return["E — unni qaytarish",()=>{KT.item="bowl"}]}
  if(inK&&dOpen(3,KP.cric.x)&&pick(KP.cric,.15,1.5)){if(it==="bowl")return["E — piyolaga guruch solish",()=>{KT.item="bowlrice"}];if(it==="bowlrice")return["E — guruchni qaytarish",()=>{KT.item="bowl"}]}
  if(inK&&(POTOK.includes(it)||RAWV.includes(it))&&pick(KP.pot,.15,1.55)){
   if(KT.potP>0)return["Qozonda tayyor taom bor — avval kosalarga soling",null];
   if(!KT.lid)return["Avval qozon qopqog'ini qo'lga oling (qo'lingiz band — narsani stolga qo'yib turing)",null];
   if(RAWV.includes(it))return["Butunligicha solib bo'lmaydi — taxtada pichoq bilan mayda to'g'rang",null];
   return["E — qozonga solish ("+(it==="chop"?"to'g'ralgan "+KN[KT.chop].replace(/ni$/,""):KN[it])+")",()=>{{const kd=it==="bowlflour"?"un":it==="bowlrice"?"guruch":it==="chop"?KT.chop:it;KT.pot.push(kd);potAddViz(kd)}KT.item=(it==="bowlflour"||it==="bowlrice")?"bowl":null;potToast()}]}
  if(inK&&it==="egg"&&!KT.pan&&pick(KP.pan,.18,1.55))return["E — tuxumni skovorodaga qo'yish",()=>{KT.pan={t:0,cooked:false,burnt:false,pk:-1};KT.item=null;toast("Plita tutqichini bosib gazni yoqing (~14 soniya)")}];
  if(inK&&pick(KP.knob,.15,1.55))return["E — gazni "+(KT.gas?"o'chirish":"yoqish"),togGas];
  if(inK){const dd=doorT();if(dd)return dd}
  if(EDIB.includes(it))return["E — "+KN[it]+" yeyish",eatItem];
  return["Qozonga soling yoki joyiga qaytaring",null]}
 if(!inK)return null;
 if(pick(KP.knob,.15,1.55))return["E — gazni "+(KT.gas?"o'chirish":"yoqish"),togGas];
 if(pick(KP.hood,.18,1.7))return["E — dimohodni "+(KT.hood?"o'chirish":"yoqish"),()=>{KT.hood=!KT.hood}];
 if(pick(KSp,.27,1.55)){if(LF.cup===1)return["E — kran: stakanga suv quyish",()=>{pourCup();KT.tapT=1.6}];if(!LF.cup)return["E — kranni "+(KT.tap?"yopish":"ochish"),()=>{KT.tap=!KT.tap}]}
 if(free){
  const ap=aim(KP.pot);if(pick(KP.pot,.15,1.55)&&ap<aim(KP.pan)){
   if(!KT.lid)return["E — qozon qopqog'ini qo'lga olish · "+potInfo(),()=>{KT.item="lid";KT.ld={w:"hand"}}];
   return["Qozon ochiq · "+potInfo(),null]}
  if(KT.pan&&pick(KP.pan,.18,1.55)){const q=KT.pan;if(q.burnt)return["E — kuygan tuxumni tashlash",()=>{KT.pan=null;toast("Tashlandi")}];if(q.cooked)return["Tuxum tayyor — avval likopcha oling (lavabo yonida)",null];return[KT.gas?"Tuxum pishmoqda… "+Math.max(0,Math.ceil(14-q.t))+" s":"Tuxum xom — avval gazni yoqing",null]}
  if(pick(KP.plate,.18,1.55))return["E — likopcha olish",()=>{KT.item="plate"}];
  if(KT.ld.w==="surf"){_pv.set(KT.ld.x,KT.ld.y+.03,KT.ld.z);if(pick(_pv,.17,1.55))return["E — qozon qopqog'ini olish",()=>{KT.item="lid";KT.ld={w:"hand"}}]}
  if(pick(KP.board,.14,1.5)){const b=KT.bd;if(!b)return["Taxta bo'sh — sabzi, kartoshka, piyoz yoki pomidorni olib kelib qo'ying",null];if(!b.cut)return["🔪 E — pichoq bilan kesish ("+b.n+"/6) · har bosish bitta kesim",()=>{b.n++;if(b.n>=6){b.cut=true;toast("🔪 Mayda to'g'raldi — taxtadan oling")}}];return["E — to'g'ralgan mahsulotni olish ("+KN[b.k]+")",()=>{KT.item="chop";KT.chop=b.k;KT.bd=null}]}
  if(pick(KP.kosa,.13,1.5))return["E — kosa olish",()=>{KT.item="kosa";KT.kp=0}];
  {const bi=KT.bws.findIndex(p=>{_pv.set(p.x,p.y+.04,p.z);return pick(_pv,.14,1.55)});if(bi>=0){const p=KT.bws[bi];return["E — kosani olish"+(p.w?" (suvli)":p.p?" (sho'rva bor)":" (bo'sh)"),()=>{KT.item=p.w?"kosaw":p.p?"kosaf":"kosa";KT.kp=p.p;KT.bws.splice(bi,1)}]}}
  if(KT.fr&&frOK()){let bi=-1,ba=9;KT.fz.forEach((s,i)=>{if(s&&pick(KP.fz[i],.075,1.5)){const a=aim(KP.fz[i]);if(a<ba){ba=a;bi=i}}});if(bi>=0)return["E — kosani muzlatkichdan olish (sovuq)",()=>{KT.item="kosaf";KT.kp=KT.fz[bi];KT.fz[bi]=0}]}
  const pi=KT.pls.findIndex(p=>{_pv.set(p.x,p.y,p.z);return pick(_pv,.17,1.55)});
  if(pi>=0){const p=KT.pls[pi];return["E — likopchani olish"+(p.k==="pdirty"?" (kir)":p.k==="pfried"?" (tuxum bilan)":""),()=>{KT.item=p.k;KT.pls.splice(pi,1)}]}
  if(KT.apples>0&&pick(KP.fruit,.18,1.55))return["E — olma olish",()=>{KT.apples--;KT.item="apple"}];
  for(const k in SRC){const r=SRC[k];if(pick(r[0],.12,1.5)&&dOpen(r[1],r[0].x))return["E — "+KN[k]+" olish",()=>{KT.item=k}]}
  if(dOpen(3,KP.cfl.x)&&pick(KP.cfl,.12,1.5))return["Un uchun avval chinni piyola oling",null];
  if(dOpen(3,KP.cric.x)&&pick(KP.cric,.12,1.5))return["Guruch uchun avval chinni piyola oling",null];
  if(KT.fr&&frOK()){if(pick(KP.egg,.17,1.5))return["E — tuxum olish",()=>{KT.item="egg"}];if(pick(KP.bread,.17,1.5))return["E — non olish",()=>{KT.item="bread"}]}}
 {const dd=doorT();if(dd)return dd}
 if(KFH.getWorldPosition(_hp)&&pick(_hp,.2,1.55))return["E — ruchkani bosib muzlatkichni "+(KT.fr?"yopish":"ochish"),()=>{KT.fr=!KT.fr}];
 return null}
const KFR=new T.Group();KFR.position.set(-6.5,0,-13.04);scene.add(KFR);{const lf=new T.Mesh(new T.BoxGeometry(.8,1.88,.04),L(0xe6ecef));lf.position.set(-.4,.97,.02);KFR.add(lf);const hd=new T.Mesh(new T.BoxGeometry(.04,.5,.05),KHM);hd.position.set(-.7,1.15,.07);KFR.add(hd);window.KFH=hd}

/* ==========================================================
 * Modul: js/kitchen/pantry.js
 * Ziravorlar va masalliqlar
 * ========================================================== */
/* ziravorlar (tepa shkaflar) */
{const cl=[0xd23b3b,0xe3b505,0x8b5a2b,0x3f8f4a,0xf1f1ee,0x333333,0xe8782a,0x9b3b8f],jb=[],jl=[];
 [[-6.45,-3.6,16],[-2.05,.1,11]].forEach(r=>{const st=(r[1]-r[0])/(r[2]-1);[1.97,2.355].forEach((y,yi)=>{for(let i=0;i<r[2];i++){const x=r[0]+i*st,z=i%2?-13.64:-13.76;jb.push([x,y,z,1,1,1,0,0,0,cl[(i*3+yi*2)%8]]);jl.push([x,y+.055,z,1,1,1,0,0,0,0xe6e6e6])}})});
 kInst(new T.CylinderGeometry(.028,.028,.09,8),L(0xffffff),jb);kInst(new T.CylinderGeometry(.03,.03,.02,8),L(0xffffff),jl)}
/* kartoshka, sabzi, piyoz, pomidor, tuxum, guruch, un (pastki shkaflar) */
{const sph=new T.SphereGeometry(1,8,6),cone=new T.ConeGeometry(1,1,6),M=L(0xffffff),pot=[],car=[],oni=[],tom=[],egg=[];
 for(let i=0;i<7;i++)pot.push([-4.78+(i%4)*.07,.07+(i>3?.05:0),-13.3-(i>3?.04:0)-(i%2)*.04,.06,.045,.05,0,i,0,0xb98d5a]);
 for(let i=0;i<5;i++)car.push([-4.22+(i%2)*.04,.05+(i>1?.04:0),-13.26-(i%3)*.05,.02,.17,.02,0,0,Math.PI/2,0xe8791e]);
 for(let i=0;i<5;i++)oni.push([-3.72+(i%3)*.08,.065+(i>2?.05:0),-13.3-(i>2?.05:0),.04,.036,.04,0,0,0,0xc89a4a]);
 for(let i=0;i<6;i++)tom.push([-4.72+(i%3)*.08,.515,-13.3-(i>2?.08:0),.043,.038,.043,0,0,0,0xd8392b]);
 for(let i=0;i<6;i++)egg.push([-1.97+(i%3)*.07,.545,-13.26-(i>2?.07:0),.026,.033,.026,0,0,0,0xf2e6cf]);
 kInst(sph,M,pot);kInst(cone,M,car);kInst(sph,M,oni);kInst(sph,M,tom);kInst(sph,M,egg);
 box(-1.9,.49,-13.3,.3,.04,.2,L(0xc9b48a));
 box(-2.2,.135,-13.35,.26,.22,.14,L(0xf2efe6));box(-1.85,.135,-13.35,.26,.22,.14,L(0xe6d8b8));lab("GURUCH",-2.2,.15,-13.279);lab("UN",-1.85,.15,-13.279);
 kcyl(.04,.04,.24,L(0xe3b505),-1.4,.145,-13.3,10);box(-1.1,.12,-13.35,.2,.19,.12,L(0xf4f6fa));lab("SHAKAR",-1.1,.14,-13.289);{const bo=new T.Mesh(new T.SphereGeometry(.07,12,8,0,Math.PI*2,Math.PI/2,Math.PI/2),L(0xf3f3ef,{side:T.DoubleSide}));bo.position.set(-1.2,.54,-13.3);scene.add(bo)}}


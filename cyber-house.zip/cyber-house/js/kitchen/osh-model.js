/* ==========================================================
 * Modul: js/kitchen/osh-model.js
 * mkOsh() modeli (likopchalar yaratilishidan oldin e'lon qilinishi kerak)
 * ========================================================== */
function mkOsh(){const g=new T.Group(),m=new T.Mesh(new T.SphereGeometry(.06,14,8,0,Math.PI*2,0,Math.PI/2),L(0xe3b955));m.scale.y=.5;m.position.y=.0085;g.add(m);
 for(let i=0;i<6;i++){const c=new T.Mesh(new T.BoxGeometry(.02,.008,.012),L(i%3?0xe8791e:0xc08a3a));const a=i*1.1;c.position.set(Math.cos(a)*.03,.03-(i%2)*.004,Math.sin(a)*.03);c.rotation.y=a;g.add(c)}return g}

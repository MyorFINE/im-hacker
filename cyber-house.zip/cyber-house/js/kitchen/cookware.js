/* ==========================================================
 * Modul: js/kitchen/cookware.js
 * Taxta, pichoq, suvli kosa, guruch
 * ========================================================== */
/* ---- taxta + pichoq, suvli kosa, guruch, qo'lga olinadigan qopqoq ---- */
Object.assign(KN,{kosaw:"suvli kosani",bowlrice:"guruchni",chop:"to'g'ralgan mahsulotni",lid:"qopqoqni"});
const KCOL={carrot:0xe8791e,potato:0xd9b97a,onion:0xe9dca8,tomato:0xd8392b};
KP.board=new V(-2.05,.975,-13.45);KP.cric=new V(-2.2,.14,-13.3);
const KBR=new T.Group(),KBC=new T.Group(),KNF=new T.Group(),KBCm=L(0xe8791e);
{KBR.position.set(-2.05,.96,-13.45);scene.add(KBR);
 const ca=new T.Mesh(new T.ConeGeometry(.02,.17,6),L(0xe8791e));ca.rotation.z=Math.PI/2;ca.position.y=.02;ca.name="carrot";
 const po=new T.Mesh(new T.SphereGeometry(1,8,6),L(0xb98d5a));po.scale.set(.06,.045,.05);po.position.y=.04;po.name="potato";
 const on=new T.Mesh(new T.SphereGeometry(.04,8,6),L(0xc89a4a));on.position.y=.04;on.name="onion";
 const tm=new T.Mesh(new T.SphereGeometry(.045,10,8),L(0xd8392b));tm.position.y=.045;tm.name="tomato";
 KBR.add(ca,po,on,tm);KBR.visible=false;
 KBC.position.set(-2.05,.96,-13.45);scene.add(KBC);KBC.visible=false;
 for(let i=0;i<16;i++){const m=new T.Mesh(new T.BoxGeometry(.02,.014,.02),KBCm);m.position.set(((i%4)-1.5)*.035+(Math.random()-.5)*.01,.007+(i>7?.012:0),(((i>>2)%2)-.5)*.05+(Math.random()-.5)*.01);m.rotation.y=Math.random()*3;KBC.add(m)}
 const bl=new T.Mesh(new T.BoxGeometry(.11,.005,.026),kmet),hd=new T.Mesh(new T.BoxGeometry(.06,.014,.02),L(0x15171a));bl.position.set(-.03,.0025,0);hd.position.set(.055,.007,0);KNF.add(bl,hd);KNF.position.set(-2.0,.96,-13.385);KNF.rotation.y=.1;scene.add(KNF)}
const hw=mkKosa(true);hw.name="kosaw";hw.userData.f.material.color.setHex(0x5aa0d8);kfill(hw,3);
const hl=new T.Group();{const kdk=L(0x2a2d31),l3=new T.Mesh(new T.CylinderGeometry(.155,.155,.02,18),kdk),k3=new T.Mesh(new T.CylinderGeometry(.02,.02,.03,8),kmet);k3.position.y=.025;hl.add(l3,k3);hl.rotation.x=.5;hl.scale.setScalar(.8);hl.name="lid"}
const hc=new T.Group(),KHCm=L(0xe8791e);{hc.name="chop";hc.add(mkPlate(false));for(let i=0;i<10;i++){const m=new T.Mesh(new T.BoxGeometry(.018,.012,.018),KHCm);m.position.set(((i%5)-2)*.03+(Math.random()-.5)*.01,.015+(i>4?.012:0),(i>4?.5:-.5)*.045);m.rotation.y=Math.random()*3;hc.add(m)}}
const hbr=new T.Group();{hbr.name="bowlrice";const w2=new T.Mesh(new T.SphereGeometry(.07,12,8,0,Math.PI*2,Math.PI/2,Math.PI/2),L(0xf3f3ef,{side:T.DoubleSide})),fl2=new T.Mesh(new T.CircleGeometry(.062,12),L(0xf1e8c8));fl2.rotation.x=-Math.PI/2;fl2.position.y=-.012;hbr.add(w2,fl2)}
KH.add(hw,hl,hc,hbr);

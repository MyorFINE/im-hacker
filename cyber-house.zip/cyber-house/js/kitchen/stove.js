/* ==========================================================
 * Modul: js/kitchen/stove.js
 * Gaz plita
 * ========================================================== */
/* gaz plita */
[[-3.1,-13.35],[-2.7,-13.65],[-2.7,-13.35],[-3.1,-13.65]].forEach(a=>kcyl(.1,.1,.012,L(0x090a0c),a[0],.945,a[1],16));
[-3.15,-2.97,-2.8,-2.62].forEach((x,i)=>kcyl(.025,.025,.03,i?L(0x8a8f95):L(0xd23b3b),x,.8,-13.115,10).rotation.x=Math.PI/2);
box(-2.9,.42,-13.1,.7,.4,.03,L(0x15181b));box(-2.9,.42,-13.085,.5,.2,.01,L(0x34444f));
const kpan=kcyl(.12,.1,.04,L(0x15171a),-3.1,.98,-13.35,16);box(-2.95,.99,-13.35,.2,.02,.04,L(0x15171a));
const kpot=kcyl(.12,.12,.18,kmet,-2.7,1.03,-13.65,16);kcyl(.125,.125,.02,kmet,-2.7,1.13,-13.65,16);
const KLP=new T.Group(),KPW=new T.Mesh(new T.CircleGeometry(1,24),new T.MeshLambertMaterial({color:0x6fa8d6,transparent:true,opacity:.9,polygonOffset:true,polygonOffsetFactor:-1})),KLID=new T.Group(),KPD=new T.Mesh(new T.CircleGeometry(1,24),L(0xcfbf8f,{polygonOffset:true,polygonOffsetFactor:-1}));
{const dk=L(0x2a2d31),dk2=L(0x2a2d31,{side:T.DoubleSide}),wl=new T.Mesh(new T.CylinderGeometry(.15,.12,.16,18,1,true),dk2);wl.position.set(-2.7,1.03,-13.35);scene.add(wl);
 const bt=new T.Mesh(new T.CircleGeometry(.118,18),L(0x15171a));bt.rotation.x=-Math.PI/2;bt.position.set(-2.7,.952,-13.35);scene.add(bt);
 const rm=new T.Mesh(new T.TorusGeometry(.15,.006,6,22),dk);rm.rotation.x=Math.PI/2;rm.position.set(-2.7,1.11,-13.35);scene.add(rm);
 KPD.rotation.x=-Math.PI/2;KPD.visible=false;scene.add(KPD);KPW.rotation.x=-Math.PI/2;KPW.visible=false;scene.add(KPW);
 /* qopqoq orqa chetidagi sharnir atrofida ochiladi */
 const ld=new T.Mesh(new T.CylinderGeometry(.155,.155,.02,18),dk),kn=new T.Mesh(new T.CylinderGeometry(.02,.02,.03,8),kmet);ld.position.set(0,0,.155);kn.position.set(0,.025,.155);KLID.add(ld,kn);KLID.position.set(-2.7,1.12,-13.505);scene.add(KLID);
 {const l2=new T.Mesh(new T.CylinderGeometry(.155,.155,.02,18),dk),k2=new T.Mesh(new T.CylinderGeometry(.02,.02,.03,8),kmet);k2.position.y=.025;KLP.add(l2,k2);KLP.visible=false;scene.add(KLP)}
 [-1,1].forEach(q=>box(-2.7+q*.158,1.05,-13.35,.04,.015,.03,dk))}
const eC=cv(128,128),eX=eC.getContext("2d"),eTx=tex(eC),eR=[];for(let i=0;i<24;i++)eR.push(.82+Math.random()*.18);
const yc=new T.Color(),y0c=new T.Color(0xf6e9a8),y1c=new T.Color(0xffbb00),y2c=new T.Color(0xc98000),y3c=new T.Color(0x1c1410);
function yolk(t){yc.copy(y0c).lerp(y1c,Math.min(1,t/14));if(t>14)yc.lerp(y2c,Math.min(1,(t-14)/14)*.6);if(t>26)yc.lerp(y3c,Math.min(1,(t-26)/14));return yc}
function eggPaint(x2,t){const p=Math.min(1,t/14),e=Math.max(0,Math.min(1,(t-9)/20))*.9,bu=Math.max(0,Math.min(1,(t-26)/14));x2.clearRect(0,0,128,128);x2.save();x2.translate(64,64);x2.beginPath();
 for(let i=0;i<=24;i++){const a=i/24*Math.PI*2,r=eR[i%24]*60;if(i)x2.lineTo(Math.cos(a)*r,Math.sin(a)*r);else x2.moveTo(Math.cos(a)*r,Math.sin(a)*r)}x2.closePath();
 x2.fillStyle="rgba("+(235+20*p|0)+","+(242+13*p|0)+","+(246+9*p|0)+","+(.5+.5*p)+")";x2.fill();x2.clip();
 const g=x2.createRadialGradient(0,0,26,0,0,64);g.addColorStop(0,"rgba(205,140,50,0)");g.addColorStop(.55,"rgba(205,140,50,"+e*.2+")");g.addColorStop(1,"rgba(150,85,22,"+e+")");x2.fillStyle=g;x2.fillRect(-64,-64,128,128);
 if(bu>0){x2.fillStyle="rgba(24,14,9,"+bu*.95+")";x2.fillRect(-64,-64,128,128)}x2.restore()}
eggPaint(eX,0);
const KEW=new T.Mesh(new T.CircleGeometry(.075,24),L(0xffffff,{map:eTx,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));KEW.rotation.x=-Math.PI/2;KEW.position.set(-3.1,1.004,-13.35);scene.add(KEW);
const KEY=new T.Mesh(new T.SphereGeometry(.027,10,6),L(0xf6e9a8));KEY.scale.y=.55;KEY.position.set(-3.1,1.012,-13.35);scene.add(KEY);KEW.visible=KEY.visible=false;
const pC=cv(128,128),pX=pC.getContext("2d"),pTx=tex(pC),pYM=L(0xffbb00);eggPaint(pX,14);
const KFL=[];for(let i=0;i<6;i++){const a=i*Math.PI/3,f=new T.Mesh(new T.ConeGeometry(.012,.05,5),B(i%2?0xffa43a:0x4db8ff));f.position.set(-3.1+Math.sin(a)*.065,.97,-13.35+Math.cos(a)*.065);f.visible=false;scene.add(f);KFL.push(f)}

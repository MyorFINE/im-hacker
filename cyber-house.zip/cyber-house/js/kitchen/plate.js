/* ==========================================================
 * Modul: js/kitchen/plate.js
 * Likopcha
 * ========================================================== */
function mkPlate(withEgg){const g=new T.Group(),p1=new T.Mesh(new T.CylinderGeometry(.11,.08,.015,16),kpl),p2=new T.Mesh(new T.TorusGeometry(.098,.008,6,18),kpr),pw=new T.Mesh(new T.CircleGeometry(.062,16),kwell);p2.rotation.x=Math.PI/2;p2.position.y=.008;pw.rotation.x=-Math.PI/2;pw.position.y=.0082;g.add(p1,p2,pw);
 if(withEgg){const w=new T.Mesh(new T.CircleGeometry(.07,20),new T.MeshLambertMaterial({map:pTx,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2})),y=new T.Mesh(new T.SphereGeometry(.024,10,6),pYM);w.rotation.x=-Math.PI/2;w.position.y=.0085;y.scale.y=.55;y.position.y=.016;g.add(w,y);g.userData={w,y}}return g}
{const a=mkPlate(false),b=mkPlate(true);a.name="plate";b.name="pfried";KH.add(a,b)}
const TPL=mkPlate(true),TPw=TPL.userData.w,TPy=TPL.userData.y;TPL.visible=false;scene.add(TPL);
KP.ccar=new V(-4.2,.07,-13.3);KP.cpot=new V(-4.67,.09,-13.32);KP.coni=new V(-3.64,.08,-13.32);KP.csug=new V(-1.1,.14,-13.3);KP.cbow=new V(-1.2,.54,-13.3);KP.cfl=new V(-1.85,.14,-13.3);KP.pot=new V(-2.7,1.08,-13.35);
const SRC={tomato:[KP.ctom,2],egg:[KP.cegg,3],carrot:[KP.ccar,2],potato:[KP.cpot,2],onion:[KP.coni,2],sugar:[KP.csug,3],bowl:[KP.cbow,3]},POTOK=["egg","sugar","bowlflour","bowlrice","chop"],RAWV=["carrot","potato","onion","tomato"],EDIB=["egg","bread","apple","tomato","carrot"];
Object.assign(KN,{carrot:"sabzini",potato:"kartoshkani",onion:"piyozni",sugar:"shakarni",bowl:"chinni piyolani",bowlflour:"unni"});
const dOpen=(ci,x)=>KC[ci].doors.some(d=>x>=d.x0&&x<=d.x1&&d.o);
{const w=L(0xf3f3ef,{side:T.DoubleSide}),mk=(n,m)=>{m.name=n;KH.add(m);return m},bw=()=>new T.Mesh(new T.SphereGeometry(.07,12,8,0,Math.PI*2,Math.PI/2,Math.PI/2),w);
 const ca=new T.Mesh(new T.ConeGeometry(.02,.17,6),L(0xe8791e));ca.rotation.z=Math.PI/2;mk("carrot",new T.Group()).add(ca);
 const po=new T.Mesh(new T.SphereGeometry(1,8,6),L(0xb98d5a));po.scale.set(.06,.045,.05);mk("potato",new T.Group()).add(po);
 mk("onion",new T.Group()).add(new T.Mesh(new T.SphereGeometry(.04,8,6),L(0xc89a4a)));
 mk("sugar",new T.Mesh(new T.BoxGeometry(.12,.16,.07),L(0xf4f6fa)));mk("bowl",bw());
 const bf=mk("bowlflour",new T.Group());bf.add(bw());const fl=new T.Mesh(new T.CircleGeometry(.062,12),L(0xffffff));fl.rotation.x=-Math.PI/2;fl.position.y=-.012;bf.add(fl)}
const stain=()=>{const m=new T.Mesh(new T.CircleGeometry(.06,12),new T.MeshBasicMaterial({color:0x8a6a3a,transparent:true,opacity:.65,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-3}));m.rotation.x=-Math.PI/2;m.position.y=.0088;return m};
{const d=mkPlate(false);d.name="pdirty";d.add(stain());KH.add(d)}
const PLS=[0,1,2,3].map(()=>{const g=mkPlate(true),st=stain();{const om=mkOsh();om.visible=false;g.add(om);g.userData.om=om}g.add(st);g.userData.st=st;g.visible=false;scene.add(g);return g});

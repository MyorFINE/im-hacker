/* ==========================================================
 * Modul: js/core/monitor-layout.js
 * Ikki monitorning ish stolidagi joylashuvi: ikkalasi stol MARKAZI (x=0) atrofida
 * simmetrik turadi, ichkariga biroz burilgan ("V" shakl). To'qnashuv va "stol ustida
 * joy band" qutilari shu yerdagi qiymatlardan hisoblanadi.
 * ========================================================== */
const MONL={gx:.52,ry:.2,pz:-3.8};
const MON1={gx:-MONL.gx,gz:MONL.pz,ry:MONL.ry};
/* monitor markazi (pivot) atrofidagi lokal to'rtburchakning aylantirilgan dunyo AABB si: [x0,x1,z0,z1] */
function monRot(m,x0,x1,z0,z1){const c=Math.cos(m.ry),s=Math.sin(m.ry);let ax=1e9,bx=-1e9,az=1e9,bz=-1e9;
 for(const x of[x0,x1])for(const z of[z0,z1]){const wx=m.gx+x*c+z*s,wz=m.gz+(-x*s+z*c);ax=Math.min(ax,wx);bx=Math.max(bx,wx);az=Math.min(az,wz);bz=Math.max(bz,wz)}
 return[ax,bx,az,bz]}
/* tana (ramka+korpus), taglik va bo'yin uchun to'qnashuv qutilari [x0,x1,y0,y1,z0,z1] */
function monBoxes(m){const b=monRot(m,-.51,.51,-.07,.0255),s=monRot(m,-.16,.16,-.16,.08),n=monRot(m,-.05,.05,-.071,-.02);
 return{body:[b[0],b[1],1,1.6,b[2],b[3]],stand:[s[0],s[1],.9,.914,s[2],s[3]],neck:[n[0],n[1],.914,1.1,n[2],n[3]]}}

/* ==========================================================
 * Modul: js/cables/cable-routes.js
 * Kabel yo'llari (aylana yoylar, stol qirrasidan oshib o'tish)
 * ========================================================== */
/* ---- kabel yo'llari: aylana yoylar bilan burilgan, stol qirrasi ustidan oshib o'tadi ---- */
const CR=.011,FY=.0115,EY=.9125,EZ=-4.2125;
/* vs: [x,y,z,burilish radiusi]; har burchak haqiqiy aylana yoyi, to'g'ri qismlar ixcham */
function cableRoute(vs){const P=vs.map(v=>new V(v[0],v[1],v[2])),o=[P[0].clone()];
 for(let i=1;i<P.length-1;i++){const r=vs[i][3]||0,a=P[i-1],v=P[i],b=P[i+1],d1=v.clone().sub(a).normalize(),d2=b.clone().sub(v).normalize(),cs=Math.max(-1,Math.min(1,d1.dot(d2))),ph=Math.acos(cs);
  if(r<=0||ph<1e-3){o.push(v.clone());continue}
  const Tn=r*Math.tan(ph/2),p1=v.clone().addScaledVector(d1,-Tn),n=d2.clone().addScaledVector(d1,-cs).normalize(),c=p1.clone().addScaledVector(n,r),k=Math.max(5,Math.ceil(ph/.15));
  for(let j=0;j<=k;j++){const th=ph*j/k;o.push(c.clone().addScaledVector(n,-r*Math.cos(th)).addScaledVector(d1,r*Math.sin(th)))}}
 o.push(P[P.length-1].clone());
 const q=[o[0]];for(let i=1;i<o.length;i++){const a=o[i-1],b=o[i],l=a.distanceTo(b),m=Math.ceil(l/.06);for(let j=1;j<=m;j++)q.push(a.clone().lerp(b,j/m))}return q}
function routeBoxes(path,tag){const out=[];let a=0;while(a<path.length-1){let b=a,mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9],len=0;for(;;){const p=path[b];mn[0]=Math.min(mn[0],p.x);mn[1]=Math.min(mn[1],p.y);mn[2]=Math.min(mn[2],p.z);mx[0]=Math.max(mx[0],p.x);mx[1]=Math.max(mx[1],p.y);mx[2]=Math.max(mx[2],p.z);if(b+1>=path.length||len>.14)break;len+=path[b].distanceTo(path[b+1]);b++}
  const bx=[mn[0]-CR,mx[0]+CR,mn[1]-CR,mx[1]+CR,mn[2]-CR,mx[2]+CR];bx.tag=tag;out.push(bx);a=b}return out}
const cabMat=L(0x0b0d10),plMat=L(0x2a3037);
function routeMesh(path){const c=new T.CatmullRomCurve3(path,false,"centripetal"),m=new T.Mesh(new T.TubeGeometry(c,Math.min(1200,path.length*2),CR,8,false),cabMat);scene.add(m);return m}
function plugBox(x,y,z,w,h,d){const m=new T.Mesh(new T.BoxGeometry(w,h,d),plMat);m.position.set(x,y,z-d/2);scene.add(m);return m}
/* klaviatura -> kompyuter USB; monitor DisplayPort -> videokarta; monitor quvvat kabeli (stol orqasidan yerga) */
const R_KB_A=cableRoute([[-.4,EY,-3.13],[-.4,EY,EZ,.0125],[-.4,FY,EZ,.05],[-.4,FY,-3.4,.05],[1.052,FY,-3.4,.05],[1.052,FY,-3.33]]),R_KB_B=cableRoute([[1.052,FY,-3.33],[1.052,FY,-3.27,.06],[1.052,.43355,-3.27,.07],[1.052,.43355,-3.2]]),R_KB=R_KB_A.concat(R_KB_B);
const R_DP_A=cableRoute([[.05,1.14,-3.8785],[.05,1.14,-4,.06],[.05,EY,-4,.06],[.05,EY,EZ,.0125],[.05,FY,EZ,.05],[.05,FY,-3.7,.05],[1.104,FY,-3.7,.05],[1.104,FY,-3.33]]),R_DP_B=cableRoute([[1.104,FY,-3.33],[1.104,FY,-3.27,.06],[1.104,.41665,-3.27,.07],[1.104,.41665,-3.2]]),R_DP=R_DP_A.concat(R_DP_B);
const R_MON=cableRoute([[-.04,1.14,-3.8805],[-.04,1.14,-4,.06],[-.04,EY,-4,.06],[-.04,EY,EZ,.0125],[-.04,FY,EZ,.05],[-.04,FY,-4.45]]);
const R_PW=cableRoute([[1.0975,.065,-3.2029],[1.0975,.065,-3.2379,.03],[1.25,.065,-3.2379]]);
/* 2-monitor: quvvat kabeli (stol orqasidan yerga) va HDMI (videokartaga) */
const _m2=MON2.pwr,_h2=MON2.hdmi;
const R_MON2=cableRoute([[_m2.x,_m2.y,_m2.z],[_m2.x,1.14,-4.02,.06],[_m2.x,EY,-4.02,.06],[_m2.x,EY,EZ,.0125],[_m2.x,FY,EZ,.05],[_m2.x,FY,-4.45]]);
const R_H2_A=cableRoute([[_h2.x,_h2.y,_h2.z],[_h2.x,1.14,-4,.06],[_h2.x,EY,-4,.06],[_h2.x,EY,EZ,.0125],[_h2.x,FY,EZ,.05],[_h2.x,FY,-4.1,.05],[1.156,FY,-4.1,.05],[1.156,FY,-3.33]]),R_H2_B=cableRoute([[1.156,FY,-3.33],[1.156,FY,-3.27,.06],[1.156,.39,-3.27,.07],[1.156,.39,-3.2]]),R_H2=R_H2_A.concat(R_H2_B);
const CABV={B:[],fp:[],pw:[]};[R_KB_A,R_DP_A,R_MON,R_MON2,R_H2_A].forEach(routeMesh);CABV.B.push(routeMesh(R_KB_B),routeMesh(R_DP_B),routeMesh(R_H2_B));CABV.pw.push(routeMesh(R_PW));
CABV.B.push(plugBox(1.052,.43355,-3.2,.024,.016,.03),plugBox(1.104,.41665,-3.2,.024,.018,.03),plugBox(1.156,.39,-3.2,.024,.018,.03));plugBox(.05,1.14,-3.8785,.03,.016,.035);plugBox(-.04,1.14,-3.8805,.036,.022,.035);
function m2plug(p,w,h,d){const m=plugBox(0,0,0,w,h,d),dir=new V(0,0,-1).transformDirection(g2.matrixWorld);m.position.copy(p).addScaledVector(dir,d/2);m.rotation.y=MON2.ry;return m}m2plug(MON2.hdmi,.034,.012,.035);m2plug(MON2.pwr,.036,.022,.035);CABV.pw.push(plugBox(1.0975,.065,-3.2029,.026,.026,.03));
[plugBox(1.052,FY,-3.3,.024,.016,.03),plugBox(1.104,FY,-3.3,.024,.016,.03),plugBox(1.156,FY,-3.3,.024,.016,.03)].forEach(m=>{m.visible=false;CABV.fp.push(m)});
/* qo'l stol ustida bo'lsa, kabel stol old qirrasi ustidan oshib o'tadi */
const frontVia=(e,w)=>(e.y>.8&&e.z<-2.7&&Math.abs(e.x)<1.9)?w.concat([new V(Math.max(-1.7,Math.min(1.7,e.x)),1,-2.5)]):w;
const SEGL=.12,DV={pc:{s:"plug",A:R_PW[R_PW.length-1].clone(),rest:REST,out:OUT,len:5.8,ox:5.4,oz:-2.2,rx:REST.x,rz:REST.z,rot:Math.PI/2,via:e=>e.distanceTo(REST)<.6?[]:e.z<-3.6?[new V(1.4,.02,-3.9),new V(1.5,FY,-4.3)]:frontVia(e,[new V(1.35,.05,-3),new V(1.4,.05,-2.45)]),gd:R_PW,tag:"pw"},
 mon:{s:"mplug",A:R_MON[R_MON.length-1].clone(),rest:REST2,out:OUT2,len:7,ox:2.6,oz:-6.3,rx:REST2.x,rz:REST2.z,rot:0,via:e=>e.distanceTo(REST2)<.6?[new V(-1.95,FY,-4.35)]:(e.z<-5||(e.x>2&&e.z<-4.3))?[]:frontVia(e,[new V(-1.95,.05,-4.35),new V(-1.95,.05,-2.4)]),gd:R_MON,tag:"mon"}};
DV.mon2={s:"mplug2",A:R_MON2[R_MON2.length-1].clone(),rest:REST3,out:OUT3,len:6,ox:3.4,oz:-6.3,rx:REST3.x,rz:REST3.z,rot:0,via:e=>e.distanceTo(REST3)<.6?[new V(1.95,FY,-4.35)]:(e.z<-5||(e.x>1.95&&e.z<-4.3))?[]:frontVia(e,[new V(1.95,.05,-4.35),new V(1.95,.05,-2.4)]),gd:R_MON2,tag:"mon2"};
const cabGeo=new T.CylinderGeometry(CR,CR,1,6,1,false);cabGeo.rotateX(Math.PI/2);
for(const k in DV){const d=DV[k];d.L=d.len+.5;d.N=Math.ceil(d.L/SEGL);d.cab=new T.InstancedMesh(cabGeo,cabMat,d.N);d.cab.frustumCulled=false;scene.add(d.cab);d.pl=new T.Mesh(new T.BoxGeometry(.07,.05,.1),plMat);scene.add(d.pl);d.pts=Array.from({length:d.N+1},()=>new V());d.pv=Array.from({length:d.N+1},()=>new V());d.last=new V(1e9,0,0);d.slp=0}

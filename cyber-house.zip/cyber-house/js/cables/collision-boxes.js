/* ==========================================================
 * Modul: js/cables/collision-boxes.js
 * Kabel va buyumlar uchun to'qnashuv qutilari
 * ========================================================== */
/* to'qnashuv qutilari (haqiqiy geometriya): kabel, tashlangan buyumlar uchun */
const MB1=monBoxes(MON1),MB2=monBoxes(MON2);
const CB=[[-1.8,1.8,.74,.9,-4.2,-2.7]].concat(DESK_CB,[
 [.856,1.1365,0,.5555,-3.2041,-2.7991],
 MB1.body,MB1.stand,MB1.neck,[-1.24,-1.10,.9,1.18,-3.93,-3.77],[1.10,1.24,.9,1.18,-3.93,-3.77],
 [-.56,.56,.9,.941,-3.13,-2.77],[.625,1.075,.9,.912,-3.18,-2.82],[.82,.88,.912,.95,-3.055,-2.945],
 [-1.69,-1.47,.9,.93,-3.81,-3.59],[-1.595,-1.565,.93,1.375,-3.715,-3.685],[-1.67,-1.49,1.35,1.45,-3.72,-3.52],[-1.25,-.95,.9,.915,-3.21,-2.99],[-.885,-.815,.9,1,-3.235,-3.165],[1.29,1.55,.9,.975,-3.645,-3.455],
 [-.275,.275,.485,.555,-2.475,-1.925],[-.275,.275,.52,1.37,-1.965,-1.895],[-.035,.035,.03,.53,-2.235,-2.165],[-.35,.35,0,.06,-2.235,-2.165],[-.035,.035,0,.06,-2.55,-1.85],[.275,.325,.5,.76,-2.375,-2.025],[-.325,-.275,.5,.76,-2.375,-2.025],
 
 [5.875,6.5,0,4.4,-7,7],[-6.5,-5.875,0,4.4,-7,7],[-6.5,-4.25,0,4.4,-7.5,-6.875],[-2.95,6.5,0,4.4,-7.5,-6.875],[5.8,5.9,0,.18,-6.9,6.9],[-5.9,-4.25,0,.18,-6.9,-6.8],[-2.95,5.9,0,.18,-6.9,-6.8],
 [-5.6,-4.77,0,2.06,-6.05,-5.15],[-5.05,-4.35,0,1,-1.65,-.75],[4.2,5,0,.7,-6.4,-5.6],[5.19,5.61,0,1.48,-.01,.41],MB2.body,MB2.stand,MB2.neck]);
const CBD=CB.concat([R_KB,R_DP,R_H2].flatMap((p,i)=>routeBoxes(p,["kb","dp","hd2"][i])));
function colBox(p,a){if(p.x>a[0]&&p.x<a[1]&&p.y>a[2]&&p.y<a[3]&&p.z>a[4]&&p.z<a[5]){const d=[p.x-a[0],a[1]-p.x,p.y-a[2],a[3]-p.y,p.z-a[4],a[5]-p.z];let m=0;for(let i=1;i<6;i++)if(d[i]<d[m])m=i;if(m===0)p.x=a[0];else if(m===1)p.x=a[1];else if(m===2)p.y=a[2];else if(m===3)p.y=a[3];else if(m===4)p.z=a[4];else p.z=a[5]}}
/* kabel simulyatsiyasi uchun kengaytirilgan (kabel qalinligi hisobga olingan) qutilar */
const CM=CR+.002,CBI=CBD.concat(routeBoxes(R_MON,"mon"),routeBoxes(R_MON2,"mon2"),routeBoxes(R_PW,"pw")).map(a=>{const b=[a[0]-CM,a[1]+CM,a[2]<=0?-1:a[2]-CM,a[3]+CM,a[4]-CM,a[5]+CM];b.tag=a.tag;return b});
const CBH=CB.map(a=>[a[0]-.06,a[1]+.06,a[2]-.06,a[3]+.06,a[4]-.06,a[5]+.06]),_o=new V();
function boxOut(x,y,z,a,o){if(x<=a[0]||x>=a[1]||y<=a[2]||y>=a[3]||z<=a[4]||z>=a[5])return false;let m=x-a[0],ax=0,s=-1,v=a[1]-x;if(v<m){m=v;s=1}v=y-a[2];if(v<m){m=v;ax=1;s=-1}v=a[3]-y;if(v<m){m=v;ax=1;s=1}v=z-a[4];if(v<m){m=v;ax=2;s=-1}v=a[5]-z;if(v<m){m=v;ax=2;s=1}o.set(ax===0?s*m:0,ax===1?s*m:0,ax===2?s*m:0);return true}

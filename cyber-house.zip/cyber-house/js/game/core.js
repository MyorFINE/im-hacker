/* ==========================================================
 * Modul: js/game/core.js
 * Iqtisod yadrosi: holat (pul, inventar, joylashtirilgan buyumlar, qurilish),
 * sozlamalar, saqlash/yuklash (localStorage), umumiy yordamchilar.
 * ========================================================== */
const ECO_KEY="hs_eco_v1";
const ECO_DEF=()=>({v:1,money:0,inv:{},placed:[],nextId:1,
 cfg:{jobs:{carry:15,cement:25,lay:40,wall:60,deliver:30},priceMul:1},
 build:{stock:0,mortar:0,pieces:0,stats:{carry:0,cement:0,lay:0,wall:0,deliver:0},order:null},
 hp:false,bench:null,intro:false,spent:0,earned:0});
const ECO=ECO_DEF();
/* aqlli birlashtirish: eski saqlashlarda yo'q maydonlar standart qiymatda qoladi */
function ecoMerge(dst,src){for(const k in src){if(src[k]&&typeof src[k]==="object"&&!Array.isArray(src[k])&&dst[k]&&typeof dst[k]==="object"&&!Array.isArray(dst[k]))ecoMerge(dst[k],src[k]);else dst[k]=src[k]}return dst}
try{const s=JSON.parse(localStorage.getItem(ECO_KEY)||"null");if(s&&s.v===1)ecoMerge(ECO,s)}catch(e){}
const HP={on:!!ECO.hp};      /* quloqchin stol ustiga qo'yilganmi */
let ecoSaveT=0,ecoDirty=false;
function ecoSerialize(){ECO.hp=HP.on;if(window.ECOX&&ECOX.saveBench)try{ECO.bench=ECOX.saveBench()}catch(e){}return JSON.stringify(ECO)}
function ecoSave(now){ecoDirty=true;if(now)ecoFlush()}
function ecoFlush(){if(!ecoDirty)return;ecoDirty=false;try{localStorage.setItem(ECO_KEY,ecoSerialize())}catch(e){}}
setInterval(ecoFlush,1500);
addEventListener("beforeunload",()=>{ecoDirty=true;ecoFlush()});
document.addEventListener("visibilitychange",()=>{if(document.hidden){ecoDirty=true;ecoFlush()}});
/* ---------- pul ---------- */
const fmt$=n=>"$"+Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g," ");
function ecoAdd(n,why){ECO.money=Math.max(0,Math.round(ECO.money+n));if(n>0)ECO.earned+=n;else ECO.spent-=n;ecoSave();if(window.ecoHud)ecoHud()}
function jobPay(k){return Math.max(0,Math.round(+ECO.cfg.jobs[k]||0))}
/* ---------- inventar ---------- */
const invQty=s=>ECO.inv[s]||0;
function invAdd(s,n){ECO.inv[s]=Math.max(0,(ECO.inv[s]||0)+(n||1));if(!ECO.inv[s])delete ECO.inv[s];ecoSave();if(window.ecoHud)ecoHud()}
/* ---------- yordamchilar ---------- */
const gClamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const gRnd=(a,b)=>a+Math.random()*(b-a);
/* yozuvli tekstura: sarlavha taxtalari uchun */
function signTex(lines,w,h,bg,fg,font){const c=cv(w,h),x=c.getContext("2d");x.fillStyle=bg||"#0c141d";x.fillRect(0,0,w,h);x.strokeStyle=fg||"#7fd4ff";x.lineWidth=Math.max(3,h/28);x.strokeRect(x.lineWidth,x.lineWidth,w-x.lineWidth*2,h-x.lineWidth*2);
 x.fillStyle=fg||"#a8efff";x.textAlign="center";x.textBaseline="middle";const L=Array.isArray(lines)?lines:[lines],fs=font||Math.floor(h/(L.length+1.2));
 L.forEach((t,i)=>{x.font="bold "+(i?Math.floor(fs*.72):fs)+"px sans-serif";x.fillText(t,w/2,h*(i+1)/(L.length+1))});return tex(c)}
function signMesh(lines,w,h,bg,fg){const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map:signTex(lines,Math.round(w*256),Math.round(h*256),bg,fg)}));return m}
/* geometriya/material keshi (bir xil o'lchamli qutilar geometriyani bo'lishadi) */
const _gb={},_gm={};
function gbox(w,h,d){const k=w+"|"+h+"|"+d;return _gb[k]||(_gb[k]=new T.BoxGeometry(w,h,d))}
function gmat(c,o){const k=c+(o?JSON.stringify(o):"");return _gm[k]||(_gm[k]=L(c,o))}
function gb(par,w,h,d,c,x,y,z,o){const m=new T.Mesh(gbox(w,h,d),gmat(c,o));m.position.set(x||0,y||0,z||0);par.add(m);return m}
function gcy(par,r1,r2,h,c,x,y,z,seg,o){const m=new T.Mesh(new T.CylinderGeometry(r1,r2,h,seg||12),gmat(c,o));m.position.set(x||0,y||0,z||0);par.add(m);return m}
/* nur — AABB kesishuvi (t masofa yoki -1) */
const _rb=new T.Vector3(),_rd=new T.Vector3();
function rayBox(b,maxT){camera.getWorldDirection(_rd);const o=camera.position;let t0=0,t1=maxT||9;
 for(const ax of["x","y","z"]){const mn=ax==="x"?b.x0:ax==="y"?b.y0:b.z0,mx=ax==="x"?b.x1:ax==="y"?b.y1:b.z1,d=_rd[ax],p=o[ax];
  if(Math.abs(d)<1e-6){if(p<mn||p>mx)return -1}else{let a=(mn-p)/d,c=(mx-p)/d;if(a>c){const q=a;a=c;c=q}t0=Math.max(t0,a);t1=Math.min(t1,c);if(t0>t1)return -1}}
 return t0}

/* ==========================================================
 * Modul: js/game/placement.js
 * INVENTAR va JOYLASHTIRISH tizimi (faqat uyda):
 *  - sotib olingan buyum inventarda; "Joylashtirish" → shaffof ko'rinish (yashil = mumkin,
 *    qizil = mumkin emas) nishon (crosshair) ketidan yuradi, aylantirish, tasdiqlash/bekor;
 *  - to'qnashuv: devor, mebel, boshqa buyumlar, o'yinchi, eshik oldi; buyum yerga yoki
 *    stol/montaj stoli sathiga o'tiradi, boshqa buyum ichiga kirib ketmaydi;
 *  - joylashtirilgan buyumni ko'chirish / inventarga qaytarish; stulga o'tirish;
 *  - kompyuter stoli istalgan joyga qo'yiladi va BO'M-BO'SH turadi: monitor, klaviatura, naushnik, kabel va h.k. hammasi qo'lda joylashtiriladi (avtomatik paydo bo'lish yo'q).
 * ========================================================== */
const PI={};                                             /* id -> {rec,mesh,col} */
const PLM={on:false,sku:null,id:0,orig:null,x:0,y:0,z:0,ry:0,ok:false,msg:"",dock:false,ghost:null,keep:{x:0,z:0,y:0}};
const SIT={on:false,rec:null,k:0,ws:false};
const DESKSLOT={x:0,z:-3.45};
const _gOk=new T.MeshBasicMaterial({color:0x2dff88,transparent:true,opacity:.42,depthWrite:false}),_gNo=new T.MeshBasicMaterial({color:0xff4a4a,transparent:true,opacity:.42,depthWrite:false});
const SLOTM=new T.Mesh(new T.PlaneGeometry(3.9,1.8),new T.MeshBasicMaterial({color:0x2dff88,transparent:true,opacity:.28,depthWrite:false}));SLOTM.rotation.x=-Math.PI/2;SLOTM.position.set(DESKSLOT.x,.03,DESKSLOT.z);SLOTM.visible=false;scene.add(SLOTM);
/* ---------- geometriya ---------- */
function fpBox(sku,x,z,ry,w,d){const f=CAT[sku].fp,c=Math.abs(Math.cos(ry)),s=Math.abs(Math.sin(ry)),W=w||f[0],D=d||f[1],hw=(c*W+s*D)/2,hd=(s*W+c*D)/2;return{x0:x-hw,x1:x+hw,z0:z-hd,z1:z+hd,hw,hd}}
const ov=(a,b,e)=>a.x0<b.x1-(e||0)&&a.x1>b.x0+(e||0)&&a.z0<b.z1-(e||0)&&a.z1>b.z0+(e||0);
function surfaces(skip){const r=[];if(RIG.desk&&!(skip&&skip.dock&&skip.sku==="desk"))r.push({x0:-1.72,x1:1.72,z0:-4.12,z1:-2.78,y:.9,id:"rig"});
 for(const rec of ECO.placed){if(rec===skip||rec.id===(skip&&skip.id))continue;const it=CAT[rec.sku];if(!it.surf||(rec.sku==="desk"&&rec.dock))continue;const b=fpBox(rec.sku,rec.x,rec.z,rec.ry,it.surf.w,it.surf.d);r.push({x0:b.x0,x1:b.x1,z0:b.z0,z1:b.z1,y:rec.y+it.surf.y,id:rec.id})}return r}
const NOPLACE=[[.55,3.1,5.1,7.2],[-4.45,-2.75,-6.9,-5.1]];
/* stol ostiga sig'adigan buyumlar (it.under — kompyuter korpusi): stol oyoqlari, orqa panel va o'ng tortma-javon (x .26..1.14) dan tashqarida bo'lsa ruxsat */
function underDesk(sku,x,z,ry,r){const it=CAT[sku];if(!it.under||r.sku!=="desk")return false;
 const c=Math.cos(r.ry),sn=Math.sin(r.ry),dx=x-r.x,dz=z-r.z,lx=dx*c-dz*sn,lz=dx*sn+dz*c,rel=ry-r.ry,cr=Math.abs(Math.cos(rel)),sr=Math.abs(Math.sin(rel)),hw=(cr*it.fp[0]+sr*it.fp[1])/2,hd=(sr*it.fp[0]+cr*it.fp[1])/2;
 if(lx-hw<-1.62||lx+hw>1.62||lz-hd<-.6||lz+hd>.68)return false;if(lx+hw>.26&&lx-hw<1.14)return false;return true}
function placeCheck(sku,x,y,z,ry,ignoreId,dock){const it=CAT[sku],A=fpBox(sku,x,z,ry),h=it.h,floor=y<.05;
 if(A.x0<-5.8||A.x1>5.8||A.z0<-6.8||A.z1>6.8)return"Devordan tashqarida";
 if(floor&&it.surfOnly)return"Faqat stol ustiga qo'yiladi";
 if(floor){for(const n of NOPLACE)if(A.x0<n[1]&&A.x1>n[0]&&A.z0<n[3]&&A.z1>n[2])return"Eshik oldini to'smang";
  for(const o of cols){if(o.x>900||(o.mine&&o.mine===ignoreId))continue;if(ov(A,{x0:o.x-o.hw,x1:o.x+o.hw,z0:o.z-o.hd,z1:o.z+o.hd},.005)&&!(dock&&o.rigDesk)){if(it.under&&o.mine){const dr=ECO.placed.find(q=>q.id===o.mine);if(dr&&underDesk(sku,x,z,ry,dr))continue}return"Boshqa jism ichiga kirib ketadi"}}
  const q=P.r+.06,cx=gClamp(P.x,A.x0,A.x1),cz=gClamp(P.z,A.z0,A.z1);if(Math.hypot(P.x-cx,P.z-cz)<q&&h>.05)return"Siz turgan joyga qo'yib bo'lmaydi"}
 else{const s=surfaces(null).find(q=>Math.abs(q.y-y)<.02&&A.x0>=q.x0-.02&&A.x1<=q.x1+.02&&A.z0>=q.z0-.02&&A.z1<=q.z1+.02);if(!s)return"Sirt chetidan chiqib ketadi";if(it.surfOnly&&s.id==="rig")return"Bu ish stansiyasi allaqachon jihozlangan";
  if(s.id==="rig"&&typeof DKEEP!=="undefined")for(const k of DKEEP)if(ov(A,{x0:k[0],x1:k[1],z0:k[2],z1:k[3]},.01))return"Monitor/klaviatura joyi band"}
 for(const r of ECO.placed){if(r.id===ignoreId)continue;const o=CAT[r.sku],B=fpBox(r.sku,r.x,r.z,r.ry);if(!ov(A,B,.005))continue;
  if(it.under&&floor&&underDesk(sku,x,z,ry,r))continue;
  if(r.y<y+h-.001&&r.y+o.h>y+.001)return"Boshqa buyum ustiga/ichiga tushadi"}
 return""}
/* ---------- nishon nuqtasi (yer yoki sirt) ---------- */
const _pd=new T.Vector3();
function aimPoint(it){camera.getWorldDirection(_pd);const o=camera.position;if(_pd.y>-.015)return null;let best=null;
 if(!it.surfOnly){const t=-o.y/_pd.y;if(t>.2&&t<8)best={t,x:o.x+_pd.x*t,z:o.z+_pd.z*t,y:0}}
 if(!it.floorOnly){for(const s of surfaces(PLM.orig)){const t=(s.y-o.y)/_pd.y;if(t<.2||t>8)continue;const x=o.x+_pd.x*t,z=o.z+_pd.z*t;if(x>=s.x0-.05&&x<=s.x1+.05&&z>=s.z0-.05&&z<=s.z1+.05&&(!best||t<best.t))best={t,x,z,y:s.y}}}
 return best}
/* ---------- joylashtirish rejimi ---------- */
function plmGhost(sku){if(PLM.ghost)scene.remove(PLM.ghost);const g=CAT[sku].build();g.traverse(m=>{if(m.isMesh)m.material=_gOk});scene.add(g);PLM.ghost=g}
function plmStart(sku,orig){if(REG.cur!=="home"||REG.busy)return toast("Buyumlarni faqat uyda joylashtirish mumkin");if(SIT.on||seated||LF.sleeping)return;
 uiClose(true);PLM.on=true;PLM.sku=sku;PLM.orig=orig||null;PLM.id=orig?orig.id:0;PLM.ok=false;PLM.msg="";PLM.dock=false;
 PLM.ry=orig?orig.ry:Math.round(P.yaw/(Math.PI/2))*Math.PI/2;PLM.x=orig?orig.x:P.x;PLM.z=orig?orig.z:P.z-1.5;PLM.y=orig?orig.y:0;plmGhost(sku);
 $("pl-bar").classList.add("on");$("pl-name").textContent=CAT[sku].name;plmUi();toast("Nishonni joylamoqchi bo'lgan joyga qarating")}
function plmEnd(){PLM.on=false;if(PLM.ghost){scene.remove(PLM.ghost);PLM.ghost=null}SLOTM.visible=false;$("pl-bar").classList.remove("on");PLM.orig=null}
function plmUi(){const e=$("pl-msg");e.textContent=PLM.ok?(PLM.dock?"✔ Ish stansiyasi joyi — monitorlar, klaviatura, kabellar bilan o'rnatiladi":"✔ Joylashtirish mumkin"):"✖ "+(PLM.msg||"Nishonni yer yoki stol sathiga qarating");e.className=PLM.ok?"ok":"no";$("pl-ok").disabled=!PLM.ok}
function plmRotate(d){if(!PLM.on||PLM.dock)return;PLM.ry=(PLM.ry+d*Math.PI/12+Math.PI*4)%(Math.PI*2);if(Math.abs(PLM.ry-Math.round(PLM.ry/(Math.PI/2))*Math.PI/2)<.02)PLM.ry=Math.round(PLM.ry/(Math.PI/2))*Math.PI/2}
function plmTick(){if(!PLM.on)return;const it=CAT[PLM.sku],a=aimPoint(it);let ok=false,msg="";
 if(a){PLM.x=a.x;PLM.z=a.z;PLM.y=a.y;PLM.dock=false;
  /* chetga yaqin joylashtirishni osonlashtirish: devorga yopishish */
  if(!PLM.dock&&PLM.y<.05){const A=fpBox(PLM.sku,PLM.x,PLM.z,PLM.ry);if(A.x0<-5.8&&A.x0>-6.1)PLM.x+=-5.8-A.x0;if(A.x1>5.8&&A.x1<6.1)PLM.x-=A.x1-5.8;if(A.z1>6.8&&A.z1<7.1)PLM.z-=A.z1-6.8;if(A.z0<-6.8&&A.z0>-7.1)PLM.z+=-6.8-A.z0}
  msg=placeCheck(PLM.sku,PLM.x,PLM.y,PLM.z,PLM.ry,PLM.id,PLM.dock);ok=!msg;
  if(ok&&Math.hypot(PLM.x-P.x,PLM.z-P.z)>6.5){ok=false;msg="Juda uzoq"}}
 else{msg="Nishonni yer yoki stol sathiga qarating"}
 PLM.ok=ok;PLM.msg=msg;const g=PLM.ghost;g.position.set(PLM.x,PLM.y,PLM.z);g.rotation.y=PLM.ry;g.visible=!!a;const mt=ok?_gOk:_gNo;if(g.userData.m!==mt){g.userData.m=mt;g.traverse(m=>{if(m.isMesh)m.material=mt})}
 SLOTM.material.opacity=.2+.15*Math.sin(performance.now()/260);SLOTM.material.color.setHex(PLM.dock?0x2dff88:0x4aa8ff);
 if(PLM._o!==ok||PLM._m!==msg||PLM._d!==PLM.dock){PLM._o=ok;PLM._m=msg;PLM._d=PLM.dock;plmUi()}}
function plmConfirm(){if(!PLM.on)return;if(!PLM.ok){toast(PLM.msg||"Bu yerga qo'yib bo'lmaydi");return}
 const sku=PLM.sku;let rec=PLM.orig;if(rec){rec.x=PLM.x;rec.y=PLM.y;rec.z=PLM.z;rec.ry=PLM.ry;rec.dock=PLM.dock&&sku==="desk"}
 else{if(invQty(sku)<1){plmEnd();return}invAdd(sku,-1);rec={id:ECO.nextId++,sku,x:PLM.x,y:PLM.y,z:PLM.z,ry:PLM.ry,dock:PLM.dock&&sku==="desk"};}
 if(!ECO.placed.includes(rec))ECO.placed.push(rec);applyRec(rec);plmEnd();ecoSave(true);feelSnd();toast("✅ "+CAT[sku].name+" joylashtirildi"+(rec.dock?" — ish stansiyasi o'rnatildi!":""));if(window.rigRefresh)rigRefresh()}
function plmCancel(){if(!PLM.on)return;const o=PLM.orig;plmEnd();if(o){applyRec(o);toast("Ko'chirish bekor qilindi")}else toast("Bekor qilindi")}
/* ---------- joylashtirilgan buyumni dunyoga qo'llash / olib tashlash ---------- */
function applyRec(rec){const it=CAT[rec.sku],pi=PI[rec.id]||(PI[rec.id]={rec});pi.rec=rec;
 if(rec.dock)rec.dock=false;      /* eski saqlash: stol endi oddiy, bo'sh stol */
 if(rec.sku==="bench"){rigSetBench(rec,pi);return}
 if(!pi.mesh){pi.mesh=it.build();scene.add(pi.mesh)}pi.mesh.position.set(rec.x,rec.y,rec.z);pi.mesh.rotation.y=rec.ry;pi.mesh.visible=true;
 if(pi.col){colDel(pi.col);pi.col=null}if(it.h>=.4&&rec.y<.05){const b=fpBox(rec.sku,rec.x,rec.z,rec.ry);pi.col=colAdd({x:(b.x0+b.x1)/2,z:(b.z0+b.z1)/2,hw:b.hw,hd:b.hd,mine:rec.id})}}
function unapplyRec(rec){const pi=PI[rec.id];if(rec.sku==="desk"&&rec.dock){rigSetDesk(false);return}if(rec.sku==="bench"){rigUnsetBench(pi);return}
 if(pi){if(pi.mesh){scene.remove(pi.mesh);pi.mesh=null}if(pi.col){colDel(pi.col);pi.col=null}}}
function supportedBy(rec){const it=CAT[rec.sku];if(!it.surf&&!(rec.sku==="desk"&&rec.dock))return[];let sb;if(rec.sku==="desk"&&rec.dock)sb={x0:-1.72,x1:1.72,z0:-4.12,z1:-2.78,y:.9};else{const b=fpBox(rec.sku,rec.x,rec.z,rec.ry,it.surf.w,it.surf.d);sb={x0:b.x0,x1:b.x1,z0:b.z0,z1:b.z1,y:rec.y+it.surf.y}}
 return ECO.placed.filter(r=>r!==rec&&r.y>.05&&Math.abs(r.y-sb.y)<.03&&r.x>sb.x0-.1&&r.x<sb.x1+.1&&r.z>sb.z0-.1&&r.z<sb.z1+.1)}
function canRemove(rec,toInv){const s=supportedBy(rec);if(s.length)return"Avval ustidagi buyumlarni oling ("+CAT[s[0].sku].name+")";
 if(rec.sku==="desk"&&rec.dock&&(!BN.pcAway||S.on||S.hold||seated))return"Avval kompyuter korpusini olib qo'ying (stol ostidan)";
 if(rec.sku==="bench"){if(KT.item||S.hold)return"Qo'lingiz band";if(toInv&&rigBenchBusy())return"Stol ustida korpus/qismlar bor — avval ularni yig'ib bo'ling"}
 if(SIT.on&&SIT.rec===rec)return"Avval turing";return""}
function plmMove(rec){const e=canRemove(rec,false);if(e)return toast(e);unapplyRec(rec);plmStart(rec.sku,rec)}
function plmTake(rec){const e=canRemove(rec,true);if(e)return toast(e);unapplyRec(rec);const i=ECO.placed.indexOf(rec);if(i>=0)ECO.placed.splice(i,1);delete PI[rec.id];invAdd(rec.sku,1);ecoSave(true);toast("🎒 "+CAT[rec.sku].name+" inventarga qaytarildi");if(window.rigRefresh)rigRefresh()}
/* ---------- qaralayotgan buyum ---------- */
function aimedRec(){let b=null,bt=3.5,u=null,ut=3.5;for(const r of ECO.placed){const it=CAT[r.sku],bx=fpBox(r.sku,r.x,r.z,r.ry),t=rayBox({x0:bx.x0,x1:bx.x1,y0:r.y,y1:r.y+it.h,z0:bx.z0,z1:bx.z1},bt);if(t>=0&&t<bt){bt=t;b=r}
  if(it.under){const t2=rayBox({x0:bx.x0,x1:bx.x1,y0:r.y,y1:r.y+it.h,z0:bx.z0,z1:bx.z1},ut);if(t2>=0&&t2<ut){ut=t2;u=r}}}
 /* stol ostidagi korpusni tanlash: nur stol ostidan (tagidan) kirsa — stol emas, korpus tanlanadi */
 if(b&&b.sku==="desk"&&u){camera.getWorldDirection(_pd);if(camera.position.y+_pd.y*bt<.72)return u}return b}
function recTarget(){const r=aimedRec();if(!r)return null;const it=CAT[r.sku];
 if(it.seat)return["E — "+it.name+"ga o'tirish  ·  ✎ tugmasi: ko'chirish/olib tashlash",()=>sitRec(r)];
 return["E — "+it.name+": ko'chirish yoki olib tashlash",()=>itemMenu(r)]}
function itemMenu(r){const it=CAT[r.sku];const e=$("imenu");e.innerHTML='<div class="pn sm"><div class="hd"><b>'+it.name+'</b><button class="x" id="imX">✕</button></div><div class="bt"><button id="imMv">↔ Ko\'chirish</button><button id="imTk">🎒 Inventarga olish</button>'+(it.seat?'<button id="imSt">🪑 O\'tirish</button>':'')+'</div></div>';
 uiOpen("imenu");$("imX").onclick=()=>uiClose();$("imMv").onclick=()=>{uiClose(true);plmMove(r)};$("imTk").onclick=()=>{uiClose(true);plmTake(r)};if(it.seat)$("imSt").onclick=()=>{uiClose(true);sitRec(r)}}
/* ---------- stulga o'tirish ---------- */
function sitRec(r){if(seated||SIT.on||LF.sleeping||PLM.on)return;
 const d=Math.abs(((r.ry-Math.PI)%(Math.PI*2)+Math.PI*3)%(Math.PI*2)-Math.PI);
 if(RIG.desk&&Math.hypot(r.x-0,r.z+2.35)<1.1&&d<.9){RIG.seatRec=r;sit();return}
 SIT.on=true;SIT.rec=r;SIT.k=0;P.x=r.x;P.z=r.z;P.vx=P.vz=0;P.yaw=r.ry+Math.PI;P.pitch=0;document.exitPointerLock&&document.exitPointerLock();$("standBtn").style.display="block";$("cross").style.display="none";toast("🪑 O'tirdingiz — turish: E yoki Esc")}
function standFree(){if(!SIT.on)return;const r=SIT.rec,fx=Math.sin(r.ry),fz=Math.cos(r.ry);let q=findFree("home",r.x-fx*.8,r.z-fz*.8);if(Math.hypot(q[0]-r.x,q[1]-r.z)<.45)q=findFree("home",r.x+fx*.9,r.z+fz*.9);
 SIT.on=false;SIT.rec=null;P.x=q[0];P.z=q[1];P.vx=P.vz=0;$("standBtn").style.display="none";$("cross").style.display="block";if(started&&!mobile)cvEl.requestPointerLock&&cvEl.requestPointerLock()}
/* ---------- inventar oynasi ---------- */
function eatInv(s){const u=CAT[s].use;if(!u||invQty(s)<1)return;if(LF.sleeping||seated||SIT.on)return toast("Hozir iste'mol qilib bo'lmaydi");
 if(u.hunger&&LF.hunger<=0&&!u.thirst)return toast("Qorningiz to'q");if(u.thirst&&!u.hunger&&LF.thirst<=0)return toast("Chanqamagansiz");
 invAdd(s,-1);if(u.hunger)LF.hunger=Math.max(0,LF.hunger-u.hunger);if(u.thirst)LF.thirst=Math.max(0,LF.thirst-u.thirst);toast("😋 "+CAT[s].name+" iste'mol qilindi"+(u.hunger?" (ochlik −"+u.hunger+")":"")+(u.thirst?" (chanqoq −"+u.thirst+")":""));ecoSave(true);feelSnd();invRender()}
let invTab="inv";
function invRender(){const e=$("inv"),rows=CAT_LIST.filter(s=>invQty(s)>0).map(s=>{const it=CAT[s],q=invQty(s);let act="";
  if(it.use)act='<button data-a="eat" data-s="'+s+'">Iste\'mol qilish</button>';
  else if(it.place)act='<button data-a="put" data-s="'+s+'"'+(REG.cur==="home"?"":" disabled")+'>Joylashtirish</button>';
  if(RIG.benchOn&&rigIsBenchItem(s))act+='<button data-a="bench" data-s="'+s+'">Montaj stoliga</button>';
  return'<div class="row"><img src="'+thumb(s)+'" alt=""><div class="inf"><b>'+it.name+'</b><span>'+q+' ta</span></div><div class="ac">'+act+'</div></div>'}).join("")||'<div class="mut pad">Inventar bo\'sh. Qurilishda pul toping va do\'kondan xarid qiling.</div>';
 const j=ECO.cfg.jobs,st=ECO.build.stats;
 const set='<div class="cfg"><h4>⚙ Iqtisod sozlamalari (o\'yin ichida o\'zgartiriladi)</h4>'+[["carry","G'isht tashish"],["cement","Sement tashish"],["lay","G'isht terish (qator)"],["wall","Devor ko'tarish"],["deliver","Material yetkazish"]].map(a=>'<label>'+a[1]+' $<input type="number" min="0" max="9999" data-k="'+a[0]+'" value="'+j[a[0]]+'"></label>').join("")+'<label>Do\'kon narxlari ×<input type="number" min="0.1" max="10" step="0.1" data-k="priceMul" value="'+ECO.cfg.priceMul+'"></label>'+
  '<div class="mut">Bajarilgan: g\'isht '+st.carry+' · sement '+st.cement+' · qator '+st.lay+' · devor '+st.wall+' · yetkazma '+st.deliver+'</div><button id="invReset" class="dng">🗑 Yangi o\'yin (hamma narsani o\'chirish)</button></div>';
 e.innerHTML='<div class="pn"><div class="hd"><b>🎒 INVENTAR</b><span class="mn">'+fmt$(ECO.money)+'</span><button class="x" id="invX">✕</button></div><div class="tabs"><button class="tab'+(invTab==="inv"?" on":"")+'" data-t="inv">Buyumlar</button><button class="tab'+(invTab==="cfg"?" on":"")+'" data-t="cfg">Sozlamalar</button></div><div class="list">'+(invTab==="inv"?rows:set)+'</div></div>';
 e.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{invTab=b.dataset.t;invRender()});$("invX").onclick=()=>uiClose();
 e.querySelectorAll("button[data-a]").forEach(b=>b.onclick=()=>{const a=b.dataset.a,s=b.dataset.s;if(a==="eat")eatInv(s);else if(a==="put")plmStart(s);else if(a==="bench"){rigDeliver(s);invRender()}else if(a==="hp"){rigHeadphones();invRender()}});
 e.querySelectorAll("input[data-k]").forEach(i=>i.onchange=()=>{const k=i.dataset.k,v=Math.max(0,+i.value||0);if(k==="priceMul"){ECO.cfg.priceMul=Math.max(.1,Math.min(10,v||1));if(window.shopLabels)shopLabels()}else ECO.cfg.jobs[k]=Math.round(v);ecoSave(true);if(window.jobHud)jobHud();toast("Saqlandi")});
 const rs=$("invReset");if(rs)rs.onclick=()=>{if(rs.dataset.c){try{localStorage.removeItem(ECO_KEY);localStorage.removeItem("hs_plays")}catch(e){}ecoDirty=false;location.reload()}else{rs.dataset.c=1;rs.textContent="⚠ Aniq o'chirilsinmi? Yana bosing";}}}
function openInv(){if(REG.busy||PLM.on||seated)return;invTab="inv";uiOpen("inv");invRender()}

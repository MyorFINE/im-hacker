/* ==========================================================
 * Modul: js/game/shop.js
 * DO'KON: alohida hudud (ichki zal) — har mahsulot aylanuvchi 3D modelda
 * postamentda turadi; kassa yoki postamentga qarab E bosilsa do'kon oynasi
 * ochiladi (3D ko'rinish rasmi, nomi, narxi, "Sotib olish"). Pul yetmasa
 * xarid bloklanadi. Sotib olingan narsa inventarga tushadi.
 * ========================================================== */
const SHG_=new T.Group();SHG_.position.set(SX,0,SZ);SHG_.visible=false;scene.add(SHG_);REG.groups.shop=SHG_;
const scol=(x,z,hw,hd)=>{const o={x:x+SX,z:z+SZ,hw,hd};REG.cols.shop.push(o);return o};
const SPED=[];
{const fc2=cv(128,128),x=fc2.getContext("2d");x.fillStyle="#cfd5da";x.fillRect(0,0,128,128);x.strokeStyle="#9aa3ab";x.lineWidth=3;x.strokeRect(0,0,64,64);x.strokeRect(64,64,64,64);x.fillStyle="#bfc6cc";x.fillRect(64,0,64,64);x.fillRect(0,64,64,64);
 const fl=new T.Mesh(new T.PlaneGeometry(14.6,11.2),L(0xffffff,{map:tex(fc2,7,6)}));fl.rotation.x=-Math.PI/2;SHG_.add(fl);
 const M=MG(SHG_),wl=M.c(0xe6e2d6),rf=M.c(0xf1efe8),dk=M.c(0x2a3138),wd=M.c(0x8a6a45),cn=M.c(0x1f6fb5),gl=M.c(0x9fd0ee);
 M.box(14.6,.2,11.2,rf,0,3.6,0);M.box(14.6,3.6,.2,wl,0,1.8,-5.7);M.box(14.6,3.6,.2,wl,0,1.8,5.7);M.box(.2,3.6,11.2,wl,-7.4,1.8,0);M.box(.2,3.6,11.2,wl,7.4,1.8,0);
 M.box(14.6,.12,.05,dk,0,.06,-5.58);M.box(.05,.12,11.2,dk,-7.28,.06,0);M.box(.05,.12,11.2,dk,7.28,.06,0);
 for(const x of[-4,0,4])M.box(2.6,.05,.5,M.c(0xfff6dd,true),x,3.47,0);
 /* kassa peshtaxtasi */
 M.box(3.2,1.0,1.0,wd,0,.5,1.6);M.box(3.3,.08,1.1,dk,0,1.04,1.6);M.box(.6,.35,.05,dk,-.7,1.25,1.6);M.box(.5,.3,.4,M.c(0x4a5560),.6,1.2,1.6);
 /* eshik (janub devor) */
 M.box(1.4,2.3,.12,M.c(0x2c3644),0,1.15,5.58);M.box(1.6,.1,.16,dk,0,2.38,5.58);M.box(.12,2.4,.16,dk,-.8,1.2,5.58);M.box(.12,2.4,.16,dk,.8,1.2,5.58);M.box(.04,.04,.04,M.c(0xd9dee3),.5,1.05,5.5);
 /* oynalar (devorlarda dekor) */
 M.box(.06,1.1,2.4,gl,-7.28,2.0,4.4);M.box(.06,1.1,2.4,gl,7.28,2.0,-4.8);
 M.done();
 const sg=(lines,w,h,bg,fg,x,y,z,ry)=>{const m=signMesh(lines,w,h,bg,fg);m.position.set(x,y,z);m.rotation.y=ry||0;SHG_.add(m);return m};
 sg(["DO'KON"],3,.6,"#10233a","#ffd24a",0,3.0,-5.58,0);sg(["KASSA — E bosing"],1.8,.34,"#06140d","#2dff88",0,1.7,1.0,Math.PI);sg(["CHIQISH"],1.2,.3,"#06140d","#2dff88",0,2.7,5.5,Math.PI);
 sg(["MEBEL VA ASBOBLAR"],2.4,.3,"#10233a","#9fe6ff",-7.25,3.0,0,Math.PI/2);sg(["KOMPYUTER QISMLARI"],2.6,.3,"#10233a","#9fe6ff",0,3.0,-5.55,0).position.y=2.55;sg(["OZIQ-OVQAT"],2,.3,"#10233a","#9fe6ff",7.25,3.0,0,-Math.PI/2);
 scol(0,1.6,1.7,.6);
 /* postamentlar */
 const lay=[];["desk","gchair","chair","bench","hp"].forEach((s,i)=>lay.push([s,-6.6,-4+i*2,Math.PI/2]));
 ["case","mobo","cpu","cooler","paste","ram","gpu","ssd","hdd"].forEach((s,i)=>lay.push([s,-6.4+i*1.6,-4.9,0]));
 ["bread","water","apple","sandwich","milk","can"].forEach((s,i)=>lay.push([s,6.6,-4+i*1.4,-Math.PI/2]));
 const pm=gmat(0x3a4552),pt=gmat(0x1f6fb5);
 lay.forEach(a=>{const sku=a[0],px=a[1],pz=a[2],g=new T.Group();g.position.set(px,0,pz);SHG_.add(g);gb(g,.9,.7,.9,0x3a4552,0,.35,0);gb(g,.96,.05,.96,0x1f6fb5,0,.725,0);
  const m=CAT[sku].build();m.updateMatrixWorld(true);const bb=new T.Box3().setFromObject(m),sz=bb.getSize(new T.Vector3()),s=.62/Math.max(sz.x,sz.y,sz.z,.01);m.scale.setScalar(s);m.updateMatrixWorld(true);const b2=new T.Box3().setFromObject(m);
  const hold=new T.Group();hold.position.set(0,.75-b2.min.y,0);const c=b2.getCenter(new T.Vector3());m.position.set(-(c.x-0),0,-(c.z-0));hold.add(m);g.add(hold);
  const lc=cv(256,96),lt=tex(lc),lm=new T.Mesh(new T.PlaneGeometry(.9,.34),new T.MeshBasicMaterial({map:lt}));lm.position.set(0,1.62,0);lm.rotation.y=a[3];g.add(lm);
  scol(px,pz,.5,.5);SPED.push({sku,x:px,z:pz,hold,lc,lt,lm})})}
function shopLabel(p){const x=p.lc.getContext("2d");x.fillStyle="#0c141d";x.fillRect(0,0,256,96);x.strokeStyle="#7fd4ff";x.lineWidth=4;x.strokeRect(3,3,250,90);x.textAlign="center";x.fillStyle="#e8f3fb";x.font="bold 24px sans-serif";x.fillText(CAT[p.sku].name.slice(0,22),128,38);x.fillStyle="#2dff88";x.font="bold 34px sans-serif";x.fillText(fmt$(catPrice(p.sku)),128,78);p.lt.needsUpdate=true}
function shopLabels(){SPED.forEach(shopLabel)}
function shopTick(dt){for(const p of SPED)p.hold.rotation.y+=dt*.7}
const swv=(x,y,z)=>new V(x+SX,y,z+SZ);
function shopTarget(){const c=[];
 const add=(v,r,re,t)=>{if(pick(v,r,re))c.push({a:aim(v),t})};
 add(swv(0,1.3,1.6),1.5,3.6,["E — do'kon oynasini ochish (kassa)",()=>openShop()]);
 for(const p of SPED)add(swv(p.x,1.1,p.z),.55,3.4,["E — «"+CAT[p.sku].name+"» — "+fmt$(catPrice(p.sku)),()=>openShop(p.sku)]);
 add(swv(0,1.2,5.5),1.0,3.4,["E — do'kondan chiqish",()=>regGo("build",SP.buildFromShop[0],SP.buildFromShop[1],SP.buildFromShop[2],"🏗 Qurilish zonasi")]);
 c.sort((a,b)=>a.a-b.a);return c.length?c[0].t:["Kassaga yoki mahsulotga qarab E bosing",null]}
/* ---------- do'kon oynasi ---------- */
let shopCat="mebel";
function openShop(sku){shopCat=sku?CAT[sku].cat:shopCat;uiOpen("shop");shopRender(sku)}
function shopRender(focus){const el=$("shop");
 const tabs=CATS.map(c=>'<button class="tab'+(c[0]===shopCat?" on":"")+'" data-c="'+c[0]+'">'+c[1]+'</button>').join("");
 const cards=CAT_LIST.filter(s=>CAT[s].cat===shopCat&&!CAT[s].noShop).map(s=>{const it=CAT[s],pr=catPrice(s),can=ECO.money>=pr;
  return'<div class="card" id="cd_'+s+'"><img alt="" src="'+thumb(s)+'"><div class="nm">'+it.name+'</div><div class="ds">'+it.desc+'</div><div class="pr">'+fmt$(pr)+'</div><div class="own">Sizda: '+invQty(s)+' ta</div>'+
  '<button class="buy" data-s="'+s+'" '+(can?"":"disabled")+'>'+(can?"Sotib olish":"Pul yetmaydi ("+fmt$(pr-ECO.money)+" kam)")+'</button></div>'}).join("");
 el.innerHTML='<div class="pn"><div class="hd"><b>🛒 DO\'KON</b><span class="mn" id="shopMoney">'+fmt$(ECO.money)+'</span><button class="x" id="shopX">✕</button></div><div class="tabs">'+tabs+'</div><div class="grid" id="shopGrid">'+cards+'</div></div>';
 el.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{shopCat=b.dataset.c;shopRender()});
 el.querySelectorAll(".buy").forEach(b=>b.onclick=()=>shopBuy(b.dataset.s));$("shopX").onclick=()=>uiClose();
 if(focus){const c=$("cd_"+focus);if(c)c.scrollIntoView({block:"center"})}}
function shopBuy(s){const pr=catPrice(s);if(ECO.money<pr){toast("Pul yetmaydi");return}ecoAdd(-pr);invAdd(s,1);ecoSave(true);toast("✅ "+CAT[s].name+" sotib olindi (−"+fmt$(pr)+") — inventarda");const y=$("shopGrid")?$("shopGrid").scrollTop:0;shopRender();if($("shopGrid"))$("shopGrid").scrollTop=y}

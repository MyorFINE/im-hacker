/* ==========================================================
 * Modul: js/game/pc-setup.js
 * Qo'lda yig'iladigan kompyuter ish joyi (avtomatik hech narsa yo'q):
 *  - montaj stolida yig'ilgan korpus inventarga «Yig'ilgan kompyuter» bo'lib tushadi; polga, stol ostiga yoki stol ustiga qo'yiladi;
 *  - kompyuter: quvvat kabeli (rozetkani o'zingiz tanlaysiz) → power tugmasi (E);
 *  - monitor: quvvat kabeli (rozetkaga) + video kabel (kompyuter korpusiga) — bitta kompyuterga 4 tagacha monitor;
 *  - klaviatura: USB kabeli kompyuter korpusiga ulanadi (kabeli o'zida);
 *  - hammasi ulangach monitor/klaviaturaga qarab E → «Kompyuterda ishlash»: Kali ish stoli ulangan monitorlarda
 *    chapdan o'ngga kengaytiriladi (Settings > Displays yoki xrandr), sichqoncha monitorlar orasida uzluksiz o'tadi;
 *  - kompyuterdan vilka uzilsa u o'chadi; monitor/klaviatura/kompyuter ko'chirilsa kabellar qayta yotqiziladi.
 * Holat saqlanadi: rec.cab (quvvat rozetkasi), rec.link (monitor/klaviatura → kompyuter id), rec.vp (video chiqish raqami).
 * ========================================================== */
const PCSET=(()=>{
  const X={lk:{on:false}},NMAX=4,LEN={vid:10,usb:5};
  const pcRec=()=>ECO.placed.find(r=>r.sku==="pcbuilt")||null,meshOf=r=>{const p=PI[r.id];return p&&p.mesh||null};
  const matV=L(0x1d4f9e),matK=L(0x2b2f36);
  const KIND={vid:{src:"monitor",port:MON_VPORT,bz:-.14,mat:matV,name:"Video kabel"},usb:{src:"kbd",port:KB_PORT,bz:-.10,mat:matK,name:"Klaviatura kabeli"}};
  const keyOf=(r,k)=>r.id+":"+k,LK={};
  const hasCable=(r,k)=>!!LK[keyOf(r,k)];

  /* ---------- kabel yo'li: qurilma portidan kompyuter orqa paneligacha ---------- */
  function planLink(src,kind,pc,idx){
    const K=KIND[kind],P0=K.port,sy=src.y+.0125,tw=GEAR.toW,rotW=GEAR.rotW,toL=GEAR.toL;
    const plug=tw(src,P0[0],P0[1],P0[2]-.004),back=tw(src,P0[0],P0[1],K.bz),drop=tw(src,P0[0],0,K.bz);drop[1]=sy;back[1]=src.y+P0[1];
    const pp=kind==="vid"?PC_VID(idx):PC_USB,port=tw(pc,pp[0],pp[1],pp[2]-.004),pb=tw(pc,pp[0],pp[1],-.42);
    const dSrc=GEAR.findDesk(src),dPc=GEAR.findDesk(pc);let vs;
    if(!dSrc)return{err:"Stol ustida emas (kompyuter stoli kerak)"};
    if(dPc){
      if(dPc!==dSrc)return{err:"Kompyuter va "+(kind==="vid"?"monitor":"klaviatura")+" bir stolda bo'lishi kerak (yoki kompyuter polda/stol ostida)"};
      vs=[[plug[0],plug[1],plug[2],0],[back[0],back[1],back[2],.04],[drop[0],sy,drop[2],.05],[pb[0],pc.y+.0125,pb[2],.05],[pb[0],pb[1],pb[2],.04],[port[0],port[1],port[2],0]]}
    else{
      const d0=toL(dSrc,drop[0],drop[2]),hx=1.8,hz=.75,cl=(v,m)=>Math.max(-m+.1,Math.min(m-.1,v));
      const E=[{n:[0,-1],p:[cl(d0[0],hx),-hz]},{n:[0,1],p:[cl(d0[0],hx),hz]},{n:[1,0],p:[hx,cl(d0[1],hz)]},{n:[-1,0],p:[-hx,cl(d0[1],hz)]}];let best=null;
      for(const e of E){const top=tw(dSrc,e.p[0]+e.n[0]*.0125,0,e.p[1]+e.n[1]*.0125),foot=[top[0],top[2]],c=Math.hypot(d0[0]-e.p[0],d0[1]-e.p[1])+Math.hypot(foot[0]-pb[0],foot[1]-pb[2]);if(!best||c<best.c)best={c,top,foot}}
      vs=[[plug[0],plug[1],plug[2],0],[back[0],back[1],back[2],.04],[drop[0],sy,drop[2],.05],[best.top[0],sy,best.top[2],.0125],[best.foot[0],FY,best.foot[1],.05],[pb[0],FY,pb[2],.07],[pb[0],pb[1],pb[2],.04],[port[0],port[1],port[2],0]]}
    vs=GEAR.radii(GEAR.clean(vs));const path=cableRoute(vs);let len=0;for(let i=1;i<path.length;i++)len+=path[i].distanceTo(path[i-1]);
    return{path,len,plug,port}}
  function lkBuild(src,kind,pc,p){const K=KIND[kind],c=new T.CatmullRomCurve3(p.path,false,"centripetal"),mesh=new T.Mesh(new T.TubeGeometry(c,Math.min(1200,Math.max(8,p.path.length*2)),CR*(kind==="vid"?1:.9),8,false),K.mat);scene.add(mesh);
    LK[keyOf(src,kind)]={mesh,plugs:[GEAR.plugMesh(p.plug[0],p.plug[1],p.plug[2],.03,.02,.03,src.ry),GEAR.plugMesh(p.port[0],p.port[1],p.port[2],.03,.02,.03,pc.ry)]}}
  function lkRemove(src,kind){const k=keyOf(src,kind),o=LK[k];if(!o)return;scene.remove(o.mesh);o.mesh.geometry.dispose();o.plugs.forEach(m=>{scene.remove(m);m.geometry.dispose()});delete LK[k]}
  const linked=(pc,sku)=>ECO.placed.filter(r=>r.sku===sku&&pc&&r.link===pc.id);
  /* ulash: src → pc. Muvaffaqiyatli bo'lsa kabel yotqiziladi, aks holda {err} */
  function lkConnect(src,kind,pc){
    const others=linked(pc,KIND[kind].src).filter(r=>r!==src);let idx=0;
    if(kind==="vid"){if(others.length>=NMAX)return{err:"Kompyuterning video chiqishlari band (maksimum "+NMAX+" ta monitor)"};const t=new Set(others.map(r=>r.vp));while(t.has(idx))idx++}
    else if(others.length>=1)return{err:"Kompyuterga bitta klaviatura ulanadi"};
    const p=planLink(src,kind,pc,idx);if(p.err)return p;
    if(p.len>LEN[kind])return{err:"Kabel yetmaydi: "+p.len.toFixed(1)+" m kerak, kabel "+LEN[kind]+" m"};
    lkRemove(src,kind);lkBuild(src,kind,pc,p);src.link=pc.id;if(kind==="vid")src.vp=idx;return{ok:true,len:p.len,idx}}
  /* mavjud ulanishlarni (rec.link) qayta yotqizish — ko'chirish/yuklashdan keyin */
  function relink(r,silent){const kind=r.sku==="monitor"?"vid":r.sku==="kbd"?"usb":null;if(!kind||r.link==null)return;const pc=pcRec();
    if(!pc||pc.id!==r.link||!meshOf(pc)||!meshOf(r))return;const e=lkConnect(r,kind,pc);if(e.err&&!silent)toast("⚠ "+KIND[kind].name+" yotmadi: "+e.err)}
  function relinkAll(){ECO.placed.forEach(r=>{if(!hasCable(r,r.sku==="monitor"?"vid":"usb"))relink(r,true)})}
  function unlink(r,kind,quiet){if(r.link==null)return;lkRemove(r,kind);r.link=null;delete r.vp;if(kind==="vid")invAdd("hdmi",1);ecoSave(true);dirty=true;if(!quiet)toast(kind==="vid"?"⏏ Video kabel ajratildi (inventarga qaytdi)":"⏏ Klaviatura kabeli ajratildi")}

  /* ---------- ulash rejimi (kompyuterga qarang) ---------- */
  const LKM=X.lk;LKM.line=null;
  const lkUi=(ok,msg)=>{LKM.ok=ok;LKM.msg=msg;const e=$("pl-msg");e.textContent=(ok?"✔ ":"✖ ")+msg;e.className=ok?"ok":"no";$("pl-ok").disabled=!ok};
  function lkLine(path,ok){if(LKM.line){scene.remove(LKM.line);LKM.line.geometry.dispose();LKM.line.material.dispose();LKM.line=null}if(!path)return;
    LKM.line=new T.Line(new T.BufferGeometry().setFromPoints(path.map(p=>new V(p.x,p.y+.012,p.z))),new T.LineBasicMaterial({color:ok?0x2dff88:0xff4a4a,transparent:true,depthTest:false}));LKM.line.renderOrder=999;scene.add(LKM.line)}
  function lkStart(src,kind){
    if(LKM.on||GEAR.cm.on||PLM.on||SIT.on||seated||LF.sleeping)return;const pc=pcRec();
    if(!pc)return toast("Avval «Yig'ilgan kompyuter»ni joylashtiring (montaj stolida yig'ib, inventardan qo'ying)");
    if(!GEAR.findDesk(src))return toast("Stol ustida emas (kompyuter stoli kerak)");
    if(kind==="vid"&&src.link==null&&invQty("hdmi")<1)return toast("Avval do'kondan video kabel sotib oling");
    LKM.on=true;LKM.src=src;LKM.kind=kind;LKM.hit=null;LKM.plan=null;$("pl-bar").classList.add("on");$("pl-name").textContent=kind==="vid"?"Video kabel":"Klaviatura kabeli";
    $("pl-l").style.display=$("pl-r").style.display="none";lkUi(false,"Kompyuter korpusiga qarating");toast("🖥 Kompyuter korpusiga qarab E (yoki ✔) bosing — Esc / ✖: bekor")}
  function lkEnd(){if(!LKM.on)return;LKM.on=false;LKM.src=null;LKM.hit=null;lkLine(null);$("pl-l").style.display=$("pl-r").style.display="";if(!PLM.on)$("pl-bar").classList.remove("on")}
  function lkTick(){if(!LKM.on)return;
    if(REG.cur!=="home"||seated||SIT.on||PLM.on||UIOPEN||LF.sleeping||!ECO.placed.includes(LKM.src)){lkEnd();return}
    const r=aimedRec(),hit=r&&r.sku==="pcbuilt"?r:null;if(hit===LKM.hit&&!LKM.dirty)return;LKM.hit=hit;LKM.dirty=false;
    if(!hit){lkLine(null);lkUi(false,"Kompyuter korpusiga qarating");return}
    const src=LKM.src,kind=LKM.kind,others=linked(hit,KIND[kind].src).filter(r=>r!==src);let idx=0,msg,ok=false,p=null;
    if(kind==="vid"){const t=new Set(others.map(r=>r.vp));while(t.has(idx))idx++}
    if(kind==="vid"&&others.length>=NMAX)msg="Video chiqishlar band (maksimum "+NMAX+" ta monitor)";
    else if(kind==="usb"&&others.length>=1)msg="Kompyuterga bitta klaviatura ulanadi";
    else{p=planLink(src,kind,hit,idx);if(p.err){msg=p.err;p=null}else if(p.len>LEN[kind])msg="Kabel yetmaydi: "+p.len.toFixed(1)+" m kerak, kabel "+LEN[kind]+" m";else{ok=true;msg=(kind==="vid"?(idx+1)+"-video chiqish":"USB")+" — kabel "+p.len.toFixed(1)+" m"}}
    lkLine(p&&p.path,ok);lkUi(ok,msg)}
  function lkConfirm(){if(!LKM.on)return;if(!LKM.hit||!LKM.ok){toast(LKM.msg?"✖ "+LKM.msg:"Avval kompyuter korpusiga qarang");return}
    const src=LKM.src,kind=LKM.kind,had=src.link!=null;if(!ECO.placed.includes(src)){lkEnd();return}
    if(kind==="vid"&&!had&&invQty("hdmi")<1){toast("Video kabel yo'q");lkEnd();return}
    const r=lkConnect(src,kind,LKM.hit);if(r.err){toast("✖ "+r.err);return}
    if(kind==="vid"&&!had)invAdd("hdmi",-1);ecoSave(true);dirty=true;lkEnd();feelSnd();
    toast(kind==="vid"?"🖥 Monitor kompyuterga ulandi ("+(r.idx+1)+"-video chiqish, "+r.len.toFixed(1)+" m)":"⌨ Klaviatura kompyuterga ulandi ("+r.len.toFixed(1)+" m)")}
  X.lkTarget=()=>[LKM.hit?(LKM.ok?"E — shu kompyuterga ulash ("+LKM.msg+")":"✖ "+LKM.msg):"Kompyuter korpusiga qarang (Esc — bekor)",LKM.ok?lkConfirm:null];
  {const c0=plmConfirm,x0=plmCancel;plmConfirm=function(){if(LKM.on){lkConfirm();return}c0()};plmCancel=function(){if(LKM.on){lkEnd();toast("Bekor qilindi");return}x0()}}
  addEventListener("keydown",e=>{if(!LKM.on)return;if(e.code==="Escape"){e.preventDefault();e.stopImmediatePropagation();lkEnd();toast("Bekor qilindi")}else if(e.code==="Enter"){e.preventDefault();e.stopImmediatePropagation();lkConfirm()}},true);

  /* ---------- holat: kompyuter ↔ monitorlar (Kali dvigateli S/MPS bilan sinxron) ---------- */
  const liveList=pc=>ECO.placed.filter(r=>r.sku==="monitor"&&pc&&r.link===pc.id&&r.cab!=null&&hasCable(r,"vid")&&meshOf(r));
  /* monitorlarni ko'rish yo'nalishiga nisbatan chapdan o'ngga tartiblash */
  function order(list){if(list.length<2)return list.slice();let nx=0,nz=0;list.forEach(r=>{nx+=Math.sin(r.ry);nz+=Math.cos(r.ry)});const l=Math.hypot(nx,nz)||1;nx/=l;nz/=l;const rx=nz,rz=-nx;
    return list.slice().sort((a,b)=>(a.x*rx+a.z*rz)-(b.x*rx+b.z*rz))}
  const kbOk=pc=>linked(pc,"kbd").some(r=>hasCable(r,"usb")&&meshOf(r));
  let sig="",lastN=-1,hue=0,chk=0;X.cent=null;
  X.live=()=>{const pc=pcRec();return pc&&meshOf(pc)?order(liveList(pc)):[]};
  X.tick=function(dt,now){
    const pc=pcRec(),pm=pc&&meshOf(pc),plug=!!(pm&&pc.cab!=null);
    LKM.on&&lkTick();
    if(S.plug&&!plug&&S.on){S.on=false;S.stage=0;dirty=true;toast("🔌 Kompyuter o'chdi (vilka uzildi)")}
    S.plug=plug;
    const live=pm?order(liveList(pc)).slice(0,NMAX):[];
    MPS.n=live.length;S.mplug=MPS.n>=1;S.mplug2=MPS.n>=2;if(MPS.n!==lastN){lastN=MPS.n;dirty=true}
    /* har kadrda (arzon): har bir monitor ekranining materialini holatiga moslash — GEAR.connect/remove uni o'zgartirib qo'ysa ham qayta tiklanadi */
    {let ch=false;const sk=live.map(r=>r.id).join(",")+"|"+(S.on?1:0);if(sk!==sig){sig=sk;ch=true}
     for(const r of ECO.placed){if(r.sku!=="monitor")continue;const m=meshOf(r);if(!m||!m.userData.screen)continue;monScreens();const i=live.indexOf(r),want=r.cab==null?_scOff:i<0?_scOn:S.on?MPS.mat[i]:_scOff;
      if(m.userData.screen.material!==want){m.userData.screen.material=want;ch=true}}
     if(ch)dirty=true}
    if(pm){const U=pm.userData;if(U.fans){hue=(hue+dt*.4)%1;U.fans.forEach((f,i)=>{if(S.on){f.rotation.z+=dt*(9+i*2);f.material.color.setHSL((hue+i*.18)%1,1,.55)}else f.material.color.setHex(0x111111)})}
      if(U.led)U.led.material.color.setHex(S.on?0x1fe39a:plug?0xff9a1f:0xff3b3b)}
    /* ulangan monitorlar markazi — xona yorug'ligi shu yerda */
    if(live.length){let cx=0,cy=0,cz=0,nx=0,nz=0;live.forEach(r=>{cx+=r.x;cy+=r.y;cz+=r.z;nx+=Math.sin(r.ry);nz+=Math.cos(r.ry)});const k=live.length,l=Math.hypot(nx,nz)||1;X.cent={x:cx/k,y:cy/k+.34,z:cz/k,nx:nx/l,nz:nz/l}}else X.cent=null;
    /* ish rejimida kompyuter yoki monitorlar yo'qolsa turib ketamiz */
    if(MPC.on&&(!pm||MPS.n<1||!plug))stand();
    if(now-chk>1000){chk=now;if(REG.cur==="home")relinkAll()}}
  X.post=function(dt){const c=X.cent;if(c&&MPS.n>0)mLight.position.set(c.x+c.nx*.7,c.y+.1,c.z+c.nz*.7)};

  /* ---------- «Kompyuterda ishlash» rejimi ---------- */
  const MPC={on:false,list:[],camPos:new V(),look:new V(),fov:40,sv:null};X.mpc=MPC;
  function use(){
    if(seated||SIT.on||LF.sleeping||PLM.on||REG.cur!=="home"||LKM.on||GEAR.cm.on)return;
    const pc=pcRec();if(!pc||!meshOf(pc))return toast("Kompyuter joylashtirilmagan");
    if(!S.plug)return toast("Kompyuterga quvvat kabeli ulanmagan (kompyuterga qarab ✎ menyu → 🔌 Kabel ulash)");
    const live=order(liveList(pc)).slice(0,NMAX);
    if(!live.length)return toast("Quvvatlangan va kompyuterga video kabel bilan ulangan monitor yo'q");
    if(!kbOk(pc))return toast("Klaviatura ulanmagan: klaviaturaga qarab E → «Kompyuterga ulash»");
    if(!S.on)return toast("Kompyuter o'chiq — korpusga qarab E (power)");
    const cs=live.map((r,i)=>{const g=meshOf(r);g.updateMatrixWorld(true);const sc=g.userData.screen,c=new V();sc.getWorldPosition(c);return{rec:r,sc,c,i}});
    let nx=0,nz=0;live.forEach(r=>{nx+=Math.sin(r.ry);nz+=Math.cos(r.ry)});let l=Math.hypot(nx,nz)||1;nx/=l;nz/=l;const rx=nz,rz=-nx;
    const ctr=new V();cs.forEach(e=>ctr.add(e.c));ctr.multiplyScalar(1/cs.length);
    let mn=1e9,mx=-1e9;cs.forEach(e=>{const p=e.c.x*rx+e.c.z*rz;mn=Math.min(mn,p);mx=Math.max(mx,p)});const span=mx-mn+.62;
    const d=Math.max(.8,Math.min(2.4,span*.7)),asp=baseW/baseH,t=Math.max(span/2*1.08/(d*asp),.19/d);
    const cam=new V(ctr.x+nx*d,ctr.y+.02,ctr.z+nz*d);
    if(Math.abs(cam.x)>5.7||Math.abs(cam.z)>6.7)return toast("Monitor oldida joy yo'q — monitorlarni devordan uzoqroq suring yoki aylantiring");
    MPC.camPos.copy(cam);MPC.look.copy(ctr);MPC.fov=Math.min(100,Math.max(14,2*Math.atan(t)*180/Math.PI));MPC.list=cs;
    MPC.sv={x:P.x,z:P.z,yaw:P.yaw,pitch:P.pitch};MPC.on=true;window.SEATX=MPC;sit();dirty=true;
    toast("🖥 Kompyuterda ishlayapsiz ("+cs.length+" ta monitor) — turish: Esc yoki «Turish» tugmasi")}
  {const s0=stand;stand=function(){if(!MPC.on){s0();return}const sv=MPC.sv;MPC.on=false;MPC.list=[];window.SEATX=null;dirty=true;s0();if(sv){P.x=sv.x;P.z=sv.z;P.yaw=sv.yaw;P.pitch=sv.pitch}}}
  /* ekran: nur ulangan monitorlarning ekranini kesadi; x = (ekran raqami)*W + u*W */
  const _pl=new T.Plane(),_pt=new T.Vector3(),_n=new T.Vector3();
  const mapUV=(e,u,v)=>({x:(SET.dmode==="dup"||!extOn()&&!dupOn()?0:e.i*W)+u*W,y:(1-v)*H});
  {const sh0=scrHit;scrHit=function(cx,cy,loose){
    if(!MPC.on||!MPC.list.length)return sh0(cx,cy,loose);
    v2.set(cx/baseW*2-1,-(cy/baseH)*2+1);camera.updateMatrixWorld();rc.setFromCamera(v2,camera);
    const hits=rc.intersectObjects(MPC.list.map(e=>e.sc),false),h=hits[0];
    if(h&&h.uv){const e=MPC.list.find(q=>q.sc===h.object);if(e.i===0||extOn()||dupOn())return mapUV(e,h.uv.x,h.uv.y);if(!loose)return null}
    if(!loose)return null;
    let best=null,bd=1e9;
    for(const e of MPC.list){if(e.i>0&&!extOn()&&!dupOn())continue;const m=e.sc;m.updateWorldMatrix(true,false);_n.set(0,0,1).transformDirection(m.matrixWorld);_pl.setFromNormalAndCoplanarPoint(_n,m.getWorldPosition(_pt));
      if(!rc.ray.intersectPlane(_pl,_pt))continue;m.worldToLocal(_pt);const dd=Math.hypot(Math.max(0,Math.abs(_pt.x)-.29),Math.max(0,Math.abs(_pt.y)-.16));
      if(dd<bd){bd=dd;best={e,u:Math.max(0,Math.min(1,_pt.x/.58+.5)),v:Math.max(0,Math.min(1,_pt.y/.32+.5))}}}
    return best?mapUV(best.e,best.u,best.v):null}}

  /* ---------- menyu va E nishonlari ---------- */
  const pcPower=r=>{if(!S.plug){toast("Kompyuterga quvvat kabeli ulanmagan: ✎ menyu → 🔌 Kabel ulash");return}power()};
  {const r0=recTarget;recTarget=function(){const r=aimedRec();
    if(r){
      if(r.sku==="pcbuilt")return r.cab!=null?["E — 🖥 Kompyuter: "+(S.on?"o'chirish":"yoqish")+" (power)  ·  ✎ tugmasi: menyu",()=>pcPower(r)]:["E — 🖥 Kompyuter: avval quvvat kabelini ulang (menyu)",()=>itemMenu(r)];
      if(r.sku==="monitor"&&r.link!=null&&r.cab!=null&&hasCable(r,"vid"))return["E — 🖥 Kompyuterda ishlash  ·  ✎ tugmasi: menyu",use];
      if(r.sku==="kbd"&&r.link!=null&&hasCable(r,"usb"))return["E — ⌨ Kompyuterda ishlash  ·  ✎ tugmasi: menyu",use]}
    return r0()}}
  {const m0=itemMenu;itemMenu=function(r){m0(r);const bt=document.querySelector("#imenu .bt");if(!bt)return;
    const add=(t,f)=>{const b=document.createElement("button");b.textContent=t;b.onclick=()=>{uiClose(true);f()};bt.insertBefore(b,bt.firstChild)};
    if(r.sku==="monitor"){if(r.link!=null&&r.cab!=null&&hasCable(r,"vid"))add("🖥 Kompyuterda ishlash",use);
      if(r.link==null)add("🖥 Kompyuterga video ulash ("+invQty("hdmi")+" ta video kabel bor)",()=>lkStart(r,"vid"));else{add("🖥 Video kabelni boshqa joyga ulash",()=>lkStart(r,"vid"));add("⏏ Video kabelni ajratish",()=>unlink(r,"vid"))}}
    else if(r.sku==="kbd"){if(r.link==null)add("⌨ Kompyuterga ulash (USB)",()=>lkStart(r,"usb"));else{add("⌨ Kompyuterda ishlash",use);add("⏏ Klaviatura kabelini ajratish",()=>unlink(r,"usb"))}}
    else if(r.sku==="pcbuilt"){add("🔧 Ta'mirlash uchun montaj stoliga olib borish",()=>toBench(r));add(S.on?"⏻ O'chirish":"⏻ Yoqish",()=>pcPower(r))}}}
  /* ---------- ko'chirish/olish: kabellar ---------- */
  {const u0=unapplyRec;unapplyRec=function(rec){if(rec.sku==="monitor")lkRemove(rec,"vid");else if(rec.sku==="kbd")lkRemove(rec,"usb");else if(rec.sku==="pcbuilt"){for(const r of ECO.placed){lkRemove(r,"vid");lkRemove(r,"usb")}}u0(rec)}}
  {const a0=applyRec;applyRec=function(rec){a0(rec);if(rec.sku==="pcbuilt")relinkAll();else if(rec.sku==="monitor"||rec.sku==="kbd")relink(rec,true)}}
  {const t0=plmTake;plmTake=function(rec){const mon=rec.sku==="monitor"&&rec.link!=null,id=rec.id,isPc=rec.sku==="pcbuilt";t0(rec);if(ECO.placed.includes(rec))return;
    if(mon){invAdd("hdmi",1);toast("🖥 Video kabel ham inventarga qaytdi")}
    if(rec.sku==="monitor"||rec.sku==="kbd"){rec.link=null;delete rec.vp}
    if(isPc){ECO.placed.forEach(r=>{if(r.link===id){if(r.sku==="monitor")invAdd("hdmi",1);r.link=null;delete r.vp}})}
    ecoSave(true)}}
  /* ---------- montaj stoliga qaytarish / yig'ilgan kompyuterni inventarga olish ---------- */
  function toBench(rec){
    if(S.on)return toast("Avval kompyuterni o'chiring (power tugmasi)");
    if(S.hold||KT.item||LF.cup>0)return toast("Qo'lingiz band");
    const id=rec.id;plmTake(rec);if(ECO.placed.some(r=>r.id===id))return;
    invAdd("pcbuilt",-1);S.on=false;S.stage=0;BN.pcAway=true;BN.root.add(RC);RC.visible=true;takeCase();ecoSave(true);
    toast("🖥 Kompyuter korpusi qo'lingizda — montaj stoliga olib boring")}
  X.convert=function(){RC.visible=false;BN.root.add(RC);RC.scale.set(1,1,1);RC.rotation.set(0,0,0);BN.pcAway=true;BN.where="home";KT.item=null;invAdd("pcbuilt",1);bnSync();
    toast("🖥 Yig'ilgan kompyuter inventarga tushdi — inventardan polga, stol ostiga yoki stol ustiga qo'ying")}
  X.init=function(){if(BN.migPc){delete BN.migPc;if(!pcRec()&&invQty("pcbuilt")<1){invAdd("pcbuilt",1);ecoSave(true)}}relinkAll()};
  X.use=use;X.lkStart=lkStart;X.toBench=toBench;X.unlink=unlink;X.links=LK;
  return X})();

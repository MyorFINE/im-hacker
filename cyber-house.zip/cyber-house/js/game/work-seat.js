/* ==========================================================
 * Modul: js/game/work-seat.js
 * 1) Kresloda o'tirib ISHLASH: kompyuter/laptop oldidagi stulga o'tirsangiz ish rejimi o'zi yoqiladi (ekranga qarab E bosish shart emas).
 *    Esc / «Turish» — ish rejimidan chiqib kresloda o'tirgan holatga qaytadi; yana Esc — o'rningizdan turasiz.
 *    Laptopda ishlash uchun ham kresloda o'tirish SHART.
 * 2) Hayotdagidek qarash: sichqoncha qaysi monitorga o'tsa, personajning boshi ham o'sha monitorga silliq buriladi va uni kattaroq ko'rsatadi.
 * 3) Yaqinlashtirish: Ctrl+F2 (yoki 🔍 tugma, Ctrl+g'ildirak) — sichqoncha turgan monitorga kamera yaqinlashadi (hamma monitorlar va laptop uchun).
 * 4) Stakan: suv ichgach stakanni istalgan stol/yuzaga (kompyuter stoli, ovqat stoli) yoki stul o'rindig'iga qo'yish mumkin.
 * ========================================================== */
const WORKSEAT=(()=>{
  const W0={chair:null,active:false},L={zoomed:false,fovMod:false};
  const UP=new T.Vector3(0,1,0),AX=new T.Vector3(1,0,0),qy=new T.Quaternion(),qp=new T.Quaternion(),zq=new T.Quaternion(),tmpC=new T.PerspectiveCamera(),vtmp=new T.Vector3(),vf=new T.Vector3();
  const sm=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
  /* ---------- 1) kresloda ishlash ---------- */
  const ahead=(ch,x,z,maxd,cos)=>{const dx=x-ch.x,dz=z-ch.z,d=Math.hypot(dx,dz);return d>.05&&d<maxd&&(dx*Math.sin(ch.ry)+dz*Math.cos(ch.ry))/d>cos};
  const laptopFor=ch=>{let b=null,bd=9;for(const r of ECO.placed){if(r.sku!=="laptop"||!PI[r.id]||!PI[r.id].mesh||!ahead(ch,r.x,r.z,1.9,.3))continue;const d=Math.hypot(r.x-ch.x,r.z-ch.z);if(d<bd){bd=d;b=r}}return b?{r:b,d:bd}:null};
  const pcFor=ch=>{let bd=9;for(const r of PCSET.live()){if(!ahead(ch,r.x,r.z,2.9,.3))continue;bd=Math.min(bd,Math.hypot(r.x-ch.x,r.z-ch.z))}return bd<9?bd:null};
  const readyHint=()=>{const ch=SIT.rec;if(!SIT.on||!ch||seated)return null;const lp=laptopFor(ch),pd=pcFor(ch);if(!lp&&pd==null)return null;return lp&&(pd==null||lp.d<pd)?"laptop":"pc"};
  function start(auto){
    if(!SIT.on||!SIT.rec||seated||LF.sleeping||PLM.on)return false;const ch=SIT.rec,lp=laptopFor(ch),pd=pcFor(ch);
    if(!lp&&pd==null){if(!auto)toast("Oldingizda kompyuter yoki laptop yo'q — stulni monitor/laptop qarshisiga qo'ying");return false}
    const useLap=lp&&(pd==null||lp.d<pd);
    SIT.on=false;window.WSEAT=true;try{if(useLap)LAPX.use(lp.r);else PCSET.use()}finally{window.WSEAT=false}
    if(!seated){SIT.on=true;SIT.rec=ch;return false}              /* shart bajarilmadi — sabab toast da; kresloda qolamiz */
    W0.chair=ch;W0.active=true;L.zoomed=false;L.fcOk=false;
    setTimeout(()=>{if(W0.active)toast("👀 Sichqonchani ekran chetiga olib borsangiz atrofga qaraysiz · Ctrl+F2 — yaqinlashtirish")},1800);return true}
  {const s0=sitRec;sitRec=function(r){const was=SIT.on;s0(r);if(SIT.on&&!was)setTimeout(()=>{if(SIT.on&&SIT.rec===r&&!seated)start(true)},500)}}
  {const s0=stand;stand=function(){
     const ch=W0.chair;if(!(W0.active&&ch&&seated)){s0();return}
     W0.active=false;W0.chair=null;L.zoomed=false;s0();                           /* ichki o'rovchilar o'yinchi joyini tiklaydi */
     if(!seated&&ECO.placed.includes(ch)){SIT.on=true;SIT.rec=ch;SIT.k=1;P.x=ch.x;P.z=ch.z;P.vx=P.vz=0;P.yaw=ch.ry+Math.PI;P.pitch=-.12;$("standBtn").style.display="block";$("cross").style.display="none";toast("🪑 Kresloda o'tiribsiz — E: ishlash · Esc: turish")}}}
  const target=()=>{const k=readyHint();if(!k)return null;return[k==="laptop"?"E — 💻 Laptopda ishlash  ·  Esc: turish":"E — 🖥 Kompyuterda ishlash  ·  Esc: turish",()=>start(false)]};
  /* ---------- 2) hayotdagidek qarash: bosh sichqoncha turgan monitorga silliq buriladi + 3) yaqinlashtirish ---------- */
  /* Ko'rsatkich xaritasi doimiy ishchi kameradan (pc-setup.js: MPC.ref) olinadi, shuning uchun bosh harakati ko'rsatkichni siljitmaydi.
     Ko'rinadigan kamera esa ko'rsatkich turgan monitorga qarab burilib, uni kattaroq ko'rsatadi (spring-silliqlash). */
  const G={q:new T.Quaternion(),fov:0,init:false,fc:new T.Vector3(),tq:new T.Quaternion(),ctrl:new T.Vector3()};
  function focusInfo(){
    const X=window.SEATX;if(!X)return null;
    if(X===LAPX){const sc=LAPX.screen;if(!sc)return null;sc.getWorldPosition(vtmp);return{c:vtmp,w:.384,h:.222,single:true}}
    const list=X.list;if(!list||!list.length)return null;let i=0;if(extOn()||dupOn())i=Math.max(0,Math.min(list.length-1,Math.floor(cur.x/W)));if(SET.dmode==="dup")i=0;
    const e=list[i]||list[0];return{c:e.c,w:.708*MON_K,h:.398*MON_K,i,n:list.length}}
  const zbtn=document.createElement("button");zbtn.id="zoomBtn";zbtn.textContent="🔍";zbtn.title="Yaqinlashtirish (Ctrl+F2)";
  zbtn.style.cssText="position:fixed;z-index:8;right:96px;bottom:calc(16px + env(safe-area-inset-bottom,0px));display:none";zbtn.onclick=()=>toggle();document.body.appendChild(zbtn);
  function toggle(){if(!(window.SEATX&&seated))return;L.zoomed=!L.zoomed;toast(L.zoomed?"🔍 Yaqinlashtirildi — sichqoncha turgan monitorga (Ctrl+F2: qaytish)":"🔍 Oddiy ko'rinish")}
  addEventListener("keydown",e=>{if(!(window.SEATX&&seated))return;if(e.key==="F2"&&(e.ctrlKey||e.metaKey||focusId!=="files")){e.preventDefault();e.stopImmediatePropagation();toggle()}},true);
  cvEl.addEventListener("wheel",e=>{if(!(window.SEATX&&seated&&e.ctrlKey))return;e.preventDefault();L.zoomed=e.deltaY<0},{passive:false});
  function look(dt){
    const act=!!(window.SEATX&&seated&&seatT>.6);zbtn.style.display=act?"block":"none";
    if(!act){G.init=false;L.zoomed=false;if(L.fovMod){if(Math.abs(camera.fov-lastFov)>.05){camera.fov+=(lastFov-camera.fov)*Math.min(1,dt*6)}else{camera.fov=lastFov;L.fovMod=false}camera.updateProjectionMatrix()}return}
    const fi=focusInfo();if(!fi)return;const sp=seatT*seatT*(3-2*seatT),kk=1-Math.exp(-dt*(L.zoomed?7:4.5));
    if(!G.init){G.q.copy(camera.quaternion);G.fov=camera.fov;G.fc.copy(fi.c);G.init=true}
    /* bosh biroz oldinga: ekranlar kattaroq, kreslo ko'rinmaydi */
    const base=window.SEATX.camPos,fwd=vf.copy(window.SEATX.look).sub(base).normalize();camera.position.addScaledVector(fwd,Math.min(.45,base.distanceTo(window.SEATX.look)*.2)*sp);
    /* nigoh nuqtasi: ko'rsatkich turgan monitor markaziga (silliq) */
    G.fc.lerp(fi.c,1-Math.exp(-dt*(L.zoomed?9:5)));
    const ctr=window.SEATX.look,gx=fi.single?G.fc.x:ctr.x+(G.fc.x-ctr.x)*.92,gy=fi.single?G.fc.y:ctr.y+(G.fc.y-ctr.y)*.92,gz=fi.single?G.fc.z:ctr.z+(G.fc.z-ctr.z)*.92;
    tmpC.position.copy(camera.position);tmpC.up.set(0,1,0);vtmp.set(gx,gy,gz);tmpC.lookAt(vtmp);G.tq.copy(tmpC.quaternion);G.q.slerp(G.tq,kk);
    const d=Math.max(.25,camera.position.distanceTo(vtmp)),asp=baseW/baseH,m=L.zoomed?1.06:1.42,need=Math.max(6,Math.min(lastFov,2*Math.atan(Math.max(fi.w*m/2/(d*asp),fi.h*(L.zoomed?1.08:1.3)/2/d))*180/Math.PI));
    G.fov+=(need-G.fov)*kk;
    camera.quaternion.slerp(G.q,sp);const f=camera.fov+(G.fov-camera.fov)*sp;if(Math.abs(camera.fov-f)>.01){camera.fov=f;camera.updateProjectionMatrix()}L.fovMod=true}
  {const u1=updateCam;updateCam=function(dt){u1(dt);look(dt)}}
  /* ---------- 4) stakan: istalgan stol/yuzaga yoki stul o'rindig'iga ---------- */
  function cupPoint(){
    const d0=deskPoint();if(d0)return d0;
    camera.getWorldDirection(vf);if(vf.y>-.05)return null;
    const cand=[],hit=(y,x0,x1,z0,z1,id,m)=>{const t=(y-camera.position.y)/vf.y;if(t<.05||t>1.9)return;const x=camera.position.x+vf.x*t,z=camera.position.z+vf.z*t;if(x>x0+m&&x<x1-m&&z>z0+m&&z<z1-m)cand.push({t,x,z,y,id,x0,x1,z0,z1})};
    for(const s of surfaces(null))hit(s.y,s.x0,s.x1,s.z0,s.z1,s.id,.04);
    for(const r of ECO.placed){const it=CAT[r.sku];if(!it.seat)continue;const b=fpBox(r.sku,r.x,r.z,r.ry);hit(r.y+it.seat.h+.02,b.x0+.12,b.x1-.12,b.z0+.12,b.z1-.12,r.id,0)}
    if(!cand.length)return null;cand.sort((a,b)=>a.t-b.t);const c=cand[0];let x=c.x,z=c.z;
    /* stol ustidagi buyumlar (monitor, klaviatura, laptop...) ichiga tushmasin */
    const boxes=ECO.placed.filter(r=>r.id!==c.id&&Math.abs(r.y-c.y)<.03&&CAT[r.sku]).map(r=>fpBox(r.sku,r.x,r.z,r.ry)),R=.05;
    for(let n=0;n<5;n++){let hitB=false;for(const b of boxes){if(x>b.x0-R&&x<b.x1+R&&z>b.z0-R&&z<b.z1+R){hitB=true;const d=[x-(b.x0-R),b.x1+R-x,z-(b.z0-R),b.z1+R-z];let m=0;for(let i=1;i<4;i++)if(d[i]<d[m])m=i;if(m===0)x=b.x0-R;else if(m===1)x=b.x1+R;else if(m===2)z=b.z0-R;else z=b.z1+R}}if(!hitB)break;if(n===4)return null}
    if(x<c.x0+.03||x>c.x1-.03||z<c.z0+.03||z>c.z1-.03)return null;
    const v=new T.Vector3(x,c.y,z);v.sid=c.id;return v}
  {const p0=putCup;putCup=function(p){LF.dcup={x:p.x,y:p.y,z:p.z,full:LF.cup===2,on:p.sid};LF.cup=0;toast("Stakan qo'yildi")}}
  {const d0=dcupUpd;dcupUpd=function(){if(LF.dcup){cupD.position.set(LF.dcup.x,(LF.dcup.y||.9)+.05,LF.dcup.z);cupD.visible=true;cupD.getObjectByName("w").visible=LF.dcup.full}else cupD.visible=false}}
  {const c0=canRemove;canRemove=function(rec,toInv){if(LF.dcup&&LF.dcup.on===rec.id)return"Avval ustidagi stakanni oling";return c0(rec,toInv)}}
  return{target,start,cupPoint,L,toggle}
})();

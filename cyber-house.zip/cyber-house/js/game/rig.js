/* ==========================================================
 * Modul: js/game/rig.js
 * Mavjud "ish stansiyasi" (stol, 2 monitor, klaviatura, kabellar, server rack) va
 * montaj stolini yangi o'yin oqimiga ulaydi. Asl o'yin kodi o'zgarmaydi:
 *  - boshida bular yashirin (uy bo'sh); kompyuter stoli ish stansiyasi joyiga
 *    joylashtirilganda ular paydo bo'ladi (asl kabel/rozetka/Kali mexanikasi bilan);
 *  - montaj stoli (asl ta'mirlash stoli) sotib olinib, istalgan joyga qo'yiladi;
 *    sotib olingan qismlar o'sha stolda ASL 3D mexanika bilan yig'iladi
 *    (anakart → protsessor → termopasta → kuller → RAM → video karta → disklar →
 *    boltlar va kabellar → yon qopqoq) va tayyor korpus stol ostiga o'rnatiladi.
 * ========================================================== */
const RIG={desk:false,benchOn:false,benchRec:null,seatRec:null,atkInit:false,deskObjs:[],chairObjs:[],rackObjs:[],lamps:[]};
const RIGC={};
/* ---------- obyektlarni tasniflash (belgilar + joylashuv bo'yicha) ---------- */
{const bb=new T.Box3(),c=new T.Vector3(),s=new T.Vector3();
 const inf=o=>{try{bb.setFromObject(o)}catch(e){return null}if(bb.isEmpty())return null;bb.getCenter(c);bb.getSize(s);return{x:c.x,y:c.y,z:c.z,sx:s.x,sy:s.y,sz:s.z}};
 const inR=(i,r)=>i.x>=r[0]&&i.x<=r[1]&&i.z>=r[2]&&i.z<=r[3]&&i.sx<5.6&&i.sz<5.6;
 const DESKR=[-2.2,2.2,-4.45,-2.65],CHAIRR=[-.8,.8,-2.75,-1.7],RACKR=[-5.9,-4.3,-6.3,-4.9];
 const vis=a=>(a||[]).filter(o=>o.visible!==false);
 const isChair=i=>Math.abs(i.x)<=.8&&i.z>-2.75;
 vis(GM.m.deskmod).forEach(o=>{const i=inf(o);(i&&isChair(i)?RIG.chairObjs:RIG.deskObjs).push(o)});
 ["techmod","cablemod","portsmod","pickmod"].forEach(k=>vis(GM.m[k]).forEach(o=>{if(o!==pc)RIG.deskObjs.push(o)}));
 vis(GM.m.rackmod).forEach(o=>{const i=inf(o);if(o===rl||(i&&i.x<-4.6&&i.z<-5))RIG.rackObjs.push(o)});
 vis(GM.m.gfxmod).forEach(o=>{if(o.isLight)return;const i=inf(o);if(!i)return;if(inR(i,CHAIRR))RIG.chairObjs.push(o);else if(inR(i,DESKR))RIG.deskObjs.push(o);else if(inR(i,RACKR)&&i.y<2.7)RIG.rackObjs.push(o)});
 if(RIG.rackObjs.indexOf(rl)<0)RIG.rackObjs.push(rl);
 /* chiroqlar: yorug'lik soni o'zgarmasligi uchun (shader qayta kompilyatsiyasiz) faqat intensivlik */
 RIG.lamp=lamp;RIG.lampI=lamp.intensity;RIG.rack=scene.children.find(o=>o.isPointLight&&Math.abs(o.position.x+4.4)<.05&&Math.abs(o.position.z+5.6)<.05)||null;RIG.rackI=RIG.rack?RIG.rack.intensity:0;
 const fc=(x,z,hw,hd)=>cols.find(o=>Math.abs(o.x-x)<1e-6&&Math.abs(o.z-z)<1e-6&&Math.abs(o.hw-hw)<1e-6&&Math.abs(o.hd-hd)<1e-6);
 RIGC.desk=fc(0,-3.45,1.8,.75);RIGC.chair=fc(0,-2.2,.36,.36);RIGC.rack=fc(-5.2,-5.6,.4,.45);if(RIGC.desk)RIGC.desk.rigDesk=true;
 [RIGC.desk,RIGC.chair,RIGC.rack].forEach(o=>{const i=cols.indexOf(o);if(o&&i>=0)cols.splice(i,1)});
 RIG.chairObjs.forEach(o=>o.visible=false);   /* asl stul doim yashirin: o'rniga sotib olingan stullar */}
function rigHideAll(){RIG.deskObjs.forEach(o=>o.visible=false);RIG.rackObjs.forEach(o=>o.visible=false);pc.visible=false;fl.visible=false;hpg.visible=false;RIG.lamp.intensity=0;if(RIG.rack)RIG.rack.intensity=0}
function rigSetDesk(v){if(RIG.desk===v)return;RIG.desk=v;RIG.deskObjs.forEach(o=>o.visible=v);RIG.rackObjs.forEach(o=>o.visible=v);RIG.lamp.intensity=v?RIG.lampI:0;if(RIG.rack)RIG.rack.intensity=v?RIG.rackI:0;
 const add=(o)=>{if(o&&cols.indexOf(o)<0)colAdd(o)},del=o=>{if(o)colDel(o)};if(v){add(RIGC.desk);add(RIGC.rack)}else{del(RIGC.desk);del(RIGC.rack)}
 pc.visible=v&&!BN.pcAway;if(v)pcAwayVis(BN.pcAway);if(!v){fl.visible=false;hpg.visible=false;if(S.hold&&["pc","mon","mon2","usb","hp"].includes(S.hold))S.hold=null}
 for(const k in DV){DV[k].init=0}rigRefresh()}
function rigRefresh(){if(RIG.desk&&invQty("hp")>0)rigHeadphones(true);ecoStatus()}
function rigHeadphones(silent){if(!RIG.desk||invQty("hp")<1)return;invAdd("hp",-1);HP.on=true;IT.hp.P.set(1.2,.907,-3.3);IT.hp.V.set(0,0,0);IT.hp.d=-1;if(!silent)toast("🎧 Naushnik stol ustiga qo'yildi");else toast("🎧 Naushnik stol ustiga qo'yildi");ecoSave(true)}
/* ---------- asl funksiyalarni "stol bor-yo'qligi" bo'yicha cheklash ---------- */
const RIGOK=()=>RIG.desk;
{const f0=flashUpd;flashUpd=function(dt){if(!RIG.desk){fl.visible=false;hpg.visible=false;return}f0(dt);if(!HP.on)hpg.visible=false};
 const c0=cable;cable=function(dt){if(RIG.desk)c0(dt)};
 const d0=deskPoint;deskPoint=function(){return RIG.desk?d0():null};
 const p0=partAt;partAt=function(){return RIG.desk?p0():null};
 const a0=atkTick;atkTick=function(dt){if(!(RIG.desk&&!BN.pcAway)){return}if(!RIG.atkInit){RIG.atkInit=true;SEC.t0=0;SEC.nextAt=0;SEC.k=0}a0(dt)};
 const s0=stand;stand=function(){if(SIT.on){standFree();return}const r=RIG.seatRec;s0();if(r&&!seated){RIG.seatRec=null;const fx=Math.sin(r.ry),fz=Math.cos(r.ry),q=findFree("home",r.x+fx*.2,r.z+fz*.2+.9);P.x=q[0];P.z=q[1];P.yaw=0;P.pitch=-.12}};
 const m0=putMainPc;putMainPc=function(){if(!RIG.desk){toast("Yig'ilgan korpusni joylashtirish va kabellar bilan ulash qo'lda ulash bosqichida qo'shiladi");return}if(BN.paste!=="new"){toast("Termopasta surtilmagan — protsessor qizib ketadi! Avval surting");return}m0();ecoSave(true);ecoStatus()};
 const t0=takeMainPc;takeMainPc=function(){t0();ecoSave(true)}}
/* ---------- montaj stoli (asl ta'mirlash stoli) joylashishi ---------- */
BG.visible=false;
function rigSetBench(rec,pi){const th=rec.ry+Math.PI,c=Math.cos(th),s=Math.sin(th),lx=-2.15,lz=6.35,wx=lx*c+lz*s,wz=-lx*s+lz*c;
 BG.position.set(rec.x-wx,0,rec.z-wz);BG.rotation.y=th;BG.visible=true;BG.updateMatrixWorld(true);
 if(pi.col)colDel(pi.col);const b=fpBox("bench",rec.x,rec.z,rec.ry);pi.col=colAdd({x:(b.x0+b.x1)/2,z:(b.z0+b.z1)/2,hw:b.hw,hd:b.hd,mine:rec.id});RIG.benchOn=true;RIG.benchRec=rec;bnSync()}
function rigUnsetBench(pi){BG.visible=false;RIG.benchOn=false;RIG.benchRec=null;if(pi&&pi.col){colDel(pi.col);pi.col=null}}
const BENCH_DIST=()=>RIG.benchRec?Math.hypot(P.x-RIG.benchRec.x,P.z-RIG.benchRec.z):99;
const BENCH_NEAR=()=>RIG.benchOn&&BENCH_DIST()<3.1;
function rigBenchBusy(){return BN.where!=="none"||Object.values(BN.pt).some(p=>p.at!=="inv")||PASTE.visible}
/* ---------- bo'sh (yangi) stol holati ---------- */
const PKEY={mobo:["mb"],cpu:["cpu"],cooler:["cooler"],gpu:["gpu"],ssd:["ssd"],hdd:["hdd"],ram:["ram1","ram2"]};
const rigIsBenchItem=s=>s==="case"||s==="paste"||!!PKEY[s];
function benchInitEmpty(){for(const k in BN.pt){const p=BN.pt[k];p.in=false;p.at="inv";p.g.visible=false;p.g.scale.set(1,1,1)}
 for(const id in BN.sc)BN.sc[id]=0;for(const k in BN.cab)BN.cab[k]=0;BN.cont.k=12;BN.cont.a=12;BN.cont.v=4;BN.paste="none";BN.lever=0;BN.tool=null;BN.where="none";BN.tilt=1;BN.done=false;BN.pcAway=true;
 RC.visible=false;pc.visible=false;PASTE.visible=false;bnSync()}
function quiet(f){const t=toast;toast=function(){};try{return f()}finally{toast=t}}
function benchFreeHands(){return!KT.item&&!S.hold&&!LF.cup}
function rigCount(){let n=0;if(invQty("case")>0&&BN.where==="none")n++;if(invQty("paste")>0&&!PASTE.visible)n++;for(const s in PKEY){const free=PKEY[s].filter(k=>BN.pt[k].at==="inv").length;n+=Math.min(invQty(s),free)}return n}
function rigDeliver(s){if(!RIG.benchOn)return toast("Avval montaj stolini joylashtiring");if(!benchFreeHands())return toast("Qo'lingiz band");let did=0;
 quiet(()=>{if(s==="case"){if(BN.where==="none"&&invQty("case")>0){invAdd("case",-1);RC.visible=true;BN.where="table";putCaseTable();["psu","fan1","fan2","panel"].forEach(k=>{installPart(k)});["u1","u2","u3","u4","p1","p2","f1_1","f1_2","f1_3","f1_4","f2_1","f2_2","f2_3","f2_4"].forEach(i=>BN.sc[i]=1);bnSync();did++}}
  else if(s==="paste"){if(invQty("paste")>0&&!PASTE.visible){invAdd("paste",-1);PASTE.visible=true;PASTE.position.set(PSPOT[0],BTOP+.0095,PSPOT[1]);BN.root.add(PASTE);did++}}
  else if(PKEY[s]){for(const k of PKEY[s]){if(invQty(s)>0&&BN.pt[k].at==="inv"){invAdd(s,-1);putTable(k);did++}}}});
 if(did){bnSync();ecoSave(true);toast("🔧 Montaj stoliga qo'yildi"+(s==="case"?" — korpusda blok pitaniya, ventilyatorlar va yon qopqoq bor":""))}
 else toast(s==="case"?"Stolda korpus allaqachon bor":"Bu qism uchun joy yo'q yoki allaqachon stolda")}
function rigDeliverAll(){const l=["case","paste"].concat(Object.keys(PKEY));let n=0;for(const s of l){if(!(invQty(s)>0))continue;const b=rigCount();rigDeliver(s);if(rigCount()<b)n++}return n}
function rigBenchTarget(){if(!BENCH_NEAR()||!benchFreeHands())return null;if(tblHit()>=9)return null;const n=rigCount();if(!n)return null;return["E — inventardagi "+n+" ta qismni montaj stoliga qo'yish",()=>rigDeliverAll()]}
/* ---------- bench holatini saqlash/yuklash ---------- */
function saveBench(){const o={pt:{},sc:Object.assign({},BN.sc),cab:Object.assign({},BN.cab),cont:Object.assign({},BN.cont),paste:BN.paste,lever:BN.lever,tilt:BN.tilt,where:BN.where==="hand"?"table":BN.where,pcAway:BN.pcAway,pasteOwned:PASTE.visible};
 for(const k in BN.pt){const p=BN.pt[k];o.pt[k]={in:p.in,at:p.at==="hand"?"table":p.at}}return o}
function loadBench(o){benchInitEmpty();if(!o||!o.pt)return;
 quiet(()=>{Object.assign(BN.sc,o.sc||{});Object.assign(BN.cab,o.cab||{});Object.assign(BN.cont,o.cont||{});BN.paste=o.paste||"none";BN.lever=o.lever?1:0;BN.tilt=o.tilt===0?0:1;BN.pcAway=!!o.pcAway;PASTE.visible=!!o.pasteOwned;
  for(const k in BN.pt){const s=o.pt[k]||{in:false,at:"inv"},p=BN.pt[k];
   if(s.at==="case"){RC.add(p.g);p.g.visible=true;p.g.scale.set(1,1,1);p.g.rotation.set(0,0,0);p.g.position.copy(p.ip);p.in=true;p.at="case"}
   else if(s.at==="table"){putTable(k)}}
  BN.where=o.where||"none";if(!BN.pcAway&&BN.where==="home"){BN.pcAway=true;BN.where="table"}   /* eski saqlash: avtomatik ish stansiyasi yo'q — korpus montaj stoliga qaytadi */
  if(BN.where==="table"){RC.visible=true;putCaseTable()}
  else if(BN.where==="home"){RC.visible=false;BN.root.add(RC)}
  pcAwayVis(BN.pcAway);pc.visible=RIG.desk&&!BN.pcAway;PASTE.position.set(PSPOT[0],BTOP+.0095,PSPOT[1]);BN.root.add(PASTE);bnSync()});
 try{bnCheck&&0}catch(e){}}
window.ECOX={saveBench};

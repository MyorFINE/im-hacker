/* ==========================================================
 * Modul: js/game/regions.js
 * Hududlar: UY (asl xona) · QURILISH zonasi · DO'KON. Har biri sahnada alohida
 * koordinatada (uzoqda) turadi — kamera uzoq tekisligi va tuman tufayli ular
 * bir-biriga ko'rinmaydi va chizilmaydi (FPS tejaladi). Hududlar orasida
 * qisqa fade-out/fade-in bilan teleport qilinadi; to'qnashuv ro'yxati (cols)
 * almashtiriladi; o'yinchi doim bo'sh joyda paydo bo'ladi.
 * ========================================================== */
const BX=300,BZ=0,SX=-300,SZ=0;           /* hudud boshlanish koordinatalari */
const REG={cur:"home",busy:false,colsHome:[],cols:{build:[],shop:[]},groups:{},
 bounds:{build:[BX-20,BX+20,BZ-16,BZ+16.3],shop:[SX-7.3,SX+7.3,SZ-5.6,SZ+5.7]},
 env:{home:{bg:0x0a1118,fog:[0x0a1118,11,26],hemi:[0xa8c4de,0x1b2128,1.05],sun:0},
  build:{bg:0x9ccbef,fog:[0xb5d7f0,17,27],hemi:[0xe3f0ff,0x6e5d46,1.2],sun:.85},
  shop:{bg:0x1b2431,fog:[0x1b2431,15,27],hemi:[0xffffff,0x4e4438,1.4],sun:0}}};
const HEMI=scene.children.find(o=>o.isHemisphereLight);
const SUN=new T.DirectionalLight(0xfff0d0,0);SUN.position.set(BX+30,60,BZ+20);SUN.target.position.set(BX,0,BZ);scene.add(SUN);scene.add(SUN.target);
function regEnv(n){const e=REG.env[n];scene.background.setHex(e.bg);scene.fog.color.setHex(e.fog[0]);scene.fog.near=e.fog[1];scene.fog.far=e.fog[2];
 if(HEMI){HEMI.color.setHex(e.hemi[0]);HEMI.groundColor.setHex(e.hemi[1]);HEMI.intensity=e.hemi[2]}SUN.intensity=e.sun}
/* to'qnashuv ro'yxatini boshqarish: uy bo'lmaganda uy ro'yxati REG.colsHome da saqlanadi */
const colList=()=>REG.cur==="home"?cols:REG.colsHome;
function colAdd(o){colList().push(o);return o}
function colDel(o){const a=colList(),i=a.indexOf(o);if(i>=0)a.splice(i,1)}
function regSwapCols(to){if(REG.cur==="home"&&to!=="home")REG.colsHome=cols.slice();cols.length=0;const src=to==="home"?REG.colsHome:REG.cols[to];for(const o of src)cols.push(o)}
/* nuqta hudud ichida va hech narsaga tegmaydimi */
function regInside(n,x,z){if(n==="home")return x>-5.45&&x<5.45&&z>-6.25&&z<6.4;const b=REG.bounds[n];return x>b[0]+.3&&x<b[1]-.3&&z>b[2]+.3&&z<b[3]-.3}
function freeAt(n,x,z,r){if(!regInside(n,x,z))return false;for(const o of cols){if(o.x>900)continue;const cx=Math.max(o.x-o.hw,Math.min(o.x+o.hw,x)),cz=Math.max(o.z-o.hd,Math.min(o.z+o.hd,z));if(Math.hypot(x-cx,z-cz)<r)return false}return true}
function findFree(n,x,z){const r=P.r+.12;if(freeAt(n,x,z,r))return[x,z];for(let rad=.3;rad<5;rad+=.3)for(let a=0;a<16;a++){const q=a/16*6.2832,px=x+Math.cos(q)*rad,pz=z+Math.sin(q)*rad;if(freeAt(n,px,pz,r))return[px,pz]}return[x,z]}
/* hududga o'tish: fade-out → almashtirish → fade-in */
function regGo(name,x,z,yaw,msg){if(REG.busy||REG.cur===name)return;REG.busy=true;P.vx=P.vz=0;const f=$("eco-fade");f.classList.add("on");
 setTimeout(()=>{regSwapCols(name);REG.cur=name;for(const k in REG.groups)REG.groups[k].visible=(k===name);regEnv(name);
  const q=findFree(name,x,z);P.x=q[0];P.z=q[1];P.vx=P.vz=0;P.yaw=yaw;P.pitch=0;P.bob=0;if(msg)toast(msg);if(window.ecoOnRegion)ecoOnRegion(name);
  setTimeout(()=>{f.classList.remove("on");REG.busy=false},140)},380)}
/* hududga kirish nuqtalari (dunyo koordinatalarida) */
const SP={home:[1.8,5.75,0],build:[BX,BZ+12.4,0],buildFromShop:[BX+9.6,BZ-3,Math.PI/2],shop:[SX,SZ+4.3,0]};
/* ---------- UY ESHIGI (janub devor) ---------- */
const HDOOR=new T.Group();HDOOR.position.set(1.8,0,6.84);scene.add(HDOOR);
{const fr=gmat(0x161b21),lf=gmat(0x2c3644);gb(HDOOR,.12,2.35,.2,0x161b21,-.62,1.175,0);gb(HDOOR,.12,2.35,.2,0x161b21,.62,1.175,0);gb(HDOOR,1.36,.12,.2,0x161b21,0,2.29,0);
 gb(HDOOR,1.12,2.2,.06,0x2c3644,0,1.1,-.02);gb(HDOOR,.12,.04,.05,0xd9dee3,.42,1.05,-.07);gb(HDOOR,.04,.18,.02,0x2b3036,.42,1.05,-.065);gb(HDOOR,.9,1.5,.012,0x233040,0,1.15,-.055);
 const s=signMesh(["QURILISH ZONASI","ESHIK  ▸  PUL ISHLASH"],1.5,.4,"#06140d","#2dff88");s.rotation.y=Math.PI;s.position.set(0,2.62,-.07);HDOOR.add(s)}
const HDOORP=new T.Vector3(1.8,1.1,6.7);
function doorOut(){if(S.hold||KT.item||LF.cup>0)return toast("Avval qo'lingizdagini qo'ying");regGo("build",SP.build[0],SP.build[1],SP.build[2],"🏗 Qurilish zonasi — ishlang, pul toping")}

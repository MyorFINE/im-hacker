/* ==========================================================
 * Modul: js/game/desk-gear.js
 * Istalgan joyga qo'yilgan kompyuter stoli — boshida BO'M-BO'SH. Monitor, klaviatura va kabel do'kondan sotib olinadi.
 *  - monitor/klaviatura faqat stol ustiga qo'yiladi (placement.js: surfOnly);
 *  - monitorga qarab E → «Kabel ulash»: kabel eng yaqin BO'SH rozetkaga ulanadi, bitta rozetkaga bitta kabel;
 *  - kabel realistik yo'l bilan yotadi: monitor orqasi → stol sathi → stol qirrasidan oshadi → pol → devor → rozetka;
 *  - monitor/stol ko'chirilsa yoki olinsa kabel ajraladi (ko'chirishda qayta ulanadi, olishda inventarga qaytadi);
 *  - holat saqlanadi (rec.cab = rozetka raqami).
 * Eski ish stansiyasi joyidagi (yashil belgi) asl kabel mexanikasi o'zgarmagan; uning 3 ta rozetkasi bu yerda band hisoblanadi.
 * ========================================================== */
const GEAR=(()=>{
  const MAXLEN=10,PORT=MON_PORT;
  const rotW=(ry,x,z)=>{const c=Math.cos(ry),s=Math.sin(ry);return[x*c+z*s,-x*s+z*c]};
  const toW=(r,x,y,z)=>{const q=rotW(r.ry,x,z);return[r.x+q[0],r.y+y,r.z+q[1]]};
  const toL=(r,wx,wz)=>{const dx=wx-r.x,dz=wz-r.z,c=Math.cos(r.ry),s=Math.sin(r.ry);return[dx*c-dz*s,dx*s+dz*c]};
  /* ---------- yangi rozetkalar (devor ichki yuzasi: x=±5.875, z=±6.875; balandligi .4) ---------- */
  /* [x, z, devor normali nx, nz]  — eshik (old: x .55..3.1, orqa: x -4.45..-2.75) va eski 3 rozetka oldida emas */
  const SD=[[-1.4,-6.855,0,1],[.9,-6.855,0,1],[4.8,-6.855,0,1],
            [-4.8,6.855,0,-1],[-2,6.855,0,-1],[4.8,6.855,0,-1],
            [-5.855,-4.5,1,0],[-5.855,3.5,1,0],[-5.855,5.5,1,0],
            [5.855,-5,-1,0],[5.855,1.2,-1,0],[5.855,4.8,-1,0]];
  const socks=SD.map((s,i)=>({i,x:s[0],z:s[1],nx:s[2],nz:s[3],used:null,led:null}));
  const plate=L(0xe8e8e8),slot=B(0x222222);
  socks.forEach(s=>{const alongZ=s.nz!==0;
    box(s.x,.4,s.z,alongZ?.2:.04,.3,alongZ?.04:.2,plate);
    box(s.x+s.nx*.015,.4,s.z+s.nz*.015,alongZ?.02:.02,.2,alongZ?.02:.02,slot);
    const led=new T.Mesh(new T.BoxGeometry(.016,.01,.016),new T.MeshBasicMaterial({color:0x2dff88}));led.position.set(s.x+s.nx*.022,.52,s.z+s.nz*.022);scene.add(led);s.led=led});
  const ledSet=s=>s.led.material.color.setHex(s.used!=null?0xff4a4a:0x2dff88);
  /* ---------- marshrut ---------- */
  function findDesk(rec){for(const r of ECO.placed){if(r.sku!=="desk"||r.dock||Math.abs(r.y+.9-rec.y)>.03)continue;const l=toL(r,rec.x,rec.z);if(Math.abs(l[0])<=1.8&&Math.abs(l[1])<=.75)return r}return null}
  function clean(vs){const o=[vs[0]];for(let i=1;i<vs.length;i++){const a=o[o.length-1],b=vs[i],d=Math.hypot(a[0]-b[0],a[1]-b[1],a[2]-b[2]),last=i===vs.length-1;if(d>.02)o.push(b);else if(last){o.pop();o.push(b)}}
    return o}
  function radii(vs){/* burilish radiusini qo'shni to'g'ri qismlarga sig'adigan qilib moslash (yoylar bir-birini yemasin) */
    for(let i=1;i<vs.length-1;i++){const a=vs[i-1],v=vs[i],b=vs[i+1],d1=[v[0]-a[0],v[1]-a[1],v[2]-a[2]],d2=[b[0]-v[0],b[1]-v[1],b[2]-v[2]],l1=Math.hypot(...d1),l2=Math.hypot(...d2);
      const cs=(d1[0]*d2[0]+d1[1]*d2[1]+d1[2]*d2[2])/(l1*l2),ph=Math.acos(Math.max(-1,Math.min(1,cs)));
      let r=vs[i][3]||0;if(ph<.05||ph>2.6)r=0;else{r=Math.min(r,.45*Math.min(l1,l2)/Math.tan(ph/2));if(r<.004)r=0}
      vs[i]=[v[0],v[1],v[2],r]}
    return vs}
  function plan(rec,desk,sk){
    const sy=rec.y+.0125,plug=toW(rec,PORT[0],PORT[1],PORT[2]-.004),back=toW(rec,PORT[0],PORT[1],-.12),drop=toW(rec,PORT[0],0,-.12);drop[1]=sy;back[1]=PORT[1]+rec.y;
    const d0=toL(desk,drop[0],drop[2]),hx=1.8,hz=.75,Sf=[sk.x+sk.nx*.08,sk.z+sk.nz*.08],cl=(v,m)=>Math.max(-m+.1,Math.min(m-.1,v));
    const E=[{n:[0,-1],p:[cl(d0[0],hx),-hz]},{n:[0,1],p:[cl(d0[0],hx),hz]},{n:[1,0],p:[hx,cl(d0[1],hz)]},{n:[-1,0],p:[-hx,cl(d0[1],hz)]}];
    let best=null;
    for(const e of E){const top=toW(desk,e.p[0]+e.n[0]*.0125,0,e.p[1]+e.n[1]*.0125),foot=[top[0],top[2]],c=Math.hypot(d0[0]-e.p[0],d0[1]-e.p[1])+Math.hypot(foot[0]-Sf[0],foot[1]-Sf[1]);
      if(!best||c<best.c)best={c,top,foot,n:rotW(desk.ry,e.n[0],e.n[1])}}
    const F=best.foot;
    let vs=[[plug[0],plug[1],plug[2],0],[back[0],back[1],back[2],.04],[drop[0],sy,drop[2],.05],[best.top[0],sy,best.top[2],.0125],[F[0],FY,F[1],.05],[Sf[0],FY,Sf[1],.08],[Sf[0],.4,Sf[1],.04],[sk.x+sk.nx*.05,.4,sk.z+sk.nz*.05,0]];
    vs=radii(clean(vs));
    const path=cableRoute(vs);let len=0;for(let i=1;i<path.length;i++)len+=path[i].distanceTo(path[i-1]);
    return{path,len,plug,sk}}
  function chooseSocket(rec,desk,pref){
    let best=null;const tried=[];
    const cands=socks.filter(s=>s.used==null||s.used===rec.id);
    if(pref!=null&&socks[pref]&&cands.includes(socks[pref])){const p=plan(rec,desk,socks[pref]);if(p.len<=MAXLEN)return{p}}
    for(const s of cands){const p=plan(rec,desk,s);if(!best||p.len<best.p.len)best={p}}
    if(!best)return{err:"Barcha rozetkalar band (bitta rozetkaga bitta kabel)"};
    if(best.p.len>MAXLEN)return{err:"Eng yaqin bo'sh rozetka ham juda uzoq (kabel "+MAXLEN+" m) — stolni rozetkaga yaqinroq suring"};
    return best}
  /* ---------- mesh ---------- */
  const cabs={};      /* rec.id -> {mesh,plugs,sock} */
  function plugMesh(x,y,z,w,h,d,ry){const m=new T.Mesh(new T.BoxGeometry(w,h,d),plMat);m.position.set(x,y,z);m.rotation.y=ry;scene.add(m);return m}
  function build(rec,p){
    const c=new T.CatmullRomCurve3(p.path,false,"centripetal"),mesh=new T.Mesh(new T.TubeGeometry(c,Math.min(1200,Math.max(8,p.path.length*2)),CR,8,false),cabMat);scene.add(mesh);
    const sk=p.sk,mry=rec.ry,plugs=[plugMesh(p.plug[0]+rotW(mry,0,-.012)[0],p.plug[1],p.plug[2]+rotW(mry,0,-.012)[1],.03,.02,.03,mry),
      plugMesh(sk.x+sk.nx*.037,.4,sk.z+sk.nz*.037,sk.nz!==0?.05:.034,.04,sk.nz!==0?.034:.05,0)];
    cabs[rec.id]={mesh,plugs,sock:sk.i};sk.used=rec.id;ledSet(sk)}
  function remove(rec){const c=cabs[rec.id];if(!c)return;scene.remove(c.mesh);c.mesh.geometry.dispose();c.plugs.forEach(m=>{scene.remove(m);m.geometry.dispose()});const s=socks[c.sock];if(s&&s.used===rec.id){s.used=null;ledSet(s)}delete cabs[rec.id];screen(rec,false)}
  function screen(rec,on){const pi=PI[rec.id];if(pi&&pi.mesh&&pi.mesh.userData.screen)pi.mesh.userData.screen.material=on?_scOn:_scOff}
  /* ---------- ulash / ajratish ---------- */
  function connect(rec,pref){remove(rec);const d=findDesk(rec);if(!d)return{err:"Monitor stol ustida emas"};const r=chooseSocket(rec,d,pref);if(r.err)return r;build(rec,r.p);screen(rec,true);return{ok:true,len:r.p.len,sock:r.p.sk.i}}
  function plugIn(rec){if(invQty("pcord")<1)return toast("Avval do'kondan quvvat kabeli sotib oling");const r=connect(rec,null);if(r.err)return toast(r.err);invAdd("pcord",-1);rec.cab=r.sock;ecoSave(true);toast("🔌 Monitor ulandi — "+(r.sock+1)+"-rozetka, kabel "+r.len.toFixed(1)+" m")}
  function unplug(rec,silent){const had=rec.cab!=null;remove(rec);if(had){rec.cab=null;invAdd("pcord",1);ecoSave(true);if(!silent)toast("⏏ Kabel ajratildi — inventarga qaytdi")}}
  /* ---------- placement.js bilan ulanish (asl funksiyalarni o'rash) ---------- */
  {const a0=applyRec;applyRec=function(rec){a0(rec);if(rec.sku!=="monitor")return;
     if(rec.cab!=null){const r=connect(rec,rec.cab);if(r.err){rec.cab=null;invAdd("pcord",1);ecoSave(true);toast("⚠ Kabel ulanmadi ("+r.err+") — inventarga qaytdi")}else rec.cab=r.sock}else screen(rec,false)};
   const u0=unapplyRec;unapplyRec=function(rec){if(rec.sku==="monitor")remove(rec);u0(rec)};     /* rec.cab saqlanadi: ko'chirilganda qayta ulanadi */
   const t0=plmTake;plmTake=function(rec){const had=rec.sku==="monitor"&&rec.cab!=null;t0(rec);if(had&&!ECO.placed.includes(rec)){invAdd("pcord",1);ecoSave(true);toast("🔌 Kabel ham inventarga qaytdi")}};
   const m0=itemMenu;itemMenu=function(r){m0(r);if(r.sku!=="monitor")return;const bt=document.querySelector("#imenu .bt");if(!bt)return;
     const b=document.createElement("button");b.textContent=r.cab==null?"🔌 Kabel ulash ("+invQty("pcord")+" ta bor)":"⏏ Kabelni ajratish";
     b.onclick=()=>{uiClose(true);if(r.cab==null)plugIn(r);else unplug(r)};bt.insertBefore(b,bt.firstChild)}}
  return{socks,MAXLEN,plan,findDesk,toW,toL,connect,unplug,cabs}
})();

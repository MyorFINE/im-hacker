/* ==========================================================
 * Modul: js/game/catalog.js
 * Mahsulotlar katalogi: nomi, narxi, o'lchami va past poligonli 3D modellari.
 * Modellar bir xil geometriya/material keshini bo'lishadi (xotira va FPS uchun).
 * Barcha modellar: boshlanish nuqtasi — taglik markazi (y=0 — pol), old tomon +z.
 * ========================================================== */
const CATS=[["mebel","🪑 Mebel"],["pc","🖥 Kompyuter qismlari"],["acc","🎧 Aksessuarlar"],["food","🍞 Oziq-ovqat"],["tool","🧰 Asboblar"]];
const CAT={};
function defItem(id,o){o.id=id;CAT[id]=o;return o}
const _M=(c,op)=>gmat(c,op);
/* --- mebel --- */
defItem("desk",{name:"Kompyuter stoli",cat:"mebel",price:80,fp:[3.6,1.5],h:.9,place:true,floorOnly:true,surf:{y:.9,w:3.3,d:1.2},
 desc:"Katta ish stoli. Rozetka va kabel o'tkazilgan yashil joyga qo'yilsa — 2 monitor, klaviatura va sichqoncha bilan ish stansiyasiga aylanadi.",
 build(){const g=new T.Group(),wb=(w,h,d,m,x,y,z)=>{const o=new T.Mesh(gbox(w,h,d),m);o.position.set(x,y,z);g.add(o);return o};
  wb(3.6,.16,1.5,WOOD.top,0,.82,0);[[-1.68,.62],[1.68,.62],[-1.68,-.63],[1.68,-.63]].forEach(a=>wb(.12,.74,.12,WOOD.leg,a[0],.37,a[1]));
  [-1.68,1.68].forEach(x=>wb(.07,.1,1.14,WOOD.dark,x,.67,0));wb(3.2,.5,.04,WOOD.dark,0,.45,-.65);wb(3.4,.04,.05,WOOD.edge,0,.69,-.65);
  /* chap tortma (yopiq): old panel + dasta + ichki quti */
  wb(.8,.12,.03,WOOD.drawer,-1,.66,.745);wb(.2,.02,.03,WOOD.handle,-1,.67,.775);wb(.76,.01,.5,L(0x1f262d),-1,.605,.48);wb(.01,.08,.5,L(0x2b333b),-1.375,.64,.48);wb(.01,.08,.5,L(0x2b333b),-.625,.64,.48);wb(.76,.08,.01,L(0x2b333b),-1,.64,.23);
  wb(.8,.06,1.3,L(0x1f262d),.7,.2,-.02);return g}});
defItem("gchair",{name:"Gaming stul",cat:"mebel",price:60,fp:[.7,.7],h:1.3,place:true,floorOnly:true,seat:{h:.52},
 desc:"Yumshoq gaming stul — balandlik va boshlig'i bilan. O'tirish uchun E.",
 build(){const g=new T.Group();gcy(g,.05,.05,.4,0x666e75,0,.25,0,10);gcy(g,.33,.33,.04,0x1f262d,0,.04,0,5);
  [[.3,.3],[-.3,.3],[.3,-.3],[-.3,-.3],[0,.38]].forEach(a=>gb(g,.06,.05,.06,0x111111,a[0]*.8,.025,a[1]*.8));
  gb(g,.52,.1,.52,0x1f262d,0,.5,0);gb(g,.5,.05,.5,0xc4262e,0,.56,0);gb(g,.5,.72,.1,0x1f262d,0,.92,-.23).rotation.x=-.12;gb(g,.46,.5,.04,0xc4262e,0,.9,-.19).rotation.x=-.12;
  gb(g,.3,.17,.08,0x1f262d,0,1.22,-.26);[-1,1].forEach(q=>{gb(g,.06,.04,.3,0x2a3138,q*.31,.7,0);gb(g,.04,.2,.04,0x2a3138,q*.31,.6,.1)});return g}});
defItem("gchair",{name:"Gaming stul (qizil)",cat:"mebel",price:90,fp:[.72,.78],h:1.3,place:true,floorOnly:true,seat:{h:.48},
 desc:"Kompyuter stuli: qizil gaming kreslo (yuqori sifatli model, charm teksturasi, 5 g'ildirakli taglik). Kompyuter stoli oldiga qo'ying va o'tirish uchun E bosing.",
 build(){return CHAIR.build()}});
defItem("chair",{name:"Oddiy stul",cat:"mebel",price:20,fp:[.5,.5],h:.95,place:true,floorOnly:true,seat:{h:.46},
 desc:"Oddiy yog'och stul. O'tirish uchun E.",
 build(){const g=new T.Group();gb(g,.46,.05,.46,0xa57a4e,0,.45,0);[[-.2,-.2],[.2,-.2],[-.2,.2],[.2,.2]].forEach(a=>gb(g,.04,.45,.04,0x6b4a2c,a[0],.225,a[1]));
  gb(g,.46,.4,.04,0xa57a4e,0,.72,-.21);gb(g,.04,.2,.04,0x6b4a2c,-.2,.58,-.21);gb(g,.04,.2,.04,0x6b4a2c,.2,.58,-.21);return g}});
/* --- asboblar --- */
defItem("bench",{name:"Montaj stoli",cat:"tool",price:50,fp:[2.7,.9],h:.8,place:true,floorOnly:true,surf:{y:.8,w:2.4,d:.7},
 desc:"Kompyuter yig'ish stoli: otvyorkalar, boltlar idishlari va korpus tayanchlari bilan. Sotib olingan qismlar shu stolda yig'iladi.",
 build(){const g=new T.Group(),wb=(w,h,d,m,x,y,z)=>{const o=new T.Mesh(gbox(w,h,d),m);o.position.set(x,y,z);g.add(o);return o};wb(2.6,.05,.8,WOOD.top,0,.775,0);[[-1.25,-.35],[1.25,-.35],[-1.25,.35],[1.25,.35]].forEach(a=>wb(.06,.76,.06,WOOD.leg,a[0],.38,a[1]));
  gb(g,2.5,.03,.7,0x6b5238,0,.25,0);gb(g,.5,.06,.02,0xd8362b,-1.0,.83,.1);gb(g,.5,.06,.02,0x2b6bd6,-.8,.83,.2);[-.4,.1,.6].forEach(x=>gcy(g,.06,.05,.03,0x24282d,x,.82,-.2,12));return g}});
/* --- kompyuter qismlari (haqiqiy o'lchamga yaqin, ko'rinishi uchun biroz kattalashtirilgan) --- */
defItem("laptop",{name:"Laptop (Predator)",cat:"pc",price:150,fp:[.40,.40],h:.30,place:true,surfOnly:true,
 desc:"Kompyuter yig'ilgunga qadar ishlatish uchun. Ekrani PC monitori bilan bir xil — kompyuterdagi barcha amallar (Kali, terminal, IDE, hujum simulyatsiyasi) shu yerda ham bor. Ishlashi uchun alohida quvvat kabeli kerak (rozetkaga ulanadi). Qo'lda ko'tarib yurish mumkin.",
 build(){return LAPTOP.build()}});
defItem("case",{name:"PC Case (korpus)",cat:"pc",price:60,fp:[.28,.58],h:.58,place:true,
 desc:"O'rta tower korpus. Ichida blok pitaniya (PSU), 2 ta ventilyator va shisha yon qopqoq bor.",
 build(){const g=new T.Group(),k=1.25;gb(g,.2*k,.45*k,.45*k,0x14181d,0,.225*k,0);const gl=gb(g,.006,.4*k,.4*k,0x6fb8d8,-.1*k-.002,.23*k,0,{transparent:true,opacity:.35});
  for(let i=0;i<3;i++){const r=new T.Mesh(new T.TorusGeometry(.055*k,.006,6,14),_M(0x2dd4ff));r.position.set(0,(.1+i*.15)*k,.227*k);g.add(r)}gcy(g,.014*k,.014*k,.01,0x2dff88,.06*k,.41*k,.228*k,10).rotation.x=Math.PI/2;return g}});
defItem("mobo",{name:"Motherboard (anakart)",cat:"pc",price:90,fp:[.4,.32],h:.06,place:true,
 desc:"ATX anakart: protsessor uyasi, RAM slotlari, PCIe va SATA portlari.",
 build(){const g=new T.Group(),k=1.3;gb(g,.305*k,.006,.244*k,0x14463a,0,.003,0);gb(g,.06*k,.012,.06*k,0x2c3036,.06*k,.012,-.04*k);gb(g,.036*k,.002,.036*k,0xc9a24a,.06*k,.019,-.04*k);
  [-.01,.01].forEach(z=>gb(g,.14*k,.014,.008*k,0x1a1d21,.06*k,.013,z*k));gb(g,.14*k,.014,.01*k,0x1a1d21,-.04*k,.013,.09*k);gb(g,.05*k,.03,.03*k,0x5d646c,-.09*k,.02,-.08*k);gb(g,.06*k,.02,.014*k,0xe8e8e8,.02*k,.016,.1*k);
  gb(g,.016*k,.012,.02*k,0x8a1f1a,.12*k,.01,.08*k);gb(g,.016*k,.012,.02*k,0x8a1f1a,.09*k,.01,.08*k);return g}});
defItem("cpu",{name:"CPU (protsessor)",cat:"pc",price:120,fp:[.1,.1],h:.02,place:true,
 desc:"Zamonaviy ko'p yadroli protsessor. Anakartga qisqich dastasi bilan o'rnatiladi.",
 build(){const g=new T.Group(),k=2.4;gb(g,.04*k,.002*k,.04*k,0x14463a,0,.002,0);gb(g,.036*k,.003*k,.036*k,0xc4c9d0,0,.006,0);gb(g,.014*k,.0012*k,.014*k,0x8d949c,0,.0105,0);return g}});
defItem("cooler",{name:"CPU Cooler (kuller)",cat:"pc",price:30,fp:[.2,.14],h:.2,place:true,
 desc:"Minora tipidagi protsessor kuller. Termopasta bilan o'rnatiladi.",
 build(){const g=new T.Group(),k=1.5;gb(g,.1*k,.006*k,.06*k,0x9aa1a8,0,.005,0);gb(g,.05*k,.115*k,.036*k,0xb7bec6,0,.07*k,0);for(let i=0;i<5;i++)gb(g,.052*k,.115*k,.0015*k,0x8d949c,0,.07*k,(-.016+i*.008)*k);
  gb(g,.12*k,.12*k,.025*k,0x23272d,0,.07*k,.045*k);gcy(g,.052*k,.052*k,.004,0x15171a,0,.07*k,.0325*k,12).rotation.x=Math.PI/2;return g}});
defItem("paste",{name:"Thermal Paste",cat:"pc",price:8,fp:[.12,.06],h:.06,place:true,
 desc:"Termopasta shprisi. Protsessorga surtiladi — usiz kompyuter qizib ketadi.",
 build(){const g=new T.Group(),k=2;const a=gcy(g,.009*k,.009*k,.075*k,0xf2f2f2,0,.02,0,12);a.rotation.z=Math.PI/2;const b=gcy(g,.0095*k,.0095*k,.02*k,0xd8362b,0,.02,0,12);b.rotation.z=Math.PI/2;
  const c=gcy(g,.004*k,.0025*k,.02*k,0xc9ced3,.047*k,.02,0,8);c.rotation.z=-Math.PI/2;return g}});
defItem("ram",{name:"RAM (xotira moduli)",cat:"pc",price:40,fp:[.22,.06],h:.07,place:true,
 desc:"DDR xotira moduli. Kompyuter to'liq ishlashi uchun 2 ta kerak.",
 build(){const g=new T.Group(),k=1.6;gb(g,.133*k,.006*k,.0016*k,0x14463a,0,.045*k,0).rotation.x=0;gb(g,.125*k,.03*k,.004*k,0x5a6a80,0,.06*k,0);gb(g,.125*k,.004*k,.0045*k,0xd8362b,0,.076*k,0);gb(g,.133*k,.012*k,.003,0xc9a24a,0,.037*k,0);return g}});
defItem("gpu",{name:"GPU (video karta)",cat:"pc",price:150,fp:[.4,.2],h:.2,place:true,
 desc:"Kuchli video karta. PCIe uyasiga o'rnatiladi, qo'shimcha quvvat kabeli kerak.",
 build(){const g=new T.Group(),k=1.4;gb(g,.28*k,.12*k,.002,0x1a1d21,0,.07*k,0);gb(g,.27*k,.115*k,.036*k,0x2a2e35,0,.07*k,.02*k);[-1,1].forEach(q=>{gcy(g,.04*k,.04*k,.004,0x101214,q*.065*k,.07*k,.04*k,12).rotation.x=Math.PI/2;gcy(g,.012*k,.012*k,.006,0x6f7780,q*.065*k,.07*k,.043*k,8).rotation.x=Math.PI/2});
  gb(g,.14*k,.008*k,.002,0xd0a84a,-.02*k,.008*k,0);gb(g,.002,.12*k,.045*k,0xaeb4ba,-.139*k,.07*k,.02*k);return g}});
defItem("ssd",{name:"SSD disk",cat:"pc",price:40,fp:[.17,.12],h:.03,place:true,
 desc:"2.5\" SSD — tez ishga tushish uchun. SATA kabellar bilan ulanadi.",
 build(){const g=new T.Group(),k=1.5;gb(g,.1*k,.007*k,.0699*k,0x2a2f36,0,.0055,0);gb(g,.098*k,.0008,.067*k,0x3a414a,0,.0105,0);gb(g,.07*k,.0009,.034*k,0xdfe6ec,0,.011,.005*k);gb(g,.05*k,.001,.008*k,0x2b6bd6,0,.0115,.005*k);return g}});
defItem("hdd",{name:"HDD disk",cat:"pc",price:30,fp:[.24,.16],h:.05,place:true,
 desc:"3.5\" qattiq disk — katta hajm. SATA ma'lumot va quvvat kabellari bilan ulanadi.",
 build(){const g=new T.Group(),k=1.4;gb(g,.147*k,.026*k,.1016*k,0x9aa1a8,0,.013*k,0);gb(g,.143*k,.0012,.098*k,0x6b7279,0,.027*k,0);gb(g,.09*k,.0014,.075*k,0xe4eaf0,.012*k,.0275*k,0);gb(g,.008*k,.0016,.06*k,0x2b6bd6,.04*k,.028*k,0);return g}});
/* --- aksessuar --- */
defItem("hp",{name:"Headphones (naushnik)",cat:"acc",price:40,fp:[.22,.1],h:.2,place:false,
 desc:"Stereo naushnik. Kompyuter stoli o'rnatilgach, stol ustiga o'zi qo'yiladi (olish, tortmaga solish mumkin).",
 build(){const g=new T.Group(),m=_M(0x20262d);const b=new T.Mesh(new T.TorusGeometry(.085,.012,6,14,Math.PI),m);b.position.y=.04;g.add(b);[-.085,.085].forEach(x=>{const c=new T.Mesh(gbox(.03,.07,.06),m);c.position.set(x,.04,0);g.add(c);const p=new T.Mesh(gbox(.012,.05,.045),_M(0xc4262e));p.position.set(x*.82,.04,0);g.add(p)});g.scale.setScalar(1.15);return g}});

/* --- stol jihozlari: ular endi sotib olinadi, stol ustiga qo'yiladi --- */
let _kbTex=null;
function kbdTexture(){if(_kbTex)return _kbTex;const c=cv(512,180),x=c.getContext("2d");x.fillStyle="#1d2228";x.fillRect(0,0,512,180);
 const rows=[[14,1],[14,1],[13,1.5],[12,2],[8,1]];let y=12;
 rows.forEach((r,i)=>{const n=r[0],kw=(480-(n-1)*5)/n;let xx=16;for(let k=0;k<n;k++){let w=kw;if(i===4&&k===3)w=kw*5.2;else if(i===4&&k>3)w=kw;x.fillStyle="#2c333b";x.fillRect(xx,y,w-3,24);x.fillStyle="#3a424b";x.fillRect(xx+2,y+2,w-7,18);xx+=w+(i===4&&k===3?0:2);if(xx>490)break}y+=30});
 return _kbTex=tex(c)}
const MON_PORT=[.2,.19,-.018];
let _scOff=null,_scOn=null;
function monScreens(){if(_scOff)return;_scOff=B(0x05080c);const c=cv(256,144),x=c.getContext("2d");x.fillStyle="#0a2a4a";x.fillRect(0,0,256,144);x.fillStyle="#7fd4ff";x.font="bold 22px monospace";x.textAlign="center";x.fillText("NO SIGNAL",128,76);x.font="12px monospace";x.fillStyle="#4a7fa0";x.fillText("kompyuter ulanmagan",128,98);_scOn=B(0xffffff);_scOn.map=tex(c)}
defItem("monitor",{name:"Monitor 27\"",cat:"acc",price:110,fp:[.64,.22],h:.52,place:true,surfOnly:true,
 desc:"Stol ustiga qo'yiladi. Yoqish uchun quvvat kabeli kerak: monitorga qarab E → «Kabel ulash» — kabel eng yaqin bo'sh rozetkaga ulanadi (bitta rozetkaga bitta kabel).",
 build(){monScreens();const g=new T.Group();gb(g,.26,.012,.2,0x1a1f25,0,.006,0);gb(g,.05,.19,.05,0x20262d,0,.105,-.04);gb(g,.62,.36,.03,0x14181d,0,.34,0);
  const sc=new T.Mesh(new T.PlaneGeometry(.58,.32),_scOff);sc.position.set(0,.34,.0155);g.add(sc);g.userData.screen=sc;
  gb(g,.03,.02,.012,0x2a2f36,MON_PORT[0],MON_PORT[1],MON_PORT[2]-.004);return g}});
defItem("kbd",{name:"Klaviatura (simsiz)",cat:"acc",price:25,fp:[.48,.17],h:.03,place:true,surfOnly:true,
 desc:"Simsiz klaviatura — stol ustiga qo'yiladi, kabel kerak emas.",
 build(){const g=new T.Group();gb(g,.46,.018,.15,0x1d2228,0,.009,0);const p=new T.Mesh(new T.PlaneGeometry(.44,.14),L(0xffffff,{map:kbdTexture()}));p.rotation.x=-Math.PI/2;p.position.y=.0185;g.add(p);return g}});
defItem("pcord",{name:"Quvvat kabeli (10 m)",cat:"acc",price:12,fp:[.2,.1],h:.05,place:false,
 desc:"Monitor uchun quvvat kabeli. Monitorga qarab E → «Kabel ulash»: eng yaqin bo'sh rozetkaga o'zi ulanadi. Bir rozetkaga bitta kabel.",
 build(){const g=new T.Group(),m=_M(0x0b0d10);const t=new T.Mesh(new T.TorusGeometry(.07,.012,6,18),m);t.rotation.x=Math.PI/2;t.position.y=.012;g.add(t);const t2=t.clone();t2.scale.set(.72,.72,1);t2.position.y=.03;g.add(t2);gb(g,.03,.02,.04,0x2a3037,.09,.02,.0);gb(g,.04,.03,.025,0x2a3037,-.09,.02,0);return g}});
/* --- oziq-ovqat (iste'mol qilinadi) --- */
defItem("bread",{name:"Non",cat:"food",price:3,fp:[.3,.12],h:.1,place:false,use:{hunger:28},desc:"Yangi tandir noni. Ochlikni −28 kamaytiradi.",
 build(){const g=new T.Group();gcy(g,.1,.1,.05,0xd9a85b,0,.025,0,16);gcy(g,.08,.09,.02,0xe8c27a,0,.055,0,16);gcy(g,.03,.03,.052,0xb98640,0,.026,0,10);return g}});
defItem("water",{name:"Suv (shisha)",cat:"food",price:2,fp:[.1,.1],h:.24,place:false,use:{thirst:60},desc:"Toza ichimlik suvi, 0.5 l. Chanqoqni −60 kamaytiradi.",
 build(){const g=new T.Group();gcy(g,.04,.04,.2,0x7fd4ff,0,.11,0,12,{transparent:true,opacity:.7});gcy(g,.014,.014,.03,0x2b6bd6,0,.235,0,8);gb(g,.082,.07,.082,0x2b6bd6,0,.12,0);return g}});
defItem("apple",{name:"Olma",cat:"food",price:4,fp:[.1,.1],h:.09,place:false,use:{hunger:16},desc:"Qizil olma. Ochlikni −16 kamaytiradi.",
 build(){const g=new T.Group(),a=new T.Mesh(new T.SphereGeometry(.045,10,8),_M(0xc4262e));a.position.y=.045;g.add(a);gcy(g,.003,.003,.03,0x5a3a1c,0,.1,0,5);const l=gb(g,.03,.004,.016,0x3aa85c,.014,.1,0);l.rotation.y=.5;return g}});
defItem("sandwich",{name:"Sendvich",cat:"food",price:7,fp:[.14,.14],h:.07,place:false,use:{hunger:42},desc:"Pishloq va go'shtli sendvich. Ochlikni −42 kamaytiradi.",
 build(){const g=new T.Group();gb(g,.13,.02,.13,0xe8c27a,0,.012,0);gb(g,.12,.01,.12,0x3aa85c,0,.027,0);gb(g,.12,.014,.12,0xe8d44a,0,.039,0);gb(g,.12,.016,.12,0xc4584a,0,.054,0);gb(g,.13,.02,.13,0xe8c27a,0,.072,0);return g}});
defItem("milk",{name:"Sut",cat:"food",price:5,fp:[.08,.07],h:.2,place:false,use:{thirst:40,hunger:10},desc:"Sut paketi. Chanqoq −40, ochlik −10.",
 build(){const g=new T.Group();gb(g,.075,.17,.065,0xf2f4f6,0,.095,0);gb(g,.076,.07,.066,0x2b6bd6,0,.08,0);const t=gb(g,.075,.04,.04,0xf2f4f6,0,.205,0);t.rotation.x=.0;return g}});
defItem("can",{name:"Konserva (tushonka)",cat:"food",price:6,fp:[.09,.09],h:.1,place:false,use:{hunger:34},desc:"Go'shtli konserva. Ochlikni −34 kamaytiradi.",
 build(){const g=new T.Group();gcy(g,.04,.04,.1,0x9aa4ad,0,.055,0,14);gcy(g,.041,.041,.06,0xc4262e,0,.055,0,14);gcy(g,.043,.043,.006,0xc0c6cc,0,.108,0,14);return g}});
const CAT_LIST=Object.keys(CAT);
const catPrice=s=>Math.max(1,Math.round(CAT[s].price*(+ECO.cfg.priceMul||1)));
/* --- 3D ko'rinish rasmlari: alohida kichik sahnada bir marta renderlanadi --- */
const TH={rt:null,sc:null,cam:null,cache:{}};
function thumb(sku){if(TH.cache[sku])return TH.cache[sku];let url="";
 try{if(!TH.rt){TH.sc=new T.Scene();TH.sc.background=new T.Color(0x14283a);TH.sc.add(new T.HemisphereLight(0xdfeeff,0x3a3f46,1.15));const d=new T.DirectionalLight(0xffffff,.85);d.position.set(2,4,3);TH.sc.add(d);
   TH.cam=new T.PerspectiveCamera(30,1,.01,50);TH.rt=new T.WebGLRenderTarget(160,160);TH.rt.texture.encoding=T.sRGBEncoding}
  const g=CAT[sku].build();g.rotation.y=-.6;g.updateMatrixWorld(true);const bb=new T.Box3().setFromObject(g),sz=bb.getSize(new T.Vector3()),c=bb.getCenter(new T.Vector3()),r=Math.max(sz.x,sz.y,sz.z)||1;
  g.position.sub(c);const hold=new T.Group();hold.add(g);TH.sc.add(hold);TH.cam.position.set(0,r*.55,r*2.35);TH.cam.lookAt(0,0,0);
  const prev=renderer.getRenderTarget();renderer.setRenderTarget(TH.rt);renderer.clear();renderer.render(TH.sc,TH.cam);const buf=new Uint8Array(160*160*4);renderer.readRenderTargetPixels(TH.rt,0,0,160,160,buf);renderer.setRenderTarget(prev);TH.sc.remove(hold);
  const cvs=document.createElement("canvas");cvs.width=cvs.height=160;const x=cvs.getContext("2d"),im=x.createImageData(160,160);for(let y=0;y<160;y++)im.data.set(buf.subarray((159-y)*640,(160-y)*640),y*640);x.putImageData(im,0,0);url=cvs.toDataURL("image/png")}
 catch(e){const cvs=document.createElement("canvas");cvs.width=cvs.height=160;const x=cvs.getContext("2d");x.fillStyle="#14283a";x.fillRect(0,0,160,160);x.fillStyle="#7fd4ff";x.font="bold 22px sans-serif";x.textAlign="center";x.fillText(CAT[sku].name.slice(0,10),80,86);url=cvs.toDataURL()}
 return TH.cache[sku]=url}

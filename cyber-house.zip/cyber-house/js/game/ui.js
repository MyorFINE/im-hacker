/* ==========================================================
 * Modul: js/game/ui.js
 * Iqtisod interfeysi (DOM): pul paneli, vazifalar, progress bar, pul animatsiyasi,
 * joylashtirish tugmalari, inventar/do'kon/buyum oynalari, fade qatlami.
 * Telefon va kompyuter ekranlariga moslashadi (css/economy.css).
 * ========================================================== */
{const d=document.createElement("div");d.id="eco-root";
 d.innerHTML='<div id="eco-bar"><span id="eco-money">$0</span><button class="ui" id="eco-inv" title="Inventar (I)">🎒</button></div>'+
 '<div id="eco-job"></div><div id="eco-prog"><i><b></b></i><span></span></div>'+
 '<div id="pl-bar"><div id="pl-info"><b id="pl-name"></b><span id="pl-msg"></span></div><div id="pl-btn"><button class="ui" id="pl-l">⟲</button><button class="ui" id="pl-r">⟳</button><button class="ui ok" id="pl-ok">✔ Tasdiqlash</button><button class="ui no" id="pl-no">✖ Bekor</button></div></div>'+
 '<button class="ui" id="eco-edit">✎</button>'+
 '<div class="eco-modal" id="shop"></div><div class="eco-modal" id="inv"></div><div class="eco-modal" id="imenu"></div><div id="eco-fade"></div>';
 document.body.appendChild(d)}
let UIOPEN=null;
function uiOpen(id){if(UIOPEN)uiClose(true);UIOPEN=id;$(id).classList.add("on");document.exitPointerLock&&document.exitPointerLock();document.body.classList.add("eco-modal-open")}
function uiClose(quiet){if(!UIOPEN)return;$(UIOPEN).classList.remove("on");UIOPEN=null;document.body.classList.remove("eco-modal-open");if(!quiet&&started&&!mobile&&!seated)cvEl.requestPointerLock&&cvEl.requestPointerLock()}
document.querySelectorAll(".eco-modal").forEach(m=>m.addEventListener("pointerdown",e=>{if(e.target===m)uiClose()}));
function ecoHud(){const e=$("eco-money");if(e)e.textContent="💰 "+fmt$(ECO.money)}
function popMoney(n,txt){const e=document.createElement("div");e.className="eco-pop";e.innerHTML="<b>+"+fmt$(n)+"</b><span>"+(txt||"")+"</span>";document.body.appendChild(e);setTimeout(()=>e.remove(),1900)}
function progShow(label,u){const p=$("eco-prog");p.classList.add("on");p.querySelector("b").style.width=Math.round(gClamp(u,0,1)*100)+"%";p.querySelector("span").textContent=label}
function progHide(){$("eco-prog").classList.remove("on")}
$("eco-inv").onclick=()=>openInv();
$("pl-l").onclick=()=>plmRotate(-1);$("pl-r").onclick=()=>plmRotate(1);$("pl-ok").onclick=()=>plmConfirm();$("pl-no").onclick=()=>plmCancel();
$("eco-edit").onclick=()=>{const r=aimedRec();if(r)itemMenu(r)};

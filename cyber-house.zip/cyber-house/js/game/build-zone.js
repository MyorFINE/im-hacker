/* ==========================================================
 * Modul: js/game/build-zone.js
 * QURILISH ZONASI (alohida hudud) va pul ishlash vazifalari:
 *  1) G'isht tashish  2) Sement tashish  3) G'isht terish (qator)
 *  4) Devor ko'tarish (to'liq devor)  5) Materiallarni kerakli joyga yetkazish
 * Har vazifa — vaqtli harakat (progress bar), animatsiya va tugagach pul.
 * G'isht/devor/xalta — InstancedMesh (kam draw-call). Holat ECO.build da saqlanadi.
 * ========================================================== */
const BLG=new T.Group();BLG.position.set(BX,0,BZ);BLG.visible=false;scene.add(BLG);REG.groups.build=BLG;
const bwv=(x,y,z)=>new V(x+BX,y,z+BZ);
const bcol=(x,z,hw,hd)=>{const o={x:x+BX,z:z+BZ,hw,hd};REG.cols.build.push(o);return o};
const BRK={w:.5,h:.2,d:.25},WALLZ=-9,WALLY=.12,ROWS=6;
/* ---------- statik muhit (rang bo'yicha birlashtirilgan) ---------- */
{const gc=cv(256,256),x=gc.getContext("2d");x.fillStyle="#7a6a4e";x.fillRect(0,0,256,256);for(let i=0;i<900;i++){x.fillStyle=Math.random()<.5?"#6c5d44":Math.random()<.5?"#8a7a5c":"#5f7a3a";x.fillRect(Math.random()*256,Math.random()*256,2+Math.random()*5,2+Math.random()*4)}
 const gm=new T.Mesh(new T.PlaneGeometry(46,38),L(0xffffff,{map:tex(gc,10,8)}));gm.rotation.x=-Math.PI/2;gm.position.y=-.01;BLG.add(gm);
 const M=MG(BLG),c=k=>M.c(k),wood=c(0x8a6a45),dwood=c(0x5a4630),stone=c(0xb9bcc0),dark=c(0x2a3138),steel=c(0x7d8791),yel=c(0xe0b320),red=c(0xb5523b),wall=c(0xd8d2c2),roof=c(0x3b4a5c),grn=c(0x2f7a43),trunk=c(0x5a3a1c),sand=c(0xd9c38a),pipeC=c(0x6f7780);
 /* panjara (chegara) */
 for(let i=-20;i<=20;i+=2){M.box(.12,1.3,.12,dwood,i,.65,-16);M.box(.12,1.3,.12,dwood,i,.65,16.3)}for(let i=-16;i<=16;i+=2){M.box(.12,1.3,.12,dwood,-20,.65,i);M.box(.12,1.3,.12,dwood,20,.65,i)}
 [.5,1.0].forEach(y=>{M.box(40,.07,.05,wood,0,y,-16);M.box(40,.07,.05,wood,0,y,16.3);M.box(.05,.07,32.3,wood,-20,y,.15);M.box(.05,.07,32.3,wood,20,y,.15)});
 /* asos plita (devor ostida) */
 M.box(4.4,.12,1.1,stone,0,.06,WALLZ);M.box(4.6,.04,1.3,dark,0,.02,WALLZ);
 /* g'isht to'plamlari (manba): pallet + g'isht uyumlari */
 M.box(3,.12,1.9,wood,-15,.06,5.5);
 /* sement qoplari uyumi */
 M.box(2.4,.12,1.6,wood,-15,.06,-2.5);
 /* taxta, qum, quvur manbalari */
 M.box(3.2,.12,1.2,wood,8.5,.06,10.5);for(let k=0;k<5;k++)M.box(3,.12,.9,c(0xc99a5b),8.5,.18+k*.13,10.5);
 M.box(2.6,.1,1.6,wood,13,.05,10.5);for(let i=0;i<2;i++)for(let k=0;k<3;k++)M.box(1.1,.3,.7,sand,12.4+i*1.2,.25+k*.3,10.5);
 M.box(2.8,.1,1.1,wood,-6,.05,10.5);for(let k=0;k<3;k++)for(let i=0;i<4;i++)M.add(new T.CylinderGeometry(.14,.14,2.4,8),pipeC,-7+i*.5+(k%2)*.25,.2+k*.22,10.5,0,0,Math.PI/2);
 /* iskala (plank yetkazish nuqtasi) */
 for(const x of[-1.4,1.4])for(const z of[-.7,.7]){M.box(.08,2.2,.08,steel,10+x,1.1,-11.4+z)}[.6,1.4,2.2].forEach(y=>{M.box(3,.06,1.6,wood,10,y,-11.4)});M.box(3,.05,.05,steel,10,1.1,-10.7);M.box(3,.05,.05,steel,10,1.1,-12.1);
 /* aralashtirgich ostidagi taglik, buyurtma taxtasi ustuni, xandaq */
 M.box(.1,2.2,.1,dwood,5.5,1.1,6);M.box(1.4,.06,.8,dark,-13,.03,-9);
 M.box(5,.05,1.6,c(0x1a140c),-12,.025,10);                                  /* xandaq (quvur nuqtasi) */
 /* DO'KON binosi (sharqda), eshigi g'arbga qaragan */
 M.box(8,3.4,7,wall,15,1.7,-3);M.box(8.4,.3,7.4,roof,15,3.55,-3);M.box(.12,2.3,1.5,dark,11.02,1.15,-3);M.box(.14,.1,1.7,dwood,11.03,2.35,-3);M.box(.1,1.2,1.8,c(0x9fd0ee),11.0,1.9,-.2);M.box(.1,1.2,1.8,c(0x9fd0ee),11.0,1.9,-5.8);
 M.box(1.2,.5,2.2,c(0xe0b320),10.2,.25,-3);                              /* kirish zinasi */
 /* chiqish darvozasi */
 M.box(.4,3,.4,steel,-2.2,1.5,15.4);M.box(.4,3,.4,steel,2.2,1.5,15.4);M.box(4.8,.35,.4,yel,0,3.1,15.4);
 /* daraxtlar va toshlar */
 /* daraxtlar — BUILDPROPS.addTo (stylized oak) */
 M.done();
 BUILDPROPS.addTo(BLG,bcol);
 /* yozuvlar */
 const sg=(lines,w,h,bg,fg,x,y,z,ry)=>{const m=signMesh(lines,w,h,bg,fg);m.position.set(x,y,z);m.rotation.y=ry||0;BLG.add(m);return m};
 sg(["DO'KON","uy jihozlari · kompyuter qismlari"],3.4,.9,"#10233a","#ffd24a",11.08,2.9,-3,-Math.PI/2);
 sg(["⌂ UYGA QAYTISH"],4.2,.5,"#06140d","#2dff88",0,3.1,15.18,Math.PI);
 sg(["G'ISHT OMBORI"],2.2,.4,"#3a1810","#ffb199",-15,2.1,5.5,Math.PI/2);sg(["SEMENT"],1.6,.4,"#1d1d1d","#e8e2d0",-15,2.0,-2.5,Math.PI/2);
 sg(["TAXTA"],1.2,.35,"#2b1e0e","#f0c27a",8.5,1.6,10.5,Math.PI);sg(["QUM"],1.2,.35,"#3a3018","#f0e0a0",13,1.6,10.5,Math.PI);sg(["QUVUR"],1.2,.35,"#20262c","#c8d4de",-6,1.5,10.5,Math.PI);
 sg(["G'ISHT TUSHIRISH"],1.8,.35,"#10233a","#9fe6ff",-5.5,1.5,-8,0);sg(["ARALASHTIRGICH"],2,.35,"#3a2a10","#ffd24a",-8.5,2.5,-9.5,0);
 sg(["DEVOR"],1.2,.35,"#10233a","#9fe6ff",0,2.0,WALLZ-1.2,0);
 /* qorishma aralashtirgich (baraban aylanadi) */
 window.MIXD=new T.Mesh(new T.CylinderGeometry(.55,.4,.9,12),L(0xe0b320));MIXD.position.set(-8.5,1.1,-9.5);MIXD.rotation.z=.5;BLG.add(MIXD);
 const mx=new T.Mesh(new T.BoxGeometry(1.2,.5,1.2),L(0x3a4048));mx.position.set(-8.5,.3,-9.5);BLG.add(mx);}
/* to'qnashuvlar (mahalliy koordinatalar) */
[[-15,5.5,1.6,1.1],[-15,-2.5,1.3,.9],[8.5,10.5,1.7,.7],[13,10.5,1.4,.8],[-6,10.5,1.5,.6],[10,-11.4,1.6,.9],[-8.5,-9.5,.9,.9],[0,WALLZ,2.4,.7],[15,-3,4.1,3.6],[-2.2,15.4,.25,.25],[2.2,15.4,.25,.25],[5.5,6,.15,.15],[-5.5,-8,.9,.6]].forEach(a=>bcol(a[0],a[1],a[2],a[3]));
/* ---------- devor (InstancedMesh) ---------- */
const PCS=[],ROWEND=[];{for(let r=0;r<ROWS;r++){if(r%2===0)for(let i=0;i<8;i++)PCS.push({r,x:-1.75+i*.5,w:.5});else{PCS.push({r,x:-1.875,w:.25});for(let i=0;i<7;i++)PCS.push({r,x:-1.25+i*.5,w:.5});PCS.push({r,x:1.875,w:.25})}ROWEND.push(PCS.length)}}
const NP=PCS.length,brkGeo=BUILDPROPS.brickGeometry(BRK.w-.02,BRK.h-.02,BRK.d-.02),brkMat=BUILDPROPS.brickMaterial();
const WALLI=new T.InstancedMesh(brkGeo,brkMat,NP);WALLI.frustumCulled=false;WALLI.count=0;BLG.add(WALLI);
{const c=new T.Color();for(let i=0;i<NP;i++){c.setHex(0xffffff).offsetHSL(0,0,gRnd(-.16,0));WALLI.setColorAt(i,c)}}
const _bm=new T.Object3D(),ANIMS=[];let WR=null;
function setPiece(i,dy,sc){const p=PCS[i];_bm.position.set(p.x,WALLY+p.r*BRK.h+BRK.h/2+(dy||0),WALLZ);_bm.scale.set((p.w/BRK.w)*(sc==null?1:sc),sc==null?1:sc,sc==null?1:sc);_bm.rotation.set(0,0,0);_bm.updateMatrix();WALLI.setMatrixAt(i,_bm.matrix)}
function wallApply(n,anim){const have=WALLI.count;WALLI.count=n;for(let i=0;i<n;i++)setPiece(i,0);if(anim&&n>have)ANIMS.push({i:n-1,t:0});WALLI.instanceMatrix.needsUpdate=true}
/* keyingi g'isht uchun shaffof ko'rsatkich + qorishma chizig'i */
const GHOST=new T.Mesh(new T.BoxGeometry(BRK.w,BRK.h,BRK.d),new T.MeshBasicMaterial({color:0x2dff88,transparent:true,opacity:.35,depthWrite:false}));BLG.add(GHOST);
const MORT=new T.Mesh(new T.BoxGeometry(4.05,.03,.2),L(0x8d8f90));BLG.add(MORT);
/* ombor uyumi (g'isht zaxirasi) va qorishma ko'rsatkichi */
const STKN=36,STK=new T.InstancedMesh(brkGeo,brkMat,STKN);STK.frustumCulled=false;STK.count=0;BLG.add(STK);
{const c=new T.Color();for(let i=0;i<STKN;i++){c.setHex(0xffffff).offsetHSL(0,0,gRnd(-.16,0));STK.setColorAt(i,c)}}
function stockApply(){const n=Math.min(STKN,ECO.build.stock);STK.count=n;for(let i=0;i<n;i++){_bm.position.set(-6.3+(i%4)*.52,.1+Math.floor(i/8)*.2,-8.35+(Math.floor(i/4)%2)*.27);_bm.scale.set(1,1,1);_bm.rotation.set(0,0,0);_bm.updateMatrix();STK.setMatrixAt(i,_bm.matrix)}STK.instanceMatrix.needsUpdate=true}
/* ---------- qo'ldagi yuk (kamera oldida) ---------- */
const CARRYG=new T.Group();scene.add(CARRYG);CARRYG.visible=false;
const CAR={brick:{name:"G'isht (6 dona)"},cement:{name:"Sement qopi"},plank:{name:"Taxtalar"},sand:{name:"Qum qopi"},pipe:{name:"Quvurlar"}};
{const add=(n,f)=>{const g=new T.Group();g.name=n;f(g);CARRYG.add(g)};
 add("brick",g=>BUILDPROPS.carryBricks(g));
 add("cement",g=>BUILDPROPS.carryBag(g));
 add("plank",g=>{for(let i=0;i<3;i++)gb(g,.7,.025,.12,0xc99a5b,0,i*.03,i*.13-.13)});
 add("sand",g=>{gb(g,.38,.1,.24,0xd9c38a,0,0,0);gb(g,.26,.03,.16,0x8a6a3a,0,.05,0)});
 add("pipe",g=>{for(let i=0;i<3;i++){const c=gcy(g,.035,.035,.8,0x6f7780,(i-1)*.08,0,0,8);c.rotation.z=Math.PI/2}})}
const BLD={carry:null,act:null,order:null};
/* ---------- buyurtmalar (5-vazifa: materialni kerakli joyga olib borish) ---------- */
const ORD={plank:{dest:[10,-9.2],name:"Taxta",to:"ISKALA",col:0xffb84a,src:[8.5,.5,10.5]},sand:{dest:[-13,-6.8],name:"Qum",to:"QORISHMA MAYDONI",col:0xffe08a,src:[13,.5,10.5]},pipe:{dest:[-12,10],name:"Quvur",to:"XANDAQ",col:0x9fe6ff,src:[-6,.5,10.5]}};
const RINGS={};for(const k in ORD){const m=new T.Mesh(new T.RingGeometry(1.0,1.35,28),new T.MeshBasicMaterial({color:ORD[k].col,transparent:true,opacity:.8,side:T.DoubleSide,depthWrite:false}));m.rotation.x=-Math.PI/2;m.position.set(ORD[k].dest[0],.05,ORD[k].dest[1]);m.visible=false;BLG.add(m);RINGS[k]=m}
const BOARD=(()=>{const c=cv(512,256),m=new T.Mesh(new T.PlaneGeometry(2.2,1.1),new T.MeshBasicMaterial({map:tex(c)}));m.position.set(5.5,2.0,6.1);BLG.add(m);return{c,m}})();
function drawBoard(){const x=BOARD.c.getContext("2d"),o=BLD.order;x.fillStyle="#10233a";x.fillRect(0,0,512,256);x.strokeStyle="#ffd24a";x.lineWidth=8;x.strokeRect(6,6,500,244);x.fillStyle="#ffd24a";x.font="bold 40px sans-serif";x.textAlign="center";x.fillText("BUYURTMA",256,56);
 x.fillStyle="#fff";x.font="bold 34px sans-serif";if(o){x.fillText(ORD[o].name+" → "+ORD[o].to,256,130);x.font="26px sans-serif";x.fillStyle="#9fe6ff";x.fillText("Materialni omborda oling, belgilangan joyga olib boring",256,182);x.fillText("Mukofot: "+fmt$(jobPay("deliver")),256,222)}BOARD.m.material.map.needsUpdate=true}
function newOrder(){const ks=Object.keys(ORD).filter(k=>k!==BLD.order);BLD.order=ks[Math.floor(Math.random()*ks.length)];ECO.build.order=BLD.order;for(const k in RINGS)RINGS[k].visible=(k===BLD.order);drawBoard();ecoSave()}
/* ---------- vaqtli harakat (progress bar) ---------- */
function startAct(label,dur,ok,done){BLD.act={label,dur,t:0,ok,done};feelSnd()}
function cancelAct(){if(BLD.act){BLD.act=null;progHide()}}
const feelSnd=()=>{try{feel("")}catch(e){}};
function wallBoxHit(){return rayBox({x0:BX-2.4,x1:BX+2.4,y0:0,y1:1.9,z0:BZ+WALLZ-.9,z1:BZ+WALLZ+.9},5.2)>=0}
/* ---------- nishon (E tugmasi) ---------- */
const dst=(x,z)=>Math.hypot(P.x-(x+BX),P.z-(z+BZ));
function srcCand(k,pos,rad,dur,txt){const c=BLD.carry;
 if(!c)return[txt,()=>startAct(txt.replace("E — ",""),dur,()=>dst(pos[0],pos[2])<4.2&&!BLD.carry,()=>{BLD.carry={t:k,n:k==="brick"?6:1};toast("📦 "+CAR[k].name+" qo'lingizda — kerakli joyga olib boring")})];
 if(c.t===k)return["E — "+CAR[k].name.toLowerCase()+"ni joyiga qaytarish",()=>{BLD.carry=null;toast("Joyiga qaytarildi")}];return null}
function bldTarget(){
 if(BLD.act)return["⏳ "+BLD.act.label+"…",null];
 const c=BLD.carry,cands=[];const add=(v,rad,reach,t)=>{if(t&&pick(v,rad,reach))cands.push({a:aim(v),t})};
 const gateV=bwv(0,1.3,15.3),shopV=bwv(11,1.2,-3);
 add(gateV,1.9,4.2,c?["Avval yukni qo'ying (qaytaring yoki yetkazing)",null]:["E — uyga qaytish",()=>regGo("home",SP.home[0],SP.home[1],SP.home[2],"🏠 Uyga qaytdingiz")]);
 add(shopV,1.6,4.2,c?["Do'konga yuk bilan kirib bo'lmaydi",null]:["E — do'konga kirish",()=>regGo("shop",SP.shop[0],SP.shop[1],SP.shop[2],"🛒 Do'kon — mahsulotlarni ko'ring")]);
 add(bwv(...ORD.plank.src),1.9,3.6,srcCand("plank",ORD.plank.src,0,.9,"E — taxta olish"));add(bwv(...ORD.sand.src),1.7,3.6,srcCand("sand",ORD.sand.src,0,.9,"E — qum qopini olish"));add(bwv(...ORD.pipe.src),1.8,3.6,srcCand("pipe",ORD.pipe.src,0,.9,"E — quvur olish"));
 add(bwv(-15,.7,5.5),2.1,3.8,srcCand("brick",[-15,.7,5.5],0,.9,"E — g'isht ortish (6 dona)"));
 add(bwv(-15,.8,-2.5),1.6,3.8,srcCand("cement",[-15,.8,-2.5],0,1.1,"E — sement qopini ko'tarish"));
 /* g'isht tushirish */
 add(bwv(-5.5,.5,-8),1.5,3.6,c&&c.t==="brick"?["E — g'ishtlarni tushirish (+"+fmt$(jobPay("carry"))+")",()=>startAct("G'isht tushirilmoqda",.9,()=>dst(-5.5,-8)<4.4&&BLD.carry&&BLD.carry.t==="brick",()=>{BLD.carry=null;ECO.build.stock+=6;ECO.build.stats.carry++;ecoAdd(jobPay("carry"));popMoney(jobPay("carry"),"G'isht tashildi");stockApply();jobHud();ecoSave()})]:(c?null:["Omborda "+ECO.build.stock+" ta g'isht — terish uchun devorga boring",null]));
 /* aralashtirgich */
 add(bwv(-8.5,1,-9.5),1.5,3.8,c&&c.t==="cement"?["E — sementni aralashtirgichga to'kish (+"+fmt$(jobPay("cement"))+")",()=>startAct("Sement to'kilmoqda",1.2,()=>dst(-8.5,-9.5)<4.6&&BLD.carry&&BLD.carry.t==="cement",()=>{BLD.carry=null;ECO.build.mortar+=12;ECO.build.stats.cement++;ecoAdd(jobPay("cement"));popMoney(jobPay("cement"),"Sement tashildi");jobHud();ecoSave()})]:(c?null:["Qorishma: "+ECO.build.mortar+" g'isht uchun yetadi",null]));
 /* devor */
 {const wv=bwv(0,.7,WALLZ);if(!c&&wallBoxHit()&&pick(wv,3.4,5.6)){const B=ECO.build;let t;if(B.pieces>=NP)t=["Devor tayyor — yangisi tayyorlanmoqda…",null];else if(B.stock<=0)t=["G'isht yo'q — avval g'isht tashing (g'isht ombori)",null];else if(B.mortar<=0)t=["Qorishma yo'q — avval sement olib borib aralashtirgichga to'king",null];
   else{const p=PCS[B.pieces],last=B.pieces+1===ROWEND[p.r],fin=B.pieces+1===NP;t=["E — g'isht terish ("+(p.r+1)+"-qator · "+(B.pieces+1)+"/"+NP+")"+(last?" — qator tugaydi +"+fmt$(jobPay("lay")):"")+(fin?" · devor tayyor bo'ladi +"+fmt$(jobPay("wall")):""),()=>startAct("G'isht terilmoqda",p.w<.5?.4:.6,()=>wallBoxHit()&&ECO.build.stock>0&&ECO.build.mortar>0&&!BLD.carry,layBrick)]}
   cands.push({a:aim(wv)-.001,t})}}
 /* yetkazish nuqtalari */
 if(c&&ORD[c.t]){const o=ORD[c.t];if(c.t===BLD.order){if(dst(o.dest[0],o.dest[1])<2.2)cands.push({a:0,t:["E — "+o.name.toLowerCase()+"ni tushirish (+"+fmt$(jobPay("deliver"))+")",()=>startAct("Yetkazilmoqda",.8,()=>dst(o.dest[0],o.dest[1])<2.8&&BLD.carry,()=>{BLD.carry=null;ECO.build.stats.deliver++;ecoAdd(jobPay("deliver"));popMoney(jobPay("deliver"),"Material yetkazildi");newOrder();jobHud()})]});
   else cands.push({a:5,t:["Buyurtma bo'yicha "+o.name.toLowerCase()+"ni «"+o.to+"» ga olib boring (yerdagi nishon)",null]})}else cands.push({a:5,t:["Bu material hozirgi buyurtmaga kerak emas — omborga qaytaring yoki «"+ORD[BLD.order].name+"» olib keling",null]})}
 if(c&&!cands.length)cands.push({a:9,t:["Qo'lingizda: "+CAR[c.t].name+(c.t==="brick"?" → «G'ISHT TUSHIRISH» joyiga":c.t==="cement"?" → aralashtirgichga":" → buyurtma nishoniga")+" olib boring",null]});
 if(BLD.order&&!c&&!cands.length&&pick(bwv(5.5,2,6.1),1.2,3.5))cands.push({a:1,t:["Buyurtma: "+ORD[BLD.order].name+" → "+ORD[BLD.order].to,null]});
 cands.sort((p,q)=>p.a-q.a);return cands.length?cands[0].t:null}
function layBrick(){const B=ECO.build,i=B.pieces;B.pieces++;B.stock--;B.mortar--;wallApply(B.pieces,true);stockApply();const r=PCS[i].r;
 if(i+1===ROWEND[r]){B.stats.lay++;ecoAdd(jobPay("lay"));popMoney(jobPay("lay"),(r+1)+"-qator terildi")}
 if(B.pieces>=NP){B.stats.wall++;ecoAdd(jobPay("wall"));popMoney(jobPay("wall"),"DEVOR KO'TARILDI!");toast("🧱 Devor ko'tarildi! Yangi devor tayyorlanmoqda…");WR={t:-2.2}}
 jobHud();ecoSave()}
/* ---------- har kadr ---------- */
function bldTick(dt,now){
 /* qo'ldagi yuk */
 const on=!!BLD.carry&&!seated;CARRYG.visible=on;if(on){camera.getWorldDirection(fw);rg.set(1,0,0).applyQuaternion(camera.quaternion);CARRYG.position.copy(camera.position).addScaledVector(fw,.6).addScaledVector(rg,.12);CARRYG.position.y-=.34+Math.sin(P.bob*1.2)*.008;CARRYG.quaternion.copy(camera.quaternion);CARRYG.children.forEach(c=>c.visible=c.name===BLD.carry.t)}
 /* vaqtli harakat */
 const a=BLD.act;if(a){let ok=false;try{ok=a.ok()}catch(e){}if(!ok){cancelAct();toast("Harakat bekor qilindi")}else{a.t+=dt;progShow(a.label,a.t/a.dur);if(a.t>=a.dur){BLD.act=null;progHide();a.done()}}}
 /* g'isht qo'yilish animatsiyasi */
 if(ANIMS.length){for(let k=ANIMS.length-1;k>=0;k--){const an=ANIMS[k];an.t+=dt;const u=Math.min(1,an.t/.2);if(an.i<WALLI.count)setPiece(an.i,(1-u*u)*.3);if(u>=1)ANIMS.splice(k,1)}WALLI.instanceMatrix.needsUpdate=true}
 /* devor tayyor bo'lgach: kechikish, so'ng g'ishtlar qisqarib yo'qoladi */
 if(WR){WR.t+=dt;if(WR.t>0){const u=Math.min(1,WR.t/.8);for(let i=0;i<NP;i++)setPiece(i,0,Math.max(.001,1-u));WALLI.instanceMatrix.needsUpdate=true;if(u>=1){WR=null;ECO.build.pieces=0;wallApply(0);ecoSave();toast("🧱 Yangi devor uchastkasi tayyor")}}}
 /* ko'rsatkichlar */
 const B=ECO.build,full=B.pieces>=NP||!!WR;GHOST.visible=!full&&B.stock>0&&B.mortar>0&&!BLD.carry;MORT.visible=!full&&B.mortar>0&&B.pieces<NP;
 if(!full){const p=PCS[B.pieces];GHOST.position.set(p.x,WALLY+p.r*BRK.h+BRK.h/2,WALLZ);GHOST.scale.set(p.w/BRK.w,1,1);MORT.position.set(0,WALLY+p.r*BRK.h+.015,WALLZ);MORT.scale.x=p.w<.5?1:1;GHOST.material.opacity=.25+.15*Math.sin(now/220)}
 MIXD.rotation.y+=dt*(B.mortar>0?2.2:.4);for(const k in RINGS)if(RINGS[k].visible){RINGS[k].material.opacity=.55+.3*Math.sin(now/260);RINGS[k].scale.setScalar(1+.04*Math.sin(now/260))}}
function bldInit(){const B=ECO.build;wallApply(Math.min(B.pieces,NP));stockApply();BLD.order=B.order&&ORD[B.order]?B.order:null;if(!BLD.order)newOrder();else{for(const k in RINGS)RINGS[k].visible=(k===BLD.order);drawBoard()}}
function jobHud(){const e=$("eco-job");if(!e)return;const B=ECO.build,s=B.stats,rowDone=B.pieces>=NP?ROWS:PCS[Math.min(B.pieces,NP-1)].r;
 e.innerHTML='<b>🏗 VAZIFALAR</b>'+row("🧱 G'isht tashish","+"+jobPay("carry"),s.carry)+row("🪣 Sement tashish","+"+jobPay("cement"),s.cement)+row("🔨 G'isht terish (qator)","+"+jobPay("lay"),s.lay)+row("🏠 Devor ko'tarish","+"+jobPay("wall"),s.wall)+row("📦 Material yetkazish","+"+jobPay("deliver"),s.deliver)+
  '<div class="jl">Devor: <i><b style="width:'+Math.round(B.pieces/NP*100)+'%"></b></i> '+B.pieces+'/'+NP+' (qator '+Math.min(ROWS,rowDone+(B.pieces>=NP?0:1))+'/'+ROWS+')</div><div class="jl">Omborda: '+B.stock+' g\'isht · qorishma: '+B.mortar+'</div>'+(BLD.carry?'<div class="jl hl">Qo\'lda: '+CAR[BLD.carry.t].name+'</div>':'')+(BLD.order?'<div class="jl hl">Buyurtma: '+ORD[BLD.order].name+' → '+ORD[BLD.order].to+'</div>':'');
 function row(n,p,c){return'<div class="jr"><span>'+n+'</span><span>$'+p.slice(1)+' · '+c+'×</span></div>'}}

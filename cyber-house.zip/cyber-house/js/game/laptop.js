/* ==========================================================
 * Modul: js/game/laptop.js
 * Laptop: do'konda 150$, stolga qo'yiladi, 1 ta quvvat kabeli bilan rozetkaga ulanadi (desk-gear.js — eng yaqin bo'sh rozetka),
 * ekrani PC monitori bilan BIR XIL (Kali ish stoli, terminal, IDE, hujum simulyatsiyasi — kompyuterdagi barcha amallar),
 * "Laptopda ishlash" rejimi: kamera ekran oldiga o'tadi, sichqoncha/klaviatura ekran bilan ishlaydi.
 * Qo'lda ko'tarib yurish mumkin (yopiq holda qo'lda ko'rinadi), keyin istalgan stol/yerga qo'yiladi.
 * ========================================================== */
function mplOn(){return S.mplug||(typeof LAPX!=="undefined"&&LAPX.powered())}      /* ekran signali: PC monitori yoki quvvatlangan laptop */
const LAPX=(()=>{
  const X={hand:!!ECO.lapHand,on:false,rec:null,screen:null,camPos:new T.Vector3(),look:new T.Vector3(),fov:30,sv:null,dm:null};
  X.powered=()=>ECO.placed.some(r=>r.sku==="laptop"&&r.cab!=null&&PI[r.id]&&PI[r.id].mesh);
  /* ---------- ishlash rejimi ---------- */
  function frame(rec){
    const pi=PI[rec.id];if(!pi||!pi.mesh)return false;const g=pi.mesh;g.updateMatrixWorld(true);const sc=g.userData.screen;
    const c=new T.Vector3(),n=new T.Vector3(0,0,1).transformDirection(sc.matrixWorld);sc.getWorldPosition(c);
    const d=.64,cam=c.clone().addScaledVector(n,d);cam.y+=.015;
    if(Math.abs(cam.x)>5.7||Math.abs(cam.z)>6.7)return false;                          /* ekran oldida joy yo'q (devor) */
    const asp=baseW/baseH,sw=LAPTOP.SCR.x1-LAPTOP.SCR.x0,sh=LAPTOP.SCR.y1-LAPTOP.SCR.y0,t=Math.max(sw*.56/(d*asp),sh*.56/d);
    X.camPos.copy(cam);X.look.copy(c);X.fov=Math.min(100,Math.max(14,2*Math.atan(t)*180/Math.PI));X.screen=sc;return true}
  function use(rec){
    if(seated||SIT.on||LF.sleeping||PLM.on||REG.cur!=="home")return;
    if(rec.cab==null)return toast("Avval quvvat kabelini ulang: ✎ menyu → 🔌 Kabel ulash");
    if(X.hand)return toast("Qo'lingizdagi laptopni qo'ying");
    if(!frame(rec))return toast("Laptop ekrani oldida joy yo'q — laptopni aylantiring yoki suring");
    X.rec=rec;X.sv={x:P.x,z:P.z,yaw:P.yaw,pitch:P.pitch};X.dm=SET.dmode;SET.dmode="off";X.on=true;
    sit();if(!S.on)power();else dirty=true;toast("💻 Laptopda ishlayapsiz — turish: Esc yoki «Turish» tugmasi")}
  function leave(){X.on=false;X.screen=null;if(X.dm!=null){SET.dmode=X.dm;X.dm=null}dirty=true}
  {const s0=stand;stand=function(){if(!X.on){s0();return}const sv=X.sv;leave();s0();if(sv){P.x=sv.x;P.z=sv.z;P.yaw=sv.yaw;P.pitch=sv.pitch}}}
  /* ekran: ish rejimida nur laptop ekranini kesib o'tadi (monitorlar o'rniga) */
  const _pl=new T.Plane(),_pt=new T.Vector3(),_n=new T.Vector3();
  {const sh0=scrHit;scrHit=function(cx,cy,loose){
     if(!X.on||!X.screen)return sh0(cx,cy,loose);
     v2.set(cx/baseW*2-1,-(cy/baseH)*2+1);camera.updateMatrixWorld();rc.setFromCamera(v2,camera);const m=X.screen;m.updateWorldMatrix(true,false);
     const h=rc.intersectObject(m,false)[0];let u,v;
     if(h&&h.uv){u=h.uv.x;v=h.uv.y}
     else if(loose){_n.set(0,0,1).transformDirection(m.matrixWorld);_pl.setFromNormalAndCoplanarPoint(_n,m.getWorldPosition(_pt));if(!rc.ray.intersectPlane(_pl,_pt))return null;m.worldToLocal(_pt);
       const w=LAPTOP.SCR.x1-LAPTOP.SCR.x0,hh=LAPTOP.SCR.y1-LAPTOP.SCR.y0;u=Math.max(0,Math.min(1,_pt.x/w+.5));v=Math.max(0,Math.min(1,_pt.y/hh+.5))}
     else return null;
     return{x:u*W,y:(1-v)*H}}}
  /* ---------- qo'lda ko'tarish ---------- */
  let hand=null;const qE=new T.Quaternion(),eu=new T.Euler(),qq=new T.Quaternion(),pp=new T.Vector3(),one=new T.Vector3(1,1,1);
  function take(rec){
    const e=canRemove(rec,true);if(e)return toast(e);if(S.hold||KT.item||LF.cup>0)return toast("Qo'lingiz band");
    unapplyRec(rec);if(rec.cab!=null){invAdd("pcord",1);rec.cab=null}
    const i=ECO.placed.indexOf(rec);if(i>=0)ECO.placed.splice(i,1);delete PI[rec.id];
    X.hand=true;ECO.lapHand=true;ecoSave(true);dirty=true;if(window.rigRefresh)rigRefresh();toast("✋ Laptop qo'lingizda (kabel ajratildi) — E: stolga/yerga qo'yish")}
  function place(){
    if(!X.hand)return;invAdd("laptop",1);X.hand=false;ECO.lapHand=false;plmStart("laptop");
    if(!PLM.on){invAdd("laptop",-1);X.hand=true;ECO.lapHand=true;return}
    ecoSave(true)}
  function handUpdate(now){
    const show=X.hand&&REG.cur==="home"&&!PLM.on&&!seated&&!SIT.on&&!LF.sleeping&&!REG.busy;
    if(!hand){if(!X.hand)return;hand=LAPTOP.build({closed:true});hand.matrixAutoUpdate=false;hand.visible=false;scene.add(hand);LAPTOP.setPower(hand,false)}
    hand.visible=show;if(!show)return;
    eu.set(.42,.2,0,"YXZ");qE.setFromEuler(eu);qq.copy(camera.quaternion).multiply(qE);
    pp.set(.2,-.3+Math.sin(now/620)*.004,-.64).applyQuaternion(camera.quaternion).add(camera.position);
    hand.matrix.compose(pp,qq,one);hand.matrixWorldNeedsUpdate=true}
  X.update=(dt,now)=>{handUpdate(now)};
  /* ---------- E tugmasi nishonlari, menyu, eshik ---------- */
  {const r0=recTarget;recTarget=function(){
     if(X.hand&&REG.cur==="home")return["E — laptopni qo'yish (nishonni stol yoki yerga qarating)",place];
     const r=aimedRec();if(r&&r.sku==="laptop")return r.cab==null?["E — Laptop: quvvat kabelini ulash (menyu)",()=>itemMenu(r)]:["E — 💻 Laptopda ishlash  ·  ✎ tugmasi: menyu",()=>use(r)];
     return r0()}}
  {const m0=itemMenu;itemMenu=function(r){m0(r);if(r.sku!=="laptop")return;const bt=document.querySelector("#imenu .bt");if(!bt)return;
     const mk=(t,f)=>{const b=document.createElement("button");b.textContent=t;b.onclick=()=>{uiClose(true);f()};return b};
     bt.insertBefore(mk("✋ Qo'lga olish",()=>take(r)),bt.firstChild);bt.insertBefore(mk("💻 Laptopda ishlash",()=>use(r)),bt.firstChild)}}
  {const d0=doorOut;doorOut=function(){if(X.hand)return toast("Avval laptopni qo'ying (E)");d0()}}
  X.use=use;X.take=take;X.place=place;
  return X})();
/* model va teksturalarni oldindan tayyorlab qo'yish (do'kon rasmi va joylashtirish tez chiqishi uchun) */
setTimeout(()=>{try{LAPTOP.res()}catch(e){console.warn("[laptop] preload",e)}},1500);

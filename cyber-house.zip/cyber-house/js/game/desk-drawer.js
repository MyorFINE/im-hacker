/* ==========================================================
 * Modul: js/game/desk-drawer.js
 * Kompyuter stoli tortmasi: tortma old panelga (yoki dastaga) qarab E — silliq ochiladi/yopiladi, holat saqlanadi.
 * Stol istalgan joyda va istalgan yo'nalishda bo'lishi mumkin (hisob stolning lokal koordinatalarida).
 * ========================================================== */
const DRAWER=(()=>{
  const OPEN=.46,A={},BX=[-1.45,-.55,.6,.74,.72];      /* tortma old paneli: x0,x1,y0,y1,z(yopiq holat) */
  const mesh=r=>{const p=PI[r.id];return p&&p.mesh&&p.mesh.userData.drawer?p.mesh.userData.drawer:null};
  const _d=new T.Vector3();
  function hit(r){
    const dg=mesh(r);if(!dg)return -1;camera.getWorldDirection(_d);
    const c=Math.cos(r.ry),s=Math.sin(r.ry),ox=camera.position.x-r.x,oz=camera.position.z-r.z,oy=camera.position.y-r.y;
    const o=[ox*c-oz*s,oy,ox*s+oz*c],d=[_d.x*c-_d.z*s,_d.y,_d.x*s+_d.z*c],u=(A[r.id]||{u:r.dr?1:0}).u,zf=BX[4]+u*OPEN;
    const mn=[BX[0],BX[2],zf-.06],mx=[BX[1],BX[3],zf+.09];let t0=0,t1=2.8;
    for(let i=0;i<3;i++){if(Math.abs(d[i])<1e-6){if(o[i]<mn[i]||o[i]>mx[i])return -1;continue}let a=(mn[i]-o[i])/d[i],b=(mx[i]-o[i])/d[i];if(a>b){const t=a;a=b;b=t}t0=Math.max(t0,a);t1=Math.min(t1,b);if(t0>t1)return -1}
    return t0}
  function toggle(r){r.dr=r.dr?0:1;ecoSave();toast(r.dr?"🗄 Tortma ochildi":"🗄 Tortma yopildi")}
  function set(r){const dg=mesh(r);if(!dg)return;const a=A[r.id]||(A[r.id]={u:0});a.u=r.dr?1:0;dg.position.z=a.u*OPEN}
  {const a0=applyRec;applyRec=function(rec){a0(rec);if(rec.sku==="desk")set(rec)}}
  {const r0=recTarget;recTarget=function(){
     if(!seated&&!SIT.on){let bt=9,br=null;for(const r of ECO.placed){if(r.sku!=="desk")continue;const t=hit(r);if(t>=0&&t<bt){bt=t;br=r}}
       if(br)return["E — tortmani "+(br.dr?"yopish":"ochish"),()=>toggle(br)]}
     return r0()}}
  function update(dt){const k=Math.min(1,dt*7);for(const r of ECO.placed){if(r.sku!=="desk")continue;const dg=mesh(r);if(!dg)continue;const a=A[r.id]||(A[r.id]={u:r.dr?1:0}),t=r.dr?1:0;if(Math.abs(a.u-t)>.002){a.u+=(t-a.u)*k;dg.position.z=a.u*OPEN}else if(a.u!==t){a.u=t;dg.position.z=t*OPEN}}}
  return{update,toggle,hit}
})();

/* ==========================================================
 * Modul: js/game/marks.js
 * Modullar orasida scene'ga qo'shilgan obyektlarni guruhlash belgilari.
 * index.html ichida GM.mark("nom") chaqiriladi — o'sha paytgacha qo'shilgan
 * yangi obyektlar shu nom ostida saqlanadi (keyin "ish stansiyasi" sifatida
 * yashirish/ko'rsatish uchun ishlatiladi). O'yin kodiga tegilmaydi.
 * ========================================================== */
window.GM={m:{},n:scene.children.length,mark(k){const a=scene.children.slice(this.n);this.m[k]=(this.m[k]||[]).concat(a);this.n=scene.children.length}};

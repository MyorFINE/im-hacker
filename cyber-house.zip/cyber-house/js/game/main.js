/* ==========================================================
 * Modul: js/game/main.js
 * Barcha yangi tizimlarni asl o'yin sikliga ulaydi: o'yinchi harakati/kamera/chegaralar
 * (hududga qarab), E tugmasi nishonlari, har kadr yangilanishi, klaviatura, saqlangan
 * holatni tiklash va maqsad ko'rsatmasi. Asl funksiyalar o'rniga ularning ustidan
 * o'raydigan (wrapper) versiyalar qo'yiladi — asl kod buzilmaydi.
 * ========================================================== */
/* ---------- o'yinchi harakati ---------- */
{const u0=updatePlayer;updatePlayer=function(dt){if(REG.busy||UIOPEN||SIT.on||PLM.dockLock){P.vx=P.vz=0;return}
  const ox=P.x,oz=P.z,c=BLD.carry;u0(dt);if(c){const k=c.t==="cement"||c.t==="sand"?.62:c.t==="brick"?.78:.85;P.x=ox+(P.x-ox)*k;P.z=oz+(P.z-oz)*k;P.vx*=k;P.vz*=k}};
 const c0=updateCam;updateCam=function(dt){c0(dt);if(SIT.on){SIT.k=Math.min(1,SIT.k+dt*3);const r=SIT.rec,eye=(CAT[r.sku].seat.h||.5)+.68;camera.position.set(P.x,1.68+(eye-1.68)*SIT.k,P.z)}};
 const k0=kBounds;kBounds=function(lim){if(REG.cur==="home")return k0(lim);P.k=false;const b=REG.bounds[REG.cur];P.x=gClamp(P.x,b[0],b[1]);P.z=gClamp(P.z,b[2],b[3])};
 const i0=interact;interact=function(){if(REG.busy||UIOPEN)return;i0()}}
/* ---------- E tugmasi nishonlari ---------- */
{const t0=target;target=function(){
  if(REG.busy)return["",null];
  if(PLM.on)return[PLM.ok?"E — shu yerga joylashtirish":"✖ "+(PLM.msg||"Bu yerga bo'lmaydi")+" (E — bekor emas, Esc — bekor)",PLM.ok?plmConfirm:null];
  if(GEAR.cm.on)return GEAR.cmTarget();
  if(SIT.on)return["E — turish",standFree];
  if(REG.cur==="build"){return bldTarget()||["",null]}
  if(REG.cur==="shop"){return shopTarget()}
  if(!seated&&!LF.sleeping){const dd=pick(HDOORP,.55,2.4);if(dd){return(BLD.carry?["",null]:["E — eshikni ochish (qurilish zonasiga chiqish)",doorOut])}}
  const o=t0();if(o[1]||seated||LF.sleeping)return o;
  const b=rigBenchTarget();if(b)return b;
  if(!seated&&!LF.sleeping&&!S.hold&&!KT.item&&!LF.cup){const r=recTarget();if(r)return r}
  return o}}
/* ---------- har kadr ---------- */
let ecoErr=0,lastEdit=false,stT=0;
function ecoTick(dt,now){if(!started)return;try{
  if(!ecoTick.i){ecoTick.i=1;ecoHud();$("eco-bar").style.display="flex"}
  const home=REG.cur==="home";
  if(PLM.on)plmTick();
  GEAR.cmTick();
  if(SIT.on&&(LF.sleeping||seated))standFree();
  if(REG.cur==="build"){bldTick(dt,now);$("eco-job").style.display="block";if(!ecoTick.j||now-ecoTick.j>600){ecoTick.j=now;jobHud()}}else{$("eco-job").style.display="none";if(BLD.act)cancelAct()}
  if(REG.cur==="shop")shopTick(dt);
  /* ko'chirish/tahrirlash tugmasi: faqat uyda, joylashtirilgan buyumga qaralganda */
  const ed=home&&!PLM.on&&!seated&&!SIT.on&&!UIOPEN&&!!aimedRec();if(ed!==lastEdit){lastEdit=ed;$("eco-edit").style.display=ed?"block":"none"}
  const inv=$("eco-inv");inv.style.display=(seated||REG.busy)?"none":"";
  if(now-stT>1500){stT=now;ecoStatus()}
 }catch(e){if(++ecoErr<4)console.error("[eco]",e)}}
function ecoOnRegion(n){ecoStatus();if(n==="home"&&window.rigRefresh)rigRefresh()}
/* maqsad ko'rsatmasi (#status) */
function ecoStatus(){const s=$("status");if(!s)return;let t="";const has=n=>ECO.placed.some(r=>r.sku===n);
 if(REG.cur==="build")t="Qurilish: g'isht va sement tashing, devor teraing — pul toping";
 else if(REG.cur==="shop")t="Do'kon: kassaga yoki mahsulotga qarab E bosing";
 else if(!has("desk"))t=ECO.money<80&&!invQty("desk")?"Maqsad: eshikdan chiqib qurilishda pul ishlang":(invQty("desk")?"Maqsad: inventardan stolni xohlagan joyga qo'ying":"Maqsad: do'kondan kompyuter stolini oling");
 else if(!RIG.benchOn)t="Maqsad: montaj stoli oling va joylashtiring";
 else if(BN.pcAway)t="Maqsad: kompyuter qismlarini sotib olib montaj stolida yig'ing";
 else t="Kompyuter o'rnatilgan — vilkalarni ulang va ishlating";
 if(s.textContent!==t)s.textContent=t}
/* ---------- klaviatura (faqat o'tirmagan holda) ---------- */
addEventListener("keydown",e=>{if(seated||document.activeElement===ta||!started)return;
 if(UIOPEN){if(e.code==="Escape"||(e.code==="KeyI"&&UIOPEN==="inv")){uiClose();e.preventDefault();e.stopPropagation()}return}
 if(PLM.on){if(e.code==="Escape"){plmCancel();e.preventDefault();e.stopPropagation();return}if(e.code==="KeyR"){plmRotate(e.shiftKey?-1:1);return}if(e.code==="Enter"){plmConfirm();return}if(e.code==="KeyQ"){e.stopPropagation();plmRotate(-1);return}}
 if(SIT.on&&e.code==="Escape"){standFree();e.preventDefault();e.stopPropagation();return}
 if(e.code==="KeyI"){openInv();e.preventDefault()}
 if(e.code==="KeyG"&&REG.cur==="home"){const r=aimedRec();if(r)itemMenu(r)}},true);
/* ---------- saqlangan holatni tiklash ---------- */
function ecoStart(){
 loadBench(ECO.bench);
 for(const r of ECO.placed)try{applyRec(r)}catch(e){console.error("[eco] apply",r,e)}
 if(!RIG.desk)rigHideAll();
 if(HP.on&&!RIG.desk){HP.on=false;invAdd("hp",1);ecoSave(true)}   /* eski saqlash: naushnik inventarga qaytadi, o'zingiz qo'yasiz */
 shopLabels();bldInit();ecoHud();regEnv("home");ecoStatus();
 if(!ECO.intro){ECO.intro=true;ecoSave();setTimeout(()=>toast("🏠 Uy bo'sh. Janub devordagi eshikdan chiqib qurilishda pul ishlang!"),2500)}}
ecoStart();

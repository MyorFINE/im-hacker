/* ==========================================================
 * Modul: js/effects/smoke.js
 * Tutun va hid
 * ========================================================== */
/* tutun va hid */
const SN=70,smP=new Float32Array(SN*3),smC=new Float32Array(SN*3),smV=new Float32Array(SN*3),smL=new Float32Array(SN),smG=new T.BufferGeometry();let smI=0,smA=0,smB=0;
for(let i=0;i<SN;i++)smP[i*3+1]=-50;smG.setAttribute("position",new T.BufferAttribute(smP,3));smG.setAttribute("color",new T.BufferAttribute(smC,3));
const smc=cv(64,64),smx=smc.getContext("2d"),smg=smx.createRadialGradient(32,32,2,32,32,30);smg.addColorStop(0,"rgba(255,255,255,.9)");smg.addColorStop(1,"rgba(255,255,255,0)");smx.fillStyle=smg;smx.fillRect(0,0,64,64);
const SMK=new T.Points(smG,new T.PointsMaterial({size:.26,map:tex(smc),vertexColors:true,transparent:true,opacity:.55,depthWrite:false}));SMK.frustumCulled=false;scene.add(SMK);
const HI=new V(-2.9,2.04,-13.58);
function smokeUpd(dt){const q=KT.pan,em=q&&KT.gas?(q.t>=40?3:q.t>14?1.6:q.t>3?.8:0):0;smA+=em*dt*5;
 while(smA>=1){smA--;const i=smI++%SN,o=i*3,dk=q&&q.t>=40;smL[i]=1;smP[o]=-3.1+(Math.random()-.5)*.1;smP[o+1]=1.06;smP[o+2]=-13.35+(Math.random()-.5)*.1;smV[o]=(Math.random()-.5)*.06;smV[o+1]=.3+Math.random()*.15;smV[o+2]=(Math.random()-.5)*.06;smC[o]=smC[o+1]=smC[o+2]=dk?.12:.9}
 {const sp=KT.lidp>.6&&KT.gas&&KT.pot.length>=3&&KT.water>=3?(KT.potT>=20?1.2:.7):0;smB+=sp*dt*4;while(smB>=1){smB--;const i=smI++%SN,o=i*3;smL[i]=1;smP[o]=-2.7+(Math.random()-.5)*.18;smP[o+1]=1.12;smP[o+2]=-13.35+(Math.random()-.5)*.18;smV[o]=(Math.random()-.5)*.05;smV[o+1]=.25+Math.random()*.12;smV[o+2]=(Math.random()-.5)*.05;smC[o]=smC[o+1]=smC[o+2]=.95}}
 let n=0;for(let i=0;i<SN;i++){if(smL[i]<=0)continue;n++;const o=i*3;smL[i]-=dt*(KT.hood?.35:.13);
  if(KT.hood){const dx=HI.x-smP[o],dy=HI.y-smP[o+1],dz=HI.z-smP[o+2],d=Math.hypot(dx,dy,dz)+1e-3,pl=(Math.min(1.6,.4/(d*d))+.3)*dt*2;smV[o]+=dx/d*pl;smV[o+1]+=dy/d*pl;smV[o+2]+=dz/d*pl;if(d<.2)smL[i]=0}
  smV[o]*=.985;smV[o+2]*=.985;smP[o]+=smV[o]*dt;smP[o+1]=Math.min(3.25,smP[o+1]+smV[o+1]*dt);smP[o+2]=Math.max(-13.8,smP[o+2]+smV[o+2]*dt);
  const f=Math.max(0,1-smL[i]),g=smC[o]+(.82-smC[o])*Math.min(1,f*f*dt*4);smC[o]=smC[o+1]=g;smC[o+2]=g*.97;if(smL[i]<=0)smP[o+1]=-50}
 if(n||em){smG.attributes.position.needsUpdate=true;smG.attributes.color.needsUpdate=true}
 KT.smk+=(n/SN-KT.smk)*Math.min(1,dt*.5);if(KT.smk>.3&&!KT.hood&&!KT.warn){KT.warn=true;toast("💨 Tutun va hid to'ldi — dimohodni yoqing!")}if(KT.smk<.1)KT.warn=false}
function kitchenUpd2(dt){
 KC.forEach(c=>c.doors.forEach(d=>{const tg=d.o?1:0;if(Math.abs(tg-d.p)>.001){d.p+=(tg-d.p)*Math.min(1,dt*5);d.g.rotation.y=d.s*1.65*d.p}}));
 {const th=1.5*KT.fdp,on=KT.fdp>.03;FDC.forEach((o,i)=>{if(on){const s=.1+.2*i;o.x=-6.5-s*Math.cos(th);o.z=-13.04+s*Math.sin(th)}else o.x=999})}
 {const tw=KT.tap||KT.tapT>0,t=performance.now();KT.tapT=Math.max(0,KT.tapT-dt);KWS.visible=KWP.visible=KWL.visible=tw;if(tw){const ph=(t/200)%1;KWS.scale.x=KWS.scale.z=1+Math.sin(t/45)*.25;KWP.scale.setScalar(1+ph);KWP.material.opacity=.6*(1-ph)}}
 if(window.KFAN)KFAN.rotation.y+=dt*(KT.hood?16:0);
 smokeUpd(dt);
 const e=KT.eat;eatT+=((e?1:0)-eatT)*Math.min(1,dt*3);
 if(e){e.t+=dt;const po=e.k==="posh",du=po?9:6,s=Math.max(.001,1-e.t/du);LF.hunger=Math.max(0,LF.hunger-(po?60:50)*dt/du);if(po)TPOm.scale.set(s,s,s);else{TPw.scale.set(s,s,1);TPy.scale.set(s,.55*s,s);TPy.visible=s>.1}
  if(e.t>=du){KT.eat=null;const c=KCH[e.ci],pz=-10.4+(c[2]?-.3:.3);P.x=c[0]+(c[0]<-3.6?-.8:.8);P.z=c[1];P.vx=P.vz=0;P.yaw=c[2]?Math.PI:0;P.pitch=-.2;if(KT.pls.length>=4)KT.pls.shift();KT.pls.push({x:c[0],y:.7975,z:pz,k:"pdirty"});TPw.visible=TPy.visible=false;toast(po?"🍚 Osh yedingiz (−60 ochlik). Likopcha kir bo'ldi — lavaboda yuvib, joyiga qo'ying":"🍽 Yedingiz (−50 ochlik). Likopcha kir bo'ldi — lavaboda yuvib, joyiga qo'ying")}}
 TPL.visible=!!e&&e.k!=="posh";TPO.visible=!!e&&e.k==="posh";
 PLS.forEach((g,i)=>{const p=KT.pls[i];g.visible=!!p;if(p){g.position.set(p.x,p.y,p.z);g.userData.w.visible=g.userData.y.visible=p.k==="pfried";g.userData.st.visible=p.k==="pdirty";g.userData.om.visible=p.k==="posh"}});
 if(KT.wash){KT.wash.t+=dt;if(KT.wash.t>=2.6){KT.wash=null;if(KT.item==="pdirty"){KT.item="plate";toast("✨ Likopcha yuvildi — idish quritgichga qo'ying")}}}
 if(KT.gas&&KT.pot.length>=3&&KT.water>=3&&KT.potT<20){KT.potT+=dt;if(KT.potT>=20){KT.potP=4;KT.dish=(KT.pot.includes("carrot")&&KT.pot.includes("onion")&&KT.pot.includes("guruch"))?"osh":"shorva";toast(KT.dish==="osh"?"🍚 Osh tayyor — 4 porsiya! Qopqoqni olib stolga qo'ying, likopchaga soling va stolda o'tirib yeng":"🍲 Taom tayyor — 4 porsiya! Qopqoqni olib stolga qo'ying, kosa oling va qozondan soling")}}

 {KT.lidp+=((KT.lid?1:0)-KT.lidp)*Math.min(1,dt*6);KLID.visible=!KT.lid;KLP.visible=KT.ld.w==="surf";if(KLP.visible)KLP.position.set(KT.ld.x,KT.ld.y+.01,KT.ld.z);
  const n=KT.pot.length,wl=KT.water,sh=KT.lid,lvv=potLv(),pr=Math.min(1,KT.potT/20),rr=.12+.03*(lvv-.95)/.16-.004;
  KPW.visible=sh&&wl>0&&KT.potP<=0;KPD.visible=sh&&KT.potP>0;
  if(KPW.visible){KPW.position.set(-2.7,lvv,-13.35);KPW.scale.set(rr,rr,1);KPW.material.opacity=.6;KPW.material.color.setRGB(.44+.28*pr,.66-.14*pr,.85-.63*pr)}
  if(KPD.visible){KPD.position.set(-2.7,lvv,-13.35);KPD.scale.set(rr,rr,1);if(KT.dish==="osh")KPD.material.color.setRGB(.88,.72,.3);else KPD.material.color.setRGB(.66,.33,.1)}
  KPI.visible=sh&&KT.pi.length>0;
  if(KPI.visible){const sig=KT.pi.length+"|"+lvv.toFixed(3)+"|"+Math.round(pr*10);if(KPI.userData.sig!==sig){KPI.userData.sig=sig;const dk2=1-.3*pr;KPI.count=KT.pi.length;KT.pi.forEach((p,i)=>{kd3.position.set(-2.7+p.x,lvv+.004+p.dy,-13.35+p.z);kd3.scale.set(p.sx,p.sy,p.sz);kd3.rotation.set(0,p.ry,0);kd3.updateMatrix();KPI.setMatrixAt(i,kd3.matrix);KPI.setColorAt(i,kc3.setHex(p.c).multiplyScalar(dk2))});KPI.instanceMatrix.needsUpdate=true;KPI.instanceColor.needsUpdate=true}}
  {const b=KT.bd,LL={carrot:.17,potato:.12,onion:.08,tomato:.09},TH={carrot:.045,potato:.085,onion:.08,tomato:.09};
   if(b&&!b.cut&&b.n>0){const L2=LL[b.k],f=b.n/6;KNF.position.set(-2.05+L2/2-f*L2,.96+TH[b.k]+.004,-13.45);KNF.rotation.set(0,Math.PI/2,0)}else{KNF.position.set(-2,.96,-13.385);KNF.rotation.set(0,.1,0)}
   KBR.visible=!!b&&!b.cut;KBC.visible=!!b&&b.n>0;
   if(b){const f=b.cut?1:b.n/6,L2=LL[b.k];KBR.children.forEach(c=>c.visible=c.name===b.k);KBCm.color.setHex(KCOL[b.k]);KBR.scale.set(Math.max(.05,1-f),1,1);KBR.position.x=-2.05-f*L2/2;KBC.position.z=b.cut?-13.45:-13.385;const nv=b.cut?16:Math.ceil(16*f);KBC.children.forEach((m,i)=>m.visible=i<nv)}}
  KHCm.color.setHex(KCOL[KT.chop]||0xe8791e);
  KSK.forEach(m=>m.visible=true);kfill(hf,KT.kp);
  BWM.forEach((g,i)=>{const p=KT.bws[i];g.visible=!!p;if(p){g.position.set(p.x,p.y-.0075,p.z);kfill(g,p.w?3:p.p);g.userData.f.material.color.setHex(p.w?0x5aa0d8:0xb5651d)}});
  FZM.forEach((g,i)=>{const s=KT.fz[i];g.visible=!!s;if(s)kfill(g,s)})}
 KG.visible=P.z<-6.3||KT.dp>.02}
{const KGl=scene.children.slice(_k1).filter(o=>(o.isMesh||o.isGroup||o.isPoints)&&o!==KH);window.KG=new T.Group();KGl.forEach(o=>KG.add(o));scene.add(KG)}

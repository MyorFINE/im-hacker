/* ==========================================================
 * Modul: js/graphics/shadows.js
 * Realistik yoritish: soyalar (shift va stol lampasi, ish stoli), muhit aksi (yog'och/metall yaltirashi).
 * Kuchsiz qurilmalarda (lowEnd): faqat bitta soyali yorug'lik, soya xaritasi kichik va har 3-kadrda yangilanadi.
 * "SIFAT: PAST" rejimida soyalar o'chadi.
 * ========================================================== */
(function(){
 const hi=!lowEnd;
 renderer.shadowMap.enabled=true;renderer.shadowMap.type=hi?T.PCFSoftShadowMap:T.PCFShadowMap;renderer.shadowMap.autoUpdate=hi;
 function spot(col,int,dist,ang,pen,pos,tgt,cast,ms,near,far){
  const s=new T.SpotLight(col,int,dist,ang,pen,1);s.position.set(pos[0],pos[1],pos[2]);s.target.position.set(tgt[0],tgt[1],tgt[2]);scene.add(s);scene.add(s.target);
  s.userData.cast=cast;s.castShadow=cast;if(cast){s.shadow.mapSize.set(ms,ms);s.shadow.camera.near=near;s.shadow.camera.far=far;s.shadow.bias=-.0003;s.shadow.normalBias=.015;s.shadow.radius=3}return s}
 const SP=[];
 /* 1) shift chirog'i — kompyuter stoli, stul, pol soyalari */
 SP.push(spot(0xfff1de,hi?1.0:.85,9,.8,.7,[0,3.6,-3.0],[0,.9,-3.45],true,hi?2048:1024,.5,8));
 if(hi){
  /* 2) stol lampasi — klaviatura/monitor/krujka soyalari */
  SP.push(spot(0xffd9a0,1.0,3.6,.95,.75,[-1.58,1.32,-3.62],[-1.2,.9,-3.1],true,1024,.1,4));lamp.intensity=.45;
  /* 3) ish stoli ustidagi yorug'lik (dunyo koordinatalarida: ish stoli markazi ~ (5.45, 5.45)) */
  SP.push(spot(0xfff1de,.9,8,.75,.7,[4.9,3.4,5.45],[5.45,.8,5.45],true,1024,.5,7));
  /* muhit aksi: yog'och va metall uchun yumshoq yaltirash */
  try{const pm=new T.PMREMGenerator(renderer),es=new T.Scene();
   es.add(new T.Mesh(new T.BoxGeometry(14,5,14),new T.MeshBasicMaterial({color:0x56626e,side:T.BackSide})));
   const pn=(w,h,x,y,z,c)=>{const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({color:new T.Color(c[0],c[1],c[2]),side:T.DoubleSide}));m.position.set(x,y,z);m.rotation.x=Math.PI/2;es.add(m)};
   pn(5,.8,0,2.3,0,[5,4.6,4]);pn(2,.5,3,2.3,2,[3,3,3.3]);
   scene.environment=pm.fromScene(es,.04).texture;pm.dispose()}catch(e){OAK.metal.metalness=.4;OAK.metal.roughness=.4}
 }
 /* soya beruvchi / qabul qiluvchi jismlar: stol atrofi va ish stoli zonasi */
 scene.updateMatrixWorld(true);
 const bb=new T.Box3(),c=new T.Vector3(),z=new T.Vector3();
 scene.traverse(o=>{
  if(!o.isMesh||!o.material||Array.isArray(o.material))return;const m=o.material;
  if(m.isMeshBasicMaterial||(m.transparent&&m.opacity<.9))return;
  bb.setFromObject(o);if(bb.isEmpty())return;bb.getCenter(c);bb.getSize(z);
  if(z.x>8||z.z>8){if(z.y<.6)o.receiveShadow=true;return}
  const inDesk=c.x>-2.5&&c.x<2.5&&c.z>-4.7&&c.z<-1.3&&c.y<2.4,inBench=c.x>4.2&&c.x<6.5&&c.z>3.5&&c.z<7.2&&c.y<1.8;
  if(!inDesk&&!inBench)return;if(Math.max(z.x,z.y,z.z)<.012)return;
  o.castShadow=true;o.receiveShadow=true});
 /* sifat tugmasi: PAST rejimida soyalar o'chadi */
 function shadowQ(m){const on=m!==2;renderer.shadowMap.enabled=on;SP.forEach(s=>{s.castShadow=on&&s.userData.cast})}
 const _sq=setQ;setQ=function(m){_sq(m);shadowQ(m)};shadowQ(qMode);
 /* kuchsiz qurilma: soya xaritasi har 3-kadrda yangilanadi */
 if(!hi){const _rd=renderer.render.bind(renderer);let fc=0;renderer.render=function(s,cm){renderer.shadowMap.needsUpdate=(fc++%3===0);_rd(s,cm)}}
})();

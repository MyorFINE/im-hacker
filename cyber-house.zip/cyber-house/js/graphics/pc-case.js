/* ==========================================================
 * Modul: js/graphics/pc-case.js
 * Kompyuter korpusi: ichki qismlar
 * ========================================================== */
/* ---------- kompyuter korpusi ---------- */
{
 pc.rotation.y=0;pc.scale.setScalar(.65);pc.position.y=-.00325;
 const dk=L(0x14181d,{side:T.DoubleSide});pm.material=[dk,new T.MeshBasicMaterial({visible:false}),dk,dk,dk,dk];
 const add=(g,m,x,y,z)=>{const o=new T.Mesh(g,m);o.position.set(x,y,z);pc.add(o);return o},bx=(w,h,d)=>new T.BoxGeometry(w,h,d);
 const ring=(r,x,y,z,ry)=>{const f=add(new T.RingGeometry(r*.3,r,7),B(0x111111),x,y,z);f.rotation.y=ry;fans.push(f)};
 add(bx(.01,.78,.56),L(0x0b0d10),.2,.43,0);add(bx(.01,.4,.34),L(0x0d3b2c),.185,.52,-.07);
 add(bx(.07,.14,.1),L(0x9aa3ab),.15,.62,-.15);ring(.05,.113,.62,-.15,-Math.PI/2);
 add(bx(.012,.1,.012),B(0xff3da8),.17,.64,-.01);add(bx(.012,.1,.012),B(0x3dd8ff),.17,.64,.02);
 add(bx(.06,.05,.3),L(0x1a1f25),.15,.38,.03);ring(.04,.119,.38,-.04,-Math.PI/2);ring(.04,.119,.38,.1,-Math.PI/2);
 add(bx(.4,.12,.54),L(0x0a0c0f),0,.07,0);
 add(bx(.012,.85,.012),L(0x2a313a),-.205,.43,.3);add(bx(.012,.85,.012),L(0x2a313a),.205,.43,.3);
 [-.12,-.08].forEach(x=>add(bx(.03,.012,.01),L(0x000000),x,.835,.302));add(new T.CircleGeometry(.008,8),B(0x2dff88),.06,.8,.302);
 const gc2=cv(128,256),g4=gc2.getContext("2d");g4.fillStyle="rgba(8,10,13,.93)";g4.fillRect(0,0,128,256);g4.globalCompositeOperation="destination-out";
 for(let y=6;y<256;y+=10)for(let x=(y/10|0)%2?9:4;x<128;x+=10){g4.beginPath();g4.arc(x,y,2.6,0,7);g4.fill()}
 add(new T.PlaneGeometry(.4,.8),new T.MeshBasicMaterial({map:tex(gc2),transparent:true,depthWrite:false}),0,.43,.308);
 const lc=cv(128,32),l2=lc.getContext("2d");l2.fillStyle="#0c0f13";l2.fillRect(0,0,128,32);l2.fillStyle="#00bce9";l2.font="bold 20px monospace";l2.textAlign="center";l2.fillText("CYBER",64,23);
 add(new T.PlaneGeometry(.2,.05),new T.MeshBasicMaterial({map:tex(lc)}),0,.06,.309);
 add(bx(.07,.04,.02),L(0x0a0a0a),.1,.15,-.31);add(new T.CircleGeometry(.07,16),B(0x1a1d22),-.05,.62,-.302).rotation.y=Math.PI;
 PORTS.forEach(p=>{add(bx(.06,.03,.006),L(0x1d4e66),p[0],p[1],.31);const m=new T.MeshBasicMaterial({color:0});add(bx(.04,.016,.008),m,p[0],p[1],.314);PM.push(m)});
 /* ===== KORPUS: Tempered Glass Side Panel, Front Panel, Rear I/O Panel, Fans, Fan Grille, Power Button, USB, Audio, PSU, Motherboard, GPU, CPU Cooler ===== */
 {const M=MG(pc),kd=M.c(0x0b0d10),kg=M.c(0x1d2228),ks=M.c(0xa7b0b8),kb=M.c(0x020304,true),kcu=M.c(0xc27b3c),kgold=M.c(0xc9a24a),kn=M.c(0x1c5fb8),kdd=M.c(0x161b21);
  /* Tempered Glass Side Panel: ramka, murvatlar, yaltiroq */
  M.box(.014,.016,.52,kd,-.222,.76,0);M.box(.014,.016,.52,kd,-.222,.14,0);M.box(.014,.62,.016,kd,-.222,.45,.25);M.box(.014,.62,.016,kd,-.222,.45,-.25);
  for(const y of[.76,.14])for(const z of[.25,-.25])M.add(new T.CylinderGeometry(.008,.008,.012,10),ks,-.226,y,z,0,0,Math.PI/2);
  part(pc,-.215,.45,0,.012,.62,.5,"Tempered Glass Side Panel — Temperli shisha yon panel",1);part(pc,-.222,.45,0,.014,.66,.54,"Tempered Glass Side Panel — Temperli shisha yon panel");
  {const gc3=cv(64,64),g5=gc3.getContext("2d"),gg2=g5.createLinearGradient(0,0,64,64);gg2.addColorStop(0,"rgba(255,255,255,.2)");gg2.addColorStop(.4,"rgba(255,255,255,.03)");gg2.addColorStop(.6,"rgba(255,255,255,.12)");gg2.addColorStop(1,"rgba(255,255,255,0)");g5.fillStyle=gg2;g5.fillRect(0,0,64,64);
   const gm=new T.Mesh(new T.PlaneGeometry(.5,.62),new T.MeshBasicMaterial({map:tex(gc3),transparent:true,depthWrite:false,blending:T.AdditiveBlending}));gm.rotation.y=-Math.PI/2;gm.position.set(-.2175,.45,0);pc.add(gm)}
  /* devorlar (qutilar): ichki qismlar shisha orqali ko'rinsin */
  part(pc,0,.43,.3,.42,.85,.012,"Front Panel — Old panel");part(pc,0,.43,-.3,.42,.85,.012,"Rear I/O Panel — Orqa panel");part(pc,.21,.43,0,.012,.85,.6,"Kompyuter korpusi");part(pc,0,.855,0,.42,.012,.6,"Kompyuter korpusi");
  /* Front Panel: ramka, RGB chiziq, logotip qismi */
  M.box(.42,.02,.016,kg,0,.845,.305);M.box(.42,.02,.016,kg,0,.015,.305);M.box(.006,.7,.002,M.c(0x00bce9,true),-.19,.43,.3095);part(pc,0,.06,.31,.2,.05,.004,"Front Panel — Old panel (CYBER logotipi)");
  /* Cooling Fans qo'shimcha: orqa ventilyator, Fan Grille (old va orqa) */
  const rf=new T.Mesh(new T.RingGeometry(.02,.065,7),B(0x111111));rf.position.set(-.05,.62,-.303);rf.rotation.y=Math.PI;pc.add(rf);fans.push(rf);
  const kgr=M.c(0x3a424a,true);for(const rr of[.02,.042,.062])M.add(new T.RingGeometry(rr-.0012,rr+.0012,18),kgr,-.05,.62,-.3068,0,Math.PI,0);for(let i=0;i<4;i++)M.box(.13,.002,.002,kgr,-.05,.62,-.3068,0,0,i*Math.PI/4);
  part(pc,-.05,.62,-.3068,.17,.17,.01,"Fan Grille — Ventilyator panjarasi",1);
  for(let i=0;i<3;i++){part(pc,0,.22+i*.22,.309,.23,.23,.004,"Fan Grille — Ventilyator panjarasi",1);part(pc,0,.22+i*.22,.302,.19,.19,.02,"Cooling Fans — Ventilyatorlar",2)}
  part(pc,-.05,.62,-.303,.13,.13,.012,"Cooling Fans — Ventilyatorlar",2);part(pc,.119,.62,-.15,.02,.1,.1,"Cooling Fans — Ventilyatorlar",2);part(pc,.119,.38,-.04,.02,.08,.08,"Cooling Fans — Ventilyatorlar",2);part(pc,.119,.38,.1,.02,.08,.08,"Cooling Fans — Ventilyatorlar",2);
  /* Power Button */
  M.add(new T.RingGeometry(.032,.04,20),ks,.12,.8,.3158);part(pc,.12,.8,.31,.085,.085,.02,"Power Button — Quvvat tugmasi");
  /* USB Ports (old): USB-C qo'shimcha + Audio Jacks */
  M.box(.03,.012,.006,kd,.13,.55,.311);M.box(.022,.006,.002,kb,.13,.55,.3145);
  part(pc,-.05,.55,.31,.06,.03,.008,"USB Ports — USB portlar");part(pc,.05,.55,.31,.06,.03,.008,"USB Ports — USB portlar");part(pc,.13,.55,.311,.034,.016,.008,"USB Ports — USB portlar");
  for(const q of[[-.12,0x3ddc84],[-.15,0xff5fa8]]){M.add(new T.CylinderGeometry(.008,.008,.008,12),M.c(q[1],true),q[0],.55,.312,Math.PI/2,0,0);M.add(new T.CircleGeometry(.0035,8),kb,q[0],.55,.3162)}
  part(pc,-.135,.55,.312,.04,.02,.01,"Audio Jacks — Audio portlar");
  /* Rear I/O Panel: USB, HDMI, DP, Ethernet, Audio Jacks, kengaytma slotlari */
  M.box(.14,.1,.006,M.c(0x7e8790),.12,.64,-.303);
  for(const x of[.08,.11])for(const y of[.672,.652]){M.box(.022,.012,.01,kn,x,y,-.308);M.box(.016,.004,.002,kb,x,y,-.3135)}
  M.box(.028,.01,.01,kdd,.145,.672,-.308);M.box(.02,.01,.01,kdd,.175,.672,-.308);M.box(.03,.024,.012,ks,.16,.646,-.309);M.box(.022,.014,.002,kb,.16,.646,-.3155);
  for(const q of[[.07,0x3ddc84],[.092,0x4aa8ff],[.114,0xff5fa8]]){M.add(new T.CylinderGeometry(.006,.006,.008,10),M.c(q[1],true),q[0],.606,-.309,Math.PI/2,0,0)}
  part(pc,.095,.662,-.308,.05,.034,.012,"USB Ports — USB portlar");part(pc,.16,.646,-.309,.04,.03,.014,"Rear I/O Panel — Ethernet va video portlar");part(pc,.092,.606,-.309,.07,.016,.012,"Audio Jacks — Audio portlar");part(pc,.12,.64,-.303,.14,.1,.008,"Rear I/O Panel — Orqa panel");
  for(let i=0;i<2;i++)M.box(.13,.02,.004,kg,.12,.5-i*.027,-.302);M.box(.13,.048,.004,kg,.12,.38,-.302);for(const x of[.07,.1,.13])M.box(.018,.008,.004,kb,x,.38,-.3045);M.box(.02,.01,.004,kb,.165,.38,-.3045);
  /* PSU (Power Supply Unit): yon yozuv, orqa plata, tugma, ventilyatsiya, 24-pin kabel */
  part(pc,0,.07,0,.4,.12,.54,"PSU (Power Supply Unit) — Quvvat bloki",2);part(pc,.03,.07,-.3,.3,.1,.008,"PSU (Power Supply Unit) — Quvvat bloki");
  M.box(.3,.1,.004,kg,.03,.07,-.3025);M.box(.012,.02,.01,M.c(0x050607),.15,.105,-.307);for(let i=0;i<6;i++)M.box(.1,.004,.002,kb,-.06,.035+i*.012,-.3045);
  M.add(new T.TubeGeometry(new T.CatmullRomCurve3([new T.Vector3(.12,.13,.13),new T.Vector3(.14,.25,.14),new T.Vector3(.165,.45,.13),new T.Vector3(.17,.58,.125)]),12,.012,6),M.c(0x2b3138),0,0,0);M.box(.012,.07,.025,M.c(0xe8e8e8),.172,.6,.125);
  {const lc2=cv(360,90),l3=lc2.getContext("2d");l3.fillStyle="#10151a";l3.fillRect(0,0,360,90);l3.fillStyle="#1d2630";for(let x=0;x<360;x+=9)l3.fillRect(x,64,5,18);l3.fillStyle="#00bce9";l3.font="bold 24px monospace";l3.textAlign="center";l3.fillText("PSU 750W",180,32);l3.fillStyle="#c9a24a";l3.font="bold 15px monospace";l3.fillText("80+ GOLD  MODULAR",180,54);
   const pl2=new T.Mesh(new T.PlaneGeometry(.36,.09),new T.MeshBasicMaterial({map:tex(lc2)}));pl2.rotation.y=-Math.PI/2;pl2.position.set(-.2008,.07,0);pc.add(pl2)}
  /* Motherboard: PCB tekstura, VRM, chipset, RAM slotlari, batareya */
  {const pcbC=cv(256,300),q=pcbC.getContext("2d");q.fillStyle="#0e3d2e";q.fillRect(0,0,256,300);q.strokeStyle="rgba(120,220,170,.35)";q.lineWidth=1.2;for(let i=0;i<60;i++){let x=Math.random()*256,y=Math.random()*300;q.beginPath();q.moveTo(x,y);for(let k=0;k<3;k++){if(k%2)x+=(Math.random()-.5)*60;else y+=(Math.random()-.5)*60;q.lineTo(x,y)}q.stroke()}
   q.fillStyle="rgba(210,190,110,.7)";for(let i=0;i<50;i++)q.fillRect(Math.random()*250,Math.random()*295,4,4);q.fillStyle="#cfe9dc";q.font="bold 12px monospace";q.fillText("CYBER-X ATX",8,292);
   const bm=new T.Mesh(new T.PlaneGeometry(.34,.4),new T.MeshBasicMaterial({map:tex(pcbC)}));bm.rotation.y=-Math.PI/2;bm.position.set(.1795,.52,-.07);pc.add(bm)}
  M.box(.02,.05,.1,ks,.17,.69,-.21);M.box(.014,.05,.05,kgold,.172,.42,.06);M.box(.01,.11,.008,kdd,.177,.64,-.04);M.box(.01,.11,.008,kdd,.177,.64,.05);M.box(.008,.012,.16,kdd,.177,.455,-.02);M.add(new T.CylinderGeometry(.01,.01,.004,10),ks,.178,.34,.06,0,0,Math.PI/2);
  part(pc,.185,.52,-.07,.012,.4,.34,"Motherboard — Anakart",2);part(pc,.17,.69,-.21,.02,.05,.1,"Motherboard — Anakart",2);part(pc,.172,.42,.06,.014,.05,.05,"Motherboard — Anakart",2);part(pc,.17,.64,.0,.03,.12,.12,"Motherboard — Anakart",2);
  /* GPU: orqaga uzaytirilgan korpus, RGB chiziq, quvvat ulagichi, I/O planka */
  M.box(.06,.05,.18,kg,.15,.38,-.21);M.box(.004,.006,.46,M.c(0x00bce9,true),.121,.358,-.04);M.box(.02,.012,.04,kd,.15,.408,-.07);M.box(.06,.008,.3,kd,.15,.356,.03);
  part(pc,.15,.38,-.06,.06,.05,.48,"GPU — Videokarta",2);
  /* CPU Cooler: qanotchalar, mis issiqlik quvurlari, qopqoq */
  for(let i=0;i<8;i++)M.box(.0712,.0016,.1,kd,.15,.555+i*.017,-.15);M.box(.07,.006,.1,kd,.15,.693,-.15);for(let i=0;i<3;i++)M.add(new T.CylinderGeometry(.0045,.0045,.03,8),kcu,.15,.705,-.185+i*.035);
  part(pc,.15,.63,-.15,.075,.17,.105,"CPU Cooler — Protsessor sovutgichi",2);
  M.done()}
  /* ventilyatorlar: pichoqli geometriya, hub va kvadrat ramka */
  {const M=MG(pc),kd=M.c(0x1d2228),kh=M.c(0x2c333b);fans.forEach(f=>{const r=f.geometry.parameters.outerRadius,ry=f.rotation.y;f.geometry.dispose();f.geometry=fanGeo(r);f.material.side=T.DoubleSide;const nx=Math.sin(ry),nz=Math.cos(ry);M.add(new T.CircleGeometry(r*.27,12),kh,f.position.x+nx*.0016,f.position.y,f.position.z+nz*.0016,0,ry,0);M.add(new T.RingGeometry(r*1.44,r*1.7,4),kd,f.position.x-nx*.0008,f.position.y,f.position.z-nz*.0008,0,ry,Math.PI/4)});M.done()}
}

/* ==========================================================
 * Modul: js/kali/screen-input.js
 * Ekran bilan ishlash (bosish, oyna harakatlari)
 * ========================================================== */
/* ekran bilan ishlash */
const rc=new T.Raycaster(),v2=new T.Vector2();
function scrHit(cx,cy){v2.set(cx/baseW*2-1,-(cy/baseH)*2+1);camera.updateMatrixWorld();rc.setFromCamera(v2,camera);const h=rc.intersectObjects([monitor,monitor2])[0];if(!h||!h.uv)return null;
 const y=(1-h.uv.y)*H;if(h.object===monitor)return{x:h.uv.x*W,y};
 /* 2-monitor: kengaytirilgan bo'lsa ish stolining o'ng yarmi, dublikatda 1-ekran nusxasi, aks holda bosib bo'lmaydi */
 if(extOn())return{x:W+h.uv.x*W,y};if(dupOn())return{x:h.uv.x*W,y};return null}
function winRight(w,x,y){if(w.hits&&w.id!=="terminal"){hitClick(w,x,y,2);return}if(w.id==="terminal")CTX={x,y,items:[["Copy output",()=>{try{navigator.clipboard.writeText(termLines.map(l=>l.t).join("\n"));toast("Nusxalandi")}catch(e){toast("Clipboard mavjud emas")}}],["Paste",()=>{try{navigator.clipboard.readText().then(t=>{termIn+=t.replace(/\n/g," ");ta.value=termIn;dirty=true}).catch(()=>toast("Paste ruxsati yo'q"))}catch(e){toast("Clipboard mavjud emas")}}],["-"],["Clear",()=>{termLines=[]}]]}}
function hitClick(w,x,y,btn){if(!w.hits)return;for(let i=w.hits.length-1;i>=0;i--){const f=w.hits[i];if(x>=f.x&&x<=f.x+f.w&&y>=f.y&&y<=f.y+f.h){if(btn===2){if(f.fr)f.fr(x,y);return}const now=performance.now(),dbl=!!f.id&&LC.id===f.id&&now-LC.t<450;LC={id:f.id||null,t:now};if(f.fn){try{f.fn(dbl,x,y)}catch(e){toast(e.message)}}dirty=true;return}}}
function winClick(w,x,y,btn){const ty=w.y+32;
 if(w.id==="ide"&&y>ty&&y<ty+28){const rx=x-w.x;if(rx>10&&rx<80)runIde();else if(rx>86&&rx<130)insTab();else if(rx>138&&rx<208){try{F.wr(ideFile,ideText);ideOut.push("[saqlandi: "+ideFile+"]")}catch(e){ideOut.push("Xato: "+e.message)}}else if(rx>216&&rx<294)ideOut=[];dirty=true;return}
 hitClick(w,x,y,btn)}
function scrDown(x,y,btn){cur.x=x;cur.y=y;dirty=true;btn=btn||0;
 if(S.stage===2){if(x>412&&x<612&&y>340&&y<378)login();return}
 if(S.stage!==3)return;
 if(DSK.edit){dskDlgClick(x,y);return}
 if(CTX){const it=ctxAt(x,y);CTX=null;if(it&&it.length>1&&!it[2]&&it[0]!=="-"){try{it[1]()}catch(e){toast(e.message)}}return}
 const wp0=POP&&POP.t;if(POP&&popClick(x,y))return;
 if(menuOpen&&menuClick(x,y))return;
 if(placesOpen&&placesClick(x,y))return;
 if(coachClick(x,y))return;
 if(y<30&&x<W){if(btn!==2)panelClick(x,y,wp0);return}
 for(let i=wins.length-1;i>=0;i--){const w=wins[i];if(w.min)continue;
  if(x>=w.x&&x<=w.x+w.w&&y>=w.y&&y<=w.y+w.h){front(w);
   if(btn===2){winRight(w,x,y);return}
   if(y<w.y+30){const rx=w.x+w.w-x;if(rx<32)closeWin(w.id);else if(rx<54)toggleMax(w);else if(rx<76){w.min=true;const o=wins.filter(q=>!q.min).pop();focusId=o?o.id:null;ta.blur()}else if(!w.max)drag={w,dx:x-w.x,dy:y-w.y}}
   else if(!w.max&&x>w.x+w.w-14&&y>w.y+w.h-14)drag={w,rs:true};
   else if(!sbDown(w,x,y))winClick(w,x,y,btn);
   return}}
 desktopClick(x,y,btn)}
const cvEl=renderer.domElement;cvEl.addEventListener("mousedown",e=>{if(mobile&&seated&&kbOpen)e.preventDefault()});
cvEl.addEventListener("pointermove",e=>{if(!seated||seatT<.9)return;const h=scrHit(e.clientX,e.clientY);if(h){cur.x=h.x;cur.y=h.y;if(sbDrag){sbMove(h.y);return}if(menuOpen)menuHover(h.x,h.y);if(drag&&drag.rs){const mn=MINW[drag.w.id]||[260,160];drag.w.w=Math.max(mn[0],Math.min(vwNow()-drag.w.x,h.x-drag.w.x));drag.w.h=Math.max(mn[1],Math.min(H-drag.w.y,h.y-drag.w.y))}else if(drag){drag.w.x=Math.max(0,Math.min(vwNow()-120,h.x-drag.dx));drag.w.y=Math.max(h.x>=W?0:30,Math.min(H-40,h.y-drag.dy))}dirty=true}});
cvEl.addEventListener("pointerdown",e=>{if(seated&&seatT>.9){const h=scrHit(e.clientX,e.clientY);if(h){scrDown(h.x,h.y,e.button);syncInput();kbAuto();if(mobile&&e.button===0){clearTimeout(lpT);lpT=setTimeout(()=>{if(!drag&&!sbDrag&&Math.hypot(cur.x-h.x,cur.y-h.y)<6){scrDown(h.x,h.y,2);syncInput()}},550)}}}else if(!seated&&!mobile&&started)cvEl.requestPointerLock&&cvEl.requestPointerLock()});
addEventListener("pointerup",()=>{drag=null;sbDrag=null;clearTimeout(lpT)});
cvEl.addEventListener("contextmenu",e=>e.preventDefault());
cvEl.addEventListener("touchstart",e=>{if(mobile&&seated&&kbOpen)e.preventDefault()},{passive:false});
cvEl.addEventListener("click",()=>kbAuto());
cvEl.addEventListener("wheel",e=>{if(!seated||S.stage!==3||e.ctrlKey)return;const h=scrHit(e.clientX,e.clientY);if(!h)return;e.preventDefault();let ln=e.deltaMode===1?e.deltaY:e.deltaMode===2?e.deltaY*10:e.deltaY*.03;ln=Math.max(-8,Math.min(8,ln));if(!ln)return;for(let i=wins.length-1;i>=0;i--){const w=wins[i];if(w.min)continue;if(h.x>=w.x&&h.x<=w.x+w.w&&h.y>=w.y&&h.y<=w.y+w.h){wheelWin(w,ln,h);dirty=true;return}}},{passive:false});

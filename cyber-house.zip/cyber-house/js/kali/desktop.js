/* ==========================================================
 * Modul: js/kali/desktop.js
 * Ish stoli: yorliqlar, Sozdat menyusi, dialoglar
 * ========================================================== */
/* ---- ish stoli ---- */
/* ---- ish stoli: fayllar, yorliqlar, Sozdat (Create) menyusi ---- */
const dskDir=()=>HOME+"/Desktop";
const isLink=(nm,n)=>n.t==="f"&&(/\.desktop$/.test(nm)||/^\[Desktop Entry\]/.test(n.c||""));
function linkInfo(n){const g=k=>{const m=String(n.c||"").match(new RegExp("^"+k+"=(.*)$","m"));return m?m[1].trim():""};return{name:g("Name"),exec:g("Exec")}}
function runLink(p){try{const n=nd(p);if(!n)throw new Error("Yorliq topilmadi");const ex=linkInfo(n).exec;if(!ex)throw new Error("Yorliq bo'sh (Exec yo'q)");
 if(ex.indexOf("app:")===0){const id=ex.slice(4);if(!APPS.find(a=>a.id===id))throw new Error("Bunday ilova yo'q: "+id);openApp(id)}
 else if(ex[0]==="/"){const t=nd(ex);if(!t)throw new Error(ex+": topilmadi");if(t.t==="d")openFiles(ex);else openPath(ex)}
 else{openApp("terminal");run(ex)}}catch(e){toast(e.message)}syncInput();dirty=true}
function iconApp(o){const ex=linkInfo(o.node).exec;if(ex.indexOf("app:")===0){const a=APPS.find(q=>q.id===ex.slice(4));if(a)return a}
 if(ex[0]==="/")return{col:"#e0a93a",k:"▤",fg:"#222"};if(ex)return{col:"#1e2a36",k:"$_",fg:"#3df0a0"};return{col:"#3a4660",k:"↗",fg:"#fff"}}
function deskItems(){const it=[
 {nm:"Home",label:"Home",col:"#e0a93a",sys:1,open:()=>openFiles(HOME)},
 {nm:"Trash",label:"Trash",col:"#7b8794",sys:1,open:()=>openFiles(TRASH)},
 {nm:"File System",label:"File System",col:"#5fa8ff",sys:1,open:()=>openFiles("/")}];
 try{const d=nd(dskDir());Object.keys(d.k).sort().forEach(k=>{if(k[0]===".")return;const n=d.k[k],p=dskDir()+"/"+k,lk=isLink(k,n);
  it.push({nm:k,label:lk?(linkInfo(n).name||k.replace(/\.desktop$/,"")):k,col:n.t==="d"?"#e0a93a":"#c5d3e0",file:n.t==="f"&&!lk,link:lk,node:n,p,open:()=>n.t==="d"?openFiles(p):lk?runLink(p):openPath(p)})})}catch(e){}return it}
const dpos=i=>[30+Math.floor(i/5)*92,54+(i%5)*86];
function drawDesk(){if(!SET.icons)return;deskItems().forEach((o,i)=>{const[px,py]=dpos(i);
 if(DSK.sel===o.nm){rr(px-10,py-10,68,86,6,"rgba(59,123,224,.30)");c.strokeStyle="rgba(127,212,255,.6)";c.lineWidth=1;c.strokeRect(px-9.5,py-9.5,67,85)}
 if(o.link){const a=iconApp(o);rr(px+2,py-5,40,40,9,a.col);tx(a.k,px+22-a.k.length*5.4,py+21,a.fg,"bold 17px monospace");rr(px+31,py+24,14,14,3,"#f2f5f8");tx("↗",px+33,py+35,"#1a2230","bold 11px monospace")}
 else if(o.file){rr(px+8,py-6,30,42,3,o.col);c.fillStyle="rgba(0,0,0,.25)";c.fillRect(px+13,py+6,20,2);c.fillRect(px+13,py+14,20,2);c.fillRect(px+13,py+22,14,2)}
 else{rr(px,py,46,36,5,o.col);rr(px,py-6,22,9,3,o.col)}
 const lb=o.label,l1=lb.slice(0,11),l2=lb.length>22?lb.slice(11,21)+"…":lb.slice(11);
 tx(l1,px+23-l1.length*3.7,py+54,"#dfe9f2","12px monospace");if(l2)tx(l2,px+23-l2.length*3.7,py+67,"#dfe9f2","12px monospace")})}
function dskAt(x,y){const it=deskItems();for(let i=0;i<it.length;i++){const[px,py]=dpos(i);if(x>=px-10&&x<px+60&&y>=py-10&&y<py+76)return it[i]}return null}
function desktopClick(x,y,btn){const o=SET.icons?dskAt(x,y):null;
 if(btn===2){if(o){DSK.sel=o.nm;CTX=ctxDskItem(o,x,y)}else{DSK.sel=null;CTX=ctxDesk(x,y)}return}
 if(!o){DSK.sel=null;return}
 const now=performance.now(),id="d:"+o.nm,dbl=mobile||(LC.id===id&&now-LC.t<450);LC={id,t:now};DSK.sel=o.nm;if(dbl){LC.id=null;o.open()}}
function ctxDskItem(o,x,y){const it=[["Open",()=>o.open()]];if(!o.sys){if(o.file)it.push(["Edit with Mousepad",()=>openPath(o.p)]);it.push(["-"],["Rename...",()=>dskStart("rename",o)],["Move to Trash",()=>{delPath(o.p,false);DSK.sel=null}])}return{x,y,items:it}}
function ctxDesk(x,y){const D=dskDir();return{x,y,items:[["Sozdat (Create)   ▸",()=>{CTX=ctxCreate(x,y)}],["Paste",()=>pasteTo({path:D}),!CLIP],["-"],["Open Terminal Here",()=>termCd(D)],["Open Thunar Here",()=>openFiles(D)],["-"],["Change Wallpaper",()=>{SET.wall=(SET.wall+1)%WALLS.length;paintWall(SET.wall);saveSet()}],["Settings",()=>openApp("settings")],["Refresh",()=>{dirty=true}]]}}
function ctxCreate(x,y){return{x,y,items:[["‹  Orqaga",()=>{CTX=ctxDesk(x,y)}],["-"],["Folder  —  Papka",()=>dskStart("dir")],["Text Document  —  Matn",()=>dskStart("txt")],["Shortcut  —  Yorliq",()=>dskStart("link")]]}}
function dskStart(kind,o){const D=dskDir();let nm="";
 if(kind==="dir")nm=uniq(D+"/Yangi papka").split("/").pop();else if(kind==="txt")nm=uniq(D+"/Yangi matn.txt").split("/").pop();else if(kind==="link")nm="Yangi yorliq";else nm=o.nm;
 DSK.edit={kind,name:nm,target:"",f:"name",old:o?o.nm:""};syncInput();setTimeout(()=>{try{ta.select()}catch(e){}},0);dirty=true}
function normTarget(t){t=t.trim();if(!t)return"";const l=t.toLowerCase();if(l.indexOf("app:")===0)return"app:"+l.slice(4).trim();const a=APPS.find(q=>q.id===l||q.n.toLowerCase()===l||q.n.toLowerCase().split(" ")[0]===l);if(a)return"app:"+a.id;if(t[0]==="/"||t[0]==="~")return abs(t,HOME);return t}
function dskCommit(){const e=DSK.edit;if(!e)return;try{const D=dskDir(),b=e.name.trim();if(!b)throw new Error("Nom kerak");if(/[\/\0]/.test(b))throw new Error("Nomda '/' belgisi bo'lmasin");F.mkdir(D,true);
 if(e.kind==="rename"){if(b!==e.old){if(nd(join(D,b)))throw new Error("Bunday nom mavjud: "+b);F.mv(join(D,e.old),join(D,b))}DSK.sel=b}
 else if(e.kind==="dir"){if(nd(join(D,b)))throw new Error("Bunday nom mavjud: "+b);F.mkdir(join(D,b));DSK.sel=b}
 else if(e.kind==="txt"){const fn=b.indexOf(".")<0?b+".txt":b;if(nd(join(D,fn)))throw new Error("Bunday nom mavjud: "+fn);F.wr(join(D,fn),"");DSK.sel=fn}
 else if(e.kind==="link"){const tg=normTarget(e.target);if(!tg)throw new Error("Maqsad kerak: ilova, papka yo'li yoki buyruq");if(tg.indexOf("app:")===0&&!APPS.find(a=>a.id===tg.slice(4)))throw new Error("Bunday ilova yo'q: "+tg.slice(4));
  const nm=b.replace(/\.desktop$/,""),fn=nm+".desktop";if(nd(join(D,fn)))throw new Error("Bunday nom mavjud: "+fn);F.wr(join(D,fn),"[Desktop Entry]\nType=Application\nName="+nm+"\nExec="+tg+"\n");DSK.sel=fn}
 }catch(er){toast(er.message);return}
 DSK.edit=null;ta.value="";syncInput();dirty=true}
function dskCancel(){DSK.edit=null;ta.value="";syncInput();dirty=true}
function dskBox(){const h=DSK.edit.kind==="link"?262:134;return{x:(W-440)/2|0,y:Math.max(44,((H-h)/2|0)-20),w:440,h}}
const DSK_T={dir:"Yangi papka (Create Folder)",txt:"Yangi matn fayli (Create Text Document)",link:"Yangi yorliq (Create Shortcut)",rename:"Qayta nomlash (Rename)"};
function drawDskDlg(){const e=DSK.edit;if(!e)return;const b=dskBox();c.fillStyle="rgba(0,0,0,.35)";c.fillRect(0,30,W,H-30);rr(b.x,b.y,b.w,b.h,8,"#232a3a");c.strokeStyle="#3a4660";c.lineWidth=1;c.strokeRect(b.x+.5,b.y+.5,b.w-1,b.h-1);
 tx(DSK_T[e.kind],b.x+16,b.y+26,"#7fd4ff","bold 13px monospace");const bl=((performance.now()/500)|0)%2===0;
 const fld=(lab,val,y,act,ph)=>{tx(lab,b.x+16,y-6,"#8fa3b5","11px monospace");rr(b.x+16,y,b.w-32,28,5,"#0b0f14");c.strokeStyle=act?accent():"#2b3347";c.lineWidth=1;c.strokeRect(b.x+16.5,y+.5,b.w-33,27);const mc=Math.floor((b.w-52)/7.8),s=val.slice(-mc);tx(s||ph||"",b.x+24,y+19,s?"#e6edf3":"#5d7385","13px monospace");if(act&&bl){c.fillStyle="#7fd4ff";c.fillRect(b.x+24+s.length*7.8,y+5,2,18)}};
 fld(e.kind==="link"?"Nomi (Name)":"Nomi",e.name,b.y+52,e.f==="name");
 if(e.kind==="link"){fld("Maqsad (Target): ilova, papka yo'li yoki buyruq",e.target,b.y+104,e.f==="target","masalan: app:terminal  yoki  /home/player");
  tx("Tez tanlash — ilova:",b.x+16,b.y+152,"#8fa3b5","11px monospace");
  APPS.forEach((a,i)=>{const x2=b.x+16+(i%5)*84,y2=b.y+160+Math.floor(i/5)*26,on=e.target==="app:"+a.id;rr(x2,y2,80,22,5,on?accent():"#2b3347");const nm=a.n.split(" ")[0].slice(0,10);tx(nm,x2+40-nm.length*3.4,y2+15,"#e6edf3","11px monospace")})}
 const by=b.y+b.h-40;rr(b.x+b.w-190,by,84,28,5,accent());tx("OK",b.x+b.w-190+42-8,by+19,"#fff","bold 13px monospace");rr(b.x+b.w-96,by,80,28,5,"#4a2b2b");tx("Bekor",b.x+b.w-96+40-17,by+19,"#fff","12px monospace")}
function dskDlgClick(x,y){const e=DSK.edit,b=dskBox(),by=b.y+b.h-40;
 if(x>=b.x+b.w-190&&x<b.x+b.w-106&&y>=by&&y<by+28){dskCommit();return}
 if(x>=b.x+b.w-96&&x<b.x+b.w-16&&y>=by&&y<by+28){dskCancel();return}
 if(x>=b.x+16&&x<b.x+b.w-16){if(y>=b.y+52&&y<b.y+80)e.f="name";else if(e.kind==="link"&&y>=b.y+104&&y<b.y+132)e.f="target"}
 if(e.kind==="link")APPS.forEach((a,i)=>{const x2=b.x+16+(i%5)*84,y2=b.y+160+Math.floor(i/5)*26;if(x>=x2&&x<x2+80&&y>=y2&&y<y2+22){e.target="app:"+a.id;if(!e.name.trim()||e.name==="Yangi yorliq")e.name=a.n}});
 syncInput();dirty=true}
function openFiles(p){openApp("files");const w=wins.find(w=>w.id==="files");go(w,p)}

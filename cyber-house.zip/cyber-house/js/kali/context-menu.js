/* ==========================================================
 * Modul: js/kali/context-menu.js
 * Kontekst menyu
 * ========================================================== */
/* ---- kontekst menyu ---- */
function ctxBox(){let wd=110;CTX.items.forEach(i=>{wd=Math.max(wd,i[0].length*7.6+30)});let h=8;CTX.items.forEach(i=>h+=i[0]==="-"?7:22);const mx=CTX.x>=W?W:0;return{x:Math.min(CTX.x,mx+W-wd-4),y:Math.min(CTX.y,H-h-4),w:wd,h}}
function ctxAt(x,y){if(!CTX)return null;const b=ctxBox();if(x<b.x||x>b.x+b.w||y<b.y||y>b.y+b.h)return null;let cy=b.y+4;for(const it of CTX.items){const hh=it[0]==="-"?7:22;if(y>=cy&&y<cy+hh)return it;cy+=hh}return null}
function drawCtx(){if(!CTX)return;const b=ctxBox();rr(b.x,b.y,b.w,b.h,5,"#232a3a");c.strokeStyle="#3a4660";c.lineWidth=1;c.strokeRect(b.x+.5,b.y+.5,b.w-1,b.h-1);let cy=b.y+4;for(const it of CTX.items){if(it[0]==="-"){c.fillStyle="#3a4660";c.fillRect(b.x+6,cy+3,b.w-12,1);cy+=7;continue}const hov=!it[2]&&cur.x>=b.x&&cur.x<=b.x+b.w&&cur.y>=cy&&cur.y<cy+22;if(hov)rr(b.x+3,cy,b.w-6,22,4,accent());tx(it[0],b.x+14,cy+15,it[2]?"#5d6b7a":"#e6edf3","13px monospace");cy+=22}}

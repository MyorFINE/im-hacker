/* ==========================================================
 * Modul: js/kali/displays.js
 * Ikki monitor: kengaytirilgan ish stoli (extend), dublikat (mirror), o'chirish,
 * kamera nazari (1-ekran / 2-ekran / ikkalasi), Settings > Displays, xrandr buyrug'i
 * ========================================================== */
/* ---------- ish stoli virtual kengligi: VW = 2 ta ekran (1024 + 1024) ---------- */
if(!SET.dmode)SET.dmode="ext"; /* ext = kengaytirish, dup = dublikat, off = 2-ekran o'chiq */
/* 2-monitor signali: 0 = signal yo'q, 1 = kengaytirilgan ish stoli, 2 = 1-ekran nusxasi */
const m2Sig=()=>!S.on||!S.mplug2?0:SET.dmode==="ext"?(S.stage===3?1:0):SET.dmode==="dup"?(S.stage>=2?2:0):0;
const extOn=()=>m2Sig()===1,dupOn=()=>m2Sig()===2,vwNow=()=>extOn()?VW:W;
/* 2-ekran o'chsa/uzilsa, undagi oynalar 1-ekranga qaytariladi (haqiqiy Linux kabi) */
function monFix(){if(extOn())return;
 wins.forEach(w=>{if(w.x+w.w>W){const m2=w.x+w.w/2>=W;
  if(w.max){w.x=0;w.y=30;w.w=W;w.h=H-30}
  else{const nx=m2?w.x-W:w.x;w.x=Math.max(0,Math.min(nx,W-w.w));w.y=Math.max(32,Math.min(w.y,H-w.h-6))}}});
 if(cur.x>W-1)cur.x=W-1}
function monGather(){wins.forEach(w=>{if(w.max){w.x=0;w.y=30;w.w=W;w.h=H-30}else{w.x=Math.max(0,Math.min(w.x>=W?w.x-W:w.x,W-w.w));w.y=Math.max(32,Math.min(w.y,H-w.h-6))}});dirty=true}
function setDmode(m){SET.dmode=m;saveSet();if(m!=="ext")monFix();dirty=true;toast({ext:"🖥🖥 Kengaytirilgan ish stoli",dup:"🖥🖥 Dublikat (mirror)",off:"🖥 Faqat 1-ekran"}[m])}
/* ---------- kamera nazari: o'tirganda qaysi monitorga qarash ---------- */
/* T[mode] = [kamera x, qarash nuqtasi x, ko'rinish yarim kengligi]; monitorlar stol markazi (x=0) atrofida: 1-monitor chapda, 2-monitor o'ngda */
/* user — foydalanuvchi qarashni o'zi tanlagan bo'lsa (F2/tugma), avtomatik "ikkalasi" ko'rinishi o'chadi */
const GZ={m:0,cx:MON1.gx/2,lx:MON1.gx,hw:.515,px:.5,et:0,sh:false,user:false,cpx:null,cpy:null,T:[[MON1.gx/2,MON1.gx,.515],[MON2.gx/2,MON2.gx,.515],[0,0,1.12]]};
const GZL=["🖥 1-ekran","🖥 2-ekran","🖥🖥 Ikkalasi"];
function gazeCycle(){if(!seated||!S.mplug2)return;GZ.user=true;GZ.m=(GZ.m+1)%3;GZ.et=-.8;dirty=true}
addEventListener("pointermove",e=>{GZ.px=e.clientX/Math.max(1,innerWidth);GZ.cpx=e.clientX;GZ.cpy=e.clientY});
addEventListener("keydown",e=>{if(e.key==="F2"&&seated&&S.mplug2){e.preventDefault();gazeCycle()}});
$("gzBtn").onclick=gazeCycle;
function gazeTick(dt){const can=seated&&!!S.mplug2,sh=can&&seatT>.9;
 if(!seated||!S.mplug2){GZ.m=0;GZ.et=0;GZ.user=false}
 /* 2-ekran ishlayotganda (kengaytirilgan stol) ikkala monitor ham ko'rinib turadi — sichqoncha ular orasida bosh burmasdan, uzluksiz o'tadi */
 else if(!GZ.user&&seatT>.5){const want=extOn()?2:0;if(GZ.m!==want){GZ.m=want;GZ.et=0}}
 if(GZ.sh!==sh){GZ.sh=sh;$("gzBtn").style.display=sh?"block":"none"}
 if(sh){const b=$("gzBtn"),lb=GZL[GZ.m];if(b.textContent!==lb)b.textContent=lb}
 /* kamera nishoni o'zgarayotganda (F2, 2-ekran yonishi) sichqoncha ostidagi nuqta har kadrda qayta hisoblanadi — kursor sakramaydi, silliq suriladi */
 if(can&&!mobile&&seatT>.9&&GZ.cpx!=null){const gt=GZ.T[GZ.m];if(Math.abs(GZ.cx-gt[0])+Math.abs(GZ.lx-gt[1])+Math.abs(GZ.hw-gt[2])>.004)scrMove(GZ.cpx,GZ.cpy)}}
/* ---------- har kadrda ---------- */
function monTick(dt){const sg=m2Sig(),live=S.mplug2&&S.on&&sg>0;
 mled2.material.color.setHex(S.mplug2?(live?0x1fe39a:0xff9a1f):0x2a1a0a);
 mLight.position.x+=((S.on&&S.stage===3&&S.mplug2&&SET.dmode!=="off"?0:MON1.gx)-mLight.position.x)*Math.min(1,dt*3);
 monFix();gazeTick(dt)}
/* ---------- Settings > Displays sahifasi ---------- */
function drawDispPage(w,px,py,T,H2,radio,chb){
 H2("Ekranlar (Displays)",py+8);
 const m=SET.dmode,p2=!!S.mplug2,bx=[px,px+150],by=py+20;
 [["1","DP-1 (asosiy)",true],["2","HDMI-1",p2]].forEach((d,i)=>{const x=bx[i],act=d[2]&&(i===0||m!=="off");
  rr(x,by,136,68,6,act?"#1d3558":"#1a1f29");c.strokeStyle=act?accent():"#3a4660";c.lineWidth=2;c.strokeRect(x+.5,by+.5,135,67);
  tx(d[0],x+12,by+34,act?"#e6edf3":"#5d6b7a","bold 28px monospace");tx(d[1],x+12,by+56,act?"#9fc3d6":"#5d6b7a","11px monospace");
  if(i===1&&m==="dup")tx("= 1",x+100,by+34,"#e5c15d","bold 16px monospace")});
 tx(m==="ext"?"◀ 1-ekran | 2-ekran ▶":m==="dup"?"nusxa (mirror)":"—",px+86,by+84,"#7f95a8","11px monospace");
 const y0=py+124;
 radio(y0,m==="ext","Kengaytirish (Extend)",()=>setDmode("ext"));
 radio(y0+24,m==="dup","Dublikat (Mirror)",()=>setDmode("dup"));
 radio(y0+48,m==="off","Faqat 1-ekran",()=>setDmode("off"));
 const by2=y0+78;rr(px,by2,232,26,6,"#2b3347");tx("Oynalarni 1-ekranga yig'ish",px+12,by2+17,"#e6edf3","12px monospace");w.hits.push({x:px,y:by2,w:232,h:26,fn:()=>{monGather();toast("Oynalar 1-ekranga yig'ildi")}});
 T(p2?(S.on?"2-monitor ulangan (HDMI-1)":"2-monitor ulangan, kompyuter o'chiq"):"2-monitor vilkasi rozetkaga ulanmagan",by2+48,p2?"#3dd8a0":"#ff9a5f","12px monospace");
 T("Terminal: xrandr  |  F2 — monitorga qarash",by2+68,"#6b7a8a","11px monospace")}
/* ---------- xrandr ---------- */
Object.assign(C,{xrandr:a=>{
 const m=SET.dmode,p2=!!S.mplug2,ext=m==="ext"&&p2,sz=(ext?VW:W)+" x "+H;
 const info=()=>{let r="Screen 0: minimum 320 x 200, current "+sz+", maximum 16384 x 16384\nDP-1 connected primary "+W+"x"+H+"+0+0 (normal left inverted right x axis y axis) 530mm x 300mm\n   "+W+"x"+H+"      60.00*+\n";
  if(!p2)r+="HDMI-1 disconnected (normal left inverted right x axis y axis)";
  else if(m==="off")r+="HDMI-1 connected (normal left inverted right x axis y axis)\n   "+W+"x"+H+"      60.00 +";
  else r+="HDMI-1 connected "+W+"x"+H+"+"+(m==="ext"?W:0)+"+0 (normal left inverted right x axis y axis) 530mm x 300mm\n   "+W+"x"+H+"      60.00*+";return r};
 if(!a.length)return info();
 if(a.includes("--listmonitors")){const r=["Monitors: "+(p2&&m!=="off"?2:1),
  " 0: +*DP-1 "+W+"/530x"+H+"/300+0+0  DP-1"];if(p2&&m!=="off")r.push(" 1: +HDMI-1 "+W+"/530x"+H+"/300+"+(m==="ext"?W:0)+"+0  HDMI-1");return r.join("\n")}
 const oi=a.indexOf("--output");if(oi<0||!a[oi+1])throw new Error("usage: xrandr [--output HDMI-1 --auto | --right-of DP-1 | --same-as DP-1 | --off]");
 const out=a[oi+1];if(out==="DP-1"){if(a.includes("--off"))throw new Error("xrandr: asosiy ekranni (DP-1) o'chirib bo'lmaydi");return""}
 if(out!=="HDMI-1")throw new Error("xrandr: cannot find output '"+out+"'");
 if(!p2)throw new Error("xrandr: output HDMI-1 disconnected (2-monitor vilkasini rozetkaga ulang)");
 if(a.includes("--off")){setDmode("off");return""}
 if(a.includes("--same-as")){setDmode("dup");return""}
 if(a.includes("--right-of")||a.includes("--auto")){setDmode("ext");return""}
 if(a.includes("--left-of"))throw new Error("xrandr: 2-monitor jismonan o'ng tomonda turibdi — --right-of DP-1 ishlating");
 throw new Error("xrandr: noto'g'ri parametr")}});
{const h1=C.help;C.help=()=>h1()+"\nEkranlar: xrandr (2-monitor: --auto | --same-as DP-1 | --off)"}

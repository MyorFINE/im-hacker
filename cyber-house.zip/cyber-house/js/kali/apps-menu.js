/* ==========================================================
 * Modul: js/kali/apps-menu.js
 * Applications menyusi va Places
 * ========================================================== */
/* ---- Applications menyusi ---- */
const KM=[
{n:"Information Gathering",d:"Tarmoq, IP, domen, port va serverlar haqida ma'lumot yig'ish.",t:["Nmap|nmap|Port va xizmatlarni skanerlash","Maltego|maltego|Aloqalar va izlar grafigi","Whois|whois|Domen egasi haqida ma'lumot","theHarvester|theharvester|Email va subdomenlarni yig'ish","DNSenum|dnsenum|DNS yozuvlarini sanash"]},
{n:"Vulnerability Analysis",d:"Tizim va serverlardagi zaifliklarni aniqlash.",t:["OpenVAS|openvas|Zaifliklar skaneri","Nikto|nikto|Veb-server zaifliklarini tekshirish","Lynis|lynis|Tizim xavfsizligi auditi"]},
{n:"Web Application Analysis",d:"Saytlarni xavfsizlik nuqtayi nazaridan tekshirish.",t:["Burp Suite|burpsuite|Veb-trafik proksi va tahlil","SQLmap|sqlmap|SQL in'eksiya zaifligini tekshirish","Nikto|nikto|Veb-server skaneri","Dirb|dirb|Yashirin yo'llarni qidirish"]},
{n:"Database Assessment",d:"Ma'lumotlar bazalari xavfsizligini baholash.",t:["SQLmap|sqlmap|SQL in'eksiya tekshiruvi","SQLite Browser|sqlitebrowser|SQLite fayllarini ko'rish"]},
{n:"Password Attacks",d:"Parollarning mustahkamligini tekshirish.",t:["John the Ripper|john|Parol heshlarini tekshirish","Hashcat|hashcat|GPU bilan hesh tekshirish","Hydra|hydra|Login xizmatlarini tekshirish"]},
{n:"Wireless Attacks",d:"Wi-Fi va simsiz tarmoqlar xavfsizligini tekshirish.",t:["Aircrack-ng|aircrack-ng|Wi-Fi shifrlash tahlili","Kismet|kismet|Simsiz tarmoq detektori","Wifite|wifite|Avtomatik Wi-Fi audit"]},
{n:"Reverse Engineering",d:"Dasturlarni teskari tahlil qilish.",t:["Ghidra|ghidra|Dekompilyator","Radare2|radare2|Binar tahlil freymvorki","GDB|gdb|Dastur nosozliklarini kuzatish"]},
{n:"Exploitation Tools",d:"Aniqlangan zaifliklarni sinov muhitida tekshirish.",t:["Metasploit|msfconsole|Penetratsion test platformasi","SearchSploit|searchsploit|Exploit bazasidan qidirish","BeEF|beef-xss|Brauzer xavfsizlik sinovi"]},
{n:"Sniffing & Spoofing",d:"Tarmoq trafigini kuzatish va tahlil qilish.",t:["Wireshark|wireshark|Paketlar tahlilchisi","Ettercap|ettercap|LAN trafik tahlili","tcpdump|tcpdump|Konsol paket tutgich"]},
{n:"Post Exploitation",d:"Tizimga kirgandan keyingi tekshiruv vositalari.",t:["Netcat|nc|Tarmoq ulanishlari vositasi","Proxychains|proxychains|Trafikni proksi zanjiri orqali o'tkazish","Evil-WinRM|evil-winrm|Windows masofaviy boshqaruv sinovi"]},
{n:"Forensics",d:"Raqamli dalillar va disk tahlili.",t:["Autopsy|autopsy|Disk tasvirlarini tahlil qilish","Binwalk|binwalk|Fayl ichidagi ma'lumotlarni topish","Foremost|foremost|O'chirilgan fayllarni tiklash"]},
{n:"Reporting Tools",d:"Natijalarni hujjatlashtirish va hisobot tayyorlash.",t:["CherryTree|cherrytree|Ierarxik qaydlar","Faraday|faraday|Hamkorlikdagi hisobotlar","Pipal|pipal|Parollar statistikasi"]},
{n:"Social Engineering Tools",d:"Inson omiliga qaratilgan xavfsizlik sinovlari.",t:["SET|setoolkit|Social-Engineer Toolkit","Gophish|gophish|Fishing xabardorlik mashqlari"]},
{n:"System Services",d:"Tizim xizmatlarini boshqarish.",t:["Apache2|apache2|Veb-server xizmati","OpenSSH|sshd|SSH serveri","PostgreSQL|postgresql|Ma'lumotlar bazasi serveri","Metasploit DB|msfdb|Metasploit bazasi"]},
{n:"Usual Applications",d:"Kundalik ilovalar va tizim vositalari.",t:["Terminal|app:terminal|Buyruqlar qatori","Thunar|app:files|Fayl menejeri","Firefox ESR|app:browser|Veb-brauzer","Mousepad|app:editor|Matn muharriri","System Monitor|app:monitor|Resurslar monitori","Settings|app:settings|Tizim sozlamalari","Kod IDE (Python)|app:ide|Python IDE","USB Flesh|app:usb|Flesh-xotira","Security Center|app:ids|IDS va himoya paneli","Attack Monitor|app:atkmon|Hujum monitoringi (IP manzillar)"]}
];
const MY0=64,RH=22;
function menuFind(q){q=q.toLowerCase();const seen={},r=[];KM.forEach(k=>k.t.forEach(t=>{const[nm,cm]=t.split("|");if(!seen[cm]&&(nm.toLowerCase().includes(q)||cm.toLowerCase().includes(q))){seen[cm]=1;r.push(t)}}));return r.slice(0,9)}
function menuList(){return menuQ?menuFind(menuQ):(menuCat>=0&&menuCat<KM.length?KM[menuCat].t:null)}
function launch(t){const cmd=t.split("|")[1];menuOpen=false;menuQ="";if(cmd.indexOf("app:")===0)openApp(cmd.slice(4));else{openApp("terminal");run(cmd+" --help")}dirty=true}
function menuEnter(){if(!menuQ)return;const l=menuFind(menuQ);if(l.length)launch(l[0]);syncInput()}
function menuHover(x,y){const n=KM.length;if(!menuQ&&x<250&&y>=MY0){const r=Math.floor((y-MY0)/RH),v=r<n?r:-1;if(v!==menuCat){menuCat=v;dirty=true}}}
function menuClick(x,y){const n=KM.length,tot=n+2,list=menuList();
 if(y<30&&x>=8&&x<=32){menuOpen=false;dirty=true;return true}
 if(x<250&&y>=30&&y<MY0+tot*RH+6){if(y>=MY0){const r=Math.floor((y-MY0)/RH);if(r<n){menuCat=r;menuQ="";ta.value=""}else if(r===n){menuOpen=false;openApp("settings")}else if(r===n+1){menuOpen=false;logout()}}dirty=true;return true}
 if(list&&x>=250&&x<610&&y>=30&&y<94+Math.max(1,list.length)*34){const j=Math.floor((y-94)/34);if(j>=0&&j<list.length)launch(list[j]);return true}
 menuOpen=false;dirty=true;return false}
function drawMenu(){if(!menuOpen)return;const n=KM.length,tot=n+2,ph=MY0+tot*RH+6-30;
 rr(0,30,250,ph,0,"#121722");c.fillStyle="#2a3345";c.fillRect(249,30,1,ph);
 rr(8,36,234,22,5,"#0b0f14");tx((menuQ||"Ilovalarni qidirish…").slice(-28),16,52,menuQ?"#e6edf3":"#5d7385","13px monospace");
 if(menuQ&&((performance.now()/500)|0)%2===0){c.fillStyle="#7fd4ff";c.fillRect(16+Math.min(28,menuQ.length)*7.8,40,2,14)}
 for(let i=0;i<tot;i++){const y=MY0+i*RH,sel=!menuQ&&i===menuCat;if(i===n){c.fillStyle="#2a3345";c.fillRect(8,y,234,1)}if(sel)rr(4,y+1,242,20,4,accent());
  tx(i<n?String(i+1).padStart(2,"0")+"  "+KM[i].n:i===n?"Settings":"Log Out",14,y+15,sel?"#fff":"#c5d3e0","13px monospace");if(i<n)tx("›",232,y+15,sel?"#fff":"#6b7a8a","bold 14px monospace")}
 const list=menuList();if(!list)return;const h=64+Math.max(1,list.length)*34;rr(250,30,360,h,0,"#161c2a");c.fillStyle="#2a3345";c.fillRect(609,30,1,h);
 if(menuQ)tx("Natijalar: "+list.length,264,52,"#7fd4ff","bold 14px monospace");
 else{const k=KM[menuCat];tx(String(menuCat+1).padStart(2,"0")+"  "+k.n,264,52,"#7fd4ff","bold 14px monospace");let a=k.d,b="";if(a.length>46){const i=a.lastIndexOf(" ",46);b=a.slice(i+1);a=a.slice(0,i)}tx(a,264,70,"#8fa3b5","12px monospace");if(b)tx(b,264,84,"#8fa3b5","12px monospace")}
 if(!list.length)tx("Hech narsa topilmadi",264,116,"#6b7a8a","13px monospace");
 list.forEach((t,j)=>{const[nm,cm,ds]=t.split("|"),y=94+j*34,hov=cur.x>=250&&cur.x<610&&cur.y>=y&&cur.y<y+34;if(hov)rr(256,y,348,32,4,"#1f2a40");
  rr(264,y+5,22,22,5,cm.indexOf("app:")===0?"#2a3b55":"#1e2a36");tx(cm.indexOf("app:")===0?"▣":"$_",268,y+21,cm.indexOf("app:")===0?"#7fd4ff":"#3df0a0","bold 11px monospace");
  tx(nm,296,y+14,"#e6edf3","bold 13px monospace");tx(ds,296,y+28,"#7f95a8","11px monospace")})}
function placesClick(x,y){if(y<30&&x>=36&&x<=92){placesOpen=false;dirty=true;return true}if(x>=36&&x<226&&y>=30&&y<30+PL.length*22+10){const i=Math.floor((y-35)/22);if(i>=0&&i<PL.length){placesOpen=false;openFiles(PL[i][1])}return true}placesOpen=false;dirty=true;return false}
function drawPlaces(){if(!placesOpen)return;rr(36,30,190,PL.length*22+10,0,"#121722");c.strokeStyle="#2a3345";c.lineWidth=1;c.strokeRect(36.5,30.5,189,PL.length*22+9);PL.forEach((p,i)=>{const y=35+i*22,hov=cur.x>=36&&cur.x<226&&cur.y>=y&&cur.y<y+22;if(hov)rr(40,y,182,22,4,accent());rr(48,y+5,14,11,2,p[0]==="Trash"?"#7b8794":p[1]==="/"?"#5fa8ff":p[0]==="Network"?"#3dd8a0":"#e0a93a");tx(p[0],70,y+16,hov?"#fff":"#c5d3e0","13px monospace")})}

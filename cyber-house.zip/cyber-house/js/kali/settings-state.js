/* ==========================================================
 * Modul: js/kali/settings-state.js
 * Foydalanuvchi, sozlamalar va menyu holatlari
 * ========================================================== */
/* ---------- Kali XFCE: sozlamalar, fayl tizimi, menyular, Thunar, monitor ---------- */
const USER="player",HOST="kali",HOME="/home/player",TRASH="/home/player/.local/share/Trash",MINW={files:[540,320],terminal:[300,160],settings:[480,300],monitor:[420,300],ids:[600,420],atkmon:[640,320]};
const PL=[["Home",HOME],["Desktop",HOME+"/Desktop"],["Documents",HOME+"/Documents"],["Downloads",HOME+"/Downloads"],["Music",HOME+"/Music"],["Pictures",HOME+"/Pictures"],["Videos",HOME+"/Videos"],["Trash",TRASH],["File System","/"],["Network","network:///"]];
const ACC=[["#2b6bd6","Kali Blue"],["#1fb5d6","Cyan"],["#7b8794","Graphite"]];
const SET={wall:0,acc:0,icons:true,vol:60,mute:false,ip:"192.168.1.37",kb:"US",fw:false,atkAuto:true};
try{Object.assign(SET,JSON.parse(localStorage.getItem("hs_set_v1")||"{}"))}catch(e){}
function saveSet(){try{localStorage.setItem("hs_set_v1",JSON.stringify(SET))}catch(e){}}
const accent=()=>(ACC[SET.acc]||ACC[0])[0];
let menuOpen=false,menuCat=0,menuQ="",placesOpen=false,POP=null,CTX=null,CLIP=null,edFile="",ASROOT=false,boost=0,up0=Date.now(),termOff=0,LC={id:null,t:0},seqN=0,AC=null;
let termC=0,lastTL=0,edS=0,edC=0,edFollow=false,ideS=0,ideC=0,ideFollow=false,ideOutS=0,ideOutC=0,sbDrag=null,atkT=0,lpT=0;
const ATKM={auto:false,opened:false},DSK={sel:null,edit:null},TCW=8.4,TLH=17;

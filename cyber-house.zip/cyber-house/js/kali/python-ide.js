/* ==========================================================
 * Modul: js/kali/python-ide.js
 * Python interpretatori va IDE
 * ========================================================== */
/* terminal buyruqlari */
const HOSTS={"192.168.1.10":{22:"ssh",80:"http",8080:"http-alt"},"192.168.1.1":{53:"domain",80:"http"}};
const STARTER='# Python simulyatsiya | API: scan(h) send(h,port,data) read(f) write(f,data) ls() print()\nhost = "192.168.1.10"\nports = scan(host)\nprint("Ochiq portlar:", ports)\n\n# payload yuborish:\n# javob = send(host, 80, "GET /robots.txt")\n# print(javob)\n# write("flag.txt", javob)\n';
FS=fsLoad();
const KL=["Linux version 6.12.0-kali1-amd64 (devel@kali.org) (gcc 14.2) #1 SMP PREEMPT_DYNAMIC","Command line: BOOT_IMAGE=/vmlinuz-6.12.0-kali1-amd64 root=/dev/sda2 ro quiet splash","BIOS-provided physical RAM map:","NX (Execute Disable) protection: active","DMI: Cyber House Labs CH-PC/B550, BIOS 2.4","tsc: Detected 3800.000 MHz processor","Memory: 16012MiB available","smpboot: Allowing 16 CPUs","ACPI: Core revision 20240827","PCI: Using configuration type 1 for base access","usbcore: registered new interface driver usbfs","xhci_hcd 0000:03:00.0: xHCI Host Controller","usb usb1: New USB device found, idVendor=1d6b","nvme nvme0: 16/0/0 default/read/poll queues","EXT4-fs (nvme0n1p2): mounted filesystem with ordered data mode","systemd[1]: Detected architecture x86-64.","systemd[1]: Hostname set to <kali>.","systemd[1]: Started Journal Service.","systemd[1]: Mounted /boot/efi.","systemd[1]: Started Network Manager.","NetworkManager: device eth0: state change: activated","systemd[1]: Started OpenBSD Secure Shell server.","systemd[1]: Started Light Display Manager.","systemd[1]: Reached target Graphical Interface."],SD=["Stopped target Graphical Interface.","Stopped Light Display Manager.","Stopped OpenBSD Secure Shell server.","Stopped Network Manager.","Unmounted /boot/efi.","Reached target Unmount All Filesystems.","reboot: Power down"];let loginErr="";
let ideText=STARTER,ideFile=HOME+"/payload.py",ideOut=[],fileHits=[],mnt=false;
const M={s:[false,false,false,false,false,false]},MT=["Monitor va kompyuter vilkasini ulang, kompyuterni yoqing","Terminalda: nmap 192.168.1.10","Kod IDE: scan() bilan ochiq portlarni chiqaring","send(host, 80, \"GET /robots.txt\") — kalitni toping","8080 portga kalitni yuboring — FLAG oling","FLAGni flesh-ga saqlang: cp flag.txt /media/usb/"];
const usbOn=()=>S.usb>=0&&S.on&&S.stage>=2;
const fmt=x=>x===true?"True":x===false?"False":x==null?"None":Array.isArray(x)?"["+x.map(r=>typeof r==="string"?"'"+r+"'":fmt(r)).join(", ")+"]":typeof x==="object"?JSON.stringify(x):String(x);
const inn=(a,b)=>typeof b==="string"||Array.isArray(b)?b.includes(a):a in b;
String.prototype.upper=function(){return this.toUpperCase()};String.prototype.lower=function(){return this.toLowerCase()};String.prototype.strip=function(){return this.trim()};String.prototype.encode=function(){return this};String.prototype.join=function(a){return a.join(this)};String.prototype.hex=function(){return[...this].map(c=>c.charCodeAt(0).toString(16).padStart(2,"0")).join("")};Array.prototype.append=function(x){this.push(x)};
function py2js(src){const o=[],st=[0];let pend=0;
 const cv=m=>m[0]==="f"?"`"+m.slice(2,-1).replace(/\{([^}]*)\}/g,"${$1}")+"`":m;
 const ex=t=>t.replace(/([\w.\u0001]+)\s+not\s+in\s+(\[[^\]]*\]|[\w.\u0001()]+)/g,"!inn($1,$2)").replace(/([\w.\u0001]+)\s+in\s+(\[[^\]]*\]|[\w.\u0001()]+)/g,"inn($1,$2)").replace(/\bTrue\b/g,"true").replace(/\bFalse\b/g,"false").replace(/\bNone\b/g,"null").replace(/\band\b/g,"&&").replace(/\bor\b/g,"||").replace(/\bnot\b/g,"!");
 for(const raw of src.replace(/\t/g,"    ").split("\n")){const sp=[];
  let l=raw.replace(/f?("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/g,m=>{sp.push(m);return"\u0001"+(sp.length-1)+"\u0001"}).replace(/#.*$/,"");
  if(!l.trim())continue;const ind=l.match(/^ */)[0].length;
  if(pend){if(ind>st[st.length-1])st.push(ind);pend=0}
  while(ind<st[st.length-1]){st.pop();o.push("}")}
  const t=l.trim();let m,r;
  if(/^(import|from)\s/.test(t)||t==="pass")r="";
  else if(m=t.match(/^for\s+(.+?)\s+in\s+(.+):$/))r="for(const "+(m[1].includes(",")?"["+m[1]+"]":m[1])+" of "+ex(m[2])+"){";
  else if(m=t.match(/^while\s+(.+):$/))r="while("+ex(m[1])+"){if(++_n>3e5)throw new Error('Cheksiz sikl to`xtatildi');";
  else if(m=t.match(/^if\s+(.+):$/))r="if("+ex(m[1])+"){";
  else if(m=t.match(/^elif\s+(.+):$/))r="else if("+ex(m[1])+"){";
  else if(t==="else:")r="else{";else if(t==="try:")r="try{";else if(/^except.*:$/.test(t))r="catch(_e){";
  else if(m=t.match(/^def\s+(\w+)\((.*)\):$/))r="function "+m[1]+"("+m[2]+"){";
  else{r=ex(t);if(/^[A-Za-z_]\w*\s*=(?!=)/.test(r))r="var "+r;r+=";"}
  if(t.endsWith(":"))pend=1;
  o.push(r.replace(/\u0001(\d+)\u0001/g,(_,i)=>cv(sp[i])))}
 while(st.length>1){st.pop();o.push("}")}return o.join("\n")}
function runPy(code,out){const api={print:(...a)=>out(a.map(x=>typeof x==="string"?x:fmt(x)).join(" ")),str:fmt,int:x=>parseInt(x,10)||0,float:parseFloat,len:x=>x.length??Object.keys(x).length,
  range:(a,b,s)=>{if(b===undefined){b=a;a=0}s=s||1;const r=[];for(let i=a;s>0?i<b:i>b;i+=s){r.push(i);if(r.length>1e5)break}return r},sorted:x=>[...x].sort((a,b)=>a>b?1:-1),sum:x=>x.reduce((a,b)=>a+b,0),min:(...a)=>Math.min(...a.flat()),max:(...a)=>Math.max(...a.flat()),abs:Math.abs,round:Math.round,inn,sleep:()=>{},
  read:p=>F.rd(abs(p,HOME)),write:(p,d)=>{F.wr(abs(p,HOME),d)},ls:p=>F.ls(abs(p||"~",HOME)),scan:h=>{M.s[2]=true;const t=HOSTS[h];return t?Object.keys(t).map(Number):[]},
  send:(h,p,d)=>{d=typeof d==="string"?d:fmt(d);p=Number(p);const t=HOSTS[h];if(!t||!(p in t))return"Connection refused";if(h!=="192.168.1.10")return"HTTP/1.1 200 OK";if(p===22)return"SSH-2.0-OpenSSH_9.6";
   if(p===80){if(/robots/i.test(d)){M.s[3]=true;return"User-agent: *\nDisallow: /admin\n# key=K4L1-2026"}return"HTTP/1.1 200 OK\n<h1>Cyber Corp</h1>"}
   if(p===8080){if(d.includes("K4L1-2026")){M.s[4]=true;return"FLAG{cyber_house_owned}"}return"401 Unauthorized: key kerak"}return"OK"}};
 api.connect=api.send;
 try{new Function("api","var _n=0;with(api){"+py2js(code)+"\n}")(api)}catch(e){out("Xato: "+(e&&e.message||e))}}
const tOut=t=>String(t).split("\n").forEach(x=>termLines.push({t:x,c:"#b8c7d6"}));
function runIde(){ideOut=[];ideOutS=0;ideOutC=0;try{F.wr(ideFile,ideText)}catch(e){}runPy(ideText,t=>String(t).split("\n").forEach(l=>{while(l.length>90){ideOut.push(l.slice(0,90));l=l.slice(90)}ideOut.push(l)}));ideOut.push("[tugadi]");dirty=true}
function insTab(){if(focusId!=="ide")return;const s=ta.selectionStart;ta.setRangeText("    ",s,ta.selectionEnd,"end");ideText=ta.value;dirty=true}
function tick2(){if(S.plug&&S.mplug&&S.on)M.s[0]=true;const cur=M.s.indexOf(false);if(cur!==M.cur){if(M.cur!==undefined)toast("✓ Missiya bajarildi");M.cur=cur;$("status").textContent=cur<0?"🏁 Barcha missiyalar bajarildi":"▸ "+(cur+1)+"/6 · "+MT[cur]}
 const u=usbOn();if(u!==mnt){mnt=u;if(u){termLines.push({t:"[usb] flesh /media/usb ga ulandi",c:"#3dd8ff"});if(S.stage===3)openApp("usb")}else if(S.on)termLines.push({t:"[usb] chiqarildi",c:"#ffb86b"});dirty=true}
 const bp=S.hold==="usb"&&near(pcc,2.3)?bestPort():-1;PM.forEach((m,i)=>m.color.setHex(i===bp?0x00e5ff:i===S.usb?0x1b8a4a:0))}

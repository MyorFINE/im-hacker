/* ==========================================================
 * Modul: js/kali/text-input.js
 * Matn kiritish, saqlash va login
 * ========================================================== */
/* matn kiritish */
const ta=$("ta");ta.addEventListener("keyup",()=>{dirty=true;if(focusId==="ide")ideFollow=true;else if(focusId==="editor")edFollow=true});
function getTxt(){if(DSK.edit)return DSK.edit.f==="name"?DSK.edit.name:DSK.edit.target;if(menuOpen)return menuQ;const w=wins.find(w=>w.id===focusId&&!w.min);if(!w)return termIn;if(w.id==="files")return w.edit?w.edit.buf:"";if(w.id==="editor")return edText;if(w.id==="ide")return ideText;if(w.id==="terminal")return termIn;return""}
function setTxt(v){if(DSK.edit){const q=v.replace(/\n/g,"");if(DSK.edit.f==="name")DSK.edit.name=q;else DSK.edit.target=q;return}if(menuOpen){menuQ=v.replace(/\n/g,"");return}const w=wins.find(w=>w.id===focusId&&!w.min);if(!w){termIn=v.replace(/\n/g,"");return}if(w.id==="files"){if(w.edit){w.edit.buf=v.replace(/\n/g,"");if(w.edit.mode==="search")w.q=w.edit.buf}return}if(w.id==="editor")edText=v;else if(w.id==="ide")ideText=v;else if(w.id==="terminal")termIn=v.replace(/\n/g,"")}
function syncInput(){if(!seated)return;const v=getTxt();if(ta.value!==v)ta.value=v;if(!mobile)ta.focus({preventScroll:true})}
function saveEd(){try{if(!edFile)edFile=HOME+"/Documents/untitled.txt";F.wr(edFile,edText);toast("Saqlandi: "+edFile)}catch(e){toast(e.message)}}
ta.addEventListener("input",()=>{setTxt(ta.value);dirty=true;if(!DSK.edit&&!menuOpen){if(focusId==="ide")ideFollow=true;else if(focusId==="editor")edFollow=true;else if(focusId==="terminal")termOff=0}if(seated&&ta.value)klight(ta.value.slice(-1))});
ta.addEventListener("keydown",e=>{
 const fw=wins.find(w=>w.id===focusId&&!w.min);
 if(DSK.edit){const de=DSK.edit;if(e.key==="Enter"){e.preventDefault();dskCommit();return}if(e.key==="Escape"){e.preventDefault();dskCancel();return}if(e.key==="Tab"&&de.kind==="link"){e.preventDefault();de.f=de.f==="name"?"target":"name";syncInput();try{ta.select()}catch(er){}dirty=true;return}return}
 if(menuOpen){if(e.key==="Escape"){menuOpen=false;dirty=true;e.preventDefault();syncInput();return}if(e.key==="Enter"){e.preventDefault();menuEnter();return}return}
 if(e.key==="Escape"){if(CTX||POP||placesOpen){CTX=null;POP=null;placesOpen=false;dirty=true;return}if(fw&&fw.id==="files"&&(fw.edit||fw.props)){if(fw.edit&&fw.edit.mode==="search")fw.q="";fw.edit=null;fw.props=null;ta.value="";dirty=true;return}stand();return}
 if(fw&&fw.id==="files"){if(fw.edit){if(e.key==="Enter"){e.preventDefault();commitEdit(fw)}return}filesKey(fw,e);return}
 if(focusId==="editor"&&(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){e.preventDefault();saveEd();return}
 if(focusId==="ide"){if(e.key==="Tab"){e.preventDefault();insTab();return}if(e.key==="Enter"&&(e.ctrlKey||e.metaKey)){e.preventDefault();runIde();return}}
 const i=keyIdx(e.key);keys.setColorAt(i,new T.Color(1.4,4,5));keys.instanceColor.needsUpdate=true;setTimeout(()=>{keys.setColorAt(i,new T.Color(1,1,1));keys.instanceColor.needsUpdate=true},110);
 if(S.stage===2&&e.key==="Enter"){login();return}
 if(focusId==="terminal"){if(e.key==="Enter"){e.preventDefault();run(termIn);termIn="";ta.value="";dirty=true}
  else if(e.key==="Tab"){e.preventDefault();const r=complete(termIn);if(r.list){termLines.push({t:"└─$ "+termIn,c:"#e6edf3"},{t:r.list,c:"#b8c7d6"})}termIn=ta.value=r.buf;termOff=0;dirty=true}
  else if(e.key==="ArrowUp"&&hist.length){hi=Math.max(0,hi-1);termIn=ta.value=hist[hi];dirty=true;e.preventDefault()}
  else if(e.key==="ArrowDown"){hi=Math.min(hist.length,hi+1);termIn=ta.value=hist[hi]||"";dirty=true;e.preventDefault()}
  else if(e.key==="PageUp"){termOff+=pgRows();dirty=true;e.preventDefault()}
  else if(e.key==="PageDown"){termOff=Math.max(0,termOff-pgRows());dirty=true;e.preventDefault()}
  else if(e.ctrlKey&&e.key.toLowerCase()==="l"){e.preventDefault();termLines=[];dirty=true}}});
function login(){menuOpen=false;if(termIn!==SEC.pw){loginErr="Authentication failure";termIn="";ta.value="";dirty=true;return}loginErr="";termIn="";ta.value="";S.stage=3;up0=Date.now();openApp("terminal");dirty=true}

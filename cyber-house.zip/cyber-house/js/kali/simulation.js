/* ==========================================================
 * Modul: js/kali/simulation.js
 * Jarayonlar, CPU, RAM, tarmoq simulyatsiyasi
 * ========================================================== */
/* ---- simulyatsiya: jarayonlar, CPU, RAM, tarmoq ---- */
const SIM={cpu:[],rx:[],cpuNow:0,ramUsed:0,rxNow:0,P:[],t:0},RAMT=16012;
function simTick(now){if(now-SIM.t<500)return;SIM.t=now;const t=now/1000,P=[],add=(pid,user,cmd,cpu,mem,tty)=>P.push({pid,user,cmd,cpu:Math.max(0,cpu+Math.sin(t*.9+pid)*cpu*.25),mem,tty:tty||"?"});
 add(1,"root","/sbin/init",.1,.3);add(412,"root","systemd-journald",.1,.4);add(688,"root","NetworkManager",.2,.6);add(731,"root","sshd: /usr/sbin/sshd -D",.02,.2);add(905,"root","/usr/lib/xorg/Xorg :0",1.4,2.1);add(1120,USER,"xfce4-session",.1,.5);add(1188,USER,"xfce4-panel",.4,.9);add(1210,USER,"xfdesktop",.3,.8);
 const W2={terminal:["qterminal",1.6,1.2,1],browser:["firefox-esr",7.5,6.5],files:["thunar",.8,1.3],editor:["mousepad",.5,1],ide:["python3 ide.py",2.4,1.6],monitor:["xfce4-taskmanager",1.2,1.1],ids:["suricata",1.8,2.2],settings:["xfce4-settings-manager",.4,1],usb:["thunar-volman",.2,.4]};
 wins.forEach((w,i)=>{const a=W2[w.id];if(!a)return;const foc=w.id===focusId;add(2000+i*37,USER,a[0],a[1]*(foc?1.6:.6),a[2],a[3]?"pts/"+i:"?");if(a[3])add(2001+i*37,USER,"-zsh",.0,.4,"pts/"+i)});
 if(boost>1)add(3100,USER,"nmap -sV 192.168.1.10",boost*.55,1.1,"pts/0");
 SIM.P=P;const tot=Math.min(100,P.reduce((s,p)=>s+p.cpu,0)+boost*.3);SIM.cpuNow=tot;SIM.cpu.push(tot);if(SIM.cpu.length>60)SIM.cpu.shift();
 SIM.ramUsed=Math.round(1400+P.reduce((s,p)=>s+p.mem*160,0));
 SIM.rxNow=Math.round(4+boost*9+(wins.some(w=>w.id==="browser")?35:0)+Math.abs(Math.sin(t))*5);SIM.rx.push(SIM.rxNow);if(SIM.rx.length>60)SIM.rx.shift();
 boost=boost<1?0:boost*.88;
 if(S.stage===3&&wins.some(w=>w.id==="monitor"&&!w.min))dirty=true}
function simEns(){if(!SIM.P.length)simTick(performance.now()+1000)}
function conns(){const r=[["tcp","0.0.0.0:22","0.0.0.0:*","LISTEN","sshd"],["udp","0.0.0.0:68","0.0.0.0:*","UNCONN","dhclient"],["tcp","127.0.0.1:631","0.0.0.0:*","LISTEN","cupsd"]];if(wins.some(w=>w.id==="browser"))r.push(["tcp",SET.ip+":43318","192.168.1.10:80","ESTAB","firefox-esr"]);if(boost>1)r.push(["tcp",SET.ip+":51234","192.168.1.10:8080","SYN-SENT","nmap"]);return r}
function upStr(){const s=Math.floor((Date.now()-up0)/1000);return Math.floor(s/3600)+":"+String(Math.floor(s/60)%60).padStart(2,"0")+":"+String(s%60).padStart(2,"0")}
function fsTotal(){let t=0;(function w(n){if(n.t==="d")Object.keys(n.k).forEach(k=>w(n.k[k]));else t+=n.c.length})(FS);return t}

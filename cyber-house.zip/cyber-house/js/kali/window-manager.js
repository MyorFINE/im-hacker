/* ==========================================================
 * Modul: js/kali/window-manager.js
 * Kali ekran holati, oynalar, ilovalarni ochish/yopish
 * ========================================================== */
/* ---------- Kali ekran ---------- */
const S={plug:false,mplug:false,mplug2:false,hold:null,usb:-1,dr:0,dp:0,on:false,stage:0,boot:0};
let seated=false,seatT=0,focusId=null,dirty=true,lastDraw=0,lastMin=-1,termIn="",edText="Eslatma:\n- nmap bilan tarmoqni tekshirish\n- hisobot yozish\n",cwd="/home/player",hist=[],hi=0,termLines=[{t:"Kali Linux 2026.3 — yordam uchun 'help' deb yozing",c:"#7fd4ff"}],drag=null;
const cur={x:512,y:288},wins=[];
const wp=cv(W*K,H*K);{const x=wp.getContext("2d");x.scale(K,K);const g=x.createLinearGradient(0,0,W,H);g.addColorStop(0,"#0b1020");g.addColorStop(.6,"#10172e");g.addColorStop(1,"#1d1038");x.fillStyle=g;x.fillRect(0,0,W,H);
 x.strokeStyle="rgba(60,150,255,.16)";x.lineWidth=2;for(let i=0;i<14;i++){x.beginPath();x.moveTo(W*.55,H*.1);x.bezierCurveTo(W*.9,H*(.05+i*.07),W*.6,H*.7,W*(.3+i*.04),H);x.stroke()}
 x.fillStyle="rgba(70,160,255,.12)";x.font="bold 190px monospace";x.textAlign="center";x.fillText("KALI",W*.62,H*.62);}
function rr(x,y,w,h,r,f){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();c.fillStyle=f;c.fill()}
function tx(s,x,y,col,f){c.fillStyle=col;c.font=f||"14px monospace";c.fillText(s,x,y)}
const APPS=[{id:"terminal",n:"Terminal",k:"$_",col:"#1e2a36",fg:"#3df0a0"},{id:"files",n:"Thunar",k:"F",col:"#e0a93a",fg:"#222"},{id:"browser",n:"Firefox",k:"W",col:"#2b6bd6",fg:"#fff"},{id:"editor",n:"Mousepad",k:"E",col:"#3b9a6a",fg:"#fff"},{id:"ide",n:"Kod IDE (Python)",k:"Py",col:"#6b4bd6",fg:"#fff"},{id:"monitor",n:"System Monitor",k:"M",col:"#b8472f",fg:"#fff"},{id:"settings",n:"Settings",k:"S",col:"#4b5a68",fg:"#fff"},{id:"ids",n:"Security Center",k:"ID",col:"#a02b2b",fg:"#fff"},{id:"usb",n:"USB Flesh",k:"U",col:"#0d7a9a",fg:"#fff"},{id:"atkmon",n:"Attack Monitor",k:"AM",col:"#8a2b7a",fg:"#fff"}];
function openApp(id){if(id==="atkmon"&&!ATKM.auto)ATKM.opened=true;let w=wins.find(w=>w.id===id);if(!w){const i=wins.length,D={ide:[780,480],usb:[460,260],terminal:[700,400],files:[760,440],monitor:[600,380],settings:[620,400],ids:[720,470],atkmon:[660,400]}[id]||[620,380];w={id,seq:++seqN,x:80+i*30,y:44+i*26,w:D[0],h:D[1]};if(id==="ide"){w.x=100;w.y=40}if(id==="usb"){w.x=520;w.y=290}if(id==="atkmon"){w.as=0;w.ac=0;const e2=extOn();w.x=(e2?VW:W)-w.w-14;w.y=e2?40:44}if(id==="files"){w.path=HOME;w.back=[];w.view="list";w.sort="n";w.asc=true;w.q="";w.edit=null;w.sel=null;w.scroll=0;w.hid=true}if(id==="monitor")w.tab=0;if(id==="settings")w.pg=0;w.x=Math.max(0,Math.min(w.x,vwNow()-w.w));w.y=Math.max(32,Math.min(w.y,H-w.h-6));wins.push(w)}w.min=false;front(w);dirty=true}
function front(w){wins.splice(wins.indexOf(w),1);wins.push(w);focusId=w.id;syncInput()}
function toggleMax(w){if(w.max){Object.assign(w,w.prev);w.max=false}else{w.prev={x:w.x,y:w.y,w:w.w,h:w.h};Object.assign(w,extOn()&&w.x+w.w/2>=W?{x:W,y:0,w:W,h:H}:{x:0,y:30,w:W,h:H-30});w.max=true}dirty=true}
function closeWin(id){const i=wins.findIndex(w=>w.id===id);if(i>=0)wins.splice(i,1);focusId=wins.length?wins[wins.length-1].id:null;dirty=true}


/* ==========================================================
 * Modul: js/kali/system-monitor.js
 * System Monitor ilovasi
 * ========================================================== */
/* ---- System Monitor ---- */
function graph(x,y,wd,ht,arr,mx,col,lab){rr(x,y,wd,ht,3,"#0e1218");c.strokeStyle="#1c2430";c.lineWidth=1;for(let i=1;i<4;i++){c.beginPath();c.moveTo(x,y+ht*i/4);c.lineTo(x+wd,y+ht*i/4);c.stroke()}
 if(arr.length>1){c.strokeStyle=col;c.lineWidth=1.5;c.beginPath();arr.forEach((v,i)=>{const px=x+wd-(arr.length-1-i)*(wd/59),py=y+ht-2-Math.min(1,v/mx)*(ht-4);if(i)c.lineTo(px,py);else c.moveTo(px,py)});c.stroke()}tx(lab,x+8,y+16,col,"bold 12px monospace")}
function drawMon(w,cx,top){const X=w.x,Y=top,Wd=w.w,Ht=w.h-33,hits=w.hits=[];rr(X+2,Y,Wd-4,Ht,0,"#161b22");simEns();
 ["Resurslar","Jarayonlar","Ulanishlar"].forEach((s,i)=>{const x=X+8+i*100,sel=w.tab===i;rr(x,Y+6,94,24,5,sel?accent():"#2b3347");tx(s,x+8,Y+22,"#fff","13px monospace");hits.push({x,y:Y+6,w:94,h:24,fn:()=>{w.tab=i}})});
 const y0=Y+40,bw=Wd-32,P=SIM.P.slice().sort((a,b)=>b.cpu-a.cpu);
 if(w.tab===0){graph(cx,y0,bw,80,SIM.cpu,100,"#3dd8ff","CPU  "+SIM.cpuNow.toFixed(0)+"%");
  const bar=(y,lab,v,t)=>{tx(lab,cx,y+11,"#c5d3e0","12px monospace");rr(cx+150,y,bw-150,12,3,"#0e1218");rr(cx+150,y,Math.max(4,(bw-150)*Math.min(1,v/t)),12,3,accent())};
  bar(y0+92,"Xotira "+SIM.ramUsed+" / "+RAMT+" MiB",SIM.ramUsed,RAMT);const du=14.2+fsTotal()/1e9;bar(y0+114,"Disk "+du.toFixed(1)+" / 512 GB",du,512);
  graph(cx,y0+140,bw,70,SIM.rx,120,"#3dd8a0","Tarmoq  "+SIM.rxNow+" KB/s");
  tx("Uptime: "+upStr()+"    Jarayonlar: "+P.length+"    Ulanishlar: "+conns().length,cx,y0+232,"#8fa3b5","12px monospace")}
 else if(w.tab===1){tx("PID",cx,y0+12,"#7fd4ff","bold 12px monospace");tx("USER",cx+56,y0+12,"#7fd4ff","bold 12px monospace");tx("CPU%",cx+130,y0+12,"#7fd4ff","bold 12px monospace");tx("MEM%",cx+190,y0+12,"#7fd4ff","bold 12px monospace");tx("COMMAND",cx+250,y0+12,"#7fd4ff","bold 12px monospace");
  const vis=Math.floor((Ht-70)/18);P.slice(0,vis).forEach((p,i)=>{const y=y0+32+i*18;tx(String(p.pid),cx,y,"#8fa3b5","12px monospace");tx(p.user,cx+56,y,"#c5d3e0","12px monospace");tx(p.cpu.toFixed(1),cx+130,y,p.cpu>5?"#ff9a5f":"#c5d3e0","12px monospace");tx(p.mem.toFixed(1),cx+190,y,"#c5d3e0","12px monospace");tx(p.cmd.slice(0,Math.floor((bw-250)/7.2)),cx+250,y,"#e6edf3","12px monospace")})}
 else{["Proto","Local","Remote","State","Program"].forEach((s,i)=>tx(s,cx+[0,50,190,330,420][i],y0+12,"#7fd4ff","bold 12px monospace"));conns().forEach((r,i)=>{const y=y0+32+i*18;r.forEach((v,j)=>tx(v,cx+[0,50,190,330,420][j],y,j===3&&v==="ESTAB"?"#3dd8a0":"#c5d3e0","12px monospace"))})}}

/* ==========================================================
 * Modul: js/kali/wallpapers.js
 * Fon rasmlari va beep ovozi
 * ========================================================== */
/* ---- fon rasmlari ---- */
const WALLS=[["#0b1020","#10172e","#1d1038","70,160,255"],["#0d1014","#151a21","#1b222b","120,140,160"],["#06151c","#0a2a33","#12182e","60,220,210"]];
function paintWall(i){const x=wp.getContext("2d"),p=WALLS[i]||WALLS[0];x.setTransform(1,0,0,1,0,0);x.scale(K,K);const g=x.createLinearGradient(0,0,W,H);g.addColorStop(0,p[0]);g.addColorStop(.6,p[1]);g.addColorStop(1,p[2]);x.fillStyle=g;x.fillRect(0,0,W,H);x.strokeStyle="rgba("+p[3]+",.16)";x.lineWidth=2;for(let j=0;j<14;j++){x.beginPath();x.moveTo(W*.55,H*.1);x.bezierCurveTo(W*.9,H*(.05+j*.07),W*.6,H*.7,W*(.3+j*.04),H);x.stroke()}x.fillStyle="rgba("+p[3]+",.12)";x.font="bold 190px monospace";x.textAlign="center";x.fillText("KALI",W*.62,H*.62);x.textAlign="left"}
function beep(){if(SET.mute)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain();o.frequency.value=660;g.gain.value=SET.vol/100*.06;o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+.08)}catch(e){}}

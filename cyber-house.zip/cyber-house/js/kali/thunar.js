/* ==========================================================
 * Modul: js/kali/thunar.js
 * Thunar fayl menejeri
 * ========================================================== */
/* ---- Thunar ---- */
function go(w,p){if(p===w.path)return;w.back.push(w.path);if(w.back.length>30)w.back.shift();w.path=p;w.sel=null;w.q="";w.scroll=0;w.edit=null;w.props=null}
function fEntries(w){if(w.path==="network:///")return Object.keys(HOSTS).map(h=>({nm:h,n:{t:"d",o:"root",m:"755",mt:Date.now(),k:{}},net:1}));const d=nd(w.path);if(!d)throw new Error(w.path+": No such file or directory");if(d.t!=="d")throw new Error("Not a directory");if(!can(d,4))throw new Error("Permission denied — sudo kerak");let r=Object.keys(d.k).map(nm=>({nm,n:d.k[nm]}));if(!w.hid)r=r.filter(e=>e.nm[0]!==".");if(w.q)r=r.filter(e=>e.nm.toLowerCase().includes(w.q.toLowerCase()));const k=w.sort,dr=w.asc?1:-1;r.sort((a,b)=>{if(a.n.t!==b.n.t)return a.n.t==="d"?-1:1;let x,y;if(k==="s"){x=a.n.t==="d"?0:a.n.c.length;y=b.n.t==="d"?0:b.n.c.length}else if(k==="t"){x=fiType(a.n,a.nm);y=fiType(b.n,b.nm)}else if(k==="d"){x=a.n.mt;y=b.n.mt}else{x=a.nm.toLowerCase();y=b.nm.toLowerCase()}return(x<y?-1:x>y?1:0)*dr});return r}
function openPath(p){if(/\.desktop$/.test(p)){runLink(p);return}try{const c2=F.rd(p);if(/\.py$/.test(p)){ideText=c2;ideFile=p;ideS=ideC=0;ideFollow=true;openApp("ide")}else if(/^\[[a-z ]+\]$/i.test(c2))toast("Binar fayl — terminalda ishga tushiring");else{edText=c2;edFile=p;edS=edC=0;openApp("editor")}syncInput()}catch(e){toast(e.message)}}
function openEntry(w,e){const p=join(w.path,e.nm);if(e.net){toast(e.nm+" — terminalda: nmap "+e.nm);return}if(e.n.t==="d"){go(w,p);return}openPath(p)}
function delPath(p,perm){try{if(perm)F.rm(p,true);else{F.mkdir(TRASH,true);F.mv(p,uniq(join(TRASH,abs(p).split("/").pop())))}toast(perm?"O'chirildi":"Savatga tashlandi")}catch(e){toast(e.message)}dirty=true}
function pasteTo(w){if(!CLIP)return;try{CLIP.p.forEach(p=>{const nm=abs(p).split("/").pop(),dst=uniq(join(w.path,nm));if(CLIP.op==="cut")F.mv(p,dst);else F.cp(p,dst,true)});if(CLIP.op==="cut")CLIP=null}catch(e){toast(e.message)}dirty=true}
function startEdit(w,mode,buf,old){w.edit={mode,buf:buf||"",old};syncInput();if(mode==="rename")try{ta.select()}catch(e){}dirty=true}
function commitEdit(w){const e=w.edit;if(!e)return;try{const b=e.buf.trim();if(e.mode==="addr"){const a=abs(b||"/",w.path),n=nd(a);if(!n||n.t!=="d")throw new Error(b+": No such directory");w.edit=null;go(w,a)}else if(e.mode==="rename"){if(b&&b!==e.old){F.mv(join(w.path,e.old),join(w.path,b));w.sel=b}}else if(e.mode==="newd"){if(!b)throw new Error("Nom kerak");F.mkdir(join(w.path,b));w.sel=b}else if(e.mode==="newf"){if(!b)throw new Error("Nom kerak");if(nd(join(w.path,b)))throw new Error("Fayl mavjud");F.wr(join(w.path,b),"");w.sel=b}}catch(er){toast(er.message)}w.edit=null;ta.value="";syncInput();dirty=true}
function ctxItem(w,e,x,y){const p=join(w.path,e.nm),tr=inTrash(w.path);return{x,y,items:[["Open",()=>openEntry(w,e)],["-"],["Cut",()=>{CLIP={op:"cut",p:[p]};toast("Kesildi")}],["Copy",()=>{CLIP={op:"copy",p:[p]};toast("Nusxalandi")}],["Rename...",()=>startEdit(w,"rename",e.nm,e.nm)],[tr?"Delete Permanently":"Move to Trash",()=>delPath(p,tr)],["-"],["Properties",()=>{w.props=p}]]}}
function ctxEmpty(w,x,y){const net=w.path==="network:///",it=[["New Folder...",()=>startEdit(w,"newd","")],["New File...",()=>startEdit(w,"newf","")],["Paste",()=>pasteTo(w),!CLIP],["-"],[(w.hid?"✓ ":"   ")+"Show Hidden Files",()=>{w.hid=!w.hid}],["Open Terminal Here",()=>termCd(w.path)]];if(net)return{x,y,items:[["Refresh",()=>{dirty=true}]]};if(w.path===TRASH)it.push(["-"],["Empty Trash",()=>{try{F.ls(TRASH).forEach(k=>F.rm(join(TRASH,k),true));toast("Savat tozalandi")}catch(e){toast(e.message)}}]);return{x,y,items:it}}
function entHit(w,e,x,y,wd,ht){return{id:"f:"+w.path+"/"+e.nm,x,y,w:wd,h:ht,fn:d=>{w.sel=e.nm;if(d){LC.id=null;openEntry(w,e)}},fr:(rx,ry)=>{w.sel=e.nm;CTX=ctxItem(w,e,rx,ry)}}}
function filesKey(w,e){const k=e.key,ctl=e.ctrlKey||e.metaKey,l=k.toLowerCase(),sel=w.sel,p=sel?join(w.path,sel):null;
 if(k==="Delete"&&p){e.preventDefault();delPath(p,inTrash(w.path))}
 else if(k==="F2"&&sel){e.preventDefault();startEdit(w,"rename",sel,sel)}
 else if(k==="Enter"&&sel){e.preventDefault();try{const en=fEntries(w).find(x=>x.nm===sel);if(en)openEntry(w,en)}catch(er){}}
 else if(k==="Backspace"){e.preventDefault();go(w,up(w.path))}
 else if(ctl&&l==="c"&&p){e.preventDefault();CLIP={op:"copy",p:[p]};toast("Nusxalandi")}
 else if(ctl&&l==="x"&&p){e.preventDefault();CLIP={op:"cut",p:[p]};toast("Kesildi")}
 else if(ctl&&l==="v"){e.preventDefault();pasteTo(w)}
 else if(ctl&&l==="h"){e.preventDefault();w.hid=!w.hid}
 else if(ctl&&l==="f"){e.preventDefault();startEdit(w,"search",w.q)}
 else if(k==="ArrowDown"||k==="ArrowUp"){e.preventDefault();try{const es=fEntries(w);if(es.length){let i=es.findIndex(x=>x.nm===sel);i=k==="ArrowDown"?Math.min(es.length-1,i+1):Math.max(0,i<0?0:i-1);w.sel=es[i].nm}}catch(er){}}
 dirty=true}
function drawFiles(w,cx,top){
 const X=w.x,Y=top,Wd=w.w,Ht=w.h-33,hits=w.hits=[],bl=w.id===focusId&&seated&&((performance.now()/500)|0)%2===0;
 rr(X+2,Y,Wd-4,Ht,0,"#161b22");rr(X+2,Y,Wd-4,32,0,"#1d2230");
 const btn=(x,wd,lab,fn,on)=>{rr(x,Y+5,wd,22,5,on?accent():"#2b3347");tx(lab,x+wd/2-lab.length*3.8,Y+21,"#e6edf3","13px monospace");hits.push({x,y:Y+5,w:wd,h:22,fn})};
 btn(X+8,24,"←",()=>{if(w.back.length){w.path=w.back.pop();w.sel=null;w.q="";w.scroll=0}});btn(X+36,24,"↑",()=>go(w,up(w.path)));btn(X+64,24,"⌂",()=>go(w,HOME));
 const ax=X+94,aw=Wd-94-262,ae=w.edit&&w.edit.mode==="addr",mc=Math.floor((aw-16)/7.8);
 rr(ax,Y+5,aw,22,5,ae?"#0b0f14":"#0e1218");if(ae){c.strokeStyle=accent();c.lineWidth=1;c.strokeRect(ax+.5,Y+5.5,aw-1,21)}
 const at=ae?w.edit.buf:w.path;tx(at.slice(-mc),ax+8,Y+21,ae?"#e6edf3":"#9fb6c8","13px monospace");if(ae&&bl){c.fillStyle="#7fd4ff";c.fillRect(ax+8+Math.min(at.length,mc)*7.8,Y+9,2,14)}
 hits.push({x:ax,y:Y+5,w:aw,h:22,fn:()=>startEdit(w,"addr",w.path)});
 btn(X+Wd-258,24,"≡",()=>{CTX=ctxEmpty(w,X+Wd-258,Y+30)});btn(X+Wd-230,24,"▤",()=>{w.view="list"},w.view==="list");btn(X+Wd-202,24,"▦",()=>{w.view="icon"},w.view==="icon");
 const sx=X+Wd-172,sw=164,se=w.edit&&w.edit.mode==="search";rr(sx,Y+5,sw,22,5,se?"#0b0f14":"#0e1218");if(se){c.strokeStyle=accent();c.lineWidth=1;c.strokeRect(sx+.5,Y+5.5,sw-1,21)}
 const st2=se?w.edit.buf:w.q;tx(st2?st2.slice(-18):"Qidirish…",sx+8,Y+21,st2?"#e6edf3":"#5d7385","13px monospace");if(se&&bl){c.fillStyle="#7fd4ff";c.fillRect(sx+8+Math.min(18,st2.length)*7.8,Y+9,2,14)}
 hits.push({x:sx,y:Y+5,w:sw,h:22,fn:()=>startEdit(w,"search",w.q)});
 rr(X+2,Y+32,132,Ht-32,0,"#11151b");
 PL.forEach((p,i)=>{const y=Y+40+i*24,sel=w.path===p[1];if(sel)rr(X+6,y,124,22,4,"#1f2a40");rr(X+14,y+5,14,11,2,p[0]==="Trash"?"#7b8794":p[1]==="/"?"#5fa8ff":p[0]==="Network"?"#3dd8a0":"#e0a93a");tx(p[0],X+36,y+16,sel?"#fff":"#c5d3e0","13px monospace");hits.push({x:X+6,y,w:124,h:22,fn:()=>go(w,p[1])})});
 const mx=X+138,mw=Wd-142,my=Y+34,sh=48,sy=Y+Ht-sh;let ents=[],err=null;try{ents=fEntries(w)}catch(e){err=e.message}
 hits.push({x:mx,y:my,w:mw,h:sy-my,fn:()=>{w.sel=null},fr:(x,y)=>{CTX=ctxEmpty(w,x,y)}});
 if(err)tx(err,mx+10,my+26,"#ff7b72","13px monospace");
 else if(w.view==="list"){const cols=[["n","Name",mx+26],["s","Size",mx+Math.floor(mw*.44)],["t","Type",mx+Math.floor(mw*.55)],["d","Modified",mx+Math.floor(mw*.68)]];rr(mx,my,mw,20,0,"#1d2230");
  cols.forEach(cc=>{const on=w.sort===cc[0];tx(cc[1]+(on?(w.asc?" ▲":" ▼"):""),cc[2],my+14,on?"#7fd4ff":"#8fa3b5","12px monospace");hits.push({x:cc[2]-4,y:my,w:70,h:20,fn:()=>{if(w.sort===cc[0])w.asc=!w.asc;else{w.sort=cc[0];w.asc=true}}})});
  if(mw>=500)tx("Permissions",mx+Math.floor(mw*.84)-6,my+14,"#8fa3b5","12px monospace");
  const rh=20,vis=Math.max(1,Math.floor((sy-my-22)/rh)),mxc=Math.max(4,Math.floor((cols[1][2]-cols[0][2]-6)/7.4));w.scroll=Math.max(0,Math.min(w.scroll||0,Math.max(0,ents.length-vis)));
  ents.slice(w.scroll,w.scroll+vis).forEach((e,i)=>{const y=my+22+i*rh,sel=w.sel===e.nm;if(sel)rr(mx+2,y,mw-4,rh,3,"#1f2a40");fIcon(mx+8,y+2,e.n,e.nm,.8);tx(e.nm.length>mxc?e.nm.slice(0,mxc-1)+"…":e.nm,cols[0][2],y+14,"#e6edf3","13px monospace");tx(fSize(e.n),cols[1][2],y+14,"#8fa3b5","12px monospace");tx(fiType(e.n,e.nm),cols[2][2],y+14,"#8fa3b5","12px monospace");tx(dstr(e.n.mt),cols[3][2],y+14,"#8fa3b5","12px monospace");if(mw>=500)tx(modeStr(e.n),mx+Math.floor(mw*.84)-6,y+14,"#6f8aa0","12px monospace");hits.push(entHit(w,e,mx+2,y,mw-4,rh))});
  sbar(w,X+Wd-12,my+22,Math.max(10,sy-my-24),ents.length,vis,()=>w.scroll||0,(v)=>{w.scroll=Math.round(v)})}
 else{const cw=96,chh=76,cl=Math.max(1,Math.floor((mw-8)/cw)),rows=Math.max(1,Math.floor((sy-my-4)/chh)),tr=Math.ceil(ents.length/cl);w.scroll=Math.max(0,Math.min(w.scroll||0,Math.max(0,tr-rows)));const s0=w.scroll*cl;
  ents.slice(s0,s0+rows*cl).forEach((e,i)=>{const gx=mx+4+(i%cl)*cw,gy=my+4+Math.floor(i/cl)*chh,sel=w.sel===e.nm;if(sel)rr(gx+2,gy,cw-4,chh-4,5,"#1f2a40");fIcon(gx+cw/2-18,gy+6,e.n,e.nm,2);const n2=e.nm.length>13?e.nm.slice(0,12)+"…":e.nm;tx(n2,gx+cw/2-n2.length*3.6,gy+58,"#e6edf3","12px monospace");hits.push(entHit(w,e,gx+2,gy,cw-4,chh-4))});
  sbar(w,X+Wd-12,my+4,Math.max(10,sy-my-8),tr,rows,()=>w.scroll||0,(v)=>{w.scroll=Math.round(v)})}
 c.fillStyle="#2a3340";c.fillRect(mx,sy,mw,1);rr(mx,sy+1,mw,sh-1,0,"#12161d");const se2=w.sel&&ents.find(e=>e.nm===w.sel);
 if(se2){tx((se2.nm+" — "+fiType(se2.n,se2.nm)+", "+fSize(se2.n)).slice(0,Math.floor((mw-20)/7.4)),mx+10,sy+18,"#e6edf3","12px monospace");tx(modeStr(se2.n)+"  "+se2.n.o,mx+10,sy+35,"#6f8aa0","12px monospace");if(se2.n.t==="f"&&can(se2.n,4)&&fiType(se2.n,se2.nm)!=="Binary")tx(se2.n.c.split("\n")[0].slice(0,Math.max(0,Math.floor((mw-190)/7))),mx+170,sy+35,"#8fa3b5","12px monospace")}
 else tx(ents.length+" element"+(w.q?'  (filtr: "'+w.q+'")':"")+(CLIP?"   |   Clipboard: "+CLIP.p.length+" ("+CLIP.op+")":""),mx+10,sy+22,"#8fa3b5","12px monospace");
 if(w.props){const n=(()=>{try{return nd(w.props)}catch(e){return null}})(),h2=[],dx=X+Wd/2-190,dy=Y+Ht/2-125;rr(dx,dy,380,250,8,"#232a3a");c.strokeStyle="#3a4660";c.lineWidth=1;c.strokeRect(dx+.5,dy+.5,379,249);
  const nm=abs(w.props).split("/").pop()||"/";tx("Properties — "+nm.slice(0,28),dx+16,dy+26,"#7fd4ff","bold 13px monospace");
  if(n){[["Type",fiType(n,nm)],["Size",fSize(n)],["Location",up(abs(w.props)).slice(0,34)],["Owner",n.o],["Modified",dstr(n.mt)],["Mode",modeStr(n)+"  ("+n.m+")"]].forEach((r,i)=>{tx(r[0]+":",dx+16,dy+52+i*20,"#8fa3b5","12px monospace");tx(r[1],dx+100,dy+52+i*20,"#e6edf3","12px monospace")});
   tx("Permissions",dx+16,dy+184,"#8fa3b5","12px monospace");["Read","Write","Exec"].forEach((s,j)=>tx(s,dx+120+j*70,dy+174,"#6b7a8a","11px monospace"));
   ["Owner","Group","Others"].forEach((s,i)=>{const y=dy+186+i*18;tx(s,dx+60,y+12,"#c5d3e0","12px monospace");[4,2,1].forEach((b,j)=>{const x=dx+120+j*70,on=(bits(n.m,i)&b)>0;rr(x,y,14,14,3,on?accent():"#2b3347");if(on)tx("✓",x+2,y+12,"#fff","bold 12px monospace");h2.push({x,y,w:14,h:14,fn:()=>{if(n.o!==USER)throw new Error("Ruxsat yo'q — sudo kerak");const d=n.m.split("").map(Number);d[i]^=b;F.chmod(w.props,d.join(""))}})})})}
  else tx("Mavjud emas",dx+16,dy+60,"#ff7b72","13px monospace");rr(dx+290,dy+214,74,24,5,"#2b3347");tx("Close",dx+308,dy+230,"#e6edf3","13px monospace");h2.push({x:dx+290,y:dy+214,w:74,h:24,fn:()=>{w.props=null}});w.hits=h2}
 else if(w.edit&&/^(rename|newd|newf)$/.test(w.edit.mode)){const h2=[],dx=X+Wd/2-160,dy=Y+Ht/2-60;rr(dx,dy,320,120,8,"#232a3a");c.strokeStyle="#3a4660";c.lineWidth=1;c.strokeRect(dx+.5,dy+.5,319,119);
  tx({rename:"Qayta nomlash",newd:"Yangi papka",newf:"Yangi fayl"}[w.edit.mode],dx+16,dy+26,"#7fd4ff","bold 13px monospace");rr(dx+16,dy+38,288,26,5,"#0b0f14");c.strokeStyle=accent();c.strokeRect(dx+16.5,dy+38.5,287,25);
  tx(w.edit.buf.slice(-34),dx+24,dy+56,"#e6edf3","13px monospace");if(bl){c.fillStyle="#7fd4ff";c.fillRect(dx+24+Math.min(34,w.edit.buf.length)*7.8,dy+42,2,18)}
  rr(dx+130,dy+80,80,26,5,accent());tx("OK",dx+160,dy+98,"#fff","bold 13px monospace");h2.push({x:dx+130,y:dy+80,w:80,h:26,fn:()=>commitEdit(w)});
  rr(dx+220,dy+80,84,26,5,"#2b3347");tx("Cancel",dx+240,dy+98,"#e6edf3","13px monospace");h2.push({x:dx+220,y:dy+80,w:84,h:26,fn:()=>{w.edit=null;ta.value="";syncInput()}});w.hits=h2}}

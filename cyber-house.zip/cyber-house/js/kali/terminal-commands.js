/* ==========================================================
 * Modul: js/kali/terminal-commands.js
 * Terminal: buyruqlar, pipe, grep, ls, run
 * ========================================================== */
/* ---- terminal: fayllar, buyruqlar ---- */
function tok(s){return(s.match(/"[^"]*"|'[^']*'|\S+/g)||[]).map(x=>x.length>1&&/^(["']).*\1$/.test(x)?x.slice(1,-1):x)}
function lsLine(nm,n){return modeStr(n)+" 1 "+n.o.padEnd(7)+" "+n.o.padEnd(7)+" "+String(n.t==="d"?4096:n.c.length).padStart(6)+" "+dstr(n.mt)+" "+nm}
function lsOne(p,all,lg,hdr){const n=nd(p);if(!n)throw new Error("cannot access '"+p+"': No such file or directory");if(n.t!=="d")return lg?lsLine(p.split("/").pop(),n):p;if(!can(n,4))throw new Error("cannot open directory '"+p+"': Permission denied");let ks=Object.keys(n.k).sort();if(!all)ks=ks.filter(k=>k[0]!==".");return(hdr?p+":\n":"")+(lg?"total "+ks.length+(ks.length?"\n":"")+ks.map(k=>lsLine(k,n.k[k])).join("\n"):ks.join("  "))}
function grepText(pat,txt,o){let re;try{re=new RegExp(pat,o.i?"i":"")}catch(e){re=new RegExp(pat.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),o.i?"i":"")}const L=txt.split("\n");if(L[L.length-1]==="")L.pop();const out=[];L.forEach((l,i)=>{if(re.test(l)!==!!o.v)out.push((o.pre||"")+(o.n?(i+1)+":":"")+l)});return out}
function grepArgs(a){const o={},ps=[];a.forEach(x=>{if(x[0]==="-"&&x.length>1)x.slice(1).split("").forEach(f=>o[f]=1);else ps.push(x)});return[o,ps]}
function pipeF(cmd,inp){const t=tok(cmd),n=t[0];
 if(n==="grep"){const[o,ps]=grepArgs(t.slice(1));if(!ps.length)throw new Error("grep: usage: grep [-ivnc] pattern");const r=grepText(ps[0],inp,o);return o.c?String(r.length):r.join("\n")}
 if(n==="head"||n==="tail"){let k=10;const i=t.indexOf("-n");if(i>0)k=parseInt(t[i+1])||10;else if(/^-\d+$/.test(t[1]||""))k=parseInt(t[1].slice(1));const L=inp.split("\n");if(L[L.length-1]==="")L.pop();return(n==="head"?L.slice(0,k):L.slice(-k)).join("\n")}
 if(n==="wc"){const L=inp.split("\n").length-(inp.endsWith("\n")||!inp?1:0),Wd=(inp.match(/\S+/g)||[]).length;return t.includes("-l")?String(L):t.includes("-w")?String(Wd):t.includes("-c")?String(inp.length):L+" "+Wd+" "+inp.length}
 if(n==="sort"){const L=inp.split("\n").filter(x=>x!=="");L.sort(t.includes("-n")?(a,b)=>parseFloat(a)-parseFloat(b):undefined);if(t.includes("-r"))L.reverse();return L.join("\n")}
 if(n==="uniq"){const L=inp.split("\n"),o=[];L.forEach(x=>{if(o[o.length-1]!==x)o.push(x)});return o.join("\n")}
 if(n==="cat")return inp;throw new Error(n+": quvur (|) ichida ishlamaydi")}
function execLine(s){let rd=null;const m=s.match(/^(.*?)\s*(>>?)\s*([^\s>|]+)\s*$/);if(m){s=m[1];rd={app:m[2]===">>",f:m[3]}}const parts=s.split(/\s*\|\s*/);let out=execCmd(parts[0]);for(let i=1;i<parts.length;i++)out=pipeF(parts[i],out==null?"":String(out));if(rd){const o=out==null?"":String(out);F.wr(rd.f,o+(o&&!/\n$/.test(o)?"\n":""),rd.app);return""}return out}
function execCmd(raw){const a=tok(raw);if(!a.length)return"";const n0=a[0];if(n0==="sudo"){if(a.length<2)return"usage: sudo <buyruq>";const sv=ASROOT;ASROOT=true;try{return execCmd(raw.replace(/^\s*sudo\s+/,""))}finally{ASROOT=sv}}const f=C[n0];if(!f){const e=new Error(n0+": command not found");e.nf=true;throw e}return f(a.slice(1),raw)}
function procLine(p){return p.user.padEnd(8)+String(p.pid).padStart(6)+" "+p.cpu.toFixed(1).padStart(4)+" "+p.mem.toFixed(1).padStart(4)+"  "+p.tty.padEnd(6)+" "+p.cmd}
const HOSTS_IPS=()=>Object.keys(HOSTS).concat([SET.ip,"127.0.0.1","localhost"]);
const C={
help:()=>"Buyruqlar: ls cd pwd mkdir touch cat nano cp mv rm echo head tail wc grep find chmod sudo\n  whoami id hostname uname ip ifconfig ping nmap ss ps top df free uptime date\n  python neofetch lsusb history clear exit\nOperatorlar:  >  >>  |  (grep head tail wc sort uniq)   Tab — avto to'ldirish\nKali menyusidagi vositalar (nikto, sqlmap, hydra, whois...) ham ishlaydi.",
ls:a=>{const fl=a.filter(x=>x[0]==="-").join(""),ps=a.filter(x=>x[0]!=="-");if(!ps.length)ps.push(".");return ps.map(p=>lsOne(p,/a/.test(fl),/l/.test(fl),ps.length>1)).join("\n\n")},
pwd:()=>cwd,
cd:a=>{const t=a[0]||"~",n=nd(t);if(!n)throw new Error(t+": No such file or directory");if(n.t!=="d")throw new Error(t+": Not a directory");if(!can(n,4)&&!can(n,1))throw new Error(t+": Permission denied");cwd=abs(t)},
mkdir:a=>{const r=a.includes("-p");a.filter(x=>x[0]!=="-").forEach(p=>F.mkdir(p,r))},
touch:a=>{a.forEach(p=>{const n=nd(p);if(n)n.mt=Date.now();else F.wr(p,"")})},
cat:a=>{if(!a.length)throw new Error("fayl nomi kerak");return a.map(p=>F.rd(p)).join("")},
nano:a=>{const p=abs(a[0]||"untitled.txt");let t="";try{t=F.rd(p)}catch(e){if(!/No such/.test(e.message))throw e}edText=t;edFile=p;edS=edC=0;openApp("editor");syncInput();return""},
cp:a=>{const r=a.some(x=>/^-\w*[rR]/.test(x)),p=a.filter(x=>x[0]!=="-");if(p.length<2)throw new Error("manzil kerak");F.cp(p[0],p[1],r)},
mv:a=>{const p=a.filter(x=>x[0]!=="-");if(p.length<2)throw new Error("manzil kerak");F.mv(p[0],p[1])},
rm:a=>{const r=a.some(x=>/^-\w*[rR]/.test(x));a.filter(x=>x[0]!=="-").forEach(p=>F.rm(p,r))},
rmdir:a=>{a.forEach(p=>{const n=nd(p);if(n&&n.t==="d"&&Object.keys(n.k).length)throw new Error(p+": Directory not empty");F.rm(p,true)})},
echo:a=>a.join(" "),
head:a=>{let k=10;const i=a.indexOf("-n");if(i>=0){k=parseInt(a[i+1])||10;a=a.filter((x,j)=>j!==i&&j!==i+1)}return F.rd(a.filter(x=>x[0]!=="-")[0]||"").split("\n").slice(0,k).join("\n")},
tail:a=>{let k=10;const i=a.indexOf("-n");if(i>=0){k=parseInt(a[i+1])||10;a=a.filter((x,j)=>j!==i&&j!==i+1)}const L=F.rd(a.filter(x=>x[0]!=="-")[0]||"").split("\n");if(L[L.length-1]==="")L.pop();return L.slice(-k).join("\n")},
wc:a=>{const t=F.rd(a.filter(x=>x[0]!=="-")[0]||"");return pipeF("wc "+a.filter(x=>x[0]==="-").join(" "),t)},
grep:a=>{const[o,ps]=grepArgs(a);if(ps.length<2)throw new Error("usage: grep [-invrc] pattern fayl...");const out=[];const doF=(p,pre)=>{const n=nd(p);if(!n)throw new Error(p+": No such file or directory");if(n.t==="d"){if(!o.r)throw new Error(p+": Is a directory");if(!can(n,4))return;Object.keys(n.k).sort().forEach(k=>doF(join(abs(p),k),true))}else{if(!can(n,4)){out.push("grep: "+p+": Permission denied");return}grepText(ps[0],n.c,Object.assign({},o,{pre:pre||ps.length>2?abs(p)+":":""})).forEach(x=>out.push(x))}};ps.slice(1).forEach(p=>doF(p,false));return out.join("\n")},
find:a=>{let start=".",name=null,type=null;for(let i=0;i<a.length;i++){if(a[i]==="-name")name=a[++i];else if(a[i]==="-type")type=a[++i];else if(a[i][0]!=="-")start=a[i]}const re=name?new RegExp("^"+name.replace(/[.+^${}()|[\]\\]/g,"\\$&").replace(/\*/g,".*").replace(/\?/g,".")+"$"):null,out=[],base=abs(start),n0=nd(base);if(!n0)throw new Error("'"+start+"': No such file or directory");(function w(p,n){const nm=p==="/"?"/":p.split("/").pop();if((!re||re.test(nm))&&(!type||(type==="d")===(n.t==="d")))out.push(p);if(n.t==="d"){if(!can(n,4)){out.push("find: '"+p+"': Permission denied");return}Object.keys(n.k).sort().forEach(k=>w(join(p,k),n.k[k]))}})(base,n0);return out.slice(0,200).join("\n")},
chmod:a=>{if(a.length<2)throw new Error("usage: chmod <mode> fayl...");a.slice(1).forEach(p=>F.chmod(p,a[0]))},
clear:()=>{termLines=[]},
whoami:()=>ASROOT?"root":USER,
id:()=>ASROOT?"uid=0(root) gid=0(root) groups=0(root)":"uid=1000("+USER+") gid=1000("+USER+") groups=1000("+USER+"),27(sudo)",
hostname:()=>HOST,
uname:a=>a.includes("-a")?"Linux "+HOST+" 6.12.0-kali1-amd64 #1 SMP PREEMPT_DYNAMIC x86_64 GNU/Linux":"Linux",
date:()=>new Date().toString().slice(0,24),
history:()=>hist.map((h,i)=>String(i+1).padStart(4)+"  "+h).join("\n"),
exit:()=>{closeWin("terminal")},
ip:a=>{const k=a[0]||"";if(/^r/.test(k))return"default via 192.168.1.1 dev eth0 proto dhcp metric 100\n192.168.1.0/24 dev eth0 proto kernel scope link src "+SET.ip;if(/^l/.test(k))return"1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536\n    link/loopback 00:00:00:00:00:00\n2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500\n    link/ether 08:00:27:4e:66:a1 brd ff:ff:ff:ff:ff:ff";return"1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 state UNKNOWN\n    inet 127.0.0.1/8 scope host lo\n2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 state UP\n    link/ether 08:00:27:4e:66:a1 brd ff:ff:ff:ff:ff:ff\n    inet "+SET.ip+"/24 brd "+SET.ip.replace(/\d+$/,"255")+" scope global dynamic eth0"},
ifconfig:()=>"eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500\n        inet "+SET.ip+"  netmask 255.255.255.0  broadcast "+SET.ip.replace(/\d+$/,"255")+"\n        ether 08:00:27:4e:66:a1  txqueuelen 1000  (Ethernet)\nlo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536\n        inet 127.0.0.1  netmask 255.0.0.0",
ping:a=>{let n=4;const i=a.indexOf("-c");if(i>=0)n=Math.min(10,parseInt(a[i+1])||4);const h=a.filter((x,j)=>x[0]!=="-"&&!(i>=0&&j===i+1)).pop();if(!h)throw new Error("usage: ping [-c N] host");const ok=HOSTS_IPS().includes(h)||h==="192.168.1.1";let r="PING "+h+" 56(84) bytes of data.";for(let k=1;k<=n;k++)r+=ok?"\n64 bytes from "+h+": icmp_seq="+k+" ttl=64 time="+(.3+k*.07).toFixed(2)+" ms":"\nFrom "+SET.ip+" icmp_seq="+k+" Destination Host Unreachable";return r+"\n\n--- "+h+" ping statistics ---\n"+n+" packets transmitted, "+(ok?n:0)+" received, "+(ok?"0":"100")+"% packet loss"},
nmap:a=>{if(a.includes("--help")||a.includes("-h"))return"Nmap 7.95 ( https://nmap.org )\nUsage: nmap [Scan Type(s)] [Options] {target}\n  -sS TCP SYN scan   -p portlar   -sV versiya   -A to'liq\nMisol: nmap 192.168.1.10";const h=a.filter(x=>x[0]!=="-").pop()||"192.168.1.1";let t=HOSTS[h];const own=h===SET.ip||h==="127.0.0.1"||h==="localhost";if(own)t=SET.fw?{}:{22:"ssh"};let r="Starting Nmap 7.95 ( https://nmap.org )\nNmap scan report for "+h;if(!t)return r+"\nHost seems down.";if(own&&SET.fw)return r+"\nAll 1000 scanned ports on "+h+" are filtered (ufw)\nNmap done: 1 host up";r+="\nPORT      STATE SERVICE";Object.keys(t).forEach(k=>r+="\n"+(k+"/tcp").padEnd(10)+"open  "+t[k]);r+="\nNmap done: 1 host up\n[+] natija ~/scan_results.txt ga saqlandi";const sv=ASROOT;ASROOT=false;try{F.wr(HOME+"/scan_results.txt",r+"\n")}catch(e){}finally{ASROOT=sv}boost=70;if(h==="192.168.1.10")M.s[1]=true;return r},
ss:a=>{simEns();const all=a.join("").includes("l"),r=["Netid State      Local Address:Port    Peer Address:Port   Process"];conns().filter(x=>all?x[3]!=="ESTAB"&&x[3]!=="SYN-SENT":x[3]==="ESTAB"||x[3]==="SYN-SENT").forEach(x=>r.push(x[0].padEnd(6)+" "+x[3].padEnd(10)+" "+x[1].padEnd(20)+" "+x[2].padEnd(18)+" "+x[4]));return r.join("\n")},
ps:a=>{simEns();if(!a.length)return"    PID TTY          TIME CMD\n   2001 pts/0    00:00:00 zsh\n   "+(4000+hist.length)+" pts/0    00:00:00 ps";return"USER       PID %CPU %MEM  TTY    COMMAND\n"+SIM.P.map(procLine).join("\n")},
top:()=>{simEns();const P=SIM.P.slice().sort((a,b)=>b.cpu-a.cpu).slice(0,10),d=new Date();return"top - "+d.toTimeString().slice(0,8)+" up "+upStr()+",  1 user,  load average: "+(SIM.cpuNow/40).toFixed(2)+", "+(SIM.cpuNow/45).toFixed(2)+", "+(SIM.cpuNow/50).toFixed(2)+"\nTasks: "+SIM.P.length+" total\n%Cpu(s): "+SIM.cpuNow.toFixed(1)+" us\nMiB Mem : "+RAMT+" total, "+(RAMT-SIM.ramUsed)+" free, "+SIM.ramUsed+" used\n\nUSER       PID %CPU %MEM  TTY    COMMAND\n"+P.map(procLine).join("\n")},
df:()=>{const u=14.2+fsTotal()/1e9;return"Filesystem      Size  Used Avail Use% Mounted on\n/dev/nvme0n1p2  512G  "+u.toFixed(1).padStart(4)+"G  "+(512-u).toFixed(0)+"G   "+Math.ceil(u/5.12)+"% /"+(usbOn()?"\n/dev/sda1       7.5G  1.0M  7.5G   1% /media/usb":"")},
free:()=>{simEns();return"               total        used        free\nMem:       "+String(RAMT*1024).padStart(10)+"  "+String(SIM.ramUsed*1024).padStart(10)+"  "+String((RAMT-SIM.ramUsed)*1024).padStart(10)},
uptime:()=>" "+new Date().toTimeString().slice(0,8)+" up "+upStr()+",  1 user,  load average: "+(SIM.cpuNow/40).toFixed(2),
neofetch:()=>{simEns();return USER+"@"+HOST+"\n---------\nOS: Kali GNU/Linux Rolling\nKernel: 6.12.0-kali1-amd64\nUptime: "+upStr()+"\nShell: zsh 5.9\nDE: Xfce 4.20\nCPU: Ryzen 7 5800X ("+SIM.cpuNow.toFixed(0)+"%)\nMemory: "+SIM.ramUsed+"MiB / "+RAMT+"MiB\nIP: "+SET.ip},
lsusb:()=>"Bus 001 Device 001: ID 1d6b:0002 Linux Foundation root hub"+(usbOn()?"\nBus 001 Device 003: ID 0781:5567 SanDisk Cruzer (CYBERKEY)":""),
python:a=>{if(!a[0])return"Python 3.12.3 (simulyatsiya). Misol: python payload.py";runPy(F.rd(a[0]),tOut)}};
C.python3=C.python;C.vi=C.nano;C.mousepad=C.nano;C.ll=a=>C.ls(["-l"].concat(a));
KM.forEach(k=>k.t.forEach(t=>{const[nm,cm,ds]=t.split("|");if(cm.indexOf("app:")!==0&&!C[cm])C[cm]=()=>nm+" — "+ds+"\nUsage: "+cm+" [options] <target>\n[sim] O'yin ichidagi o'quv simulyatsiya: haqiqiy tarmoqqa ta'sir qilmaydi."}));
function complete(buf){const m=buf.match(/^([\s\S]*?)(\S*)$/),pre=m[1],w=m[2],first=!/\S/.test(pre)||/^\s*sudo\s+$/.test(pre);let cands;
 if(first&&w.indexOf("/")<0)cands=Object.keys(C).filter(x=>x.indexOf(w)===0);
 else{const i=w.lastIndexOf("/"),dir=i>=0?w.slice(0,i+1):"",base=w.slice(i+1);let names=[],d=null;try{d=nd(dir||".")}catch(e){}if(d&&d.t==="d"&&can(d,4))names=Object.keys(d.k);cands=names.filter(x=>x.indexOf(base)===0&&(base||x[0]!==".")).sort().map(x=>dir+x+(d.k[x].t==="d"?"/":""))}
 if(!cands.length)return{buf};if(cands.length===1)return{buf:pre+cands[0]+(/\/$/.test(cands[0])?"":" ")};let p=cands[0];cands.forEach(x=>{while(x.indexOf(p)!==0)p=p.slice(0,-1)});return{buf:pre+p,list:cands.map(x=>x.replace(/\/$/,"")===x?x:x).join("  ")}}
function run(raw){const s=raw.trim();termOff=0;termLines.push({t:"┌──("+USER+"㉿"+HOST+")-["+pd()+"]",c:"#5fa8ff"},{t:"└─$ "+raw,c:"#e6edf3"});
 if(s){try{const r=execLine(s);if(r)String(r).replace(/\n$/,"").split("\n").forEach(t=>termLines.push({t,c:"#b8c7d6"}))}catch(e){const cn=tok(s.split(/\s*[|>]/)[0].replace(/^\s*sudo\s+/,""))[0]||"";termLines.push({t:e.nf?e.message:cn+": "+e.message,c:"#ff7b72"})}hist.push(raw)}
 hi=hist.length;if(termLines.length>400)termLines.splice(0,termLines.length-400)}
if(SET.wall>0)paintWall(SET.wall);


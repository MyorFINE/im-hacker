/* ==========================================================
 * Modul: js/life/life-state.js
 * Hayot tizimi holati: karavot, uyqu
 * ========================================================== */
/* ---------- hayot tizimi: karavot, suv idishi, chanqash, uyqu ---------- */
const LF={hunger:0,hd:0,h70:0,thirst:0,tired:10,cup:0,sleeping:false,integ:100,srv:100,wd:0,ut:0,w70:0};
let sleepT=0;
const bedPos=new T.Vector3(-4.2,.95,5.5),BEDP=new T.Vector3(-4.2,.7,5.7),DISP=new T.Vector3(5.18,.8,.2),dmy2=new T.PerspectiveCamera();
dmy2.position.copy(bedPos);dmy2.lookAt(-4.2,2.6,4.4);const bedQ=dmy2.quaternion.clone();
{const fr=L(0x3b2a1d),mt=L(0xdfe6ee),bl=L(0x2b5c8a),pi=L(0xf4f7fa);
 box(-4.2,.2,5.69,1.24,.26,2.2,fr);box(-4.2,.43,5.7,1.12,.2,2.06,mt);box(-4.2,.58,6.4,.84,.12,.42,pi);box(-4.2,.56,5.3,1.1,.1,1.25,bl);box(-4.2,.625,6.82,1.3,.89,.1,fr);
 [[-4.78,4.68],[-3.62,4.68],[-4.78,6.7],[-3.62,6.7]].forEach(a=>box(a[0],.1,a[1],.08,.2,.08,fr));cols.push({x:-4.2,z:5.72,hw:.66,hd:1.14});
 box(5.4,.5,.2,.42,1.0,.42,L(0xdde4e8));box(5.18,.78,.2,.04,.1,.12,L(0x2b6bd6));box(5.18,.62,.2,.14,.03,.2,L(0x555d66));box(5.4,1.445,.2,.18,.05,.18,L(0x2b6bd6));
 const bt=new T.Mesh(new T.CylinderGeometry(.14,.14,.42,14),new T.MeshLambertMaterial({color:0x7fd4ff,transparent:true,opacity:.55}));bt.position.set(5.4,1.21,.2);scene.add(bt);cols.push({x:5.4,z:.2,hw:.23,hd:.23});
 const lb=cv(256,64),l2=lb.getContext("2d");l2.fillStyle="#0c2a3a";l2.fillRect(0,0,256,64);l2.fillStyle="#7fd4ff";l2.font="bold 34px monospace";l2.textAlign="center";l2.fillText("SUV",128,44);
 const lm=new T.Mesh(new T.PlaneGeometry(.3,.075),new T.MeshBasicMaterial({map:tex(lb)}));lm.rotation.y=-Math.PI/2;lm.position.set(5.185,.92,.2);scene.add(lm)}

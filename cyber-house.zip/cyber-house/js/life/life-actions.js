/* ==========================================================
 * Modul: js/life/life-actions.js
 * Stakan, ichish, uyqu, vitals va lifeTick
 * ========================================================== */
function cupUpd(){if(LF.cup){camera.getWorldDirection(fw);rg.set(1,0,0).applyQuaternion(camera.quaternion);cupG.position.copy(camera.position).addScaledVector(fw,.5).addScaledVector(rg,.2);cupG.position.y-=.2;cupG.visible=!seated&&!LF.sleeping;cupG.getObjectByName("w").visible=LF.cup===2}else cupG.visible=false;alarmL.intensity=SEC.alarm>0?.9+.9*Math.sin(performance.now()/110):0}
function drink(){if(LF.sleeping||seated||KT.eat)return;if(LF.cup!==2){toast("Avval stakanga suv quying (suv idishi — sharq devor)");return}LF.thirst=Math.max(0,LF.thirst-62);LF.cup=1;toast("💧 Suv ichdingiz — bo'sh stakanni stolga qo'yishingiz mumkin")}
function startSleep(){if(LF.sleeping)return;if(seated)stand();P.x=-3.4;P.z=5.4;P.vx=P.vz=0;LF.sleeping=true;document.exitPointerLock&&document.exitPointerLock();const b=$("standBtn");b.style.display="block";b.textContent="Uyg'onish (E)";$("cross").style.display="none";toast("😴 Uxlayapsiz...")}
function wake(msg){if(!LF.sleeping)return;LF.sleeping=false;P.x=-3.1;P.z=5.4;P.yaw=Math.PI/2;P.pitch=0;P.vx=P.vz=0;const b=$("standBtn");b.style.display="none";b.textContent="Turish (Esc)";$("cross").style.display="block";toast(msg||"☀ Uyg'ondingiz");if(started&&!mobile)cvEl.requestPointerLock&&cvEl.requestPointerLock()}
function vitalsUI(){const e=$("vitals");if(!started){e.style.display="none";return}e.style.display="block";
 const col=v=>v<50?"#2dff88":v<75?"#ffb84a":"#ff4d4d",inv=v=>v>65?"#2dff88":v>35?"#ffb84a":"#ff4d4d",row=(l,v,c)=>'<div class="vr"><span>'+l+'</span><i><b style="width:'+Math.round(v)+'%;background:'+c+'"></b></i></div>';
 e.innerHTML=row("💧 Chanqash",LF.thirst,col(LF.thirst))+row("🍽 Ochlik",LF.hunger,col(LF.hunger))+row("😴 Charchoq",LF.tired,col(LF.tired))+row("🖥 Kompyuter",LF.integ,inv(LF.integ))+row("🗄 Serverlar",LF.srv,inv(LF.srv))+(seated?'<div style="margin-top:4px;color:#9fc3d6">💰 Ball: '+SEC.score+(SEC.vault?' · 🔒 '+SEC.vault:'')+'</div>':'')}
function lifeTick(dt,now){if(!started)return;
 LF.thirst=Math.min(100,LF.thirst+dt*(LF.sleeping?.12:.33));LF.hunger=Math.min(100,LF.hunger+dt*(LF.sleeping?.05:.16));
 if(LF.sleeping){LF.tired=Math.max(0,LF.tired-dt*10);if(LF.tired<=0)wake("☀ To'yib uxladingiz")}
 else{LF.tired=Math.min(100,LF.tired+dt*.1);
  if(LF.thirst>=70&&!LF.w70){LF.w70=1;toast("💧 Chanqayapsiz — suv idishi sharq devor yonida")}if(LF.thirst<60)LF.w70=0;
  if(LF.hunger>=70&&!LF.h70){LF.h70=1;toast("🍽 Qorningiz ochdi — oshxona shimoliy devordagi eshik ortida")}if(LF.hunger<60)LF.h70=0;
  if(LF.hunger>=100&&now-LF.hd>25000){LF.hd=now;toast("🥵 Och qoldingiz — kuchsizlanyapsiz! Oshxonaga boring")}
  if(LF.thirst>=100&&now-LF.wd>20000){LF.wd=now;toast("🥵 Suvsizlikdan holsizlanyapsiz!")}
  if(LF.tired>=100){toast("😵 Charchoqdan yiqildingiz");startSleep()}}
 if(now-LF.ut>500){LF.ut=now;vitalsUI()}
 const fx=$("fx").style,vg=$("vig").style,o=Math.min(.9,sleepT*.9),v=Math.max(0,Math.min(.75,Math.max((LF.thirst-75)/25,(LF.tired-85)/15,(LF.hunger-80)/20)));
 if(fx.opacity!=o)fx.opacity=o;if(vg.opacity!=v)vg.opacity=v}

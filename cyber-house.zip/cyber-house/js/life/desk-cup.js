/* ==========================================================
 * Modul: js/life/desk-cup.js
 * Stakanni stolga qo'yish va olish
 * ========================================================== */
/* ---------- stakanni stolga qo'yish ---------- */
function mkCup(){const g=new T.Group(),cm=new T.Mesh(new T.CylinderGeometry(.04,.03,.1,10,1,true),new T.MeshLambertMaterial({color:0xffffff,transparent:true,opacity:.45,side:T.DoubleSide}));g.add(cm);const wt=new T.Mesh(new T.CylinderGeometry(.036,.029,.07,10),new T.MeshBasicMaterial({color:0x4fc3ff}));wt.position.y=-.012;wt.name="w";g.add(wt);g.visible=false;scene.add(g);return g}
const cupD=mkCup();LF.dcup=null;
function deskPoint(){camera.getWorldDirection(fw);if(fw.y>-.05)return null;const t=(.9-camera.position.y)/fw.y;if(t<0||t>1.9)return null;const x=camera.position.x+fw.x*t,z=camera.position.z+fw.z*t;if(x<-1.6||x>1.6||z<-3.6||z>-2.8)return null;const q=deskFree(x,z);if(!q)return null;return new T.Vector3(q[0],.9,q[1])}
/* stakan stol ustidagi buyumlar (klaviatura, monitor, karnay...) ichiga tushmasligi uchun */
const _mk=m=>{const b=monBoxes(m);return[[b.body[0],b.body[1],b.body[4],b.body[5]],[b.stand[0]-.04,b.stand[1]+.04,b.stand[4]-.04,b.stand[5]+.04]]};
const DKEEP=[[-.56,.56,-3.13,-2.77],[.625,1.075,-3.18,-2.82],[-1.24,-1.10,-3.93,-3.77],[1.10,1.24,-3.93,-3.77],[-1.71,-1.45,-3.83,-3.57],[-1.25,-.95,-3.21,-2.99],[1.29,1.55,-3.645,-3.455]].concat(_mk(MON1),_mk(MON2));
function deskFree(x,z){const r=.045;for(let n=0;n<4;n++){let hit=false;for(const a of DKEEP){if(x>a[0]-r&&x<a[1]+r&&z>a[2]-r&&z<a[3]+r){hit=true;const d=[x-(a[0]-r),a[1]+r-x,z-(a[2]-r),a[3]+r-z];let m=0;for(let i=1;i<4;i++)if(d[i]<d[m])m=i;if(m===0)x=a[0]-r;else if(m===1)x=a[1]+r;else if(m===2)z=a[2]-r;else z=a[3]+r}}if(!hit)return(x<-1.7||x>1.7||z<-4.1||z>-2.75)?null:[x,z]}return null}
const dcW=()=>new T.Vector3(LF.dcup.x,.95,LF.dcup.z);
function putCup(p){LF.dcup={x:p.x,z:p.z,full:LF.cup===2};LF.cup=0;toast("Stakan stolga qo'yildi")}
function pickCup(){LF.cup=LF.dcup.full?2:1;LF.dcup=null;toast("Stakan olindi")}
function pourCup(){LF.cup=2;toast("🥛 Stakan to'ldirildi — ichish: E yoki Q")}
function dcupUpd(){if(LF.dcup){cupD.position.set(LF.dcup.x,.95,LF.dcup.z);cupD.visible=true;cupD.getObjectByName("w").visible=LF.dcup.full}else cupD.visible=false}

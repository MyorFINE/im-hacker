/* ==========================================================
 * Modul: js/education/mentor-coach.js
 * Mentor: kompyuter o'zi o'rgatadi
 * ========================================================== */
/* ---------- Mentor: kompyuter o'zi o'rgatadi (dastlabki 3 o'yin) ---------- */
let PLAYS=1;try{PLAYS=(+localStorage.getItem("hs_plays")||0)+1;localStorage.setItem("hs_plays",PLAYS)}catch(e){}
const COACH={on:PLAYS<=3,step:0,t0:0,pre:false,okT:0,click:0};
const fIp=()=>SEC.list.length?SEC.list[SEC.list.length-1].ip:"<ip>",c2Ip=()=>Object.keys(SEC.traced)[0]||"<c2>";
const COACH_STEPS=[
{t:()=>"Salom! Men Mentorman — dastlabki o'yinlarda sizga o'rgataman. Boshlash: terminalda 'help' deb yozing.",ok:()=>hist.some(h=>/^help\b/.test(h))},
{t:()=>"HIMOYA 1/4. Firewall yoqing:  sudo ufw enable  (skanerlash va SSH hujumlarini to'sadi).",ok:()=>SET.fw},
{t:()=>"HIMOYA 2/4. Kuchli parol:  passwd  — yangi parolni eslab qoling! (brute-force o'tmaydi).",ok:()=>SEC.strong},
{t:()=>"HIMOYA 3/4. Zaifliklarni yamang:  sudo apt upgrade  (web va ransomware hujumlarini to'sadi).",ok:()=>SEC.patched},
{t:()=>"HIMOYA 4/4. Zaxira oling:  backup  — ransomware fayllarni shifrlasa, 'restore' bilan qaytarasiz.",ok:()=>SEC.lastBackup>0},
{t:()=>"KUZATISH. Hujum ~20 soniyada boshlanadi, lekin ogohlantirish CHIQMAYDI! 'Attack Monitor' (AM) ni ochib turing — hujumlar faqat shu yerda ko'rinadi. Har hujumni 60 soniyada bartaraf eting.",ok:()=>wins.some(w=>w.id==="ids"||w.id==="atkmon")||hist.some(h=>/^ids\b/.test(h)),on:()=>{SEC.nextAt=Math.min(SEC.nextAt||Infinity,Date.now()+20000)}},
{t:()=>"Hujum kutilmoqda... Attack Monitor da qizil qator paydo bo'ladi (⏱ taymer 60s). Tezkor chora:  ids block <ip>  (Block tugmasi).",ok:()=>SEC.list.length>0},
{t:()=>"ANIQLASH. Yozing:  ids trace "+fIp()+"  (yoki Trace tugmasi, ~8 soniya). Bu IP — faqat bot; asl boshqaruvchi (C2) topiladi.",ok:()=>Object.keys(SEC.traced).length>0},
{t:()=>"QARSHI HUJUM 1/3. C2 ni skanerlang:  nmap "+c2Ip()+"  (ochiq portlar chiqadi).",ok:()=>hist.some(h=>/nmap\s+203\.0\.113\./.test(h))},
{t:()=>"QARSHI HUJUM 2/3. Parolni toping:  hydra -l admin -P Wordlists/common.txt ssh://"+c2Ip(),ok:()=>Object.keys(SEC.cracked).length>0},
{t:()=>"QARSHI HUJUM 3/3. Botnetni o'chiring:  ssh admin@"+c2Ip()+' "pkill botnetd"',ok:()=>(SEC.killed||0)>0},
{t:()=>"Ajoyib! Hujumni aniqlash, himoyalanish va qarshi hujumni o'rgandingiz. Eslatma: stol tortmasidagi blaknot va 'audit' buyrug'i. 'mentor off' — o'chirish.",ok:()=>false}];
function coachBegin(){const st=COACH_STEPS[Math.min(COACH.step,COACH_STEPS.length-1)];COACH.t0=performance.now();COACH.okT=0;COACH.pre=false;try{COACH.pre=!!(st&&st.ok())}catch(e){}if(st&&st.on)st.on();dirty=true}
function coachAdv(){if(COACH.step<COACH_STEPS.length-1)COACH.step++;coachBegin()}
function coachReset(){COACH.step=0;COACH.on=true;coachBegin()}
function coachTick(){if(!COACH.on||S.stage!==3)return;if(!COACH.t0){coachBegin();return}const st=COACH_STEPS[COACH.step];if(!st||COACH.step>=COACH_STEPS.length-1||COACH.pre)return;
 let ok=false;try{ok=!!st.ok()}catch(e){}const now=performance.now();
 if(ok){if(!COACH.okT){COACH.okT=now;dirty=true}if(now-COACH.okT>1800&&now-COACH.t0>2500){toast("✓ Mentor: qadam bajarildi");coachAdv()}}else if(COACH.okT){COACH.okT=0;dirty=true}}
function drawCoach(){if(!COACH.on||!S.on||S.stage!==3)return;const X=W-392,Y=H-146,Wd=382,Ht=138,N=COACH_STEPS.length,done=COACH.step>=N-1,st=COACH_STEPS[Math.min(COACH.step,N-1)];
 rr(X,Y,Wd,Ht,8,"rgba(10,22,34,.94)");c.strokeStyle=accent();c.lineWidth=1.5;c.strokeRect(X+.75,Y+.75,Wd-1.5,Ht-1.5);
 tx("Mentor — "+(done?"yakun":"qadam "+(COACH.step+1)+"/"+(N-1)),X+12,Y+20,"#7fd4ff","bold 13px monospace");rr(X+12,Y+27,Wd-24,4,2,"#1d2a38");rr(X+12,Y+27,Math.max(2,(Wd-24)*Math.min(1,COACH.step/(N-1))),4,2,"#2dff88");
 wrapT(st.t(),50).slice(0,4).forEach((l,i)=>tx(l,X+12,Y+50+i*15,"#e6edf3","12px monospace"));
 if(!done){const ok=COACH.pre||COACH.okT>0;tx(COACH.pre?"✓ bajarilgan — Keyingi ▸":ok?"✓ ajoyib, davom etamiz…":"… harakatingiz kutilmoqda",X+12,Y+Ht-15,ok?"#2dff88":"#7f95a8","11px monospace")}
 rr(X+Wd-196,Y+Ht-30,90,22,5,"#2b3347");tx(done?"Qaytadan":"Keyingi ▸",X+Wd-188,Y+Ht-15,"#fff","12px monospace");rr(X+Wd-100,Y+Ht-30,88,22,5,"#4a2b2b");tx("Yopish",X+Wd-84,Y+Ht-15,"#fff","12px monospace")}
function coachClick(x,y){if(!COACH.on||!S.on||S.stage!==3)return false;const X=W-392,Y=H-146,Wd=382,Ht=138;if(x<X||x>X+Wd||y<Y||y>Y+Ht)return false;const N=COACH_STEPS.length;
 if(y>=Y+Ht-30&&y<=Y+Ht-8){if(x>=X+Wd-196&&x<=X+Wd-106){const now=performance.now();if(now-COACH.click>500){COACH.click=now;if(COACH.step>=N-1)coachReset();else coachAdv()}}else if(x>=X+Wd-100&&x<=X+Wd-12)COACH.on=false}
 dirty=true;return true}
Object.assign(C,{mentor:a=>{const s=a[0]||"on";if(s==="off"){COACH.on=false;dirty=true;return"Mentor o'chirildi"}if(s==="reset"){coachReset();return"Mentor boshidan boshlandi"}if(s==="next"){coachAdv();return""}COACH.on=true;dirty=true;return"Mentor yoqildi (mentor off | mentor next | mentor reset)"}});
const h2=C.help;C.help=()=>h2()+"\nMentor: mentor on|off|next|reset";

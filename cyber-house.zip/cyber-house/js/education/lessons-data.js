/* ==========================================================
 * Modul: js/education/lessons-data.js
 * O'rgatuvchi auditlar (LESSONS)
 * ========================================================== */
/* ---------- o'rgatuvchi auditlar + blaknot ---------- */
const LESSONS=[
{t:"1. Boshlash",b:`• Ochlik ham bor: oshxona — shimoliy devordagi eshik ortida (E bilan oching).
• Kompyuter va monitor vilkasini rozetka OLDIGA borib ulang (E), power tugmasini bosing, stulga o'tiring (E).
• Kirish paroli: kali (keyin passwd bilan o'zgartirasiz).
• Bir vaqtda qo'lda faqat BITTA narsa: stakan, vilka yoki flesh. Yangisini olishdan oldin qo'ldagini stolga qo'ying.
• Hujumlar haqida ekranda xabar chiqmaydi! Kompyuterga o'tirib 'Attack Monitor' (AM) ni oching.
• Terminalda: help — ro'yxat, man <buyruq> — tushuntirish, audit — shu daftar.`},
{t:"2. Fayl buyruqlari",b:`$ pwd
→ Hozir qaysi papkadasiz — to'liq yo'lni chiqaradi (masalan /home/player).
$ ls -la
→ Papka ichini ko'rsatadi. -l: huquq, egasi, o'lcham bilan batafsil; -a: yashirin (nuqta bilan boshlanuvchi) fayllarni ham.
$ cd <papka>
→ Papkaga o'tadi. cd .. — bir pog'ona yuqoriga, cd ~ — uy papkasiga.
$ mkdir <nom>
→ Yangi papka yaratadi.
$ touch <fayl>
→ Bo'sh fayl yaratadi (bor bo'lsa vaqtini yangilaydi).
$ cat <fayl>
→ Fayl ichini ekranga chiqaradi. Loglarni o'qishda ko'p ishlatiladi.
$ nano <fayl>
→ Matn muharririni ochadi: yozing, saqlang. Sozlama fayllarini tahrirlash uchun.
$ cp <manba> <nishon>
→ Nusxa ko'chiradi (papka uchun cp -r). Zaxira olishda kerak.
$ mv <eski> <yangi>
→ Faylni boshqa joyga ko'chiradi yoki nomini o'zgartiradi.
$ rm <fayl>
→ O'chiradi. Qaytarib bo'lmaydi! Papka uchun rm -r.
$ chmod 600 <fayl>
→ Kirish huquqini o'zgartiradi: 600 — faqat egasi o'qiy va yoza oladi, boshqalar kira olmaydi.`},
{t:"3. Matn va filtrlash",b:`$ echo "salom"
→ Matnni ekranga chiqaradi. echo "x" > f.txt — faylga yozadi (eskisini o'chirib), >> — oxiriga qo'shadi.
$ head -n 5 <fayl>
→ Faylning dastlabki 5 qatorini ko'rsatadi.
$ tail -n 20 <fayl>
→ Oxirgi 20 qatorni ko'rsatadi — yangi log yozuvlari shu yerda.
$ wc -l <fayl>
→ Qatorlar sonini sanaydi (-w so'z, -c belgi).
$ grep Failed <fayl>
→ Fayldan so'z bor qatorlarni ajratib beradi. Masalan: sudo grep Failed /var/log/auth.log.
$ find / -name "*.txt"
→ Fayllarni nomi bo'yicha qidiradi.
$ sort | uniq
→ sort tartiblaydi, uniq takrorlarni olib tashlaydi. "|" — bir buyruq natijasini keyingisiga uzatadi.
Misol: sudo cat /var/log/auth.log | grep Failed | wc -l   (muvaffaqiyatsiz urinishlar soni)`},
{t:"4. Tizim va tarmoq",b:`$ whoami
→ Qaysi foydalanuvchi ekaningizni aytadi.
$ id
→ Foydalanuvchi raqami va guruhlari.
$ hostname
→ Kompyuter nomi.
$ uname -a
→ Yadro (kernel) va tizim versiyasi.
$ date
→ Hozirgi sana va vaqt.
$ uptime
→ Kompyuter qancha vaqtdan beri yoniq.
$ ip a
→ Tarmoq kartalari va IP manzilingiz (ifconfig ham shu).
$ ping <ip>
→ Manzil javob beradimi tekshiradi. Aloqa bormi — shu bilan bilinadi.
$ ss -tuln
→ Ochiq portlar va ulanishlar. Begona ulanishni shu yerdan ko'rasiz.
$ ps aux
→ Ishlayotgan jarayonlar. Shubhali jarayonni qidiring.
$ top
→ Jarayonlarning jonli ro'yxati: CPU va xotira.
$ df -h
→ Disk to'lganligi.
$ free -h
→ Xotira (RAM) holati.
$ sudo <buyruq>
→ Buyruqni administrator (root) huquqi bilan bajaradi: ufw, apt, systemctl uchun kerak.
$ history
→ Oldingi buyruqlaringiz.
$ clear
→ Ekranni tozalaydi.
$ neofetch
→ Tizim haqida chiroyli qisqa ma'lumot.
$ lsusb
→ Ulangan USB qurilmalar (flesh).
$ python <fayl.py>
→ Python dasturini ishga tushiradi.`},
{t:"5. Kali vositalari",b:`$ nmap <ip>
→ Portlarni skanerlaydi: qaysi xizmatlar ochiq (22 ssh, 80 web, 8080 c2-panel). Razvedkaning birinchi qadami.
$ hydra -l admin -P Wordlists/common.txt ssh://<ip>
→ Parol tanlab ko'radi: -l login, -P parollar ro'yxati. Faqat o'zingizning/o'yin ichidagi nishonga!
$ john <hesh-fayl>
→ Parol heshlarini tekshiradi (zaif parolni topadi).
$ nikto -h <ip>
→ Veb-serverdagi ma'lum zaifliklarni qidiradi.
$ sqlmap -u <url>
→ Saytda SQL-inyeksiya zaifligini tekshiradi.
$ whois <domen>
→ Domen/IP egasi haqida ma'lumot.
$ nc <ip> <port>
→ Netcat: portga to'g'ridan-to'g'ri ulanib, xizmatga yozish/o'qish.
$ man <buyruq>
→ Istalgan buyruq tushuntirishini ko'rsatadi (shu daftardan).
Eslatma: o'yinda bu vositalar o'quv simulyatsiya. Haqiqiy hayotda faqat o'z tizimingizda yoki yozma ruxsat bilan ishlating.`},
{t:"6. Hujumlar (ogohlantirishsiz!)",b:`• Hujum boshlanganda ekranda hech narsa chiqmaydi. Kompyuterda Attack Monitor'ni oching: qizil qator + taymer.
• 1 o'yin kuni = 1 real soat. Kuniga 5 ta hujum bo'ladi (tasodifiy vaqtda). Har hujumni bartaraf etish uchun 60 soniya bor. Tugasa — buzilish va ball o'g'irlanadi.
1) Port skanerlash — razvedka, o'zi zarar bermaydi, keyingi hujumni 1.2 marta tezlashtiradi.
2) SSH brute-force — parol taxmini. Belgi: auth.log da 'Failed password'.
3) Web zaiflik (CVE) — web-srv ga. Belgi: syslog da 'suspicious request'.
4) Ransomware — Documents fayllarini shifrlaydi ([ENCRYPTED]).
• Buzilganda ochiq ballning bir qismi (kompyuter 35%, server 20%) o'g'irlanadi.
• Himoya 100% emas: botlar vaqt o'tishi bilan firewall, kuchli parol va yamoqni ba'zan aylanib o'tadi (hujumlar ko'paygan sari ko'proq). Shuning uchun Block, counter va wallet lock ham kerak.\n• Uxlab yotganingizda hech kim sizni uyg'otmaydi — uxlashdan oldin himoyani yoqing.`},
{t:"7. Himoya buyruqlari",b:`$ ufw enable
→ (sudo bilan) Firewall yoqadi: skanerlash va SSH hujumlarini to'xtatadi. ufw status — holat, ufw deny from <ip> — IP bloklash.
$ passwd
→ Kuchli parol o'rnatadi (kamida 8 belgi, harf+raqam). Parolni yozib qo'ying! SSH brute-force endi o'tmaydi.
$ apt upgrade
→ (sudo bilan) Zaifliklarni yamaydi: web va ransomware hujumlariga qarshi.
$ systemctl stop ssh
→ (sudo bilan) Xizmatni o'chiradi. Ishlatilmayotgan xizmatni yopish — eng oddiy himoya (apache2 ham shunday).
$ backup
→ Documents zaxira nusxasini ~/Backups ga saqlaydi.
$ restore
→ Oxirgi zaxirani qaytaradi (ransomware'dan keyin kerak).
$ ids
→ Hujumlar ro'yxati. ids block <ip> — shu IP ni bloklaydi, ids trace <ip> — hujumchini aniqlaydi.
Tartib (hujumdan OLDIN): sudo ufw enable → passwd → sudo apt upgrade → backup → wallet lock all`},
{t:"8. Hamyon va o'g'rilik",b:`Kompyuterda ballaringiz (pul) turadi. Botlar (boshqa o'yinchilar rolida) buzib kirsa, OCHIQ ballni o'g'irlaydi.
$ wallet
→ Ochiq ball va seyfdagi ballni ko'rsatadi.
$ wallet lock 200
→ 200 ballni seyfga qulflaydi (shifrlangan): bot o'g'irlay olmaydi. wallet lock all — hammasini.
$ wallet unlock 100
→ Seyfdan qaytaradi. Qulflangandan keyin 60 soniya kutish kerak.
Maslahat: ball kerak bo'lmasa seyfda saqlang. Ball o'z-o'zidan ko'paymaydi: faqat counter-hujumda C2 dan o'g'irlab (steal) topiladi.
O'g'irlangan ballni qaytarish: 9-sahifadagi qarshi hujum (ssh ... "recover").`},
{t:"9. Qarshi hujum (kuniga 4 marta)",b:`Hujumchini (C2) istalgan vaqtda — hujum paytida ham, u offline bo'lganda ham — aniqlab, unga hujum qilishingiz mumkin: vaqt oynasi yo'q, izi yo'qolmaydi. Limit: kuniga 4 ta hujum (steal / recover / pkill har biri 1 ta; 1 o'yin kuni = 1 real soat). JONLI BONUS: hujum davom etayotganda (yoki himoya qilingan zahoti, 60 soniya ichida) hujumchini aniqlab (ids trace), hydra bilan kirib, steal / recover / pkill qilsangiz — har hujum uchun qo'shimcha +30 ball. Qoldiq: Attack Monitor'da "Hujum qilish: n/4".
$ ids trace <ip>
→ Hujumdagi IP — bot. Trace asl boshqaruvchi (C2) ni topadi (~8 soniya). Hujum paytida ham qilish mumkin.
$ nmap <c2>
→ C2 ning ochiq portlari (22 ssh, 8080 panel).
$ hydra -l admin -P Wordlists/common.txt ssh://<c2>
→ Admin parolini topadi (ro'yxatda 'letmein' bor).
$ ssh admin@<c2> "cat wallet.dat"
→ Sizdan o'g'irlangan ball miqdorini ko'rsatadi.
$ ssh admin@<c2> "steal"
→ C2 g'aznasidan 40% ni hamyoningizga o'g'irlaydi (g'azna asta-sekin to'lib turadi). Ball shu yerdan keladi!
$ ssh admin@<c2> "recover"
→ O'g'irlangan ballni hamyoningizga qaytaradi va qo'shimcha +20 ball beradi (C2 offline bo'lsa ham).
$ ssh admin@<c2> "pkill botnetd"
→ Botnetni 4 daqiqaga o'chiradi, faol hujumlar to'xtaydi. DIQQAT: avval steal qiling — o'chirilgan C2 dan ball olib bo'lmaydi.`},
{t:"10. Loglar va xatolar",b:`$ sudo tail /var/log/auth.log
→ Kirish urinishlari. ko'p 'Failed password' = brute-force; 'Accepted password' = kirib olishdi!
$ sudo cat /var/log/ids.log
→ IDS hodisalari: hujum boshi, buzilish, o'g'irlangan ball (THEFT).
Tez-tez xatolar:
  - Attack Monitor ni ochmasdan ishlash: hujumni ko'rmay qolasiz
  - passwd bergan parolni yozib qo'ymaslik
  - ballni ochiq qoldirish (wallet lock!)
  - zaxirasiz ransomware'ga duch kelish
Haqiqiy hayotda bu usullar faqat o'z tizimingizda yoki yozma ruxsat bilan ishlatiladi.`}];

let noteOpen=false,notePg=0;

/* ==========================================================
 * Modul: js/player/touch-controls.js
 * Mobil joystick va qarash boshqaruvi
 * ========================================================== */
/* ---------- kiritish ---------- */
addEventListener("keydown",e=>{if(noteOpen){if(e.code==="Escape"||e.code==="KeyE")closeNote();else if(e.code==="ArrowRight"||e.code==="KeyD")noteGo(1);else if(e.code==="ArrowLeft"||e.code==="KeyA")noteGo(-1);e.preventDefault();return}if(e.code==="KeyF"&&!seated){fs();return}if(LF.sleeping){if(e.code==="KeyE"||e.code==="Escape")wake();return}if(e.code==="KeyQ"&&!seated){drink();return}if(seated){if(e.code==="Escape")stand();return}
 if(["Space","ArrowUp","ArrowDown"].includes(e.code))e.preventDefault();if(e.code==="KeyE")interact();keysDown[e.code]=true});
addEventListener("keyup",e=>keysDown[e.code]=false);
document.addEventListener("mousemove",e=>{if(document.pointerLockElement!==cvEl||seated||LF.sleeping||noteOpen)return;P.yaw-=e.movementX*.002;P.pitch=Math.max(-1.2,Math.min(1.2,P.pitch-e.movementY*.002))});
const stick=$("stick"),knob=$("knob");let sid=null;
function sm(e){const r=stick.getBoundingClientRect();let dx=e.clientX-(r.left+60),dy=e.clientY-(r.top+60);const l=Math.hypot(dx,dy);if(l>42){dx=dx/l*42;dy=dy/l*42}joy.x=dx/42;joy.y=dy/42;knob.style.transform="translate("+dx+"px,"+dy+"px)"}
function rs(){sid=null;joy.x=joy.y=0;knob.style.transform=""}
const sz=$("sz");function rs2(){rs();stick.style.left=stick.style.top=stick.style.bottom="";stick.style.opacity=""}
sz.onpointerdown=e=>{if(sid!==null)return;sid=e.pointerId;sz.setPointerCapture(sid);stick.style.left=Math.max(4,Math.min(innerWidth-124,e.clientX-60))+"px";stick.style.top=Math.max(4,Math.min(innerHeight-124,e.clientY-60))+"px";stick.style.bottom="auto";stick.style.opacity="1";sm(e)};sz.onpointermove=e=>{if(e.pointerId===sid)sm(e)};sz.onpointerup=sz.onpointercancel=e=>{if(e.pointerId===sid)rs2()};
const lk=$("look");let lid=null,lx=0,ly=0;
lk.onpointerdown=e=>{if(seated)return;lid=e.pointerId;lx=e.clientX;ly=e.clientY;lk.setPointerCapture(lid)};
lk.onpointermove=e=>{if(e.pointerId!==lid)return;P.yaw-=(e.clientX-lx)*.004;P.pitch=Math.max(-1.2,Math.min(1.2,P.pitch-(e.clientY-ly)*.004));lx=e.clientX;ly=e.clientY};
lk.onpointerup=lk.onpointercancel=()=>lid=null;
$("mE").onclick=interact;
async function fs(){try{document.fullscreenElement?await document.exitFullscreen():await document.documentElement.requestFullscreen()}catch(e){toast("Brauzer to’liq ekranni qo’llamadi")}}
$("full").onclick=fs;
$("enter").onclick=()=>{$("start").style.display="none";started=true;try{navigator.wakeLock&&navigator.wakeLock.request("screen").catch(()=>{})}catch(e){}if(mobile){try{document.documentElement.requestFullscreen().then(()=>screen.orientation.lock("landscape")).catch(()=>{})}catch(e){}}if(!mobile)cvEl.requestPointerLock&&cvEl.requestPointerLock()};
addEventListener("resize",()=>{if(mobile&&kbOpen)return;baseW=innerWidth;baseH=innerHeight;camera.aspect=baseW/baseH;camera.updateProjectionMatrix();renderer.setSize(baseW,baseH);lastFov=-1});

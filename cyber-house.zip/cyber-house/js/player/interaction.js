/* ==========================================================
 * Modul: js/player/interaction.js
 * O'zaro ta'sir: o'tirish, turish, E tugmasi, ko'rsatmalar
 * ========================================================== */
/* ---------- o’zaro ta’sir ---------- */
const dist=(x,z)=>Math.hypot(P.x-x,P.z-z),nearOut=()=>dist(5.4,-2.2)<1.4,nearPc=()=>dist(1,-2.8)<1.4,nearDesk=()=>dist(0,-2.2)<1.7;
function toast(t){const e=$("toast");e.textContent=t;e.style.display="block";clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.display="none",1600)}
function sit(){seated=true;document.body.classList.add("sit");document.exitPointerLock&&document.exitPointerLock();$("standBtn").style.display="block";$("kbBtn").style.display="block";$("mobile").style.visibility="hidden";$("cross").style.display="none";cvEl.style.cursor="none";syncInput()}
function stand(){if(!seated)return;seated=false;document.body.classList.remove("sit");P.x=0;P.z=-1.2;P.vx=P.vz=0;P.yaw=0;P.pitch=-.12;ta.blur();drag=null;$("standBtn").style.display="none";$("kbBtn").style.display="none";$("mobile").style.visibility="";$("cross").style.display="block";cvEl.style.cursor=""}
$("standBtn").onclick=()=>LF.sleeping?wake():stand();
let kbOpen=false;
function setKb(v){kbOpen=v;{const b=$("kbBtn").style;b.top=v?"calc(56px + env(safe-area-inset-top,0px))":"";b.bottom=v?"auto":"";b.left=v?"auto":"";b.right=v?"12px":""}$("kbBtn").textContent=v?"⌨ Yopish":"⌨ Klaviatura";if(mobile){if(v)camera.setViewOffset(baseW,baseH,0,baseH*.22,baseW,baseH);else camera.clearViewOffset()}}
ta.addEventListener("focus",()=>setKb(true));ta.addEventListener("blur",()=>setKb(false));
let kbBlurT=0;ta.addEventListener("blur",()=>{kbBlurT=performance.now()});
function toggleKb(){if(kbOpen||document.activeElement===ta||performance.now()-kbBlurT<350){ta.blur();return}
 if(S.stage===3){const w=wins.filter(q=>(q.id==="terminal"||q.id==="editor"||q.id==="ide")&&!q.min).pop();if(w)front(w);else openApp("terminal")}
 ta.focus({preventScroll:true})}
$("kbBtn").onclick=toggleKb;
function power(){if(!S.on){S.on=true;S.stage=1;S.boot=performance.now();termIn="";ta.value="";toast("Kompyuter yoqildi")}else if(S.stage===4){}else if(S.stage===1){S.on=false;S.stage=0}else{S.stage=4;S.boot=performance.now();toast("O'chirilmoqda...")}dirty=true}
function target(){const h=S.hold,np=near(pcc,1.5)&&!BN.pcAway;if(LF.sleeping)return["E — uyg'onish",wake];
 if(KT.eat)return["🍽 Yeyapsiz…",null];
 {const bt=benchTarget();if(bt)return bt}
 {const kt=kitchenTarget();if(kt)return kt}
 if(h==="usb"||h==="hp"){const it=IT[h];
  if(h==="usb"&&np){const i=bestPort();if(i>=0&&i!==S.usb)return["E — "+(i+1)+"-portga ulash",()=>{S.usb=i;S.hold=null;toast((i+1)+"-portga ulandi");dirty=true}]}
  if(S.dp>.5&&pick(drI(),.24,1.55))return["E — tortmaga solish",()=>{const sl=[0,1].find(i=>!Object.values(IT).some(o=>o.d===i));if(sl===undefined){toast("Tortma to'la");return}it.d=sl;S.hold=null;toast("Tortmaga solindi")}];
  return["E — tashlash",()=>{S.hold=null;it.P.copy(hand);camera.getWorldDirection(it.V).multiplyScalar(1.2);toast("Tashlandi")}]}
 if(h){const d=DV[h];
  if(nearSock(d))return["E — rozetkaga ulash",()=>{S.hold=null;S[d.s]=true;dirty=true;toast("Vilka ulandi")}];
  if(pick(d.rest,.28,1.5))return["E — vilkani joyiga qo'yish",()=>{S.hold=null;toast("Joyiga qo'yildi")}];return[aim(d.out)<.6?"Vilkani ulash uchun rozetka oldiga boring":"Vilkani rozetkaga qarab oling",null]}
 if(LF.cup>0){const dp=deskPoint();if(dp&&dist(dp.x,dp.z)<1.7)return["E — stakanni stolga qo'yish",()=>putCup(dp)];if(LF.cup!==2&&pick(DISP,.3,1.5))return["E — stakanga suv quyish",pourCup];if(LF.cup===2)return["E (yoki Q) — suvni ichish",drink];return["Qo'lingiz band — avval stakanni stolga qo'ying",null]}
 if(S.usb>=0&&np&&pick(portW(S.usb),.09,1.5))return["E — USB ni sug'urish",()=>{S.usb=-1;S.hold="usb";toast("USB sug'urildi");dirty=true}];
 for(const k in IT){const it=IT[k];if(k==="usb"&&S.usb>=0)continue;if(it.d>=0&&S.dp<.5)continue;const g=it.g.position;if(pick(g,.12,1.55))return["E — "+(k==="usb"?"flesh-xotirani":"quloqchinni")+" olish",()=>{it.d=-1;S.hold=k;toast("Olindi")}]}
 if(S.dp>.5&&pick(nbW(),.15,1.55))return["E — blaknotni o'qish",openNote];
  if(pick(drF(),.18,1.55))return["E — tortmani "+(S.dr?"yopish":"ochish"),()=>{S.dr=S.dr?0:1}];
 for(const k in DV){const d=DV[k],q=d.pl.position;
  if(S[d.s]&&nearSock(d))return["E — vilkani sug'urish",()=>{S[d.s]=false;S.hold=k;if(k==="pc"&&S.on){S.on=false;S.stage=0}dirty=true;toast("Vilka sug'urildi")}];
  if(!S[d.s]&&pick(q,.15,1.55))return["E — "+(k==="pc"?"kompyuter":"monitor")+" vilkasini olish",()=>{S.hold=k;toast("Vilkani rozetkaga olib boring")}]}
 if(np&&pick(pbW(),.09,1.5))return["E — "+(S.on?"o'chirish":"yoqish")+" (power)",()=>{if(!S.plug)toast("Kompyuterga vilka ulanmagan");else power()}];
 if(LF.dcup&&!LF.cup&&pick(dcW(),.12,1.55))return["E — stakanni olish",pickCup];
  if(LF.cup>0){const dp=deskPoint();if(dp&&dist(dp.x,dp.z)<1.7)return["E — stakanni stolga qo'yish",()=>putCup(dp)]}
  if(LF.cup!==2&&pick(DISP,.3,1.5))return["E — stakanga suv quyish",pourCup];
  if(pick(BEDP,.35,1.7))return["E — karavotga yotib uxlash",startSleep];
  if(pick(chW,.38,1.55))return["E — stulga o'tirish",sit];
 if(LF.cup===2)return["E (yoki Q) — suvni ichish",drink];{const mp=mainPcTarget();if(mp)return mp}if(!BN.pcAway){const pt=partAt();if(pt)return["🔎 "+pt,null]}return["",null]}
const nearSock=d=>pick(d.out,.2,1.5);
function interact(){if(noteOpen){closeNote();return}if(seated)return;if(LF.sleeping){wake();return}const t=target();if(t[1]){t[1]();feel(t[0])}}
function hintText(){if(seated){hintText.act=false;return""}pick.far=false;const t=target();hintText.act=!!t[1];return t[0]||(pick.far?"↔ Yaqinroq keling":"")}
function feel(t){try{if(navigator.vibrate)navigator.vibrate(/eshik|shkaf|tortma|muzlatkich|kran/.test(t)?22:10);if(SET.mute)return;AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain(),door=/eshik|shkaf|tortma|muzlatkich/.test(t),n=AC.currentTime;o.type=door?"triangle":"sine";o.frequency.setValueAtTime(door?150:560,n);if(door)o.frequency.exponentialRampToValueAtTime(70,n+.14);g.gain.setValueAtTime(SET.vol/100*(door?.16:.07),n);g.gain.exponentialRampToValueAtTime(.0001,n+(door?.16:.07));o.connect(g);g.connect(AC.destination);o.start(n);o.stop(n+.17)}catch(e){}}
let lastHint="";

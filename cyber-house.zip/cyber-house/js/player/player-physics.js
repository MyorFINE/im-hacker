/* ==========================================================
 * Modul: js/player/player-physics.js
 * O'yinchi harakati, to'qnashuv va kamera
 * ========================================================== */
/* ---------- o’yinchi va fizika ---------- */
const P={x:0,z:4.6,vx:0,vz:0,yaw:0,pitch:0,bob:0,r:.28};
const keysDown={};let started=false,joy={x:0,y:0};
function collide(){
 for(const o of cols){const cx=Math.max(o.x-o.hw,Math.min(o.x+o.hw,P.x)),cz=Math.max(o.z-o.hd,Math.min(o.z+o.hd,P.z)),dx=P.x-cx,dz=P.z-cz,d=Math.hypot(dx,dz);
  if(d<P.r){if(d>1e-4){const nx=dx/d,nz=dz/d;P.x=cx+nx*P.r;P.z=cz+nz*P.r;const vn=P.vx*nx+P.vz*nz;if(vn<0){P.vx-=vn*nx;P.vz-=vn*nz}}else{P.z+=P.r}}}
 const lim=(a,m)=>Math.max(-m,Math.min(m,a));const ox=P.x,oz=P.z;kBounds(lim);if(P.x!==ox)P.vx=0;if(P.z!==oz)P.vz=0;
 const dv=DV[S.hold];if(dv){const dx=P.x-dv.A.x,dz=P.z-dv.A.z,d=Math.hypot(dx,dz);if(d>dv.len){P.x=dv.A.x+dx/d*dv.len;P.z=dv.A.z+dz/d*dv.len;P.vx*=.2;P.vz*=.2;if(!collide.w){toast("Kabel uzunligi tugadi");collide.w=1;setTimeout(()=>collide.w=0,1200)}}}}
function updatePlayer(dt){
 if(seated||LF.sleeping||noteOpen||KT.eat)return;let f=0,s=0;if(keysDown.KeyW||keysDown.ArrowUp)f++;if(keysDown.KeyS||keysDown.ArrowDown)f--;if(keysDown.KeyD||keysDown.ArrowRight)s++;if(keysDown.KeyA||keysDown.ArrowLeft)s--;
 f-=joy.y;s+=joy.x;const l=Math.hypot(f,s);if(l>1){f/=l;s/=l}
 const sp=3.3*(keysDown.ShiftLeft?1.5:1)*(LF.thirst>=100?.55:1)*(LF.hunger>=100?.6:1)*(LF.tired>=90?.75:1),fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),rx=Math.cos(P.yaw),rz=-Math.sin(P.yaw);
 const tx_=(fx*f+rx*s)*sp,tz=(fz*f+rz*s)*sp,k=Math.min(1,dt*(l>0?9:7));P.vx+=(tx_-P.vx)*k;P.vz+=(tz-P.vz)*k;
 const n=Math.max(1,Math.ceil(Math.hypot(P.vx,P.vz)*dt/.1));for(let i=0;i<n;i++){P.x+=P.vx*dt/n;P.z+=P.vz*dt/n;collide()}
 P.bob+=Math.hypot(P.vx,P.vz)*dt*2.6}
const qa=new T.Quaternion(),eul=new T.Euler(0,0,0,"YXZ"),seatPos=new T.Vector3(0,1.38,-2.8),dmy=new T.PerspectiveCamera();
dmy.position.copy(seatPos);dmy.lookAt(0,1.3,-3.78);const seatQ=dmy.quaternion.clone();let lastFov=72,zoomT=0;
function updateCam(dt){sleepT+=((LF.sleeping?1:0)-sleepT)*Math.min(1,dt*2.2);if(Math.abs(sleepT-(LF.sleeping?1:0))<.003)sleepT=LF.sleeping?1:0;
 const tg=seated?1:0;seatT+=(tg-seatT)*Math.min(1,dt*4.5);const typing=false&&seated&&(focusId==="terminal"||focusId==="editor"||focusId==="ide")&&wins.some(w=>w.id===focusId&&!w.min);zoomT+=((typing?1:0)-zoomT)*Math.min(1,dt*4);seatPos.z=-2.8-.28*zoomT;{const gt=GZ.T[GZ.m],kk=Math.min(1,dt*5);GZ.cx+=(gt[0]-GZ.cx)*kk;GZ.lx+=(gt[1]-GZ.lx)*kk;GZ.hw+=(gt[2]-GZ.hw)*kk;seatPos.x=GZ.cx;dmy.position.copy(seatPos);dmy.lookAt(GZ.lx,1.3,-3.78);seatQ.copy(dmy.quaternion)}if(typeof LAPX!=="undefined"&&LAPX.on){seatPos.copy(LAPX.camPos);dmy.position.copy(seatPos);dmy.lookAt(LAPX.look);seatQ.copy(dmy.quaternion)}if(Math.abs(seatT-tg)<.003)seatT=tg;
 const sp=seatT*seatT*(3-2*seatT),spd=Math.hypot(P.vx,P.vz);
 eul.set(P.pitch,P.yaw,Math.sin(P.bob*.5)*.0025*Math.min(1,spd));qa.setFromEuler(eul);
 camera.position.set(P.x,1.68+Math.sin(P.bob)*.02*Math.min(1,spd/3),P.z).lerp(seatPos,sp);
 camera.quaternion.copy(qa).slerp(seatQ,sp);if(sleepT>.001){const s2=sleepT*sleepT*(3-2*sleepT);camera.position.lerp(bedPos,s2);camera.quaternion.slerp(bedQ,s2)}if(eatT>.001){const s3=eatT*eatT*(3-2*eatT);camera.position.lerp(eatPos,s3);camera.quaternion.slerp(eatQ,s3)}
 if(seatT===1){camera.position.x+=(cur.x/vwNow()-.5)*.05;camera.position.y+=Math.sin(performance.now()/1900)*.003}
 const asp=baseW/baseH,dd=Math.hypot(GZ.lx-seatPos.x,3.78+seatPos.z),sf=Math.min(100,Math.max(14,Math.max(2*Math.atan((GZ.hw-.08*zoomT)/(dd*asp)),2*Math.atan((.292-.045*zoomT)/dd))*180/Math.PI)),fov=(72+((typeof LAPX!=="undefined"&&LAPX.on?LAPX.fov:sf)-72)*sp)*(1-.3*(window.BNZ||0));
 if(Math.abs(fov-lastFov)>.05){camera.fov=lastFov=fov;camera.updateProjectionMatrix()}}

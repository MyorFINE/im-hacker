/* ==========================================================
 * Modul: js/world/grass.js
 * Qurilish zonasi uchun tabiiy o't (balandligi ~10 sm):
 *  - har bir "tup" 4 ta ingichka, uchi o'tkir, egilgan barg (3 segment) — silliq, qirrasiz ko'rinish;
 *  - rang: asosi to'q, uchi yorqin, har bir bargda tasodifiy sarg'ish/yashil farq, ba'zi qurigan barglar;
 *  - FIZIKA: shamol (ko'p chastotali to'lqin, uchi ko'proq tebranadi) + o'yinchi bosib yurgan joyda o'tlar
 *    egiladi/yotadi va ~2 soniyada silliq qaytib turadi (so'nuvchi iz);
 *  - samaradorlik: 5x5 m bo'laklar, masofaga qarab 2 daraja (yaqin: zich/ingichka, o'rta: siyrak/keng), uzoqda o'chadi;
 *  - bino, pallet, plita, iskala, xandaq, darvoza kabi joylarda o't o'smaydi (buyumlar ichidan chiqib ketmaydi).
 * Hamma hisob GPU da (vertex shader) — JS har kadrda faqat 12 ta "iz" nuqtasini yangilaydi.
 * ========================================================== */
const GRASS=(()=>{
  const CH=5,X0=-20,X1=20,Z0=-16,Z1=16.3,TRN=12;
  const inEx=TERRAIN.blockedGrass;
  const rng=s=>()=>{s=(s*16807)%2147483647;return(s-1)/2147483646};

  /* ---------- bitta o'tlar tupi (n ta barg) ---------- */
  function tuft(n,seg,wm,seed){
    const f=rng(seed),pos=[],nor=[],at=[],ab=[],idx=[];
    for(let b=0;b<n;b++){
      const a=f()*6.2832,r=Math.sqrt(f())*.035,rx=Math.cos(a)*r,rz=Math.sin(a)*r,phi=f()*6.2832,th=f()*6.2832,h=.10*(.78+f()*.44),L=.025+f()*.045,w0=.0058*wm*(.8+f()*.4),rnd=f();
      const sx=Math.cos(phi),sz=Math.sin(phi),nx=-Math.sin(phi),nz=Math.cos(phi),base=pos.length/3;
      for(let j=0;j<=seg;j++){const t=j/seg,cx=rx+Math.cos(th)*L*t*t,cz=rz+Math.sin(th)*L*t*t,y=h*t,hw=w0*(1-Math.pow(t,1.6))*.5;
        pos.push(cx-sx*hw,y,cz-sz*hw,cx+sx*hw,y,cz+sz*hw);for(let k=0;k<2;k++){nor.push(nx,.35,nz);at.push(t);ab.push(rnd)}}
      for(let j=0;j<seg;j++){const o=base+j*2;idx.push(o,o+1,o+2,o+1,o+3,o+2)}}
    return{pos:new Float32Array(pos),nor:new Float32Array(nor),at:new Float32Array(at),ab:new Float32Array(ab),idx:new Uint16Array(idx)}}
  /* ---------- material (Lambert + shader o'zgartirish: yorug'lik va tuman asl holicha ishlaydi) ---------- */
  const U={uTime:{value:0},uTrail:{value:Array.from({length:TRN},()=>new T.Vector3(1e5,1e5,0))}};
  const mat=new T.MeshLambertMaterial({color:0xffffff,side:T.DoubleSide});
  mat.onBeforeCompile=sh=>{
    sh.uniforms.uTime=U.uTime;sh.uniforms.uTrail=U.uTrail;
    sh.vertexShader="attribute vec4 iA;attribute float iB;attribute float iH;attribute float aT;attribute float aB;uniform float uTime;uniform vec3 uTrail["+TRN+"];varying vec3 vGrassCol;\n"+sh.vertexShader
     .replace("#include <beginnormal_vertex>",
      "float gy=iA.z,gc=cos(gy),gs=sin(gy);\n vec3 objectNormal=normalize(vec3(gc*normal.x-gs*normal.z,normal.y*2.2,gs*normal.x+gc*normal.z));")
     .replace("#include <begin_vertex>",
      "vec3 gp=position;gp.y*=iA.w;gp.xz=vec2(gc*gp.x-gs*gp.z,gs*gp.x+gc*gp.z);\n"+
      "vec2 gb=iA.xy;float gh=aT*aT;\n"+
      "float wv=sin(uTime*1.15+gb.x*.42+gb.y*.27)*.5+sin(uTime*2.3+gb.x*.83-gb.y*.61)*.3+.2;\n"+
      "vec2 wind=vec2(.9,.4)*wv*.032+vec2(sin(uTime*3.3+gb.y*3.1+aT*2.0),cos(uTime*2.9+gb.x*2.7+aT*2.0))*.0035;\n"+
      "gp.xz+=wind*gh*iA.w;\n"+
      "float gf=0.0;for(int i=0;i<"+TRN+";i++){vec3 tr=uTrail[i];vec2 d=gb+gp.xz-tr.xy;float r=length(d)+0.001;float f=tr.z*smoothstep(.62,.04,r);gp.xz+=d/r*f*.09*gh;gf=max(gf,f*gh);}\n"+
      "gp.y*=1.0-gf*.6;\n"+
      "vec3 transformed=vec3(gb.x+gp.x,gp.y+iH,gb.y+gp.z);\n"+
      "float gk=fract(iB*7.31+aB*3.17);vec3 gtip=mix(vec3(.20,.44,.09),vec3(.46,.58,.16),gk);if(gk>.93)gtip=vec3(.56,.50,.24);\n"+
      "vGrassCol=mix(vec3(.05,.12,.03),gtip,smoothstep(0.0,1.0,aT))*(.88+.24*iB);");
    sh.fragmentShader="varying vec3 vGrassCol;\n"+sh.fragmentShader.replace("#include <color_fragment>","diffuseColor.rgb*=vGrassCol;")};
  /* ---------- bo'laklar ---------- */
  const chunks=[];let _built=false,hiR=0,midR=0;
  function mk(g,n,pts,cx,cz){
    const geo=new T.InstancedBufferGeometry();
    geo.setAttribute("position",new T.BufferAttribute(g.pos,3));geo.setAttribute("normal",new T.BufferAttribute(g.nor,3));geo.setAttribute("aT",new T.BufferAttribute(g.at,1));geo.setAttribute("aB",new T.BufferAttribute(g.ab,1));geo.setIndex(new T.BufferAttribute(g.idx,1));
    geo.setAttribute("iA",new T.InstancedBufferAttribute(pts.a,4));geo.setAttribute("iB",new T.InstancedBufferAttribute(pts.b,1));geo.setAttribute("iH",new T.InstancedBufferAttribute(pts.h,1));geo.instanceCount=n;
    geo.boundingSphere=new T.Sphere(new T.Vector3(cx,.05,cz),CH*.72+.3);geo.boundingBox=null;
    const m=new T.Mesh(geo,mat);return m}
  function scatter(x0,z0,dens,f){
    const cell=1/Math.sqrt(dens),a=[],b=[],h=[];
    for(let x=x0;x<x0+CH;x+=cell)for(let z=z0;z<z0+CH;z+=cell){const px=x+f()*cell,pz=z+f()*cell;const yaw=f()*6.2832,sc=.82+f()*.4,tint=f(),keep=f();if(px<X0+.2||px>X1-.2||pz<Z0+.2||pz>Z1-.2||keep>TERRAIN.grassP(px,pz)||inEx(px,pz))continue;a.push(px,pz,yaw,sc);b.push(tint);h.push(TERRAIN.heightAt(px,pz))}
    return{a:new Float32Array(a),b:new Float32Array(b),h:new Float32Array(h),n:b.length}}
  function addTo(parent){
    if(_built)return;_built=true;const dh=lowEnd?20:48,dm=lowEnd?8:16;hiR=lowEnd?8:10;midR=lowEnd?17:25;
    const gH=tuft(5,3,1,11),gM=tuft(4,2,1.7,23);
    for(let cx=X0;cx<X1;cx+=CH)for(let cz=Z0;cz<Z1;cz+=CH){
      const f=rng(Math.floor((cx+50)*131+(cz+50)*7919)+5),ph=scatter(cx,cz,dh,f),pm=scatter(cx,cz,dm,f);if(!ph.n)continue;
      const hi=mk(gH,ph.n,{a:ph.a,b:ph.b,h:ph.h},cx+CH/2,cz+CH/2),mi=mk(gM,pm.n,{a:pm.a,b:pm.b,h:pm.h},cx+CH/2,cz+CH/2);
      hi.visible=false;mi.visible=false;parent.add(hi);parent.add(mi);chunks.push({x:cx+CH/2,z:cz+CH/2,hi,mi})}
    return chunks.length}
  /* ---------- fizika: so'nuvchi iz (0-uyacha — o'yinchining hozirgi joyi) ---------- */
  const st=Array.from({length:TRN},()=>({x:1e5,z:1e5,s:0}));let head=1,lx=1e5,lz=1e5;
  const ease=s=>s*s*(3-2*s);
  function update(dt,now){
    dt=Math.min(dt||.016,.05);U.uTime.value=now/1000;
    const px=P.x-BX,pz=P.z-BZ;
    st[0].x=px;st[0].z=pz;st[0].s=1;
    if(Math.hypot(px-lx,pz-lz)>.3){lx=px;lz=pz;const q=st[head];q.x=px;q.z=pz;q.s=1;head=head%(TRN-1)+1}
    for(let i=1;i<TRN;i++){const q=st[i];if(q.s>0)q.s=Math.max(0,q.s-dt*.5)}
    for(let i=0;i<TRN;i++){const q=st[i],u=U.uTrail.value[i];u.set(q.x,q.z,ease(q.s)*(i?.85:1))}
    for(let i=0;i<chunks.length;i++){const c=chunks[i],d=Math.hypot(c.x-px,c.z-pz)-CH*.7;c.hi.visible=d<hiR;c.mi.visible=d>=hiR-1&&d<midR}}
  return{addTo,update,inEx,tuft,chunks}
})();

/* ==========================================================
 * Modul: js/world/laptop-model.js
 * Laptop (Alienware/Predator uslubidagi GLB modeli) — o'yin sahnasi uchun yig'ish:
 *  - butun geometriya saqlangan (45 ming uchburchak), qopqoq alohida guruh: ochiladi / yopiladi;
 *  - PBR materiallar (metall, shisha, matoli alyuminiy, shamollatish teshiklari normal xaritasi), klaviatura yoritilishi (emissive);
 *  - metall qismlar qorayib ketmasligi uchun kichik sintetik yorug'lik muhiti (PMREM) — faqat shu model materiallariga;
 *  - ekran: PC monitori bilan BIR XIL tekstura (scrTex) — monitorda ko'ringan narsa laptopda ham ko'rinadi.
 * Model o'qlari: boshi — taglik markazi (pol/stol sathida), oldi = +z, yuqori = +y. Haqiqiy o'lcham ~0.39 x 0.26 m.
 * ========================================================== */
const LAP_PORT=[-.12,.012,-.13];      /* quvvat uyasi: orqa devorning chap tomoni (kabel GEAR orqali shu yerga ulanadi) */
const LAPTOP=(()=>{
  const D=LAPTOP_DATA,Q=D.range/32767,PIV=D.pivot,SCR=D.screen,OPEN=-.32,CLOSED=Math.PI/2;
  let R=null;
  const dec=(b,Ty)=>{const s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return new Ty(u.buffer)};
  function geo(m){
    const g=new T.BufferGeometry(),p16=dec(m.p,Int16Array),p=new Float32Array(p16.length);for(let i=0;i<p16.length;i++)p[i]=p16[i]*Q;
    const uq=dec(m.uv,Uint16Array),uv=new Float32Array(uq.length);for(let i=0;i<uq.length;i++){const k=i&1;uv[i]=m.umin[k]+uq[i]/65535*m.urng[k]}
    g.setAttribute("position",new T.BufferAttribute(p,3));g.setAttribute("normal",new T.BufferAttribute(dec(m.nr,Int8Array),3,true));g.setAttribute("uv",new T.BufferAttribute(uv,2));
    g.setIndex(new T.BufferAttribute(dec(m.i,Uint16Array),1));g.computeBoundingSphere();return g}
  /* kichik "xona" muhiti: tepada yorug' panellar, pastda qorong'i pol — metall va shisha jonli aks ettirsin */
  function makeEnv(){
    try{const sc=new T.Scene(),sg=new T.SphereGeometry(10,32,16),pp=sg.attributes.position,cl=new Float32Array(pp.count*3);
      for(let i=0;i<pp.count;i++){const t=(pp.getY(i)/10+1)/2,k=.05+.55*Math.pow(t,.8);cl[i*3]=k;cl[i*3+1]=k*1.02;cl[i*3+2]=k*1.08}
      sg.setAttribute("color",new T.BufferAttribute(cl,3));sc.add(new T.Mesh(sg,new T.MeshBasicMaterial({vertexColors:true,side:T.BackSide})));
      const panel=(w,h,x,y,z,ry,rx,k)=>{const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({color:new T.Color(k,k,k*.96),side:T.DoubleSide}));m.position.set(x,y,z);m.rotation.set(rx,ry,0);sc.add(m)};
      panel(6,3,0,9,0,0,Math.PI/2,5);panel(2.2,5,-8,3,2,Math.PI/2,0,3.2);panel(2.2,5,8,3,-2,Math.PI/2,0,2.4);panel(5,2.5,0,2.5,-9,0,0,1.8);
      const pm=new T.PMREMGenerator(renderer),rt=pm.fromScene(sc,.03);pm.dispose();return rt.texture}catch(e){console.warn("[laptop] env",e);return null}}
  function ldTex(url,srgb){const t=new T.TextureLoader().load(url);t.flipY=false;t.encoding=srgb?T.sRGBEncoding:T.LinearEncoding;t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=lowEnd?2:8;return t}
  function res(){
    if(R)return R;const env=makeEnv(),tx={emi:ldTex(D.tex.emi,true),b1:ldTex(D.tex.base1,true),m1:ldTex(D.tex.mr1,false),n1:ldTex(D.tex.nrm1,false),b2:ldTex(D.tex.base2,true),m2:ldTex(D.tex.mr2,false)};
    const mats=D.mats.map((m,i)=>{
      const o={color:new T.Color(m.base[0],m.base[1],m.base[2]),metalness:m.met==null?0:m.met,roughness:m.rough==null?1:m.rough,side:T.DoubleSide,envMap:env,envMapIntensity:.95};
      if(i===1)o.roughness=.62;
      if(i===4){o.map=tx.b1;o.metalnessMap=tx.m1;o.roughnessMap=tx.m1;o.metalness=1;o.roughness=1;o.normalMap=tx.n1;o.normalScale=new T.Vector2(.8,.8);o.color=new T.Color(1,1,1)}
      if(i===7){o.map=tx.b2;o.metalnessMap=tx.m2;o.roughnessMap=tx.m2;o.metalness=1;o.roughness=1;o.color=new T.Color(1,1,1)}
      if(i===0)o.color=new T.Color(1,1,1);
      if(i===2){o.color=new T.Color(0,0,0);o.metalness=0;o.roughness=.7;o.emissive=new T.Color(1,1,1);o.emissiveMap=tx.emi;o.emissiveIntensity=0}   /* tugma yozuvlari: faqat yoqilganda yonadi */
      return new T.MeshStandardMaterial(o)});
    const glassOff=new T.MeshStandardMaterial({color:0x030405,roughness:.06,metalness:0,envMap:env,envMapIntensity:1.1}),glassOn=new T.MeshBasicMaterial({map:scrTex});
    R={env,mats,glassOff,glassOn,gb:D.base.map(geo),gl:D.lid.map(geo),qg:new T.PlaneGeometry(SCR.x1-SCR.x0,SCR.y1-SCR.y0)};return R}
  /* ---------- nusxa yaratish ---------- */
  function build(opt){
    const r=res(),g=new T.Group(),lid=new T.Group(),emi=r.mats[2].clone();
    D.base.forEach((m,i)=>{const o=new T.Mesh(r.gb[i],m.mat===2?emi:r.mats[m.mat]);g.add(o)});
    lid.position.set(PIV[0],PIV[1],PIV[2]);
    D.lid.forEach((m,i)=>{lid.add(new T.Mesh(r.gl[i],r.mats[m.mat]))});
    const sc=new T.Mesh(r.qg,r.glassOff);sc.position.set((SCR.x0+SCR.x1)/2,(SCR.y0+SCR.y1)/2,SCR.z+.0007);lid.add(sc);
    g.add(lid);g.userData={lid,screen:sc,emi,isLaptop:true};
    setLid(g,!(opt&&opt.closed));return g}
  const setLid=(g,open)=>{g.userData.lid.rotation.x=open?OPEN:CLOSED;g.userData.open=!!open};
  /* quvvat bor/yo'q: ekran (PC monitori teksturasi) va klaviatura yoritilishi */
  function setPower(g,on){const u=g.userData;u.screen.material=on?R.glassOn:R.glassOff;u.emi.emissiveIntensity=on?1.1:0;u.on=!!on}
  return{build,setLid,setPower,res,OPEN,CLOSED,SCR,size:D.size,PIV}
})();

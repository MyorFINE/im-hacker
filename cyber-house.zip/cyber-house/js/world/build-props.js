/* ==========================================================
 * Modul: js/world/build-props.js
 * Qurilish zonasi uchun realistik buyumlar (faqat fabrika funksiyalari — sahnaga o'zi hech narsa qo'shmaydi):
 *  - Sement qopi (deepseek dizayni: shishgan tana, yig'ilgan og'iz, kraft qog'oz teksturasi) — 10 dona, tik turadi
 *  - G'isht (gisht.html dizayni: yumaloqlangan qirra, pishgan loy teksturasi) — 200 dona uyum
 *  - Daraxt (stylized-tree.zip: oak 01) — soddalashtirilgan geometriya (tree-data.js)
 * Hamma buyum polga/pallet ustiga aniq tegib turadi (geometriya pastki nuqtasi y=0 ga keltiriladi).
 * ========================================================== */
const BUILDPROPS=(()=>{
  const S=lowEnd?512:1024;
  const rndf=seed=>()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646};
  const R=(a,b,f)=>a+f()*(b-a);

  /* ================= SEMENT QOPI ================= */
  const BAG={W:.40,H:.70,D:.16,SW:24,SH:40,SD:10};
  let _bg=null,_bm=null;
  function bagAlbedo(){
    const w=S,h=S,c=cv(w,h),x=c.getContext("2d");
    x.fillStyle="#b89868";x.fillRect(0,0,w,h);
    const im=x.getImageData(0,0,w,h),d=im.data;for(let i=0;i<d.length;i+=4){const n=(Math.random()-.5)*35;d[i]+=n;d[i+1]+=n;d[i+2]+=n}x.putImageData(im,0,0);
    for(let i=0;i<400;i++){x.fillStyle="rgba(180,175,170,"+(.04+Math.random()*.12)+")";x.beginPath();x.arc(Math.random()*w,Math.random()*h,(4+Math.random()*25)*w/1024,0,Math.PI*2);x.fill()}
    const bt=h*.40,bh=h*.18,g=x.createLinearGradient(0,bt,0,bt+bh);g.addColorStop(0,"#2a3a5a");g.addColorStop(.5,"#1a2a4a");g.addColorStop(1,"#2a3a5a");
    x.fillStyle=g;x.fillRect(0,bt,w,bh);x.fillStyle="#d4a848";x.fillRect(0,bt-4*w/1024,w,4*w/1024);x.fillRect(0,bt+bh,w,4*w/1024);
    x.textAlign="center";x.textBaseline="middle";
    x.fillStyle="#fff";x.font="bold "+w*.085+"px 'Arial Black',Arial,sans-serif";x.fillText("CEMENT",w/2,bt+bh*.35);
    x.font="bold "+w*.042+"px Arial,sans-serif";x.fillStyle="#d4c8a8";x.fillText("PORTLAND · M500",w/2,bt+bh*.72);
    x.font="bold "+w*.14+"px 'Arial Black',Arial,sans-serif";x.fillStyle="#1a2a4a";x.fillText("50 kg",w/2,h*.78);
    x.font="bold "+w*.055+"px Arial,sans-serif";x.fillStyle="#3a2818";x.fillText("BUILDING MATERIALS",w/2,h*.12);
    x.font="bold "+w*.026+"px Arial,sans-serif";x.fillStyle="#5a4530";x.fillText("STORE IN DRY PLACE · NET WEIGHT 50 KG",w/2,h*.93);
    x.strokeStyle="rgba(90,70,45,.5)";x.lineWidth=3;x.beginPath();x.moveTo(0,h*.05);x.lineTo(w,h*.05);x.stroke();x.beginPath();x.moveTo(0,h*.96);x.lineTo(w,h*.96);x.stroke();
    return tex(c)}
  function bagNormal(){
    const N=256,c=cv(N,N),x=c.getContext("2d"),im=x.createImageData(N,N),d=im.data;
    for(let i=0;i<N*N;i++){const nx=(Math.random()-.5)*.4,ny=(Math.random()-.5)*.4,l=Math.hypot(nx,ny,1);d[i*4]=(nx/l*.5+.5)*255;d[i*4+1]=(ny/l*.5+.5)*255;d[i*4+2]=(1/l*.5+.5)*255;d[i*4+3]=255}
    x.putImageData(im,0,0);const t=new T.CanvasTexture(c);return t}   /* normal xarita — chiziqli (sRGB emas) */
  function bagGeometry(){
    if(_bg)return _bg;
    const W=BAG.W,H=BAG.H,D=BAG.D,g=new T.BoxGeometry(W,H,D,BAG.SW,BAG.SH,BAG.SD),p=g.attributes.position;
    for(let i=0;i<p.count;i++){
      const x=p.getX(i),y=p.getY(i)+H/2,z=p.getZ(i),nx=x/(W/2),ny=y/H,nz=z/(D/2);
      let X=x,Y=y,Z=z;
      const bulge=Math.sin(ny*Math.PI)*.5+.5;
      if(Math.abs(Math.abs(nx)-1)<.01)Z=z*(.7+bulge*.6);
      if(Math.abs(Math.abs(nz)-1)<.01)X=x*(.85+bulge*.15);
      if(ny>.82){const t=(ny-.82)/.18,pinch=1-Math.pow(t,1.5)*.75;X*=pinch;Z*=pinch;X+=Math.sin(t*Math.PI*1.5)*.03*t;Z+=Math.cos(t*Math.PI)*.015*t;Y+=t*.03}
      if(ny<.10){const t=ny/.10,f=.82+t*.18;X=x*f;Z=z*f}
      Y+=Math.sin(nx*4+ny*6+nz*3)*.004;
      p.setXYZ(i,X,Y,Z)}
    g.computeVertexNormals();g.computeBoundingBox();g.translate(0,-g.boundingBox.min.y,0);g.computeBoundingBox();   /* pastki nuqta aynan y=0 */
    return _bg=g}
  function bagMaterial(){return _bm||(_bm=new T.MeshStandardMaterial({map:bagAlbedo(),normalMap:bagNormal(),normalScale:new T.Vector2(.6,.6),roughness:.95,metalness:0}))}
  /* 2 qator x 5 ta, tik turadi; qatorlar va qoplar o'rtasida kafolatlangan bo'shliq (kesishmaydi) */
  function bagLayout(cx,cz,y0){
    const yaw=[.05,-.07,.03,-.04,.08,-.05,.06,-.03,.04,-.08],o=[];
    for(let r=0;r<2;r++)for(let i=0;i<5;i++)o.push({x:cx+(i-2)*.46,y:y0+.0005,z:cz+(r?1:-1)*.21,ry:yaw[r*5+i]});
    return o}
  function carryBag(g){   /* qo'ldagi yuk: yotqizilgan qop */
    const m=new T.Mesh(bagGeometry(),bagMaterial()),w=new T.Group(),h=BAG.H;
    m.rotation.z=Math.PI/2;m.position.x=(_bg.boundingBox.max.y)/2;w.add(m);w.rotation.x=Math.PI/2;w.scale.setScalar(.58);g.add(w)}

  /* ================= G'ISHT ================= */
  const BR={w:.5,h:.2,d:.25};   /* o'yindagi devor g'ishti o'lchami (BRK) bilan bir xil */
  let _bt=null,_bk=null;
  function brickTextures(){
    if(_bt)return _bt;
    const s=S/1024,c=cv(S,S),x=c.getContext("2d"),rr=(a,b)=>a+Math.random()*(b-a);
    x.fillStyle="#a94728";x.fillRect(0,0,S,S);
    const cs=["rgba(65,24,13,.17)","rgba(190,87,45,.22)","rgba(235,130,67,.14)","rgba(89,39,23,.22)","rgba(215,102,51,.18)","rgba(53,26,19,.13)"];
    for(let i=0;i<2200*s;i++){x.fillStyle=cs[Math.floor(Math.random()*cs.length)];x.beginPath();x.ellipse(rr(0,S),rr(0,S),rr(2,45)*s,rr(2,22)*s,rr(-1,1),0,Math.PI*2);x.fill()}
    for(let i=0;i<1400*s;i++){x.strokeStyle=Math.random()>.5?"rgba(50,20,12,.18)":"rgba(255,165,105,.12)";x.lineWidth=rr(.3,2);const a=rr(0,S),b=rr(0,S);x.beginPath();x.moveTo(a,b);x.lineTo(a+rr(-35,35)*s,b+rr(-3,3)*s);x.stroke()}
    for(let i=0;i<11000*s*s;i++){const r=(Math.random()<.9?rr(.3,1.5):rr(1.5,3.5))*s;x.fillStyle=Math.random()>.5?"rgba(35,15,10,.48)":"rgba(245,157,100,.27)";x.beginPath();x.ellipse(rr(0,S),rr(0,S),r,r*rr(.5,1.4),rr(0,Math.PI),0,Math.PI*2);x.fill()}
    for(let i=0;i<45;i++){const a=rr(0,S),b=rr(0,S),r=rr(20,85)*s,g=x.createRadialGradient(a,b,1,a,b,r);g.addColorStop(0,"rgba(48,22,17,.25)");g.addColorStop(1,"rgba(48,22,17,0)");x.fillStyle=g;x.fillRect(a-r,b-r,r*2,r*2)}
    const im=x.getImageData(0,0,S,S),d=im.data;for(let i=0;i<d.length;i+=4){const n=rr(-8,8);d[i]+=n;d[i+1]+=n*.65;d[i+2]+=n*.4}x.putImageData(im,0,0);
    /* g'ovaklik (bump) -> normal xarita (Sobel), 256x256 */
    const N=256,c2=cv(N,N),x2=c2.getContext("2d");x2.drawImage(c,0,0,N,N);const id=x2.getImageData(0,0,N,N).data,h=new Float32Array(N*N);
    for(let i=0;i<N*N;i++)h[i]=(id[i*4]*.299+id[i*4+1]*.587+id[i*4+2]*.114)/255;
    const out=x2.createImageData(N,N),od=out.data,k=2.2;
    for(let y=0;y<N;y++)for(let xx=0;xx<N;xx++){
      const L=h[y*N+(xx+N-1)%N],Rr=h[y*N+(xx+1)%N],U=h[((y+N-1)%N)*N+xx],Dn=h[((y+1)%N)*N+xx];
      let nx=(L-Rr)*k,ny=(Dn-U)*k;const l=Math.hypot(nx,ny,1),i=(y*N+xx)*4;
      od[i]=(nx/l*.5+.5)*255;od[i+1]=(ny/l*.5+.5)*255;od[i+2]=(1/l*.5+.5)*255;od[i+3]=255}
    x2.putImageData(out,0,0);
    return _bt={color:tex(c),normal:new T.CanvasTexture(c2)}}
  function brickMaterial(){
    if(_bk)return _bk;const t=brickTextures();
    return _bk=new T.MeshStandardMaterial({map:t.color,normalMap:t.normal,normalScale:new T.Vector2(.7,.7),roughness:.96,metalness:0})}
  /* yumaloqlangan quti (RoundedBoxGeometry o'rniga — r128 yadrosida yo'q) */
  function brickGeometry(w,h,d,r){
    r=r||Math.min(w,h,d)*.04;
    const g=new T.BoxGeometry(w,h,d,3,3,3),p=g.attributes.position,nm=g.attributes.normal,uv=g.attributes.uv;
    const a=[w/2,h/2,d/2],cl=(v,i)=>{const t=v/a[i];return t<-.9?-a[i]:t<0?-a[i]+r:t<.9?a[i]-r:a[i]};
    for(let i=0;i<p.count;i++){
      const ax=Math.abs(nm.getX(i))>.5?0:Math.abs(nm.getY(i))>.5?1:2;    /* asl yuz o'qi (UV uchun) */
      const q=[cl(p.getX(i),0),cl(p.getY(i),1),cl(p.getZ(i),2)],inn=q.map((v,j)=>Math.max(-a[j]+r,Math.min(a[j]-r,v)));
      const dd=q.map((v,j)=>v-inn[j]),l=Math.hypot(dd[0],dd[1],dd[2]);let n=dd;
      if(l>1e-9){n=dd.map(v=>v/l)}else n=[nm.getX(i),nm.getY(i),nm.getZ(i)];
      const f=l>1e-9?[inn[0]+n[0]*r,inn[1]+n[1]*r,inn[2]+n[2]*r]:q;
      p.setXYZ(i,f[0],f[1],f[2]);nm.setXYZ(i,n[0],n[1],n[2]);
      if(ax===0)uv.setXY(i,f[2]/d+.5,f[1]/h+.5);else if(ax===1)uv.setXY(i,f[0]/w+.5,f[2]/d+.5);else uv.setXY(i,f[0]/w+.5,f[1]/h+.5)}
    g.computeBoundingBox();return g}
  /* 200 ta g'isht: toq qatlam — x bo'ylab 5x6, juft qatlam — z bo'ylab 10x3 (o'zaro kesishgan teriq); oxirgisi to'lmagan */
  function brickLayout(cx,cz,y0,count){
    const f=rndf(4242),o=[],L=BR.w,H=BR.h,Wd=BR.d;
    for(let layer=0;o.length<count;layer++){
      const yc=y0+.001+H/2+layer*(H+.002),A=layer%2===0,rows=[];
      if(A){for(let j=0;j<6;j++)for(let i=0;i<5;i++)rows.push({x:(i-2)*(L+.012),z:(j-2.5)*(Wd+.012),ry:0,row:j})}
      else{const px=Wd+.012;for(let i=0;i<10;i++)for(let j=0;j<3;j++)rows.push({x:(i-4.5)*px,z:(j-1)*(L+.012),ry:Math.PI/2,row:j})}
      for(const b of rows){if(o.length>=count)break;
        o.push({x:cx+b.x+R(-.003,.003,f),y:yc,z:cz+b.z+R(-.003,.003,f),ry:b.ry+R(-.006,.006,f),layer})}}
    return o}
  function carryBricks(g){
    const geo=brickGeometry(.17,.065,.085,.003),m=brickMaterial();
    for(let i=0;i<3;i++)for(let j=0;j<2;j++){const b=new T.Mesh(geo,m);b.position.set(-.09+j*.18,-.05+i*.07,0);g.add(b)}}

  /* ================= DARAXT ================= */
  let _oak=null;
  function dec(b,Ty){const s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return new Ty(u.buffer)}
  function oakParts(){
    if(_oak)return _oak;const D=OAK_DATA;
    const tg=new T.BufferGeometry();
    tg.setAttribute("position",new T.BufferAttribute(dec(D.trunk.p,Int16Array),3));
    tg.setAttribute("normal",new T.BufferAttribute(dec(D.trunk.nr,Int8Array),3,true));
    tg.setAttribute("color",new T.BufferAttribute(dec(D.trunk.c,Uint8Array),3,true));
    tg.setIndex(new T.BufferAttribute(dec(D.trunk.i,Uint16Array),1));tg.computeBoundingSphere();
    const n=D.leaves.cards,lg=new T.BufferGeometry(),flip=dec(D.leaves.flip,Uint8Array),uv=new Float32Array(n*8),ix=new Uint16Array(n*6);
    for(let k=0;k<n;k++){const b=k*4,o=k*6;uv.set([1,0,1,1,0,1,0,0],k*8);
      if(flip[k]){ix[o]=b;ix[o+1]=b+2;ix[o+2]=b+1;ix[o+3]=b;ix[o+4]=b+3;ix[o+5]=b+2}else{ix[o]=b;ix[o+1]=b+1;ix[o+2]=b+2;ix[o+3]=b;ix[o+4]=b+2;ix[o+5]=b+3}}
    lg.setAttribute("position",new T.BufferAttribute(dec(D.leaves.p,Int16Array),3));
    lg.setAttribute("normal",new T.BufferAttribute(dec(D.leaves.nr,Int8Array),3,true));
    lg.setAttribute("color",new T.BufferAttribute(dec(D.leaves.c,Uint8Array),3,true));
    lg.setAttribute("uv",new T.BufferAttribute(uv,2));lg.setIndex(new T.BufferAttribute(ix,1));lg.computeBoundingSphere();
    const mask=new T.TextureLoader().load(D.mask);
    const tm=new T.MeshLambertMaterial({vertexColors:true,side:T.DoubleSide});
    const lm=new T.MeshLambertMaterial({vertexColors:true,alphaMap:mask,alphaTest:.5,side:T.DoubleSide});
    return _oak={tg,lg,tm,lm}}
  function oakTree(x,z,s,ry){
    const P=oakParts(),g=new T.Group(),k=OAK_DATA.q*s,a=new T.Mesh(P.tg,P.tm),b=new T.Mesh(P.lg,P.lm);
    a.scale.setScalar(k);b.scale.setScalar(k);g.add(a,b);g.position.set(x,0,z);g.rotation.y=ry;return g}

  /* ================= SAHNAGA QO'YISH ================= */
  const TREES=[[-18,-13],[-18,12],[18,13],[18,-14],[-9,-14.5],[3,-14.5],[16,7.5],[-18,2]];
  function addTo(parent,col){
    const PALLET_TOP=.12;
    /* 10 ta sement qopi (pallet: markaz -15,-2.5; yuza y=.12) */
    const bg=bagGeometry(),bm=bagMaterial();
    bagLayout(-15,-2.5,PALLET_TOP).forEach(b=>{const m=new T.Mesh(bg,bm);m.position.set(b.x,b.y,b.z);m.rotation.y=b.ry;parent.add(m)});
    /* 200 ta g'isht (pallet: markaz -15,5.5; yuza y=.12) */
    const pile=brickLayout(-15,5.5,PALLET_TOP,200),geo=brickGeometry(BR.w,BR.h,BR.d),mat=brickMaterial(),im=new T.InstancedMesh(geo,mat,pile.length),o=new T.Object3D(),c=new T.Color(),f=rndf(99);
    pile.forEach((b,i)=>{o.position.set(b.x,b.y,b.z);o.rotation.set(0,b.ry,0);o.scale.set(1,1,1);o.updateMatrix();im.setMatrixAt(i,o.matrix);c.setScalar(R(.8,1,f));im.setColorAt(i,c)});
    im.instanceMatrix.needsUpdate=true;if(im.instanceColor)im.instanceColor.needsUpdate=true;im.frustumCulled=false;parent.add(im);
    /* daraxtlar: tana ostida aniq yer (y=0), tana to'qnashuvi bilan */
    const f2=rndf(2026);TREES.forEach(t=>{parent.add(oakTree(t[0],t[1],R(.085,.105,f2),R(0,6.28,f2)));if(col)col(t[0],t[1],.2,.2)});
    return{bags:10,bricks:pile.length,trees:TREES.length}}
  return{BAG,BR,bagGeometry,bagMaterial,bagLayout,carryBag,brickGeometry,brickMaterial,brickLayout,carryBricks,oakTree,addTo,TREES}
})();

/* ==========================================================
 * Modul: js/world/desk-chair.js
 * Stol va stul
 * ========================================================== */
/* ---------- stol, stul ---------- */
/* kompyuter stoli: preview.html dagi eman stol (usti, oyoqlar, tayanchlar). Tortma — js/interaction/port-picking.js */
const DESK_CB=buildOakDesk({par:scene,st:1,cx:0,cz:-3.45,W:3.6,D:1.5,y:.9,th:.16,r:.035,lw:.09,lx:1.53,lz:.58,ah:.08,aw:.06,back:-1});
cols.push({x:0,z:-3.45,hw:1.8,hd:.75});
box(0,.52,-2.2,.55,.07,.55,L(0x1f262d));box(0,.95,-1.93,.55,.6,.07,L(0x1f262d));box(0,.28,-2.2,.07,.5,.07,L(0x666e75));box(0,.6,-1.93,.1,.16,.05,L(0x1f262d));[[.29,-2.31],[.29,-2.09],[-.29,-2.31],[-.29,-2.09]].forEach(a=>box(a[0],.61,a[1],.03,.22,.03,L(0x1f262d)));
box(0,.04,-2.2,.7,.04,.07,L(0x666e75));box(0,.04,-2.2,.07,.04,.7,L(0x666e75));
cols.push({x:0,z:-2.2,hw:.36,hd:.36});

/* ==========================================================
 * Modul: js/world/monitor2.js
 * 2-monitor: birinchi monitorning o'ng tomonida (biroz ichkariga burilgan)
 * Alohida ekran teksturasi, LED, ranglar, portlar (HDMI, DP, quvvat) va qismlar
 * ========================================================== */
/* ===== 2-MONITOR: 1-monitor bilan bir xil detallar, lekin guruh ichida (lokal koordinatalar) ===== */
const MON2={gx:1.08,gz:-3.8,ry:-.2};
const g2=new T.Group();g2.position.set(MON2.gx,0,MON2.gz);g2.rotation.y=MON2.ry;scene.add(g2);
/* lokal z: 1-monitor koordinatasi (-3.8 markaz) -> guruh lokal koordinatasi */
const z2=v=>Math.round((v+3.8)*10000)/10000;
const sc2=cv(W*K,H*K),sx2=sc2.getContext("2d");
const scrTex2=tex(sc2);scrTex2.generateMipmaps=false;scrTex2.minFilter=T.LinearFilter;scrTex2.anisotropy=8;
const monitor2=new T.Mesh(new T.PlaneGeometry(.96,.54),new T.MeshBasicMaterial({map:scrTex2}));monitor2.position.set(0,1.3,z2(-3.781));g2.add(monitor2);
const mled2=new T.Mesh(new T.SphereGeometry(.015,6,6),B(0x2a1a0a));mled2.position.set(.4,1.012,z2(-3.781));g2.add(mled2);
{const b1=new T.Mesh(new T.BoxGeometry(1.02,.6,.035),L(0x0c0f13));b1.position.set(0,1.3,0);g2.add(b1);
 const b2=new T.Mesh(new T.BoxGeometry(.5,.4,.06),L(0x0a0c10));b2.position.set(0,1.3,z2(-3.84));g2.add(b2);
 /* ekran yaltirashi (1-monitordagi kabi) */
 const gc=cv(64,64),g3=gc.getContext("2d"),gg=g3.createLinearGradient(0,0,64,64);gg.addColorStop(0,"rgba(255,255,255,.16)");gg.addColorStop(.45,"rgba(255,255,255,.02)");gg.addColorStop(1,"rgba(255,255,255,0)");g3.fillStyle=gg;g3.fillRect(0,0,64,64);
 const gl=new T.Mesh(new T.PlaneGeometry(.96,.54),new T.MeshBasicMaterial({map:tex(gc),transparent:true,depthWrite:false,blending:T.AdditiveBlending}));gl.position.set(0,1.3,z2(-3.78));g2.add(gl)}
{const M=MG(g2),k=M.c(0x1a2028),kg=M.c(0x2a3138),ks=M.c(0xa7b0b8),kb=M.c(0x020304,true),kc=M.c(0x1d252c),zf=z2(-3.7785),N2="2-monitor · ";
 /* Bezel */
 M.box(1.02,.03,.008,k,0,1.585,zf);M.box(1.02,.03,.008,k,0,1.015,zf);M.box(.03,.54,.008,k,-.495,1.3,zf);M.box(.03,.54,.008,k,.495,1.3,zf);
 M.box(.07,.006,.002,ks,0,1.015,z2(-3.7737));for(let i=0;i<4;i++)M.box(.014,.008,.004,kc,.26+i*.03,1.012,z2(-3.7745));
 M.add(new T.CircleGeometry(.0065,10),kb,0,1.585,z2(-3.7739));M.add(new T.RingGeometry(.0065,.0095,10),kc,0,1.585,z2(-3.7741));
 part(g2,0,1.3,0,1.02,.6,.035,N2+"Bezel — Monitor ramkasi");part(g2,0,1.585,zf,1.02,.03,.008,N2+"Bezel — Monitor ramkasi");part(g2,0,1.015,zf,1.02,.03,.008,N2+"Bezel — Monitor ramkasi");part(g2,-.495,1.3,zf,.03,.54,.008,N2+"Bezel — Monitor ramkasi");part(g2,.495,1.3,zf,.03,.54,.008,N2+"Bezel — Monitor ramkasi");
 part(g2,0,1.3,z2(-3.7805),.96,.54,.004,N2+"Display Panel — Ekran paneli");
 part(g2,0,1.3,z2(-3.84),.5,.4,.06,N2+"Monitor orqa korpusi");
 /* Stand */
 M.add(new T.CylinderGeometry(.15,.16,.014,28),kg,0,.907,z2(-3.84),0,0,0,1,1,.75);M.add(new T.CylinderGeometry(.152,.152,.002,28),ks,0,.9145,z2(-3.84),0,0,0,1,1,.75);
 part(g2,0,.907,z2(-3.84),.32,.014,.24,N2+"Monitor Stand — Monitor oyoqchasi");
 /* Stand Neck */
 M.box(.07,.17,.032,kg,0,1.012,z2(-3.855));M.add(new T.CylinderGeometry(.04,.05,.02,16),kg,0,.925,z2(-3.84));M.add(new T.CylinderGeometry(.02,.02,.1,12),ks,0,1.1,z2(-3.85),0,0,Math.PI/2);M.box(.02,.05,.002,kb,0,1.0,z2(-3.8715));
 part(g2,0,1.01,z2(-3.855),.07,.18,.034,N2+"Stand Neck — Monitor bo'yni");
 /* orqa portlar: HDMI, DisplayPort, Power Connector */
 M.box(.036,.014,.008,ks,-.15,1.14,z2(-3.874));M.box(.028,.008,.002,kb,-.15,1.14,z2(-3.8785));
 M.box(.03,.012,.008,ks,.05,1.14,z2(-3.874));M.box(.022,.007,.002,kb,.05,1.14,z2(-3.8785));M.box(.004,.004,.002,kb,.0635,1.1445,z2(-3.8785));
 M.box(.04,.02,.01,kg,-.04,1.14,z2(-3.875));M.box(.004,.008,.002,kb,-.05,1.14,z2(-3.8805));M.box(.004,.008,.002,kb,-.03,1.14,z2(-3.8805));
 part(g2,-.15,1.14,z2(-3.875),.04,.02,.012,N2+"HDMI Port");part(g2,.05,1.14,z2(-3.875),.034,.016,.012,N2+"DisplayPort");part(g2,-.04,1.14,z2(-3.876),.044,.024,.012,N2+"Power Connector — Quvvat porti");
 /* Ventilation Grilles */
 for(const sd of[-1,1]){for(let r=0;r<8;r++)M.box(.07,.006,.002,kb,sd*.14,1.33+r*.016,z2(-3.8708));part(g2,sd*.14,1.39,z2(-3.8715),.08,.13,.004,N2+"Ventilation Grilles — Orqa ventilyatsiya teshiklari")}
 M.done()}
g2.updateMatrixWorld(true);
/* portlarning dunyo koordinatalari (kabel yo'llari uchun) */
MON2.pwr=g2.localToWorld(new T.Vector3(-.04,1.14,z2(-3.8805)));
MON2.hdmi=g2.localToWorld(new T.Vector3(-.15,1.14,z2(-3.8785)));

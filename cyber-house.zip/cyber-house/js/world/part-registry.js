/* ==========================================================
 * Modul: js/world/part-registry.js
 * Qismlarni nomi bilan topish (part, partAt), fan geometriyasi
 * ========================================================== */
/* ===== jihoz detallari: yordamchilar ===== */
const PARTS=[],_I4=new T.Matrix4(),_pr2=new T.Ray(),_hit=new T.Vector3(),_pdir=new T.Vector3();
function part(o,cx,cy,cz,w,h,d,n,fl){PARTS.push({o,n,fl:fl||0,b:new T.Box3(new T.Vector3(cx-w/2,cy-h/2,cz-d/2),new T.Vector3(cx+w/2,cy+h/2,cz+d/2))})}
/* qismni nomi bilan topish: nur bilan quti kesishuvi, shisha orqali ichki qismlar ko'rinadi */
function partAt(){if(Math.hypot(P.x-.3,P.z+3.2)>3.2)return null;camera.getWorldDirection(_pdir);const mws=new Map(),hits=[];
 for(const p of PARTS){let m=mws.get(p.o);if(!m){if(p.o){p.o.updateMatrixWorld(true);m={w:p.o.matrixWorld,i:new T.Matrix4().copy(p.o.matrixWorld).invert()}}else m={w:_I4,i:_I4};mws.set(p.o,m)}
  _pr2.origin.copy(camera.position).applyMatrix4(m.i);_pr2.direction.copy(_pdir).transformDirection(m.i);
  if(_pr2.intersectBox(p.b,_hit)){_hit.applyMatrix4(m.w);const d=_hit.distanceTo(camera.position);if(d<1.9)hits.push([d,p])}}
 hits.sort((a,b)=>a[0]-b[0]);let g=null;
 for(const h of hits){const p=h[1];if(p.fl===1){if(!g)g=p;continue}if(g&&p.fl!==2)return g.n;return p.n}
 return g?g.n:null}
/* statik geometriyani rang bo'yicha birlashtirish (kam draw-call) */
function MG(parent){const m=new Map(),mats={};
 return{c(col,basic){const k=col+(basic?"b":"l");return mats[k]||(mats[k]=basic?B(col):L(col))},
 add(geo,mat,x,y,z,rx,ry,rz,sx,sy,sz){const g=geo.index?geo.toNonIndexed():geo.clone();g.applyMatrix4(new T.Matrix4().compose(new T.Vector3(x||0,y||0,z||0),new T.Quaternion().setFromEuler(new T.Euler(rx||0,ry||0,rz||0)),new T.Vector3(sx||1,sy||1,sz||1)));let a=m.get(mat);if(!a)m.set(mat,a=[]);a.push(g)},
 box(w,h,d,mat,x,y,z,rx,ry,rz){this.add(new T.BoxGeometry(w,h,d),mat,x,y,z,rx,ry,rz)},
 done(){m.forEach((arr,mat)=>{let n=0;arr.forEach(g=>n+=g.attributes.position.count);const P3=new Float32Array(n*3),N3=new Float32Array(n*3),U2=new Float32Array(n*2);let o=0;arr.forEach(g=>{const c=g.attributes.position.count;P3.set(g.attributes.position.array,o*3);N3.set(g.attributes.normal.array,o*3);if(g.attributes.uv)U2.set(g.attributes.uv.array,o*2);o+=c;g.dispose()});const G=new T.BufferGeometry();G.setAttribute("position",new T.BufferAttribute(P3,3));G.setAttribute("normal",new T.BufferAttribute(N3,3));G.setAttribute("uv",new T.BufferAttribute(U2,2));const me=new T.Mesh(G,mat);me.matrixAutoUpdate=false;(parent||scene).add(me)});m.clear()}}}
function fanGeo(r){const n=7,pos=[],r0=r*.26;for(let i=0;i<n;i++){const a=i/n*Math.PI*2,p=(rr,aa)=>[Math.cos(a+aa)*rr,Math.sin(a+aa)*rr,0];pos.push(...p(r0,0),...p(r0,.5),...p(r*.97,.95),...p(r0,0),...p(r*.97,.95),...p(r*.97,.38))}const g=new T.BufferGeometry();g.setAttribute("position",new T.Float32BufferAttribute(pos,3));return g}

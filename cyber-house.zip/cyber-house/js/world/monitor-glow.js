/* ==========================================================
 * Modul: js/world/monitor-glow.js
 * Monitor/laptop yongach ekran yorug'ligi: har bir yoqilgan ekran oldida yumshoq ko'kimtir yorug'lik paydo bo'ladi
 * (stol, klaviatura, qo'llar va devor shu yorug'likda yoritiladi). 4 ta doimiy yorug'lik — soni o'zgarmaydi (shader qayta tuzilmaydi).
 * ========================================================== */
const MGLOW=(()=>{
  const N=4,Ls=[];for(let i=0;i<N;i++){const l=new T.PointLight(0x8cc8ff,0,3.6,1.7);l.position.set(0,-50,0);scene.add(l);Ls.push(l)}
  const c=new T.Vector3(),n=new T.Vector3();
  function update(dt){
    const tg=[],on=!!S.on;
    if(on){const k=S.stage===3?.62:S.stage>=1?.3:0;
      if(typeof PCSET!=="undefined")for(const r of PCSET.live()){const p=PI[r.id],m=p&&p.mesh;if(!m||!m.userData.screen)continue;const s=m.userData.screen;s.getWorldPosition(c);n.set(0,0,1).transformDirection(s.matrixWorld);tg.push({x:c.x+n.x*.55,y:c.y+.03,z:c.z+n.z*.55,i:k})}
      if(typeof LAPX!=="undefined"&&LAPX.powered())for(const r of ECO.placed){if(r.sku!=="laptop"||r.cab==null)continue;const p=PI[r.id],m=p&&p.mesh;if(!m||!m.userData.screen)continue;const s=m.userData.screen;s.getWorldPosition(c);n.set(0,0,1).transformDirection(s.matrixWorld);tg.push({x:c.x+n.x*.4,y:c.y+.02,z:c.z+n.z*.4,i:k*.7})}}
    const kk=Math.min(1,(dt||.016)*6);
    for(let i=0;i<N;i++){const L=Ls[i],t=tg[i];if(t){L.position.set(t.x,t.y,t.z);L.intensity+=(t.i-L.intensity)*kk}else{L.intensity+=(0-L.intensity)*kk;if(L.intensity<.004)L.intensity=0}}}
  return{update,lights:Ls}
})();

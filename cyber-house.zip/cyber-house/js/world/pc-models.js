/* ==========================================================
 * Modul: js/world/pc-models.js
 * Realistik o'lchamdagi kompyuter jihozlari:
 *  - MON32: 32" monitor modeli (ekran 0.708 x 0.398 m, 16:9), o'yinda MON_K=1.2 marta kattalashtirilgan (≈38", ekran 0.85 x 0.48 m).
 *  - PCCASE: ATX mid-tower korpus 0.22 x 0.46 x 0.45 m: tarmoqli old panel + 3 ta RGB ventilyator, chap yon panel — qattiq metall,
 *    o'ng yon panel — tempered glass; ichida anakart, protsessor sovutgichi (ventilyatorli), 2 ta RAM, videokarta, blok pitaniya, kabellar.
 * O'qlar: boshi — pol/stol sathida markaz; oldi = +z (monitor ekrani ham +z ga qaraydi), orqa = -z.
 * Portlar joyi catalog.js dagi MON_PORT/MON_VPORT/PC_PW/PC_VID/PC_USB bilan bir xil.
 * ========================================================== */
const PCM=(()=>{
  let R=null;
  function res(){
    if(R)return R;let env=null;try{env=LAPTOP.env()}catch(e){}
    const S=(c,r,m,k)=>new T.MeshStandardMaterial({color:c,roughness:r,metalness:m,envMap:env,envMapIntensity:k==null?.8:k});
    /* old panel: teshikli (hex) tarmoq — alfa xarita bilan ichidagi ventilyatorlar ko'rinadi */
    const cvp=cv(256,512),x=cvp.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,256,512);x.fillStyle="#000";
    for(let r=0;r<44;r++)for(let c=0;c<22;c++){const px=10+c*11.2+(r%2?5.6:0),py=10+r*11.2;if(px<246&&py<502){x.beginPath();x.arc(px,py,3.6,0,6.2832);x.fill()}}
    const am=new T.CanvasTexture(cvp);
    R={env,
      bezel:S(0x0c0e11,.42,.25,.55),shell:S(0x15181c,.6,.2,.4),silver:S(0x9aa1a9,.28,.9,1),dark:S(0x0b0d10,.7,.1,.3),
      steel:S(0x1b1f25,.5,.65,.8),steelD:S(0x101317,.65,.4,.5),pcb:S(0x0f1f19,.6,.25,.5),heat:S(0x2b3037,.32,.85,.9),
      gpu:S(0x121519,.4,.75,.9),ram:S(0x1a1d22,.5,.4,.6),cable:S(0x07080a,.8,0,.2),rubber:S(0x050607,.9,0,0),
      glass:new T.MeshStandardMaterial({color:0x1a2a38,transparent:true,opacity:.2,roughness:.04,metalness:0,envMap:env,envMapIntensity:1.3,depthWrite:false,side:T.DoubleSide}),
      mesh:new T.MeshStandardMaterial({color:0x14171c,roughness:.55,metalness:.5,envMap:env,envMapIntensity:.6,alphaMap:am,alphaTest:.5,side:T.DoubleSide})};
    return R}
  const bx=(g,w,h,d,m,x,y,z)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);g.add(o);return o};
  /* ---------- 32" monitor ---------- */
  function monitor(){
    monScreens();const r=res(),g=new T.Group();
    bx(g,.3,.012,.2,r.silver,0,.006,0);                 /* tayanch plitasi */
    bx(g,.075,.2,.045,r.silver,0,.112,-.04);            /* bo'yin */
    bx(g,.724,.42,.012,r.bezel,0,.32,0);                /* old ramka (ingichka) */
    bx(g,.5,.27,.03,r.shell,0,.325,-.021);              /* orqa qalin qism */
    bx(g,.724,.42,.004,r.shell,0,.32,-.008);            /* orqa qopqoq */
    bx(g,.06,.005,.002,r.silver,0,.121,.0062);          /* pastki ramkadagi belgi chizig'i */
    const sc=new T.Mesh(new T.PlaneGeometry(.708,.398),_scOff);sc.position.set(0,.329,.0063);g.add(sc);g.userData.screen=sc;
    bx(g,.018,.005,.0015,new T.MeshBasicMaterial({color:0x2a2f36}),.33,.121,.0063);   /* quvvat chirog'i */
    const pl=new T.MeshStandardMaterial({color:0x22272e,roughness:.5,metalness:.4});
    bx(g,.03,.02,.012,pl,MON_PORT[0]/MON_K,MON_PORT[1]/MON_K,MON_PORT[2]/MON_K-.004);bx(g,.03,.02,.012,new T.MeshStandardMaterial({color:0x1b4fa0,roughness:.5}),MON_VPORT[0]/MON_K,MON_VPORT[1]/MON_K,MON_VPORT[2]/MON_K-.004);
    g.scale.setScalar(MON_K);return g}   /* butun monitor bir tekis kattalashtiriladi (ekran: 0.708*K x 0.398*K) */
  /* ---------- ventilyator (RGB): pichoqlar aylanadi (rotation.z), halqa yonadi ---------- */
  function fan(g,x,y,z,ry,glow,fans){
    const R_=res(),f=new T.Group();f.position.set(x,y,z);f.rotation.y=ry;g.add(f);
    bx(f,.12,.12,.025,R_.steelD,0,0,0);
    const ring=new T.Mesh(new T.RingGeometry(.047,.055,40),new T.MeshBasicMaterial({color:0x111111,side:T.DoubleSide}));ring.position.z=.0135;f.add(ring);glow.push(ring.material);
    const pos=[],N=7;for(let k=0;k<N;k++){const a=k/N*Math.PI*2,a1=a-.1,a2=a+.12,a3=a+.5,a4=a+.28,ri=.013,ro=.046;
      const p=(r,t)=>[Math.cos(t)*r,Math.sin(t)*r,0];pos.push(...p(ri,a1),...p(ri,a2),...p(ro,a3),...p(ri,a1),...p(ro,a3),...p(ro,a4))}
    const bg=new T.BufferGeometry();bg.setAttribute("position",new T.Float32BufferAttribute(pos,3));
    const bl=new T.Mesh(bg,new T.MeshBasicMaterial({color:0x111111,side:T.DoubleSide}));bl.position.z=.012;f.add(bl);fans.push(bl);
    const hub=new T.Mesh(new T.CircleGeometry(.014,16),R_.dark);hub.position.z=.0125;f.add(hub);return f}
  /* ---------- ATX mid-tower korpus ---------- */
  function pcCase(){
    const r=res(),g=new T.Group(),Y=.016,fans=[],glow=[],gm=()=>{const m=new T.MeshBasicMaterial({color:0x111111});glow.push(m);return m};
    /* tagliklar */
    [[-.09,-.17],[.09,-.17],[-.09,.17],[.09,.17]].forEach(a=>bx(g,.025,Y,.035,r.rubber,a[0],Y/2,a[1]));
    /* korpus: chap (qattiq) yon, tepa, past, orqa; o'ng — shisha */
    bx(g,.004,.46,.45,r.steel,-.108,Y+.23,0);bx(g,.22,.004,.45,r.steel,0,Y+.458,0);bx(g,.22,.004,.45,r.steel,0,Y+.002,0);bx(g,.22,.46,.004,r.steel,0,Y+.23,-.223);
    bx(g,.17,.0015,.3,r.dark,0,Y+.4605,.02);                                            /* tepa shamollatish oynasi */
    bx(g,.004,.44,.44,r.glass,.108,Y+.23,0);                                            /* tempered glass */
    [[.004,.012,.45,.108,Y+.456,0],[.004,.012,.45,.108,Y+.004,0],[.004,.44,.012,.108,Y+.23,.219],[.004,.44,.012,.108,Y+.23,-.219]].forEach(a=>bx(g,a[0],a[1],a[2],r.steel,a[3],a[4],a[5]));  /* shisha romi */
    /* old panel (teshikli) */
    const fp=new T.Mesh(new T.PlaneGeometry(.22,.46),r.mesh);fp.position.set(0,Y+.23,.2205);g.add(fp);
    bx(g,.22,.012,.012,r.steel,0,Y+.454,.218);bx(g,.22,.012,.012,r.steel,0,Y+.006,.218);
    [.085,.225,.365].forEach(y=>fan(g,0,Y+y,.19,0,glow,fans));                            /* 3 ta old ventilyator */
    fan(g,0,Y+.37,-.205,Math.PI,glow,fans);                                              /* orqa ventilyator */
    /* ichki: anakart (chap yon panelga yaqin, vertikal) */
    bx(g,.0025,.30,.25,r.pcb,-.0985,Y+.30,.02);
    bx(g,.014,.055,.075,r.heat,-.09,Y+.41,-.075);bx(g,.014,.04,.07,r.heat,-.09,Y+.405,-.0);bx(g,.007,.045,.045,r.heat,-.095,Y+.215,.085);   /* VRM va chipset */
    bx(g,.012,.0035,.07,new T.MeshStandardMaterial({color:0xc9a227,roughness:.3,metalness:.9,envMap:r.env}),-.093,Y+.18,.03);                    /* PCIe uyasi */
    /* protsessor sovutgichi: minora + ventilyator */
    bx(g,.13,.125,.04,r.heat,-.03,Y+.325,-.015);bx(g,.1,.12,.012,r.steelD,-.03,Y+.325,.012);
    fan(g,-.03,Y+.325,.03,0,glow,fans).scale.set(.95,.95,.95);
    /* RAM (2 dona, RGB) */
    [.085,.108].forEach(z=>{bx(g,.032,.133,.007,r.ram,-.082,Y+.32,z);bx(g,.032,.006,.007,gm(),-.082,Y+.386,z)});
    /* videokarta: pol bo'ylab (old-orqa), shisha tomonidan RGB chiziq */
    bx(g,.105,.045,.27,r.gpu,-.045,Y+.2,.02);bx(g,.1,.004,.26,r.heat,-.045,Y+.2235,.02);bx(g,.002,.007,.2,gm(),.0075,Y+.2,.03);bx(g,.01,.042,.01,r.silver,-.09,Y+.2,-.118);
    /* blok pitaniya g'ilofi + kabellar */
    bx(g,.21,.085,.30,r.steelD,0,Y+.052,-.065);for(let i=0;i<5;i++)bx(g,.19,.0015,.012,r.dark,0,Y+.0955,-.18+i*.045);
    [[-.085,.0,-.14],[-.077,-.012,-.14],[-.069,.012,-.14]].forEach(a=>bx(g,.006,.2,.009,r.cable,a[0],Y+.21+a[1],a[2]));
    /* orqa panel portlari (pc-setup shu joylarga kabel ulaydi) */
    bx(g,.06,.04,.012,r.dark,PC_PW[0],PC_PW[1],-.2265);bx(g,.01,.012,.006,r.silver,PC_PW[0]-.02,PC_PW[1],-.2325);
    for(let i=0;i<4;i++){const p=PC_VID(i);bx(g,.024,.011,.012,new T.MeshStandardMaterial({color:0x1b4fa0,roughness:.5}),p[0],p[1],-.2265)}
    bx(g,.03,.012,.012,r.dark,PC_USB[0],PC_USB[1],-.2265);
    /* tepa old: quvvat tugmasi + chiroq (pc-setup shularni boshqaradi) */
    const pb=new T.Mesh(new T.CylinderGeometry(.009,.009,.008,16),r.silver);pb.position.set(-.05,Y+.462,.185);g.add(pb);
    const led=new T.Mesh(new T.BoxGeometry(.012,.002,.006),new T.MeshBasicMaterial({color:0xff3b3b}));led.position.set(-.02,Y+.4615,.19);g.add(led);
    bx(g,.014,.003,.008,r.dark,.03,Y+.4605,.19);bx(g,.014,.003,.008,r.dark,.052,Y+.4605,.19);
    g.userData.fans=fans;g.userData.glow=glow;g.userData.led=led;return g}
  return{monitor,pcCase,res}
})();

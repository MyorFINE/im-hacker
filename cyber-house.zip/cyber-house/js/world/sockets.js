/* ==========================================================
 * Modul: js/world/sockets.js
 * Rozetka va kabel boshlang'ich nuqtalari
 * ========================================================== */
/* rozetka + kabel */
const OUT=new T.Vector3(5.79,.4,-2.2),REST=new T.Vector3(1.3,.025,-3.05),OUT2=new T.Vector3(2.6,.4,-6.79),REST2=new T.Vector3(-2.2,.025,-3.1),OUT3=new T.Vector3(3.4,.4,-6.79),REST3=new T.Vector3(2.25,.025,-3.1);
box(2.6,.4,-6.86,.2,.3,.04,L(0xe8e8e8));box(2.6,.4,-6.83,.02,.2,.02,B(0x222222));box(3.4,.4,-6.86,.2,.3,.04,L(0xe8e8e8));box(3.4,.4,-6.83,.02,.2,.02,B(0x222222));
box(5.86,.4,-2.2,.04,.3,.2,L(0xe8e8e8));box(5.83,.4,-2.2,.02,.2,.02,B(0x222222));
const V=T.Vector3,dm2=new T.Object3D(),hand=new V();

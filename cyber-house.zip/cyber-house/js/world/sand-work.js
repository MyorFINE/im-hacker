/* ==========================================================
 * Modul: js/world/sand-work.js
 * Qum bilan ishlash (preview.html asosida, o'yin tizimiga moslab yaxshilangan):
 *   belkurakni olish -> qum uyumidan olish -> qopga to'kish -> to'lgan qopni QO'LDA ko'tarib buyurtma joyiga olib borish.
 * Yaxshilanishlar:
 *  - QUM FIZIKASI: uyum qiyalik burchagi (repose ~34°) bilan ishlaydi — kavlangan joy devori o'zi to'kilib (ko'chki) tekislanadi,
 *    uyum asta-sekin to'ldirib turiladi; olingan qum hajmi haqiqiy (hajm = chuqurlik x yuza) bo'yicha hisoblanadi;
 *  - katta bo'laklar (chunk): belkurakka 12–30 birlik, qopga to'kilganda 20–60 ta yirik dona;
 *  - to'kilish FIZIKASI: har bir dona balistik uchadi (gravitatsiya), qop og'zi/devoriga uriladi, sakraydi, yerga tushsa sekin to'xtaydi;
 *    faqat og'izdan kirgan donalar qopni to'ldiradi (sepilib ketgani yo'qoladi);
 *  - qop: matodagi burmalar, to'lgan sari shishadi, ichida qum sathi ko'tariladi; ko'tarilganda og'zi bog'langan holda qo'lda ko'rinadi;
 *  - hamma narsa yerga/polga tegib turadi, boshqa buyumlar ichiga kirmaydi.
 * Hamma obyektlar BLG (qurilish zonasi guruhi) ichida — hudud o'zgarganda o'zi yashirinadi.
 * ========================================================== */
const SANDWORK=(()=>{
  const C={x:13,z:10.5},R=1.35,H=.78,RAD=96,RNG=44,TAN=.675,CAP=30;
  const SK={x:14.95,z:9.3},SHV={x:11.3,z:12.1},SS=.72;                 /* qop va belkurak joyi (mahalliy); SS — qop masshtabi */
  const S={has:false,load:0,sack:"ground",fill:0,anim:null,hit:null,slump:0,regT:0,pour:null,busy:false};
  const rng=s=>()=>{s=(s*16807)%2147483647;return(s-1)/2147483646};
  const sm=(x)=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x)};
  const hash=(x,y,z)=>{const s=Math.sin(x*127.1+y*311.7+z*74.7)*43758.5453;return s-Math.floor(s)};
  /* ---------- sof hisob: qum uyumi (balandliklar xaritasi, qutb to'ri) ---------- */
  const NV=(RNG+1)*RAD,px=new Float32Array(NV),pz=new Float32Array(NV),ph0=new Float32Array(NV),ph=new Float32Array(NV),area=new Float32Array(NV),nbI=new Int32Array(NV*4),nbD=new Float32Array(NV*4);
  const edgeShape=a=>R*(1+Math.sin(a*3+.5)*.025+Math.sin(a*7)*.012+Math.cos(a*11)*.006+Math.sin(a*17)*.003);
  function profile(r,a){const e=edgeShape(a),n=Math.max(0,1-r/e),irr=Math.sin(a*8+r*3)*.02+Math.sin(a*17-r*5)*.011+Math.cos(r*12+a*4)*.007;return Math.max(0,Math.pow(n,1.12)*H+irr*n)}
  (function buildGrid(){
    for(let j=0;j<=RNG;j++)for(let i=0;i<RAD;i++){const a=i/RAD*Math.PI*2,r=j/RNG*edgeShape(a),v=j*RAD+i;px[v]=Math.cos(a)*r;pz[v]=Math.sin(a)*r;ph0[v]=ph[v]=j===RNG?0:profile(r,a);
      area[v]=j===0?0:(edgeShape(a)/RNG)*(r*2*Math.PI/RAD);
      const nb=[[j,(i+RAD-1)%RAD],[j,(i+1)%RAD],[j-1,i],[j+1,i]];
      nb.forEach((q,k)=>{nbI[v*4+k]=(q[0]<0||q[0]>RNG)?-1:q[0]*RAD+q[1]})}
    /* qo'shni masofalari — hamma nuqtalar hisoblangandan KEYIN */
    for(let v=0;v<NV;v++)for(let k=0;k<4;k++){const w=nbI[v*4+k];nbD[v*4+k]=w<0?0:Math.hypot(px[v]-px[w],pz[v]-pz[w])}}());
  /* qiyalik burchagi (repose): tik devor o'zi to'kiladi */
  function relax(passes){
    for(let p=0;p<passes;p++){
      for(let v=0;v<NV;v++){if(v>=NV-RAD)continue;const hv=ph[v];if(hv<=0)continue;
        for(let k=0;k<4;k++){const w=nbI[v*4+k];if(w<0)continue;const d=nbD[v*4+k];if(d<1e-3)continue;const dh=ph[v]-ph[w]-TAN*d;if(dh>0){const m=Math.min(dh*.45,ph[v]);ph[v]-=m;ph[w]+=m}}}
      let s=0;for(let i=0;i<RAD;i++)s+=ph[i];s/=RAD;for(let i=0;i<RAD;i++)ph[i]=s}}
  /* belkurak bilan olish: (lx,lz) — uyum markaziga nisbatan; qaytaradi: hajm (m3) */
  function dig(lx,lz){const rad=.34;let vol=0;
    for(let v=0;v<NV;v++){const d=Math.hypot(px[v]-lx,pz[v]-lz);if(d>=rad)continue;const inf=1-d/rad,dep=.26*inf,act=Math.min(dep,ph[v]);ph[v]-=act;vol+=act*area[v]}
    return vol}
  const loadFromVol=v=>Math.max(0,Math.min(CAP,v*1000));
  function regen(){let ch=false;for(let v=0;v<NV;v++){const d=ph0[v]-ph[v];if(d>.0005){ph[v]+=Math.min(d,.003+d*.05);ch=true}}return ch}
  /* ---------- THREE obyektlar (kechiktirilgan) ---------- */
  let ready=false,parent=null,pile,pGeo,sandMat,fabric,shovelG,shovelHand,shovelMound,sackG,sackBody,sackSand,sackRim,carryG,grains,gOb,gp=[],mouthY=1.08*SS-.01,mouthR=.44*SS;
  const V3=()=>new T.Vector3();
  function sandTexture(){const s=lowEnd?512:1024,c=cv(s,s),x=c.getContext("2d"),f=rng(5);x.fillStyle="#c2a06b";x.fillRect(0,0,s,s);
    const n=lowEnd?30000:110000;for(let i=0;i<n;i++){x.fillStyle=f()>.5?"rgba(255,231,173,.7)":"rgba(76,48,20,.7)";x.globalAlpha=.1+f()*.3;x.beginPath();x.arc(f()*s,f()*s,f()*1.7+.2,0,6.2832);x.fill()}x.globalAlpha=1;return tex(c,1,1)}
  function fabricTexture(){const s=512,c=cv(s,s),x=c.getContext("2d"),f=rng(9);x.fillStyle="#b4a17e";x.fillRect(0,0,s,s);
    for(let i=0;i<s;i+=3){x.fillStyle="rgba(95,78,48,.18)";x.fillRect(i,0,1,s);x.fillRect(0,i,s,1)}   /* to'qilgan mato iplari */
    for(let i=0;i<40000;i++){x.fillStyle=f()>.5?"rgba(244,226,186,.5)":"rgba(61,45,26,.5)";x.globalAlpha=.1+f()*.3;x.fillRect(f()*s,f()*s,1.5,1.5)}x.globalAlpha=1;return tex(c,3,3)}
  function pileMesh(){
    const g=new T.BufferGeometry(),pos=new Float32Array(NV*3),uv=new Float32Array(NV*2),idx=[];
    for(let v=0;v<NV;v++){pos[v*3]=px[v];pos[v*3+1]=ph[v];pos[v*3+2]=pz[v];uv[v*2]=px[v]*1.2;uv[v*2+1]=pz[v]*1.2}
    for(let j=0;j<RNG;j++)for(let i=0;i<RAD;i++){const a=j*RAD+i,b=j*RAD+(i+1)%RAD,c=(j+1)*RAD+i,d=(j+1)*RAD+(i+1)%RAD;idx.push(a,c,b,b,c,d)}
    g.setAttribute("position",new T.BufferAttribute(pos,3));g.setAttribute("uv",new T.BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();g.computeBoundingSphere();
    const m=new T.Mesh(g,sandMat);m.position.set(C.x,-.012,C.z);return m}
  function syncPile(){const p=pGeo.attributes.position;for(let v=0;v<NV;v++)p.setY(v,ph[v]);p.needsUpdate=true;pGeo.computeVertexNormals()}
  /* chaqiq (chunk) shaklli qum bo'lagi — belkurakdagi uyum uchun */
  function chunkGeo(seg){const g=new T.SphereGeometry(1,seg,Math.max(6,seg-4)),p=g.attributes.position;for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),n=1+(hash(x*3.1,y*3.1,z*3.1)-.5)*.34;p.setXYZ(i,x*n,y*n,z*n)}g.computeVertexNormals();return g}
  /* ----- belkurak modeli: o'q +y (dasta tepada), tig' pastda, ichki tomoni +z ----- */
  function shovelModel(){
    const g=new T.Group(),wood=new T.MeshStandardMaterial({color:0x70431f,roughness:.72}),metal=new T.MeshStandardMaterial({color:0x9aa3a6,roughness:.42,metalness:.35,side:T.DoubleSide});
    const h=new T.Mesh(new T.CylinderGeometry(.026,.034,1.12,14),wood);h.position.y=.99;g.add(h);
    const grip=new T.Mesh(new T.TorusGeometry(.1,.03,10,20,Math.PI),wood);grip.rotation.z=Math.PI;grip.position.y=1.55;g.add(grip);
    /* tig': tor, tomoni ko'tarilgan, o'rtasi botiq; yuqori qirrasi atrofida -.45 rad egilgan */
    const sh=new T.Shape();sh.moveTo(-.24,0);sh.quadraticCurveTo(-.32,.2,-.28,.43);sh.lineTo(.28,.43);sh.quadraticCurveTo(.32,.2,.24,0);sh.lineTo(0,-.09);sh.closePath();
    const bg=new T.ShapeGeometry(sh,14),p=bg.attributes.position,th=-.45,y0=.43;
    for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),dz=.05*(x/.28)*(x/.28),q=y-y0;p.setXYZ(i,x,y0+q*Math.cos(th)-dz*Math.sin(th),q*Math.sin(th)+dz*Math.cos(th))}
    bg.computeVertexNormals();g.add(new T.Mesh(bg,metal));
    const sock=new T.Mesh(new T.CylinderGeometry(.04,.032,.12,12),metal);sock.position.y=.45;g.add(sock);
    return g}
  const G_PIV=new T.Vector3(0,.95,0);        /* qo'l ushlaydigan nuqta (dasta o'rtasi) */
  /* ----- qop ----- */
  const bodyProfile=f=>{const h=1.05+f*.18;return{h,p:[[.30,0],[.34,.06],[.37,.17],[.39,.35],[.40+f*.05,.57],[.43+f*.07,.79],[.44+f*.07,h]]}};
  const radAt=(f,y)=>{const pr=bodyProfile(f).p;for(let i=1;i<pr.length;i++)if(y<=pr[i][1]){const t=(y-pr[i-1][1])/(pr[i][1]-pr[i-1][1]);return pr[i-1][0]+(pr[i][0]-pr[i-1][0])*t}return pr[pr.length-1][0]};
  function foldLathe(pts,seg){const g=new T.LatheGeometry(pts.map(q=>new T.Vector2(q[0],q[1])),seg),p=g.attributes.position;
    for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),a=Math.atan2(z,x),k=1+Math.sin(a*9+y*2.2)*.014+Math.sin(a*5-y*3)*.01;p.setXYZ(i,x*k,y,z*k)}g.computeVertexNormals();return g}
  function buildSack(){
    const f=S.fill/100,pr=bodyProfile(f);
    if(sackBody){sackG.remove(sackBody);sackBody.geometry.dispose()}
    sackBody=new T.Mesh(foldLathe(pr.p,48),fabric);sackBody.position.y=.03;sackG.add(sackBody);
    if(sackRim){sackG.remove(sackRim);sackRim.geometry.dispose()}
    sackRim=new T.Mesh(new T.TorusGeometry(.44+f*.07,.028,10,48),new T.MeshStandardMaterial({color:0x8b7855,roughness:1}));sackRim.rotation.x=Math.PI/2;sackRim.position.y=pr.h+.03;sackG.add(sackRim);
    if(sackSand){sackG.remove(sackSand);sackSand.geometry.dispose();sackSand=null}
    if(S.fill>0){const yS=.1+f*(pr.h-.26),r=radAt(f,yS)-.012,g=new T.CircleGeometry(r,36),p=g.attributes.position;g.rotateX(-Math.PI/2);
      for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i),d=Math.hypot(x,z)/r;p.setY(i,(1-d)*.05+(hash(x*9,z*9,3)-.5)*.012)}g.computeVertexNormals();
      sackSand=new T.Mesh(g,sandMat);sackSand.position.y=yS;sackG.add(sackSand)}
    mouthY=(pr.h+.03)*SS-.01;mouthR=(.44+f*.07)*SS}
  function carryModel(g){
    ensure();const pts=[[.30,0],[.34,.06],[.37,.17],[.40,.4],[.45,.62],[.46,.78],[.41,.92],[.24,1.02],[.10,1.09],[.115,1.15],[.25,1.24]];
    const m=new T.Mesh(foldLathe(pts,40),fabric),tie=new T.Mesh(new T.TorusGeometry(.105,.02,8,20),new T.MeshStandardMaterial({color:0x6b5230,roughness:1}));tie.rotation.x=Math.PI/2;tie.position.y=1.06;
    const w=new T.Group();w.add(m,tie);w.scale.setScalar(.5);w.position.set(.04,-.4,-.02);w.rotation.set(-.22,.25,-.28);g.add(w)}
  function ensure(){
    if(ready)return;ready=true;sandMat=new T.MeshStandardMaterial({map:sandTexture(),color:0xe2c18b,roughness:1,side:T.DoubleSide});fabric=new T.MeshStandardMaterial({map:fabricTexture(),color:0xc1ae87,roughness:1,side:T.DoubleSide})}
  /* ---------- sahnaga o'rnatish ---------- */
  function init(par){
    ensure();parent=par;const B=ECO.build;S.fill=Math.max(0,Math.min(100,B.sandFill||0));
    pile=pileMesh();pGeo=pile.geometry;par.add(pile);
    sackG=new T.Group();sackG.position.set(SK.x,-.01,SK.z);sackG.scale.setScalar(SS);par.add(sackG);buildSack();
    shovelG=shovelModel();shovelG.rotation.set(-Math.PI/2,.35,0,"YXZ");shovelG.scale.setScalar(.85);shovelG.position.set(SHV.x,.04,SHV.z);par.add(shovelG);
    shovelHand=shovelModel();shovelHand.matrixAutoUpdate=false;shovelHand.visible=false;par.add(shovelHand);
    const cg=chunkGeo(12);shovelMound=new T.Mesh(cg,sandMat);shovelMound.rotation.x=-.45;shovelMound.position.set(0,.2,.15);shovelMound.visible=false;shovelHand.add(shovelMound);
    /* zarralar (yirik qum bo'laklari) */
    gOb=new T.Object3D();grains=new T.InstancedMesh(new T.IcosahedronGeometry(1,0),new T.MeshLambertMaterial({color:0xd8b97a}),96);grains.frustumCulled=false;grains.instanceMatrix.setUsage&&grains.instanceMatrix.setUsage(T.DynamicDrawUsage);
    const cc=new T.Color(),f=rng(3);for(let i=0;i<96;i++){gp.push({on:false,p:V3(),v:V3(),r:.02,life:0,rest:0,amt:0});gOb.position.set(0,-9,0);gOb.scale.setScalar(.0001);gOb.updateMatrix();grains.setMatrixAt(i,gOb.matrix);cc.setRGB(.82+f()*.15,.7+f()*.13,.45+f()*.1);grains.setColorAt(i,cc)}
    par.add(grains);return true}
  /* ---------- qo'l holati (kamera bilan birga) ---------- */
  const P0={x:.30,y:-.42,z:-.58,pitch:-.30,yaw:.10,roll:0},PD={x:.20,y:-.64,z:-.82,pitch:-.85,yaw:.04,roll:0},PO={x:.14,y:-.36,z:-.78,pitch:-.50,yaw:.02,roll:0},PP={x:.12,y:-.40,z:-.74,pitch:-1.25,yaw:.0,roll:.0};
  const lerpP=(a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t,pitch:a.pitch+(b.pitch-a.pitch)*t,yaw:a.yaw+(b.yaw-a.yaw)*t,roll:a.roll+(b.roll-a.roll)*t});
  const qB=new T.Quaternion().multiplyQuaternions(new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),Math.PI),new T.Quaternion().setFromAxisAngle(new T.Vector3(1,0,0),-Math.PI/2));
  const _q=new T.Quaternion(),_q2=new T.Quaternion(),_e=new T.Euler(),_p=new T.Vector3(),_o=new T.Vector3(),_s=new T.Vector3(),_pos=new T.Vector3();
  const SC=.8;
  function handPose(p){
    _e.set(p.pitch,p.yaw,p.roll,"YXZ");_q2.setFromEuler(_e);_q.copy(camera.quaternion).multiply(_q2).multiply(qB);
    _p.set(p.x,p.y,p.z).applyQuaternion(camera.quaternion).add(camera.position);_o.copy(G_PIV).multiplyScalar(SC).applyQuaternion(_q);_p.sub(_o);
    _s.set(SC,SC,SC);shovelHand.matrix.compose(_p,_q,_s);shovelHand.matrix.elements[12]-=BX;shovelHand.matrix.elements[14]-=BZ;shovelHand.matrixWorldNeedsUpdate=true}
  /* shovel uchi (tig' ucha) mahalliy koordinatada — zarralar shu yerdan chiqadi */
  function tipLocal(out){_o.set(0,.43+(-.52)*Math.cos(-.45),(-.52)*Math.sin(-.45)).multiplyScalar(1);_o.applyMatrix4(shovelHand.matrix);out.copy(_o);return out}
  /* ---------- harakatlar ---------- */
  const holding=()=>S.has;
  function scoopStart(){
    const rc=new T.Raycaster();camera.getWorldDirection(_pos);rc.set(camera.position,_pos);rc.far=6;const h=rc.intersectObject(pile,false);
    if(!h.length){toast("Qum uyumiga mo'ljallang");return}
    const lx=h[0].point.x-BX-C.x,lz=h[0].point.z-BZ-C.z;    S.hit={x:lx,z:lz};S.anim={k:"scoop",t:0,dur:.8,did:false};
    startAct("Qum olinmoqda",.8,()=>dst(C.x,C.z)<3.9&&!BLD.carry&&S.has,()=>{S.anim=null})}
  function pourStart(){
    if(S.load<=0)return;const n=Math.max(20,Math.min(60,Math.round(S.load*2)));S.pour={left:n,total:n,per:S.load/n,em:0};S.anim={k:"pour",t:0,dur:1.6};
    startAct("Qum to'kilmoqda",1.6,()=>dst(SK.x,SK.z)<2.5&&!BLD.carry&&S.has,()=>{S.anim=null;S.pour=null})}
  function spawnGrain(o){
    const g=gp.find(q=>!q.on);if(!g||!S.pour)return false;const f=Math.random;if(o)g.p.set(o.x,o.y,o.z);else tipLocal(g.p);g.p.x+=(f()-.5)*.1;g.p.z+=(f()-.5)*.1;
    const D=_pos.set(SK.x+(f()+f()+f()-1.5)*.26,mouthY+.03,SK.z+(f()+f()+f()-1.5)*.26),t=.38+f()*.14;g.v.set((D.x-g.p.x)/t,(D.y-g.p.y)/t+4.9*t,(D.z-g.p.z)/t);
    g.amt=S.pour.per;g.r=.018+f()*.018;g.on=true;g.life=0;g.rest=0;g.v.multiplyScalar(.97);return true}
  function absorb(a){S.fill=Math.min(100,S.fill+a);buildSack();ECO.build.sandFill=S.fill;ecoSave()}
  function physics(dt){
    for(let i=0;i<gp.length;i++){const g=gp[i];if(!g.on)continue;
      const py=g.p.y;g.v.y-=9.8*dt;g.p.x+=g.v.x*dt;g.p.y+=g.v.y*dt;g.p.z+=g.v.z*dt;g.life+=dt;
      const dx=g.p.x-SK.x,dz=g.p.z-SK.z,rr=Math.hypot(dx,dz)||1e-4,ox=dx/rr,oz=dz/rr;
      if(py>mouthY&&g.p.y<=mouthY&&g.v.y<0){                                   /* og'iz tekisligidan o'tish */
        if(rr<mouthR-.03&&S.fill<100){g.on=false;absorb(g.amt||0);continue}
        g.p.y=mouthY+.004;g.v.y=Math.abs(g.v.y)*.3;g.v.x+=ox*(.5+Math.random()*.5);g.v.z+=oz*(.5+Math.random()*.5)}   /* qirraga urildi */
      else if(g.p.y<mouthY&&g.p.y>0&&rr<(radAt(S.fill/100,g.p.y/SS)*SS+g.r)){g.p.x=SK.x+ox*(radAt(S.fill/100,g.p.y/SS)*SS+g.r+.002);g.p.z=SK.z+oz*(radAt(S.fill/100,g.p.y/SS)*SS+g.r+.002);g.v.x=ox*Math.abs(g.v.x)*.3+ox*.2;g.v.z=oz*Math.abs(g.v.z)*.3+oz*.2}   /* qop devoriga urildi */
      if(g.p.y<g.r){g.p.y=g.r;g.v.y=Math.abs(g.v.y)<.5?0:-g.v.y*.25;g.v.x*=.55;g.v.z*=.55;if(Math.hypot(g.v.x,g.v.z)<.15)g.rest+=dt}
      if(g.rest>.5||g.life>3){g.rest+=dt;if(g.rest>1.1){g.on=false}}}
    for(let i=0;i<gp.length;i++){const g=gp[i];gOb.position.copy(g.p);const sc=g.on?g.r*(g.rest>.5?Math.max(.05,1-(g.rest-.5)/.6):1):.0001;gOb.scale.setScalar(sc);gOb.rotation.set(i,i*2,i*3);gOb.updateMatrix();grains.setMatrixAt(i,gOb.matrix)}
    grains.instanceMatrix.needsUpdate=true}
  /* ---------- har kadr ---------- */
  function update(dt,now){
    if(!ready)return;dt=Math.min(dt||.016,.05);
    /* piyoda yetkazilgach qop qayta paydo bo'ladi (bo'sh) */
    if(S.sack==="carried"&&!(BLD.carry&&BLD.carry.t==="sand")){S.sack="ground";S.fill=0;ECO.build.sandFill=0;buildSack();sackG.visible=true;ecoSave()}
    /* uyum: ko'chki + qayta to'lish */
    let ch=false;if(S.slump>0){S.slump-=dt;relax(6);ch=true}
    S.regT+=dt;if(S.regT>.25){S.regT=0;if(regen()){relax(1);ch=true}}
    if(ch)syncPile();
    /* belkurak: yerda yoki qo'lda */
    const hold=S.has&&!BLD.carry;shovelG.visible=!S.has;shovelHand.visible=hold;
    if(hold){
      let pose=P0;const a=S.anim;
      if(a){a.t+=dt;const u=a.t/a.dur;
        if(a.k==="scoop"){pose=u<.5?lerpP(P0,PD,sm(u/.5)):lerpP(PD,P0,sm((u-.5)/.5));
          if(u>=.5&&!a.did){a.did=true;const v=dig(S.hit.x,S.hit.z),amt=loadFromVol(v);if(amt<4){toast("Bu joyda qum qolmagan");}else{S.load=Math.min(CAP,S.load+amt);S.slump=1.6;syncPile();toast("Belkurakda: "+Math.round(S.load)+" / "+CAP)}}}
        else if(a.k==="pour"){pose=u<.25?lerpP(P0,PO,sm(u/.25)):u<.8?lerpP(PO,PP,sm((u-.25)/.55)):lerpP(PP,P0,sm((u-.8)/.2));
          if(u>.3&&u<.95&&S.pour){S.pour.em+=dt*S.pour.total/((.95-.3)*a.dur);let n=Math.floor(S.pour.em);S.pour.em-=n;while(n-->0&&S.pour.left>0){if(spawnGrain()){S.pour.left--;S.load=Math.max(0,S.load-S.pour.per)}else break}}}
        if(!BLD.act&&a.t>.05&&a.t<a.dur){S.anim=null;S.pour=null}}               /* bekor qilingan */
      else{pose={x:P0.x,y:P0.y+Math.sin(now/520)*.004,z:P0.z,pitch:P0.pitch+Math.sin(now/700)*.006,yaw:P0.yaw,roll:0}}
      handPose(pose);
      const lf=S.load/CAP;shovelMound.visible=lf>.02;if(shovelMound.visible)shovelMound.scale.set(.2,.24,.012+.09*lf)}
    physics(dt)}
  /* ---------- nishon (E) ---------- */
  const pct=v=>Math.round(v)+"%";
  function cands(add){
    const c=BLD.carry,V=bwv;
    /* qop: yerda */
    if(S.sack==="ground")add(V(SK.x,.4,SK.z),.7,3.6,(()=>{
      if(c)return null;
      if(S.has&&S.load>0){if(S.fill>=100)return["Qop to'la — uni ko'taring (belkurakni qo'ying)",null];return dst(SK.x,SK.z)<2.3?["E — qumni qopga to'kish (qop "+pct(S.fill)+")",pourStart]:["Qopga yaqinroq keling (2 m)",null]}
      if(S.fill>=100)return["E — qopni ko'tarish",()=>startAct("Qop ko'tarilmoqda",1.1,()=>dst(SK.x,SK.z)<3.6&&!BLD.carry&&S.sack==="ground",()=>{BLD.carry={t:"sand",n:1};S.sack="carried";sackG.visible=false;toast("📦 Qum qopi qo'lingizda — kerakli joyga olib boring");jobHud()})];
      return["Qop "+pct(S.fill)+" — belkurak bilan qum soling (to'lgach ko'tariladi)",null]})());
    /* ko'tarilgan qopni joyiga qo'yish */
    if(c&&c.t==="sand")add(V(SK.x,.4,SK.z),.9,3.8,["E — qum qopini joyiga qo'yish",()=>{S.sack="ground";S.fill=100;ECO.build.sandFill=100;buildSack();sackG.visible=true;BLD.carry=null;toast("Qop joyiga qo'yildi");jobHud();ecoSave()}]);
    /* belkurak */
    if(!c){
      if(!S.has)add(V(SHV.x,.1,SHV.z),1.1,3.8,["E — belkurakni olish",()=>startAct("Belkurak olinmoqda",.5,()=>dst(SHV.x,SHV.z)<4.4&&!BLD.carry&&!S.has,()=>{S.has=true;toast("⛏ Belkurak qo'lda — qum uyumiga mo'ljallab E bosing")})]);
      else{
        add(V(C.x,.35,C.z),1.6,4.2,S.load>=CAP-.5?["Belkurak to'la ("+Math.round(S.load)+") — qopga to'king",null]:dst(C.x,C.z)<3.9?["E — qum olish (belkurak "+Math.round(S.load)+"/"+CAP+")",scoopStart]:["Qum uyumiga yaqinroq boring",null]);
        add(V(SHV.x,.1,SHV.z),1.1,3.8,S.load>0?["Avval belkurakdagi qumni to'king",null]:["E — belkurakni qo'yish",()=>{S.has=false;S.anim=null;toast("Belkurak joyiga qo'yildi")}])}}
  }
  return{_sim:(o,n)=>{S.pour={left:n,total:n,per:1,em:0};S.fill=0;let sp=0;for(let i=0;i<n;i++)if(spawnGrain(o))sp++;for(let k=0;k<400;k++)physics(.01);return{spawned:sp,fill:Math.round(S.fill)}},_gp:gp,_stubs:(a,b)=>{gOb=a;grains=b},init,update,cands,carryModel,holding,S,dig,relax,regen,ph,ph0,NV,area,CAP,loadFromVol,C,SK,SHV}
})();

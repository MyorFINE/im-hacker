/* ==========================================================
 * Modul: js/world/wood.js
 * Tabiiy eman (oak) yog'och teksturalari va materiallari.
 * Kompyuter stoli, ovqatlanish stoli va montaj (ish) stoli bir xil dizaynda bo'lishi uchun.
 * Tekstura protsedurali (canvas) — tashqi fayl kerak emas.
 * ========================================================== */
const WOOD=(()=>{
  const S=lowEnd?512:1024,K=S/1024;
  function rng(seed){let s=seed;return()=>{s=(s*16807)%2147483647;return(s-1)/2147483646}}
  function make(baseC,darkC,lightC,seed){
    const c=cv(S,S),x=c.getContext("2d"),r=rng(seed);
    x.fillStyle=baseC;x.fillRect(0,0,S,S);
    /* tolalar */
    for(let i=0;i<1300;i++){const y=r()*S,th=(r()*2.8+.2)*K;x.beginPath();x.strokeStyle=r()>.5?darkC:lightC;x.globalAlpha=.05+r()*.13;x.lineWidth=th;x.moveTo(0,y);let cy=y;for(let px=0;px<=S;px+=32*K){cy+=(r()-.5)*7*K;x.lineTo(px,cy)}x.stroke()}
    /* yillik halqa to'lqinlari */
    for(let i=0;i<30;i++){const y=r()*S;x.beginPath();x.globalAlpha=.12;x.strokeStyle=darkC;x.lineWidth=(r()*3+1)*K;for(let px=0;px<=S;px+=8*K){x.lineTo(px,y+(Math.sin(px*.015/K+i)*5+Math.sin(px*.035/K+i*2)*2)*K)}x.stroke()}
    /* mayda tugunlar */
    for(let i=0;i<9;i++){const px=r()*S,py=r()*S;x.globalAlpha=.18;x.strokeStyle=darkC;x.lineWidth=2*K;x.beginPath();x.ellipse(px,py,(r()*18+5)*K,(r()*5+2)*K,0,0,Math.PI*2);x.stroke()}
    x.globalAlpha=1;
    /* mayda shovqin */
    const im=x.getImageData(0,0,S,S),d=im.data;for(let i=0;i<d.length;i+=4){const n=(r()-.5)*9;d[i]+=n;d[i+1]+=n;d[i+2]+=n}x.putImageData(im,0,0);
    return tex(c,1,1)}
  const tTop=make("#a87546","#60391e","#e1b27b",123),tDark=make("#75472c","#3f2417","#b77a4c",456),tDrw=make("#94603b","#59341e","#c18b5b",789);
  /* ingichka oyoqlar: tola yo'nalishi vertikal bo'lishi uchun tekstura 90° aylantiriladi */
  const tLeg=tDark.clone();tLeg.center.set(.5,.5);tLeg.rotation=Math.PI/2;tLeg.needsUpdate=true;
  const M=(map,rough)=>new T.MeshStandardMaterial({map,roughness:rough,metalness:0});
  return{
    top:M(tTop,.43),          /* stol usti (mat sayqallangan eman) */
    dark:M(tDark,.55),        /* qirralar, orqa panel */
    leg:M(tLeg,.55),          /* oyoqlar */
    drawer:M(tDrw,.5),        /* tortma old paneli */
    edge:new T.MeshStandardMaterial({color:0x59341e,roughness:.55,metalness:0}),
    handle:new T.MeshStandardMaterial({color:0xb9bdc3,roughness:.32,metalness:.35})   /* envMap yo'q — metal juda qorayib ketmasligi uchun metalness past */
  }})();

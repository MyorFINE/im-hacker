/* ==========================================================
 * Modul: js/world/chair-model.js
 * Kompyuter stuli: qizil gaming kreslo (red_gaming_chair_highquality.glb, 40 ming uchburchakka soddalashtirilgan).
 * PBR: charm (rang + AO + g'adir-budurlik + normal xarita), metall g'ildirak/taglik; laptop bilan umumiy yorug'lik muhiti.
 * O'qlar: boshi — g'ildiraklar markazi pol sathida; oldi = +z (suyanchiq -z da); haqiqiy o'lcham ~0.70 x 0.77 x 1.29 m; o'tirish balandligi ~0.48 m.
 * ========================================================== */
const CHAIR=(()=>{
  const D=CHAIR_DATA,Q=D.range/32767;let R=null;
  const dec=(b,Ty)=>{const s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return new Ty(u.buffer)};
  const ld=(url,srgb)=>{const t=new T.TextureLoader().load(url);t.flipY=false;t.encoding=srgb?T.sRGBEncoding:T.LinearEncoding;t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=lowEnd?2:8;return t};
  function res(){
    if(R)return R;
    const p16=dec(D.p,Int16Array),p=new Float32Array(p16.length);for(let i=0;i<p16.length;i++)p[i]=p16[i]*Q;
    const uq=dec(D.uv,Uint16Array),uv=new Float32Array(uq.length);for(let i=0;i<uq.length;i++)uv[i]=uq[i]/65535;
    const g=new T.BufferGeometry();g.setAttribute("position",new T.BufferAttribute(p,3));g.setAttribute("normal",new T.BufferAttribute(dec(D.nr,Int8Array),3,true));
    const ua=new T.BufferAttribute(uv,2);g.setAttribute("uv",ua);g.setAttribute("uv2",ua);   /* AO xaritasi uv2 dan o'qiydi (asl modelda hamma UV to'plamlari bir xil) */
    g.setIndex(new T.BufferAttribute(D.idx32?dec(D.i,Uint32Array):dec(D.i,Uint16Array),1));g.computeBoundingSphere();
    let env=null;try{env=LAPTOP.env()}catch(e){}
    const orm=ld(D.tex.orm,false);
    const m=new T.MeshStandardMaterial({map:ld(D.tex.base,true),aoMap:orm,roughnessMap:orm,metalnessMap:orm,normalMap:ld(D.tex.nrm,false),normalScale:new T.Vector2(1,1),metalness:1,roughness:1,envMap:env,envMapIntensity:.9});
    return R={g,m}}
  function build(){const r=res(),g=new T.Group(),o=new T.Mesh(r.g,r.m);g.add(o);return g}
  return{build,res,seatH:D.seatH,bbox:D.bbox}
})();

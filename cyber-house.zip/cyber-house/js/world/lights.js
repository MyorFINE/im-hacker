/* ==========================================================
 * Modul: js/world/lights.js
 * Yoritgichlar (lampa, nuqtaviy yorug'lik)
 * ========================================================== */
/* ---------- yorug’lik ---------- */
scene.add(new T.HemisphereLight(0xa8c4de,0x1b2128,1.05));
const lamp=new T.PointLight(0xffd9a0,.9,5);lamp.position.set(-1.3,1.55,-3.6);scene.add(lamp);
const cl=new T.PointLight(0xdfeaff,.75,16);cl.position.set(0,3.7,-.5);scene.add(cl);
const mLight=new T.PointLight(0x4fc3ff,0,4.5);mLight.position.set(0,1.3,-3.3);scene.add(mLight);

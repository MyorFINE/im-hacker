/* ==========================================================
 * Modul: js/world/lights.js
 * Yoritgichlar (lampa, nuqtaviy yorug'lik)
 * ========================================================== */
/* ---------- yorug’lik ---------- */
scene.add(new T.HemisphereLight(0xe3e6ea,0x2b2a28,.6));   /* devorlar sut rangida — xona biroz qoraroq, yorug'lik tabiiy */
const lamp=new T.PointLight(0xffd9a0,.9,5);lamp.position.set(-1.58,1.55,-3.6);scene.add(lamp);
const cl=new T.PointLight(0xfff1de,.42,9);cl.position.set(-3,4.0,-1);scene.add(cl);
for(const x of[0,3]){const l=new T.PointLight(0xfff1de,.42,9);l.position.set(x,4.0,-1);scene.add(l)}   /* shiftdagi 3 ta panel — tabiiy iliq oq nur */
const mLight=new T.PointLight(0x4fc3ff,0,4.5);mLight.position.set(MON1.gx,1.3,-3.3);scene.add(mLight);

/* ==========================================================
 * Modul: js/world/oak-desk.js
 * Eman (oak) stol: preview.html dagi "Premium Wooden Desk" asosida.
 * Kompyuter stoli (desk-chair.js) va ish stoli (bench-table.js) shu yerdan quriladi.
 * three.js r128 uchun moslangan: RoundedBox o'rniga rbox(), yengil Lambert materiallar.
 * ========================================================== */
/* ---------- protsedurali yog'och teksturasi (preview.html dagi createWoodTexture) ---------- */
function oakTexture(base,dark,light,seed){
 const S=lowEnd?256:512,c=cv(S,S),x=c.getContext("2d");x.fillStyle=base;x.fillRect(0,0,S,S);x.save();x.scale(S/1024,S/1024);
 let rs=seed;const rnd=()=>{rs=(rs*16807)%2147483647;return(rs-1)/2147483646};
 for(let i=0;i<1300;i++){const y=rnd()*1024;x.beginPath();x.strokeStyle=rnd()>.5?dark:light;x.globalAlpha=.05+rnd()*.13;x.lineWidth=rnd()*2.8+.2;x.moveTo(0,y);let cy=y;for(let px=0;px<=1024;px+=32){cy+=(rnd()-.5)*7;x.lineTo(px,cy)}x.stroke()}
 for(let i=0;i<30;i++){const y=rnd()*1024;x.beginPath();x.globalAlpha=.12;x.strokeStyle=dark;x.lineWidth=rnd()*3+1;for(let px=0;px<=1024;px+=8)x.lineTo(px,y+Math.sin(px*.015+i)*5+Math.sin(px*.035+i*2)*2);x.stroke()}
 for(let i=0;i<9;i++){const px=rnd()*1024,py=rnd()*1024;x.globalAlpha=.18;x.strokeStyle=dark;x.lineWidth=2;x.beginPath();x.ellipse(px,py,rnd()*18+5,rnd()*5+2,0,0,Math.PI*2);x.stroke()}
 x.restore();x.globalAlpha=1;
 const im=x.getImageData(0,0,S,S),d=im.data;for(let i=0;i<d.length;i+=4){const n=(rnd()-.5)*9;d[i]+=n;d[i+1]+=n;d[i+2]+=n}x.putImageData(im,0,0);
 const t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=lowEnd?1:4;return t}
const _oT=oakTexture("#a87546","#60391e","#e1b27b",123),_oL=oakTexture("#75472c","#3f2417","#b77a4c",456),_oD=oakTexture("#94603b","#59341e","#c18b5b",789);
const OAK={top:L(0xffffff,{map:_oT}),leg:L(0xffffff,{map:_oL}),drw:L(0xffffff,{map:_oD}),drwIn:L(0xb0b0b0,{map:_oD}),edge:L(0x59341e),
 metal:new T.MeshPhongMaterial({color:0xb4b7bb,specular:0xffffff,shininess:90})};
/* ---------- yumaloq burchakli quti (RoundedBoxGeometry o'rniga; s — TOQ son: 3 yoki 5) ---------- */
function rbox(w,h,d,r,s,vert,uvm){
 s=s||3;r=Math.min(r,w/2-.001,h/2-.001,d/2-.001);uvm=uvm||1.6;
 const g=new T.BoxGeometry(1,1,1,s,s,s),p=g.attributes.position,n=g.attributes.normal,u=g.attributes.uv,hs=.5/s,bx=w/2-r,by=h/2-r,bz=d/2-r,per=(s+1)*(s+1);
 for(let i=0;i<p.count;i++){
  const px=p.getX(i),py=p.getY(i),pz=p.getZ(i),sx=Math.sign(px),sy=Math.sign(py),sz=Math.sign(pz);
  let nx=px-sx*hs,ny=py-sy*hs,nz=pz-sz*hs;const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;
  const X=bx*sx+nx*r,Y=by*sy+ny*r,Z=bz*sz+nz*r;p.setXYZ(i,X,Y,Z);n.setXYZ(i,nx,ny,nz);
  const f=Math.floor(i/per);let a,b;if(f<2){a=Z;b=Y}else if(f<4){a=X;b=Z}else{a=X;b=Y}
  if(vert&&(f<2||f>3)){const t=a;a=b;b=t}u.setXY(i,a/uvm+.5,b/uvm+.5)}
 return g}
/* ---------- to'liq stol: usti, qirra chiziqlari, 4 oyoq, yon va orqa tayanchlar ----------
 * o: par(ota), st(1 — qotirilgan), cx,cz(markaz), W,D(usti o'lchami), y(usti balandligi), th(qalinlik), r(yumaloqlik),
 *    lw(oyoq qalinligi), lx,lz(oyoq markazining siljishi), ah,aw(tayanch bo'yi/eni), back(-1/+1: orqa tayanch tomoni)
 * Qaytaradi: oyoq va tayanchlarning to'qnashuv qutilari [x0,x1,y0,y1,z0,z1] */
function buildOakDesk(o){
 const par=o.par,add=(m,x,y,z)=>{m.position.set(x,y,z);par.add(m);if(o.st){m.matrixAutoUpdate=false;m.updateMatrix()}return m};
 const cx=o.cx,cz=o.cz,W=o.W,D=o.D,Y=o.y,th=o.th,u=Y-th,lw=o.lw,lx=o.lx,lz=o.lz,ah=o.ah,aw=o.aw,cb=[];
 add(new T.Mesh(rbox(W,th,D,o.r,5,0,W),OAK.top),cx,Y-th/2,cz);
 [-1,1].forEach(s=>add(new T.Mesh(new T.BoxGeometry(W-.12,.018,.025),OAK.edge),cx,u-.003,cz+s*(D/2-.015)));
 [-1,1].forEach(sx=>[-1,1].forEach(sz=>{add(new T.Mesh(rbox(lw,u,lw,.012,3,1),OAK.leg),cx+sx*lx,u/2,cz+sz*lz);cb.push([cx+sx*lx-lw/2,cx+sx*lx+lw/2,0,u,cz+sz*lz-lw/2,cz+sz*lz+lw/2])}));
 [-1,1].forEach(sx=>{add(new T.Mesh(new T.BoxGeometry(aw,ah,2*lz),OAK.leg),cx+sx*lx,u-ah/2,cz);cb.push([cx+sx*lx-aw/2,cx+sx*lx+aw/2,u-ah,u,cz-lz,cz+lz])});
 const bz=cz+o.back*lz;add(new T.Mesh(new T.BoxGeometry(2*lx,ah,aw),OAK.leg),cx,u-ah/2,bz);cb.push([cx-lx,cx+lx,u-ah,u,bz-aw/2,bz+aw/2]);
 return cb}

/* ==========================================================
 * Modul: js/world/monitor-base.js
 * Monitor: asosiy korpus va ekran teksturasi
 * ========================================================== */
/* monitor */
/* 1-monitor: g1 — stol markazidan chapda, ichkariga burilgan; i1 — asl (dunyo) koordinatalarni saqlovchi ichki guruh */
const g1=new T.Group();g1.position.set(MON1.gx,0,MON1.gz);g1.rotation.y=MON1.ry;scene.add(g1);
const i1=new T.Group();i1.position.set(0,0,-MON1.gz);g1.add(i1);
i1.add(box(0,1.3,-3.8,1.02,.6,.035,L(0x0c0f13)));i1.add(box(0,1.3,-3.84,.5,.4,.06,L(0x0a0c10)));

const K=mobile?1:1.25,sc=cv(W*K,H*K),sx=sc.getContext("2d"),bc=cv(VW*K,H*K),c=bc.getContext("2d");c.scale(K,K);
const scrTex=tex(sc);scrTex.generateMipmaps=false;scrTex.minFilter=T.LinearFilter;scrTex.anisotropy=8;const monitor=new T.Mesh(new T.PlaneGeometry(.96,.54),new T.MeshBasicMaterial({map:scrTex}));
monitor.position.set(0,1.3,-3.781);i1.add(monitor);
const mled=new T.Mesh(new T.SphereGeometry(.015,6,6),B(0xff9a1f));mled.position.set(.4,1.012,-3.781);i1.add(mled);

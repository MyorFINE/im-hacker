/* ==========================================================
 * Modul: js/world/textures.js
 * Pol, devor teksturalari va plakat
 * ========================================================== */
/* teksturalar */
const fc=cv(256,256),fx=fc.getContext("2d");fx.fillStyle="#2b333d";fx.fillRect(0,0,256,256);
for(let i=0;i<500;i++){fx.fillStyle="rgba("+(i%2?"255,255,255":"0,0,0")+",.03)";fx.fillRect(Math.random()*256,Math.random()*256,3,3)}
fx.strokeStyle="#161c23";fx.lineWidth=3;fx.strokeRect(0,0,256,256);fx.strokeRect(0,0,128,128);fx.strokeRect(128,128,128,128);
const wc=cv(256,256),wx=wc.getContext("2d");wx.fillStyle="#3a4553";wx.fillRect(0,0,256,256);wx.fillStyle="#323c49";wx.fillRect(4,4,120,248);wx.fillRect(132,4,120,248);
function poster(t1,t2,col){const c=cv(512,720),x=c.getContext("2d");x.fillStyle="#05080c";x.fillRect(0,0,512,720);x.strokeStyle=col;x.lineWidth=6;x.strokeRect(14,14,484,692);
 x.fillStyle=col;x.font="bold 120px monospace";x.textAlign="center";x.shadowColor=col;x.shadowBlur=24;x.fillText(t1,256,300);x.shadowBlur=0;x.font="26px monospace";x.fillStyle="#8fb4c8";
 t2.forEach((s,i)=>x.fillText(s,256,380+i*38));return tex(c)}

/* ==========================================================
 * Modul: js/world/room.js
 * Xona: devorlar, pol, shift, eshik, oyna
 * ========================================================== */
/* ---------- xona ---------- */
box(0,-.15,0,12,.3,14,L(0xffffff,{map:tex(fc,6,7)}));
const wm=L(0xffffff,{map:tex(wc,6,2)});
box(0,4.5,0,12,.2,14,L(0x252c35));
box(-5.125,2.15,-7,1.75,4.5,.25,wm);box(1.525,2.15,-7,8.95,4.5,.25,wm);box(-3.6,3.4,-7,1.3,2.2,.25,wm);box(-6,2.15,0,.25,4.5,14,wm);box(6,2.15,0,.25,4.5,14,wm);box(0,2.15,7,12,4.5,.25,wm);
for(const [x,z,w,d] of [[-5.075,-6.85,1.65,.1],[1.475,-6.85,8.85,.1],[0,6.85,11.8,.1],[-5.85,0,.1,13.8],[5.85,0,.1,13.8]])box(x,.09,z,w,.18,d,L(0x161b21));
for(const x of [-3,0,3])box(x,4.38,-1,.9,.04,1.6,B(0xe6f4ff));
const sc0=cv(1024,256),sx0=sc0.getContext("2d");sx0.fillStyle="#0c141d";sx0.fillRect(0,0,1024,256);sx0.textAlign="center";sx0.shadowColor="#00bce9";sx0.shadowBlur=22;sx0.fillStyle="#a8efff";sx0.font="bold 90px monospace";sx0.fillText("CYBER HOUSE",512,130);sx0.shadowBlur=0;sx0.fillStyle="#4289a5";sx0.font="30px monospace";sx0.fillText("SECURITY OPERATIONS LAB",512,185);
const sign=new T.Mesh(new T.PlaneGeometry(3.6,.9),B(0xffffff));sign.material.map=tex(sc0);sign.position.set(0,3.2,-6.86);scene.add(sign);
const p1=new T.Mesh(new T.PlaneGeometry(1.3,1.83),B(0xffffff));p1.material.map=poster("KALI",["the quieter you","become, the more","you can hear"],"#2f9bff");p1.position.set(-5.86,2.3,-1.5);p1.rotation.y=Math.PI/2;scene.add(p1);
const p2=new T.Mesh(new T.PlaneGeometry(1.1,1.55),B(0xffffff));p2.material.map=poster("root#",["nmap · wireshark","burp · metasploit"],"#19e6a1");p2.position.set(-5.86,2.3,1.2);p2.rotation.y=Math.PI/2;scene.add(p2);
{/* deraza */const c=cv(512,256),x=c.getContext("2d"),g=x.createLinearGradient(0,0,0,256);g.addColorStop(0,"#0b1530");g.addColorStop(1,"#243a63");x.fillStyle=g;x.fillRect(0,0,512,256);
 for(let i=0;i<40;i++){x.fillStyle="#101a2e";const h=30+Math.random()*90;x.fillRect(i*13,256-h,11,h);for(let j=0;j<5;j++){x.fillStyle=Math.random()>.5?"#ffd98a":"#2a3a5a";x.fillRect(i*13+2,256-h+j*14+4,3,4)}}
 x.fillStyle="#e8f0ff";x.beginPath();x.arc(430,50,14,0,7);x.fill();
 const w=new T.Mesh(new T.PlaneGeometry(3.2,1.6),B(0xffffff));w.material.map=tex(c);w.position.set(5.86,2.4,2.6);w.rotation.y=-Math.PI/2;scene.add(w);
 box(5.85,3.24,2.6,.08,.07,3.3,L(0x10151b));box(5.85,1.56,2.6,.08,.07,3.3,L(0x10151b));box(5.85,2.4,2.6,.08,1.7,.07,L(0x10151b));}

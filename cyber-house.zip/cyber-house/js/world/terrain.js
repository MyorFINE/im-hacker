/* ==========================================================
 * Modul: js/world/terrain.js
 * Qurilish zonasi yeri — realistic_first_person_construction_site.html dagi yer asosida:
 *  - loyqa-tuproq (clay) teksturasi + yumshoq relyef (tepalik/pastliklar);
 *  - g'ildirak izlari (relyefga yopishib boradi), loyqa balchiqlar;
 *  - realistik toshlar: shovqin bilan deformatsiyalangan qirrali shakllar, har xil kattalik, qisman ko'milgan, rang farqli.
 * (Fayldagi qurilish buyumlari olinmagan.)
 * MUHIM — joylashuv xavfsizligi: relyef bino, pallet, plita, iskala, xandaq, darvoza, daraxt, balchiq atrofida
 * silliq ravishda 0 ga tushadi (tekis), shuning uchun mavjud modellar havoda qolmaydi va yerga kirib ketmaydi.
 * Toshlar bino/pallet/daraxt/balchiq/izlar ustida paydo bo'lmaydi; yirik toshlar to'qnashuvga ega.
 * ========================================================== */
const TERRAIN=(()=>{
  const X0=-20,X1=20,Z0=-16,Z1=16.3,BASE=-.01;
  /* o'tsiz/tekis joylar [x0,x1,z0,z1] — build-zone dagi buyumlar bilan mos */
  const EX=[[10.1,19.4,-6.9,.9],[9.4,11,-4.2,-1.8],[-3.6,3.6,-10.6,-7.4],[-16.8,-13.2,4.3,6.7],[-16.5,-13.5,-3.6,-1.4],[6.6,10.4,9.7,11.3],[10.8,15.8,8.6,12.7],[-7.7,-4.3,9.7,11.3],
            [8.2,11.8,-12.6,-10.2],[-9.5,-7.5,-10.5,-8.5],[-14,-12,-9.7,-8.3],[-14.9,-9.1,8.9,11.1],[-2.8,2.8,13.8,16.4],[5.3,5.7,5.8,6.2]];
  /* vazifa (tushirish) halqalari atrofi: tosh/o't yo'q, yer tekis */
  const KEEP=[[8.5,11.5,-10.7,-7.7],[-14.5,-11.5,-8.3,-5.3]];
  const rng=s=>()=>{s=(s*16807)%2147483647;return(s-1)/2147483646};
  const sm=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)};
  const rectD=(e,x,z)=>Math.hypot(Math.max(e[0]-x,0,x-e[1]),Math.max(e[2]-z,0,z-e[3]));
  const TR=()=>(typeof BUILDPROPS!=="undefined"?BUILDPROPS.TREES:[]);
  const pathX=z=>Math.sin(z*.12)*.5;                       /* darvozadan plitagacha g'ildirak izi o'qi */
  const PZ0=-6.2,PZ1=16;
  let _plan=null;
  function plan(){
    if(_plan)return _plan;const f=rng(515),pud=[],tr=TR();
    const free=(x,z,r)=>{for(const e of EX)if(rectD(e,x,z)<r+.8)return false;for(const t of tr)if(Math.hypot(x-t[0],z-t[1])<r+1.6)return false;if(z>PZ0-1&&Math.abs(x-pathX(z))<2.4+r)return false;return x>X0+3&&x<X1-3&&z>Z0+3&&z<Z1-3};
    for(let i=0,g=0;i<13&&g<400;g++){const x=X0+3+f()*(X1-X0-6),z=Z0+3+f()*(Z1-Z0-6),r=.35+f()*.8;if(free(x,z,r*1.1)){pud.push({x,z,r});i++}}
    return _plan={pud}}
  /* yer balandligi (mahalliy y). Relyef 0..4.5 sm, buyumlar atrofida 0 ga tushadi */
  function relief(x,z){const r=Math.sin(x*.14+z*.07)*.10+Math.sin(z*.31)*.045+Math.sin(x*.5+z*.4)*.018;return(r/.163*.5+.5)*.045}
  function mask(x,z){
    let m=1;for(const e of EX)m=Math.min(m,sm(.3,1.8,rectD(e,x,z)));for(const e of KEEP)m=Math.min(m,sm(.3,1.5,rectD(e,x,z)));
    for(const t of TR())m=Math.min(m,sm(.9,2.1,Math.hypot(x-t[0],z-t[1])));
    for(const p of plan().pud)m=Math.min(m,sm(p.r*1.3+.1,p.r*1.3+.9,Math.hypot(x-p.x,z-p.z)));
    m=Math.min(m,sm(.5,2.5,Math.min(x-X0,X1-x,z-Z0,Z1-z)));return m}
  const heightAt=(x,z)=>BASE+relief(x,z)*mask(x,z);
  const blocked=(x,z,m)=>{m=m||0;for(const e of EX.concat(KEEP))if(x>e[0]-m&&x<e[1]+m&&z>e[2]-m&&z<e[3]+m)return true;return false};
  /* ---------- tuproq teksturasi (fayldagi usul) ---------- */
  function dirtTexture(){
    const S=lowEnd?512:1024,k=S/1024,c=cv(S,S),x=c.getContext("2d"),f=rng(31);
    x.fillStyle="#75634b";x.fillRect(0,0,S,S);
    const wrapE=(px,py,rx,ry,a)=>{for(const ox of[-S,0,S])for(const oy of[-S,0,S]){const X=px+ox,Y=py+oy,m=Math.max(rx,ry);if(X<-m||X>S+m||Y<-m||Y>S+m)continue;x.beginPath();x.ellipse(X,Y,rx,ry,a,0,6.2832);x.fill()}};
    const N=lowEnd?30000:90000;
    for(let i=0;i<N;i++){const v=f(),r=(1+f()*9)*k;x.globalAlpha=.04+f()*.17;x.fillStyle=v<.35?"#302b22":v<.7?"#b49a70":"#d0b78e";wrapE(f()*S,f()*S,r,r*(.3+f()),f()*3.14)}
    x.globalAlpha=1;return tex(c,4.6,3.8)}
  function ground(){
    const g=new T.PlaneGeometry(X1-X0,Z1-Z0,92,76);g.rotateX(-Math.PI/2);const p=g.attributes.position;
    for(let i=0;i<p.count;i++)p.setY(i,heightAt(p.getX(i),p.getZ(i)));
    g.computeVertexNormals();return new T.Mesh(g,new T.MeshStandardMaterial({map:dirtTexture(),roughness:1}))}
  /* ---------- toshlar ---------- */
  const hash=(x,y,z)=>{const s=Math.sin(x*127.1+y*311.7+z*74.7)*43758.5453;return s-Math.floor(s)};
  function vn(x,y,z){const ix=Math.floor(x),iy=Math.floor(y),iz=Math.floor(z),fx=x-ix,fy=y-iy,fz=z-iz,u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy),w=fz*fz*(3-2*fz),L=(a,b,t)=>a+(b-a)*t,h=(a,b,c)=>hash(ix+a,iy+b,iz+c);
    return L(L(L(h(0,0,0),h(1,0,0),u),L(h(0,1,0),h(1,1,0),u),v),L(L(h(0,0,1),h(1,0,1),u),L(h(0,1,1),h(1,1,1),u),v),w)}
  const fbm=(x,y,z)=>vn(x,y,z)*.55+vn(x*2,y*2,z*2)*.3+vn(x*4,y*4,z*4)*.15;
  function rockGeo(seed,detail,sx,sz){
    const g=new T.IcosahedronGeometry(1,detail),p=g.attributes.position,n=p.count,col=new Float32Array(n*3);
    for(let i=0;i<n;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),nn=fbm(x*1.7+seed,y*1.7+seed*1.3,z*1.7-seed);
      let r=.74+nn*.62;r=Math.round(r*6)/6*.55+r*.45;                         /* biroz qirrali (chaqiq) shakl */
      let X=x*r*sx,Y=y*r*.62,Z=z*r*sz;if(Y<-.28)Y=-.28+(Y+.28)*.1;           /* asosi deyarli tekis — yerga o'tiradi */
      p.setXYZ(i,X,Y,Z);
      const c2=fbm(x*3+seed*2,y*3,z*3),sh=.62+c2*.62*(.6+r*.4),warm=hash(seed,1,2)*.06;
      col[i*3]=(.50+warm)*sh;col[i*3+1]=(.48+warm*.6)*sh;col[i*3+2]=.43*sh}
    g.setAttribute("color",new T.BufferAttribute(col,3));g.computeVertexNormals();g.computeBoundingBox();return g}
  const rockMat=()=>new T.MeshLambertMaterial({color:0xffffff,vertexColors:true});
  function addRocks(parent,col){
    const f=rng(8080),tr=TR(),pud=plan().pud,spots=[];
    const okAt=(x,z,r)=>{if(x<X0+.6||x>X1-.6||z<Z0+.6||z>Z1-.6)return false;if(blocked(x,z,r+.15))return false;for(const t of tr)if(Math.hypot(x-t[0],z-t[1])<r+.6)return false;
      for(const p of pud)if(Math.hypot(x-p.x,z-p.z)<p.r*1.3+r)return false;if(z>PZ0-.5&&Math.abs(x-pathX(z))<1.9+r)return false;for(const s of spots)if(Math.hypot(x-s.x,z-s.z)<s.r+r)return false;return true};
    const sets=[{geo:[rockGeo(1.3,2,1,.85),rockGeo(4.1,2,.9,1.1),rockGeo(7.7,2,1.1,.9)],n:45,smin:.2,smax:.5,solid:true,cluster:true},
                {geo:[rockGeo(2.2,1,1,.9),rockGeo(5.5,1,.9,1)],n:260,smin:.06,smax:.17,solid:false,cluster:true},
                {geo:[rockGeo(3.3,1,1,1)],n:520,smin:.022,smax:.06,solid:false,cluster:false}];
    const cent=[];for(let i=0;i<12;i++)cent.push([X0+2+f()*(X1-X0-4),Z0+2+f()*(Z1-Z0-4)]);
    const o=new T.Object3D(),c=new T.Color();let total=0;
    for(const st of sets){const per=st.geo.length,items=st.geo.map(()=>[]);
      for(let i=0,g=0;i<st.n&&g<st.n*30;g++){
        let x,z;if(st.cluster&&f()<.7){const q=cent[Math.floor(f()*cent.length)];x=q[0]+(f()+f()+f()-1.5)*3.4;z=q[1]+(f()+f()+f()-1.5)*3.4}else{x=X0+f()*(X1-X0);z=Z0+f()*(Z1-Z0)}
        const s=st.smin+Math.pow(f(),1.6)*(st.smax-st.smin),ay=.55+f()*.6,rad=s*1.05*(st.solid?1:.7);
        if(st.smax>=.17?!okAt(x,z,rad):(x<X0+.4||x>X1-.4||z<Z0+.4||z>Z1-.4||blocked(x,z,.1)||(z>PZ0-.5&&Math.abs(x-pathX(z))<.9&&f()<.7)))continue;
        let bad=false;if(st.smax<.17){for(const t of tr)if(Math.hypot(x-t[0],z-t[1])<.5)bad=true;for(const p of pud)if(Math.hypot(x-p.x,z-p.z)<p.r*1.3+.05)bad=true}if(bad)continue;
        items[Math.floor(f()*per)].push({x,z,s,ay,ry:f()*6.2832,rx:(f()-.5)*.3,rz:(f()-.5)*.3,t:.82+f()*.34,w:f()});
        if(st.smax>=.17)spots.push({x,z,r:rad});i++}
      st.geo.forEach((geo,gi)=>{const it=items[gi];if(!it.length)return;
        const bb=geo.boundingBox,im=new T.InstancedMesh(geo,rockMat(),it.length);
        it.forEach((r,k)=>{const gy=heightAt(r.x,r.z),h=(bb.max.y-bb.min.y)*r.s*r.ay;
          o.position.set(r.x,gy-bb.min.y*r.s*r.ay-h*.2,r.z);o.rotation.set(r.rx,r.ry,r.rz);o.scale.set(r.s,r.s*r.ay,r.s);o.updateMatrix();im.setMatrixAt(k,o.matrix);
          c.setRGB(r.t*(1+(r.w-.5)*.12),r.t,r.t*(1-(r.w-.5)*.1));im.setColorAt(k,c);
          if(st.solid&&col)col(r.x,r.z,r.s*.8,r.s*.8)});
        im.instanceMatrix.needsUpdate=true;im.instanceColor.needsUpdate=true;im.frustumCulled=false;parent.add(im);total+=it.length})}
    return{rocks:total,spots}}
  /* ---------- balchiq va g'ildirak izlari ---------- */
  function addPuddles(parent){
    const water=new T.MeshStandardMaterial({color:0x4c514c,roughness:.23,metalness:.05}),ring=new T.MeshBasicMaterial({color:0x3a3328,transparent:true,opacity:.55,depthWrite:false});
    for(const p of plan().pud){const gy=heightAt(p.x,p.z);
      const w=new T.Mesh(new T.CircleGeometry(p.r,24),water);w.rotation.x=-Math.PI/2;w.scale.set(1,.45,.55);w.position.set(p.x,gy+.012,p.z);parent.add(w);   /* scale: rotatsiyadan keyin (x,z) bo'ylab */
      const m=new T.Mesh(new T.CircleGeometry(p.r*1.28,24),ring);m.rotation.x=-Math.PI/2;m.scale.set(1,.5,.6);m.position.set(p.x,gy+.005,p.z);parent.add(m)}}
  function addRuts(parent){
    const mat=new T.MeshStandardMaterial({color:0x514432,roughness:1,transparent:true,opacity:.55,depthWrite:false,side:T.DoubleSide});
    for(let l=0;l<4;l++){const ox=-1.0+l*.55,N=Math.ceil((PZ1-PZ0)/.25),pos=[],idx=[];
      for(let i=0;i<=N;i++){const z=PZ1-i*(PZ1-PZ0)/N,cx=pathX(z)+ox+Math.sin(z*.35+l)*.05,cz=z,w=.115,y=heightAt(cx,cz)+.012;pos.push(cx-w,y,cz,cx+w,heightAt(cx+w,cz)+.012,cz)}
      for(let i=0;i<N;i++){const a=i*2;idx.push(a,a+1,a+2,a+1,a+3,a+2)}
      const g=new T.BufferGeometry();g.setAttribute("position",new T.Float32BufferAttribute(pos,3));g.setIndex(idx);g.computeVertexNormals();parent.add(new T.Mesh(g,mat))}}
  let _spots=[];
  function addTo(parent,col){addPuddles(parent);addRuts(parent);const r=addRocks(parent,col);_spots=r.spots;return r}
  /* o't o'smaydigan joylar: buyumlar, balchiq, tosh, g'ildirak izlari yo'lagi */
  function blockedGrass(x,z){
    if(blocked(x,z,.18))return true;
    for(const p of plan().pud)if(Math.hypot(x-p.x,z-p.z)<p.r*1.3+.12)return true;
    for(const s of _spots)if(Math.hypot(x-s.x,z-s.z)<s.r+.06)return true;
    return z>PZ0-.3&&z<PZ1+.5&&Math.abs(x-pathX(z))<1.75}
  /* o't zichligi: faqat chetlarda zich, o'rtada siyrak va notekis (tabiiy) */
  function grassP(x,z){const e=Math.min(x-X0,X1-x,z-Z0,Z1-z),n=.5+.5*Math.sin(x*.7+Math.sin(z*.4)*2)*Math.sin(z*.6+1.3);return(.05+.95*sm(11,3,e))*(.3+.7*n)}
  return{EX,heightAt,blocked,blockedGrass,grassP,ground,addTo,plan,rectD,pathX,PZ0,PZ1,rockGeo,X0,X1,Z0,Z1}
})();

/* ==========================================================
 * Modul: js/world/keyboard-model.js
 * Klaviatura UGREEN K371 (ILya Gamzayev, CC-BY-4.0) — model O'ZGARTIRILMAGAN: faqat bir tekis masshtab (KB_K) qo'llanadi,
 * shunda u stol va monitorlar bilan bir o'lchamda ko'rinadi (asl: 29 x 10 sm, o'yinda: 29*KB_K sm).
 * PBR: rang (tugma yozuvlari), g'adir-budurlik, normal xarita; laptop bilan umumiy yorug'lik muhiti.
 * O'qlar: boshi — stol sathida markaz; oldi (yozuvchi tomoni) = +z; orqa (USB-C porti) = -z.
 * ========================================================== */
const KBM=(()=>{
  const D=KB_DATA;let R=null;
  const dec=(b,Ty)=>{const s=atob(b),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return new Ty(u.buffer)};
  const ld=(url,srgb)=>{const t=new T.TextureLoader().load(url);t.flipY=false;t.encoding=srgb?T.sRGBEncoding:T.LinearEncoding;t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=lowEnd?4:16;return t};
  function res(){
    if(R)return R;const g=new T.BufferGeometry();
    g.setAttribute("position",new T.BufferAttribute(dec(D.p,Float32Array),3));g.setAttribute("normal",new T.BufferAttribute(dec(D.nr,Float32Array),3));g.setAttribute("uv",new T.BufferAttribute(dec(D.uv,Float32Array),2));
    g.setIndex(new T.BufferAttribute(dec(D.i,Uint16Array),1));g.computeBoundingSphere();
    let env=null;try{env=LAPTOP.env()}catch(e){}
    const mr=ld(D.tex.mr,false),m=new T.MeshStandardMaterial({map:ld(D.tex.base,true),metalnessMap:mr,roughnessMap:mr,normalMap:ld(D.tex.nrm,false),normalScale:new T.Vector2(1,1),metalness:1,roughness:1,side:T.DoubleSide,envMap:env,envMapIntensity:.7});
    return R={g,m}}
  function build(){const r=res(),g=new T.Group(),o=new T.Mesh(r.g,r.m);o.scale.setScalar(KB_K);g.add(o);return g}
  return{build,res}
})();

/* ==========================================================
 * Modul: js/interaction/port-picking.js
 * Port tanlash va yonib-o'chish effekti
 * ========================================================== */
/* real hayotdagidek: nuqta nigoh nuri ustida (rad ichida) va yelkadan reach masofada bo'lsa true */
const _pa=new V(),_pb=new V(),_pf=new V();
function pick(v,rad,reach){camera.getWorldDirection(_pf);_pa.copy(v).sub(camera.position);const t=_pa.dot(_pf);if(t<.08)return false;_pb.copy(_pf).multiplyScalar(t);if(_pa.sub(_pb).length()>rad)return false;
 const dx=v.x-camera.position.x,dy=v.y-(camera.position.y-.3),dz=v.z-camera.position.z,d=Math.sqrt(dx*dx+dy*dy+dz*dz);if(d>reach){if(d<reach*2.8)pick.far=true;return false}return true}
function bestPort(){let b=-1,ba=.15;PORTS.forEach((p,i)=>{const w=portW(i),a=aim(w);if(a<ba&&cd(w)<1.5){ba=a;b=i}});return b}
const pcc=new V(1,0,-2.8),near=(v,r)=>Math.hypot(P.x-v.x,P.z-v.z)<r;
const hpg=new T.Group();{const m=L(0x20262d),b=new T.Mesh(new T.TorusGeometry(.085,.012,6,14,Math.PI),m);b.position.y=.035;hpg.add(b);[-.085,.085].forEach(x=>{const c=new T.Mesh(new T.BoxGeometry(.03,.07,.06),m);c.position.set(x,.035,0);hpg.add(c)})}scene.add(hpg);
const IT={usb:{g:fl,P:DFL,V:FV,d:-1},hp:{g:hpg,P:new V(1.2,.907,-3.3),V:new V(),d:-1}};
const dr=new T.Group();dr.position.set(-1,.66,-2.705);scene.add(dr);
/* tortma: preview.html dagi eman tortma (old panel, bezak chiziq, metall dastak, relslar). O'lchamlar va ichki joy avvalgidek */
{const bx=(g,m,x,y,z)=>{const o=new T.Mesh(g,m);o.position.set(x,y,z);dr.add(o);return o};
bx(rbox(.8,.13,.034,.012,3),OAK.drw,0,0,0);bx(new T.BoxGeometry(.69,.012,.008),OAK.edge,0,-.04,.0185);
bx(rbox(.21,.026,.03,.01,3),OAK.metal,0,.012,.062);
[-.075,.075].forEach(x=>{const c=bx(new T.CylinderGeometry(.014,.014,.04,10),OAK.metal,x,.012,.04);c.rotation.x=Math.PI/2});
bx(new T.BoxGeometry(.74,.01,.5),OAK.drwIn,0,-.055,-.265);
[-.37,.37].forEach(x=>bx(new T.BoxGeometry(.02,.08,.5),OAK.drw,x,-.02,-.265));
bx(new T.BoxGeometry(.76,.08,.01),OAK.drw,0,-.02,-.52);
[-.388,.388].forEach(x=>bx(new T.BoxGeometry(.016,.03,.46),OAK.metal,x,-.02,-.26))}
const SL=[[-.2,-.046,-.2],[.15,-.046,-.2]],chW=new V(0,.6,-2.2),pbW=()=>pc.localToWorld(new V(.12,.8,.31)),drF=()=>dr.localToWorld(new V(0,0,.015)),drI=()=>dr.localToWorld(new V(0,-.03,-.2));
const drC={x:-1,z:-2.7,hw:.4,hd:.001};cols.push(drC); /* ochilgan tortma o'yinchini to'sadi */
function flashUpd(dt){dt=Math.min(dt||.016,.033);S.dp+=(S.dr-S.dp)*Math.min(1,dt*5);{const ex=S.dp>.03?.32*S.dp+.09:0;drC.hd=ex/2+.001;drC.z=-2.7+ex/2}dr.position.z=-2.705+.32*S.dp;dr.updateMatrixWorld();
 for(const k in IT){const it=IT[k],g=it.g;g.visible=true;
  if(S.hold===k){g.position.copy(hand);g.quaternion.copy(camera.quaternion);it.V.set(0,0,0)}
  else if(k==="usb"&&S.usb>=0){g.position.copy(portW(S.usb)).add(zOff);g.rotation.set(0,0,0)}
  else if(it.d>=0){g.position.set(SL[it.d][0],SL[it.d][1],SL[it.d][2]);dr.localToWorld(g.position);g.rotation.set(0,0,0);g.visible=S.dp>.05}
  else{const Q=it.P,W2=it.V;W2.y-=9.8*dt;Q.addScaledVector(W2,dt);const on=Math.abs(Q.x)<1.8&&Q.z>-4.2&&Q.z<-2.7,gy=(on&&Q.y>.8?.9005:.0005)+(k==="usb"?.006:0);if(Q.y<=gy){Q.y=gy;if(W2.y<-.8)W2.y*=-.3;else W2.y=0;W2.x*=.8;W2.z*=.8}
   for(const a of CB)colBox(Q,a);Q.x=Math.max(-5.6,Math.min(5.6,Q.x));Q.z=Math.max(-6.6,Math.min(6.6,Q.z));g.position.copy(Q);g.rotation.set(0,g.rotation.y+Math.hypot(W2.x,W2.z)*dt*2,0)}}}

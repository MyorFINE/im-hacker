/* ==========================================================
 * Modul: js/repair/storage.js
 * Disklar: SSD (2.5") va HDD (3.5") — korpusga boltlanadi, SATA kabel bilan ulanadi
 * ========================================================== */
/* HDD: 3.5" qattiq disk, uzun tomoni z bo'ylab; SATA ulagich g'arbiy (-x) tomonda */
function mkHdd(){const g=new T.Group();
 bbx(g,.1016,.026,.147,0x9aa1a8,0,0,0);bbx(g,.098,.0012,.143,0x6b7279,0,.0136,0);
 bbx(g,.075,.0014,.09,0xe4eaf0,0,.0142,.012);bbx(g,.06,.0016,.008,0x2b6bd6,0,.0146,.04);bbx(g,.05,.0016,.006,0x59636e,0,.0146,.015);
 /* SATA ulagich: ma'lumot (data, kichik) + quvvat (power, katta) — ikki alohida kabel ulanadi */
 bbx(g,.01,.008,.016,0x15171a,-.0566,-.005,.01);bbx(g,.004,.004,.012,0xc9a24a,-.0636,-.005,.01);
 bbx(g,.01,.008,.033,0x15171a,-.0566,-.005,.0425);bbx(g,.004,.004,.026,0xc9a24a,-.0636,-.005,.0425);
 bcy(g,.006,.006,.002,0x59636e,.03,.0136,-.05,"y");return g}
/* SSD: 2.5" (7 mm), uzun tomoni z bo'ylab; SATA ulagich g'arbiy (-x) tomonda */
function mkSsd(){const g=new T.Group();
 bbx(g,.0699,.007,.1,0x2a2f36,0,0,0);bbx(g,.067,.0008,.098,0x3a414a,0,.0039,0);
 bbx(g,.034,.0009,.07,0xdfe6ec,.008,.0043,0);bbx(g,.008,.001,.05,0x2b6bd6,.008,.0047,0);
 /* SATA ulagich: ma'lumot (data) + quvvat (power) */
 bbx(g,.01,.004,.018,0x15171a,-.0405,0,-.021);bbx(g,.004,.003,.012,0xc9a24a,-.0475,0,-.021);
 bbx(g,.01,.004,.038,0x15171a,-.0405,0,.011);bbx(g,.004,.003,.03,0xc9a24a,-.0475,0,.011);return g}
regPart("hdd",mkHdd(),new V(.071,.013,.1135),"qattiq disk (HDD)",[-2.78,6.38],[0,0,0],1.4,[.7,.5,.2],new V(0,.01,0),.06);
regPart("ssd",mkSsd(),new V(.19,.0035,.12),"SSD disk",[-2.78,6.54],[0,0,0],2,[.7,.5,.2],new V(0,.004,0),.045);
/* terminal: lsblk */
Object.assign(C,{lsblk:()=>{const L=["NAME   MAJ:MIN RM   SIZE RO TYPE MOUNTPOINTS","sda      8:0    0 476.9G  0 disk","├─sda1   8:1    0   512M  0 part /boot/efi","└─sda2   8:2    0 476.4G  0 part /","sdb      8:16   0 931.5G  0 disk"];
 if(usbOn())L.push("sdc      8:32   1   7.5G  0 disk","└─sdc1   8:33   1   7.5G  0 part /media/usb");return L.join("\n")}});
{const h1=C.help;C.help=()=>h1()+"\nDisklar: lsblk (SSD = sda, HDD = sdb, USB flesh = sdc)"}

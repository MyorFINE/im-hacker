/* ==========================================================
 * Modul: js/repair/fans.js
 * Fanlar
 * ========================================================== */
/* fanlar */
function mkFan(){const g=new T.Group();bbx(g,.12,.12,.025,0x23272d,0,0,0);bcy(g,.054,.054,.003,0x15171a,0,0,-.0105,"z");bcy(g,.014,.014,.005,0x6f7780,0,0,-.0125,"z");for(let i=0;i<7;i++){const b=bbx(g,.022,.045,.002,0x1c2026,Math.cos(i*.9)*.03,Math.sin(i*.9)*.03,-.0118);b.rotation.z=i*.9}return g}
regPart("fan1",mkFan(),new V(.02,.105,.2025),"korpus ventilyatori (1)",[-1.8,6.58],[Math.PI/2,0,0],1,[.3,.6,0],new V(0,0,0),.06);
regPart("fan2",mkFan(),new V(.15,.105,.2025),"korpus ventilyatori (2)",[-1.62,6.58],[Math.PI/2,0,0],1,[.3,.6,0],new V(0,0,0),.06);

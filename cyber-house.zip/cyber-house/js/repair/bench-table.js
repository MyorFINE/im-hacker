/* ==========================================================
 * Modul: js/repair/bench-table.js
 * Ta'mirlash stoli modeli
 * ========================================================== */
/* --- ish stoli: preview.html dagi eman stol (usti, oyoqlar, tayanchlar, old tortma) --- */
buildOakDesk({par:BN.root,cx:-2.15,cz:6.35,W:2.6,D:.8,y:.8,th:.07,r:.02,lw:.07,lx:1.2,lz:.28,ah:.07,aw:.05,back:1});
{const bx=(g,m,x,y,z)=>{const o=new T.Mesh(g,m);o.position.set(x,y,z);BN.root.add(o);return o},dx=-2.77;
bx(rbox(.56,.12,.03,.01,3),OAK.drw,dx,.665,5.955);bx(new T.BoxGeometry(.48,.01,.008),OAK.edge,dx,.64,5.936);
bx(new T.BoxGeometry(.52,.09,.4),OAK.drwIn,dx,.665,6.17);
bx(rbox(.16,.022,.026,.008,3),OAK.metal,dx,.68,5.915);
[-.055,.055].forEach(x=>{const c=bx(new T.CylinderGeometry(.011,.011,.03,10),OAK.metal,dx+x,.68,5.935);c.rotation.x=Math.PI/2})}
{const c0=cv(1024,400),x=c0.getContext("2d");x.fillStyle="#1d2a36";x.fillRect(0,0,1024,400);x.strokeStyle="#6fb1e0";x.lineWidth=8;x.strokeRect(8,8,1008,384);x.fillStyle="#7fd4ff";x.font="bold 54px sans-serif";x.textAlign="center";x.fillText("ISH STOLI — KOMPYUTER TA'MIRI",512,80);x.textAlign="left";x.fillStyle="#e8f3fb";
 ["1. Korpusni yerdan oling va stolga qo'ying","2. Otvyorka oling, qopqoq boltlarini burab chiqaring","3. Kabellarni uzing, qismlarni bittalab ajrating","4. Protsessorga termopasta surting","5. Teskari tartibda yig'ing, boltlarni mahkamlang"].forEach((t,i)=>{x.font="36px sans-serif";x.fillText(t,44,150+i*54)});
 const sg=new T.Mesh(new T.PlaneGeometry(1.5,.586),new T.MeshBasicMaterial({map:tex(c0)}));sg.rotation.y=Math.PI;sg.position.set(-2.15,1.75,6.765);BN.root.add(sg)}

/* ==========================================================
 * Modul: js/repair/main-pc-link.js
 * Asosiy kompyuter bilan bog'lanish
 * ========================================================== */
/* asosiy kompyuter bilan bog'lanish */
const PCA0=DV.pc.A.clone(),PCA1=new V(1.25,FY,-3.2379);
function pcAwayVis(a){CABV.B.forEach(m=>m.visible=!a);CABV.fp.forEach(m=>m.visible=a);CABV.pw.forEach(m=>m.visible=!a);DV.pc.A.copy(a?PCA1:PCA0);DV.pc.init=0}
function takeMainPc(){BN.pcAway=true;pc.visible=false;S.on=false;S.stage=0;pcAwayVis(true);BN.root.add(RC);RC.visible=true;takeCase();toast("🖥 Kompyuter korpusi qo'lingizda — ish stoliga olib boring (montaj stoliga)")}
function putMainPc(){RC.visible=false;BN.root.add(RC);RC.scale.set(1,1,1);RC.rotation.set(0,0,0);pc.visible=true;BN.pcAway=false;BN.where="home";KT.item=null;pcAwayVis(false);bnSync();toast("🖥 Kompyuter joyiga qo'yildi — vilkani ulab ishlatishingiz mumkin")}
function mainPcTarget(){if(BN.pcAway||KT.item||S.hold||LF.cup>0)return null;if(Math.hypot(P.x-1,P.z+2.8)>2.6)return null;if(!pick(new V(1,.3,-3),.34,1.8))return null;
 if(S.on)return["Avval kompyuterni o'chiring (power tugmasi)",null];if(S.plug)return["Avval kompyuter vilkasini rozetkadan sug'uring",null];if(S.usb>=0)return["Avval USB flesh-xotirani sug'uring",null];
 return["E — kompyuter korpusini qo'lga olish (ta'mirlash uchun)",takeMainPc]}
const bcn=id=>{const s=SCR.find(q=>q[0]===id);return s[2]};

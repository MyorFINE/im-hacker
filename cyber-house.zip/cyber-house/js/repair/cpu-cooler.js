/* ==========================================================
 * Modul: js/repair/cpu-cooler.js
 * Protsessor va kuller
 * ========================================================== */
/* protsessor */
const cpg=new T.Group();{bbx(cpg,.04,.002,.04,0x14463a,0,.001,0);bbx(cpg,.036,.003,.036,0xc4c9d0,0,.0035,0);const ps=new T.Mesh(new T.SphereGeometry(1,10,6),L(0xc9ced3));ps.position.y=.0052;ps.name="paste";cpg.add(ps);BN.pasteM=ps}
regPart("cpu",cpg,new V(.125,.02,-.09),"protsessor",[-1,6.1],[0,0,0],2.6,[.3,.6,0],new V(0,.003,0),.02);
/* kuller */
const clg=new T.Group();{bbx(clg,.1,.006,.06,0x9aa1a8,0,.003,-.01);bbx(clg,.05,.115,.036,0xb7bec6,0,.0635,-.012);for(let i=0;i<6;i++)bbx(clg,.052,.115,.0015,0x8d949c,0,.0635,-.028+i*.0064);
 bbx(clg,.12,.12,.025,0x23272d,0,.066,.0245);bcy(clg,.052,.052,.003,0x15171a,0,.066,.0115,"z");bcy(clg,.014,.014,.005,0x6f7780,0,.066,.0105,"z");for(let i=0;i<7;i++){const b=bbx(clg,.02,.045,.002,0x1c2026,Math.cos(i*.9)*.03,.066+Math.sin(i*.9)*.03,.0105);b.rotation.z=i*.9}}
regPart("cooler",clg,CPUO,"protsessor kulleri",[-1.3,6.4],[0,0,-Math.PI/2],.8,[.3,.6,0],new V(0,.06,.0),.07);

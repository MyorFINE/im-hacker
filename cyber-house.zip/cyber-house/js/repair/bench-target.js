/* ==========================================================
 * Modul: js/repair/bench-target.js
 * Asosiy nishon funksiyasi (benchTarget)
 * ========================================================== */
/* --- asosiy nishon funksiyasi --- */
function benchTarget(){
 const it=KT.item,hb=!!it&&it.indexOf("b_")===0;
 if(S.hold||LF.cup>0||LF.sleeping)return null;
 if(it&&!hb)return null;
 const nb=BENCH_NEAR();
 if(!hb&&!nb)return null;
 const nearPc=it==="b_case"&&BN.pcAway&&Math.hypot(P.x-1,P.z+2.8)<2.6;
 if(hb&&!nb){if(it!=="b_case")return["Ushlab turgan narsani ish stoliga olib boring (montaj stoliga)",null];return bnReady()?["E — yig'ilgan kompyuterni inventarga olish (keyin xohlagan joyga qo'yasiz)",putMainPc]:["Avval kompyuterni to'liq yig'ing: barcha qismlar, boltlar va kabellar joyida bo'lsin",null]}
 let best=null,bs=9;const addS=(s,h,a)=>{if(s<bs){bs=s;best=[h,a]}},add=(id,pf,r,h,a,pen)=>{const s=rayN(id,pf,r);if(s<9)addS(s+(pen||0),h,a)};
 const P2=BN.pt,tool=BN.tool,onT=BN.where==="table",free=!it;
 /* qo'ldagi narsani stolga qo'yish */
 if(hb){const nm=it==="b_case"?"korpusni":it==="b_paste"?"termopasta tubasini":BLAB[it.slice(2)]+"ni";
  addS(tblHit(),"E — "+nm+" stolga qo'yish",it==="b_case"?putCaseTable:it==="b_paste"?()=>{PASTE.position.set(PSPOT[0],BTOP+.0095,PSPOT[1]);PASTE.rotation.set(0,0,0);PASTE.scale.set(1,1,1);BN.root.add(PASTE);PASTE.visible=true;KT.item=null;bnSync();toast("Tuba joyiga qo'yildi")}:()=>putTable(it.slice(2)));
 }
 /* korpus: yerda yoki stolda */
 if(free&&onT){add("ct",()=>rcw(0,.1,-.2),.14,"E — korpusni qo'lga olish (stol ostiga qaytarish uchun)",takeCase,.7);add("tilt",()=>rcw(0,.1,0),.3,BN.tilt?"E — korpusni tekis qo'yish":"E — korpusni qiyalatish (ichini yaxshi ko'rish)",()=>setTilt(!BN.tilt),.85)}
 /* otvyorkalar, pasta, idishlar, stoldagi qismlar */
 for(const k in DRS){const sp=DRS[k],nm=k==="ph"?"krestovoy otvyorka":"yassi otvyorka";
  if(tool===k)add("d_"+k,()=>bw(sp[0],BTOP+.02,sp[1]),.07,"E — "+nm+"ni joyiga qo'yish",()=>{BN.tool=null;bnSync();toast("Otvyorka joyiga qo'yildi")},.1);
  else add("d_"+k,()=>bw(sp[0],BTOP+.02,sp[1]),.07,"E — "+nm+" olish"+(tool?" (qo'ldagisi almashadi)":""),()=>toolSwap(k),.1)}
 if(free&&PASTE.parent!==KH&&PASTE.visible)add("pst",()=>bw(PSPOT[0],BTOP+.02,PSPOT[1]),.07,"E — termopasta tubasini olish",()=>{KH.add(PASTE);PASTE.visible=true;PASTE.position.set(0,0,0);PASTE.rotation.set(.4,.6,0);PASTE.scale.setScalar(1.6);KT.item="b_paste";bnSync();toast("🧴 Termopasta qo'lingizda")},.1);
 for(const k in TRS){const t=TRS[k];add("t_"+k,()=>bw(t[0],BTOP+.02,t[1]),.075,"Idish «"+t[3]+"» — boltlar: "+BN.cont[k],null,.5)}
 if(free)for(const k in P2){const p=P2[k];if(p.at==="table")add("lp_"+k,()=>p.g.getWorldPosition(new V()),.1,"E — "+BLAB[k]+"ni olish",()=>takePart(k),.2)}
 /* korpus ichi */
 if(onT){
  const sc=s=>{const id=s[0],pk=s[1];if(!P2[pk].in)return;if(pk!=="panel"&&P2.panel.in)return;const inn=BN.sc[id]===1,pf=()=>rcw(s[3],s[4],s[5]);
   if(tool==="ph")add(id,pf,.02,inn?"E — boltni burab chiqarish (idish: "+CN[s[2]]+")":"E — boltni mahkamlash (idishdan, "+(BN.cont[s[2]]+"")+" ta)",inn?()=>unscrew(id):()=>screwIn(id));
   else add(id,pf,.02,tool==="flat"?"🔩 Yassi otvyorka bolt boshiga mos kelmaydi — krestovoyni oling":"🔩 Bolt — avval stoldan krestovoy otvyorkani oling",null)};
  SCR.forEach(sc);
  if(P2.panel.in){const r=remBlock("panel");add("panel",()=>rcw(0,.212,0),.25,r?"🔒 Qopqoq: "+r:"E — yon qopqoqni olish",r?null:()=>takePart("panel"),.6)}
  else{
   for(const k in CAB){const c=CAB[k],ow=P2[c.own].in,nd=c.need.every(q=>P2[q].in);if(!ow)continue;const pf=()=>rcw(c.sock[0],c.sock[1],c.sock[2]);
    if(BN.cab[k]===1)add("cb_"+k,pf,.03,"E — "+c.lab+"ni uzish",()=>cabToggle(k),.1);
    else if(nd&&(c.own!=="psu"||P2.psu.in))add("cb_"+k,pf,.03,"E — "+c.lab+"ni ulash",()=>cabToggle(k),.1)}
   for(const k of ["psu","gpu","ram1","ram2","cooler","cpu","mb","fan1","fan2","hdd","ssd"]){const p=P2[k];
    const ctr=()=>rcw(p.ip.x+p.cOff.x,p.ip.y+p.cOff.y,p.ip.z+p.cOff.z);
    if(p.in){if(k==="cpu"&&P2.cooler.in)continue;
     if(k==="cpu"&&!BN.lever){const pp=BN.paste;if(free)add("pc",ctr,.022,pp!=="none"?"E — "+(pp==="old"?"eski":"")+" termopastani sidirib tozalash":"Protsessor toza — termopasta tubasini oling",pp!=="none"?()=>{BN.paste="none";bnSync();toast("🧽 Termopasta tozalandi")}:null);
      else if(it==="b_paste")add("pc",ctr,.022,pp==="none"?"E — termopasta surtish":pp==="new"?"Termopasta allaqachon surtilgan ✓":"Avval eski pastani sidirib tozalang (qo'lingiz bo'sh bo'lsin)",pp==="none"?()=>{BN.paste="new";bnSync();toast("🧴 Termopasta surtildi")}:null);continue}
     if(free){const r=remBlock(k);add("p_"+k,ctr,p.rad,r?"🔒 "+BLAB[k]+": "+r:"E — "+BLAB[k]+"ni olish",r?null:()=>takePart(k),k==="mb"?.5:0)}}
    else if(it==="b_"+k){const r=plBlock(k);add("s_"+k,ctr,Math.max(p.rad,.03),r?"🔒 "+r:"E — "+BLAB[k]+"ni joyiga o'rnatish",r?null:()=>installPart(k),.05)}}
   if(!P2.cooler.in){const lv=()=>rcw(.13,.024,-.06),cr=!P2.cpu.in;
    add("lev",lv,.03,BN.lever?(cr?"Protsessor yo'q — avval uni o'rnating":"E — qisqich dastasini tushirish (mahkamlash)"):"E — qisqich dastasini ko'tarish",BN.lever&&cr?null:leverToggle,.1)}}
  if(it==="b_panel"&&!P2.panel.in)add("s_panel",()=>rcw(0,.212,0),.25,"E — yon qopqoqni yopish",()=>installPart("panel"),.6)}
 if(best&&bs<9)return best;
 if(hb)return["Qo'lingizda: "+(it==="b_case"?"korpus":it==="b_paste"?"termopasta":BLAB[it.slice(2)])+" — stolga yoki joyiga qarang",null];
 return null}

/* ==========================================================
 * Modul: js/repair/bench-helpers.js
 * Ta'mirlash stoli: yordamchi funksiyalar
 * ========================================================== */
/* ===================== ISH STOLI (karavot yonida): kompyuter ta'mirlash ===================== */
const BTOP=.8,BN={root:new T.Group(),pt:{},sc:{},hole:{},scm:{},cab:{},cabm:{},lever:0,paste:"old",cont:{k:0,a:0,v:0},tool:null,where:"home",done:false,tilt:1,pcAway:false};
const BG=new T.Group();BG.position.set(-.9,0,3.3);BG.rotation.y=Math.PI/2;scene.add(BG);BG.add(BN.root);cols.push({x:5.45,z:5.45,hw:.4,hd:1.3});BG.updateMatrixWorld(true);
const bw=(x,y,z)=>BG.localToWorld(new V(x,y,z));
function bbx(par,w,h,d,c,x,y,z,o){const m=new T.Mesh(new T.BoxGeometry(w,h,d),L(c,o));m.position.set(x,y,z);par.add(m);return m}
function bcy(par,r1,r2,h,c,x,y,z,ax,o){const m=new T.Mesh(new T.CylinderGeometry(r1,r2,h,14),L(c,o));m.position.set(x,y,z);if(ax==="z")m.rotation.x=Math.PI/2;else if(ax==="x")m.rotation.z=Math.PI/2;par.add(m);return m}

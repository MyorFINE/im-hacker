/* ==========================================================
 * Modul: js/repair/bench-update.js
 * Ta'mirlash stoli yangilanishi
 * ========================================================== */
function benchUpd(dt){if(TOOLG.parent!==scene)scene.add(TOOLG);const sh=!!BN.tool&&!seated&&!LF.sleeping;TOOLG.visible=sh;if(sh){camera.getWorldDirection(fw);rg.set(1,0,0).applyQuaternion(camera.quaternion);TOOLG.position.copy(camera.position).addScaledVector(fw,.45).addScaledVector(rg,-.2);TOOLG.position.y-=.2;TOOLG.quaternion.copy(camera.quaternion);TOOLG.children.forEach(c=>c.visible=c.name===BN.tool)}
 let zt=0;if(BN.where==="table"&&!seated&&BENCH_DIST()<2.4){const s=rayN("zm",()=>rcw(0,.1,0),.55);if(s<9)zt=1}
 window.BNZ=(window.BNZ||0)+(zt-(window.BNZ||0))*Math.min(1,dt*5)}

const cupG=new T.Group();{const cm=new T.Mesh(new T.CylinderGeometry(.04,.03,.1,10,1,true),new T.MeshLambertMaterial({color:0xffffff,transparent:true,opacity:.45,side:T.DoubleSide}));cupG.add(cm);const wt=new T.Mesh(new T.CylinderGeometry(.036,.029,.07,10),new T.MeshBasicMaterial({color:0x4fc3ff}));wt.position.y=-.012;wt.name="w";cupG.add(wt)}cupG.visible=false;scene.add(cupG);
const alarmL=new T.PointLight(0xff2020,0,6);alarmL.position.set(-4.6,2.6,-5.0);scene.add(alarmL);

/* ==========================================================
 * Modul: js/repair/side-panel-bolts.js
 * Yon qopqoq (shisha) va boltlar
 * ========================================================== */
/* yon qopqoq (shisha) */
const pag=new T.Group();{bbx(pag,.5,.004,.45,0x9fc4e4,0,0,0,{transparent:true,opacity:.22,depthWrite:false});bbx(pag,.5,.006,.012,0x1c2026,0,0,.219);bbx(pag,.5,.006,.012,0x1c2026,0,0,-.219);bbx(pag,.012,.006,.45,0x1c2026,.244,0,0);bbx(pag,.012,.006,.45,0x1c2026,-.244,0,0)}
regPart("panel",pag,new V(0,.212,0),"yon qopqoq (shisha)",[-1.1,6.62],[-1.4,0,0],.55,[-.9,.4,0],new V(0,0,0),.22);
/* boltlar */
const SCR=[["p1","panel","k",-.21,.2155,-.205,"y"],["p2","panel","k",.21,.2155,-.205,"y"],
 ["u1","psu","k",-.225,.025,-.2285,"z"],["u2","psu","k",-.165,.025,-.2285,"z"],["u3","psu","k",-.225,.125,-.2285,"z"],["u4","psu","k",-.165,.125,-.2285,"z"],
 ["g1","gpu","v",-.06,.115,-.2285,"z"],["g2","gpu","v",.025,.115,-.2285,"z"],
 ["c1","cooler","a",.085,.033,-.114,"y"],["c2","cooler","a",.085,.033,-.088,"y"],["c3","cooler","a",.165,.033,-.114,"y"],["c4","cooler","a",.165,.033,-.088,"y"],
 ["m1","mb","a",-.055,.0175,-.195,"y"],["m2","mb","a",.235,.0175,-.195,"y"],["m3","mb","a",-.055,.0175,.034,"y"],["m4","mb","a",.235,.0175,.034,"y"],["m5","mb","a",.09,.0175,-.195,"y"],["m6","mb","a",.09,.0175,.034,"y"],
 ["d1","hdd","k",.031,.0275,.0535,"y"],["d2","hdd","k",.111,.0275,.0535,"y"],["d3","hdd","k",.031,.0275,.1735,"y"],["d4","hdd","k",.111,.0275,.1735,"y"],
 ["e1","ssd","k",.19,.0085,.082,"y"],["e2","ssd","k",.19,.0085,.158,"y"]];
[[.02,"fan1","1"],[.15,"fan2","2"]].forEach(f=>[[-1,-1],[1,-1],[-1,1],[1,1]].forEach((q,i)=>SCR.push(["f"+f[2]+"_"+(i+1),f[1],"k",f[0]+q[0]*.052,.105+q[1]*.052,.1895,"z"])));
const SHG=new T.CylinderGeometry(.004,.004,.003,8),SHM=L(0xc0c6cc),SLM=L(0x2b2f35),HOG=new T.CircleGeometry(.0048,10),HOM=new T.MeshBasicMaterial({color:0x07080a});
SCR.forEach(s=>{const g=new T.Group();g.add(new T.Mesh(SHG,SHM));const sl=new T.Mesh(new T.BoxGeometry(.006,.0012,.0012),SLM);sl.position.y=.0016;g.add(sl);const sl2=sl.clone();sl2.rotation.y=Math.PI/2;g.add(sl2);
 const h=new T.Mesh(HOG,HOM);if(s[6]==="z"){g.rotation.x=-Math.PI/2;g.position.set(s[3],s[4],s[5]-.0015);h.position.set(s[3],s[4],s[5]+.0013);h.rotation.y=Math.PI}else{g.position.set(s[3],s[4],s[5]);h.position.set(s[3],s[4]-.0014,s[5]);h.rotation.x=-Math.PI/2}
 RC.add(g);RC.add(h);BN.sc[s[0]]=1;BN.scm[s[0]]=g;BN.hole[s[0]]=h});

/* ==========================================================
 * Modul: js/repair/bench-actions.js
 * Harakatlar: olish, qo'yish, o'rnatish
 * ========================================================== */
/* --- harakatlar --- */
function setPose(g,p){g.visible=true;g.position.set(0,0,0);g.rotation.set(p.hr[0],p.hr[1],p.hr[2]);g.scale.setScalar(p.hs)}
function takePart(k){const p=BN.pt[k];KH.add(p.g);setPose(p.g,p);p.in=false;p.at="hand";KT.item="b_"+k;BN.done=false;bnSync();toast("🔧 "+BLAB[k]+" qo'lingizda")}
function putTable(k){const p=BN.pt[k],g=p.g;BN.root.add(g);g.visible=true;g.scale.set(1,1,1);g.rotation.set(p.tr[0],p.tr[1],p.tr[2]);g.position.set(p.tab[0],0,p.tab[1]);g.updateMatrixWorld(true);const bb=new T.Box3().setFromObject(g);g.position.y+=BTOP+.0008-bb.min.y;p.at="table";KT.item=null;bnSync();toast("Stolga qo'yildi")}
function installPart(k){const p=BN.pt[k],g=p.g;RC.add(g);g.visible=true;g.scale.set(1,1,1);g.rotation.set(0,0,0);g.position.copy(p.ip);p.in=true;p.at="case";KT.item=null;bnSync();toast("✅ "+BLAB[k]+" o'rnatildi"+(SCR.some(s=>s[1]===k)?" — endi boltlarini mahkamlang":""));
 if(k==="cooler")toast(BN.paste==="new"?"✅ Kuller o'rnatildi — termopasta yangi":"⚠ Kuller o'rnatildi, lekin termopasta yangilanmagan (eski)");bnCheck()}
function takeCase(){KH.add(RC);RC.visible=true;RC.position.set(0,0,0);RC.rotation.set(.35,.6,0);RC.scale.setScalar(.5);BN.where="hand";KT.item="b_case";bnSync();toast("🖥 Korpus qo'lingizda")}
/* korpus stolda: tekis yoki old tomonga qiyalatilgan (ichini ko'rish oson) */
function setTilt(t){BN.tilt=t?1:0;const th=t?.45:0,c=Math.cos(th),s=Math.sin(th);RC.scale.set(1,1,1);RC.rotation.set(-th,0,0);RC.position.set(-2.35,BTOP+.1,6.125-.006*s+.225*c);BN.root.updateMatrixWorld(true);RC.updateMatrixWorld(true);
 const bb=new T.Box3().setFromObject(RC);RC.position.y+=BTOP+.0008-bb.min.y;RC.updateMatrixWorld(true);
 STANDS.forEach((m,i)=>{const q=i?1:-1,p=BN.root.worldToLocal(RC.localToWorld(new V(q*.2,-.006,.225))),h=Math.max(.01,p.y-.012-BTOP);m.scale.y=h;m.position.set(p.x,BTOP+h/2,p.z-.02)});bnSync()}
function putCaseTable(){BN.root.add(RC);RC.visible=true;BN.where="table";KT.item=null;setTilt(BN.tilt);toast("Korpus stolda — ichi ko'rinadi (qiyalatilgan)")}
const bnReady=()=>Object.values(BN.pt).every(p=>p.in)&&SCR.every(s=>BN.sc[s[0]]===1)&&Object.values(CAB).every((c,i)=>true)&&Object.keys(CAB).every(k=>BN.cab[k]===1)&&!BN.lever;

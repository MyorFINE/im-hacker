/* ==========================================================
 * Modul: js/ui/main-menu.js
 * Bosh menyu: Boshlash, Sozlamalar (grafika + to'liq ekran),
 * Yo'riqnoma va Chiqish.
 * Eslatma: "Boshlash" tugmasi (#enter) o'yinni js/player/touch-controls.js
 * ichidagi eski ishlovchi orqali boshlaydi — o'yin kodi o'zgarmagan.
 * ========================================================== */
(function(){
const el=id=>document.getElementById(id);
const modal=el("hhModal"),mTitle=el("hhModalTitle"),mBody=el("hhModalBody"),mAct=el("hhModalActions"),bye=el("hhBye"),start=el("start");
const QKEY="hh_quality";

/* ---------- oyna tizimi ---------- */
let lastFocus=null;
function btn(label,fn,cls){const b=document.createElement("button");b.className="hh-btn"+(cls?" "+cls:"");b.textContent=label;b.onclick=fn;return b}
function showModal(title,html,buttons){
  lastFocus=document.activeElement;
  mTitle.textContent=title;mBody.innerHTML=html;mBody.scrollTop=0;mAct.innerHTML="";
  (buttons||[btn("ORQAGA",closeModal)]).forEach(b=>mAct.appendChild(b));
  modal.classList.add("show");
  const f=mAct.querySelector("button");if(f)f.focus({preventScroll:true});
}
function closeModal(){modal.classList.remove("show");if(lastFocus&&lastFocus.focus)lastFocus.focus({preventScroll:true})}
modal.addEventListener("pointerdown",e=>{if(e.target===modal)closeModal()});
addEventListener("keydown",e=>{if(e.key==="Escape"&&start.style.display!=="none"&&modal.classList.contains("show")){closeModal();e.stopPropagation()}},true);

/* ---------- SOZLAMALAR ---------- */
const QDESC=[
 "AVTO — o‘yin kadr tezligiga qarab sifatni o‘zi moslaydi (tavsiya etiladi).",
 "YUQORI — eng aniq tasvir. Kuchli qurilmalar uchun.",
 "PAST — eng yengil rejim. Sekin kompyuter va telefonlar uchun."
];
const QNAME=["AVTO","YUQORI","PAST"];
function curQ(){return typeof qMode==="number"?qMode:0}
function applyQ(m){try{if(typeof setQ==="function")setQ(m);localStorage.setItem(QKEY,String(m))}catch(e){}}
function fsOn(){return !!document.fullscreenElement}
function openSettings(){
  showModal("SOZLAMALAR",
   '<div class="hh-row"><label>GRAFIKA SIFATI</label><div class="hh-seg" id="hhQ">'+
   QNAME.map((n,i)=>'<button data-q="'+i+'">'+n+'</button>').join("")+
   '</div><div class="hh-note" id="hhQNote"></div></div>'+
   '<div class="hh-row"><label>TO‘LIQ EKRAN</label><div class="hh-fs"><button class="hh-btn" id="hhFs"></button><span id="hhFsNote" class="hh-note" style="margin:0"></span></div></div>'+
   '<div class="hh-note">Sozlamalar saqlanadi. O‘yin vaqtida ham yuqoridagi SIFAT va ⛶ tugmalari ishlaydi, <kbd>F</kbd> — to‘liq ekran.</div>'
  );
  const seg=el("hhQ"),note=el("hhQNote");
  const sync=()=>{[...seg.children].forEach((b,i)=>b.classList.toggle("on",i===curQ()));note.textContent=QDESC[curQ()]};
  [...seg.children].forEach(b=>b.onclick=()=>{applyQ(+b.dataset.q);sync()});
  sync();
  const fb=el("hhFs"),fn=el("hhFsNote");
  const syncFs=()=>{fb.textContent=fsOn()?"ODDIY OYNA":"TO‘LIQ EKRANGA O‘TISH";fn.textContent=fsOn()?"Hozir: yoqilgan":"Hozir: o‘chiq"};
  fb.onclick=async()=>{try{fsOn()?await document.exitFullscreen():await document.documentElement.requestFullscreen()}catch(e){fn.textContent="Brauzer to‘liq ekranni qo‘llamadi"}};
  syncFs();
  /* modal yopilgach tinglovchini olib tashlash */
  const h=()=>{if(modal.classList.contains("show")&&el("hhFs"))syncFs()};
  document.addEventListener("fullscreenchange",h);
}
/* Saqlangan sifatni qayta tiklash */
try{const s=parseInt(localStorage.getItem(QKEY));if(s>=0&&s<=2&&typeof setQ==="function")setQ(s)}catch(e){}

/* ---------- YO'RIQNOMA ---------- */
function openGuide(){
  showModal("YO‘RIQNOMA",
  '<h3>MAQSAD</h3>'+
  '<p>Siz — o‘z hacker uyingizning egasisiz. Kompyuteringizni yig‘ing va ishga tushiring, tizimingizni hujumlardan himoya qiling, ovqatlaning, suv iching va uxlashni unutmang.</p>'+
  '<h3>BOSHQARUV (KOMPYUTER)</h3>'+
  '<ul>'+
  '<li><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> yoki strelkalar — yurish</li>'+
  '<li><kbd>Shift</kbd> — tez yugurish</li>'+
  '<li><b>Sichqoncha</b> — atrofga qarash</li>'+
  '<li><kbd>E</kbd> — ta’sir: olish, ulash, eshik ochish, o‘tirish, uxlash</li>'+
  '<li><kbd>Q</kbd> — suv ichish (stakan to‘la bo‘lsa)</li>'+
  '<li><kbd>F</kbd> — to‘liq ekran</li>'+
  '<li><kbd>Esc</kbd> — stuldan turish / oynani yopish</li>'+
  '<li><kbd>F2</kbd> — 2-monitorga yaqinlashtirish (o‘tirganda)</li>'+
  '</ul>'+
  '<h3>BOSHQARUV (TELEFON)</h3>'+
  '<ul><li>Chap tomonni bosib suring — yurish (joystick)</li><li>O‘ng tomonni suring — atrofga qarash</li><li><b>E</b> tugmasi — ta’sir qilish</li><li>Telefonni gorizontal holatda ushlang</li></ul>'+
  '<h3>BIRINCHI QADAMLAR</h3>'+
  '<ul>'+
  '<li>Kompyuter va monitor vilkasini rozetka oldiga borib ulang (<kbd>E</kbd>), so‘ng kompyuterdagi <b>power</b> tugmasini bosing.</li>'+
  '<li>Stulga o‘tiring (<kbd>E</kbd>) va tizimga kiring. Standart parol: <b>kali</b>.</li>'+
  '<li>Qo‘lingizda bir vaqtning o‘zida faqat BITTA narsa bo‘lishi mumkin: stakan, vilka yoki flesh-xotira.</li>'+
  '<li>Stol tortmasidagi <b>blaknot</b>da barcha buyruqlar yozilgan. Terminalda <b>help</b> va <b>audit</b> buyruqlarini sinab ko‘ring.</li>'+
  '</ul>'+
  '<h3>HAYOT</h3>'+
  '<ul>'+
  '<li>💧 Chanqash — suv idishi sharq devor yonida.</li>'+
  '<li>🍽 Ochlik — oshxona shimoliy devordagi eshik ortida.</li>'+
  '<li>😴 Charchoq — karavotga yotib uxlang.</li>'+
  '<li>1 o‘yin kuni = 1 real soat.</li>'+
  '</ul>'+
  '<h3>HUJUMLAR</h3>'+
  '<p class="hh-red">Hujum boshlanganda ekranda hech qanday ogohlantirish chiqmaydi!</p>'+
  '<ul>'+
  '<li>Kompyuterda <b>Attack Monitor</b> ilovasini oching va qizil qatorlarni kuzating.</li>'+
  '<li>Har bir hujumni bartaraf etish uchun 60 soniya bor.</li>'+
  '<li>Hujum turlari: port skanerlash, SSH brute-force, web zaiflik, ransomware.</li>'+
  '<li>Ballaringizni <b>wallet lock</b> bilan seyfga qulflang — o‘g‘irlanmaydi.</li>'+
  '<li>Hujumchini topib, qarshi hujum qilish mumkin (kuniga 4 marta).</li>'+
  '</ul>'+
  '<h3>MASLAHAT</h3>'+
  '<ul><li>Sekin ishlasa — Sozlamalardan grafikani PAST qiling.</li><li>Kompyuter buzilsa — ta’mirlash stolida uni qismlarga ajratib tuzatish mumkin.</li></ul>'
  );
}

/* ---------- CHIQISH ---------- */
function doQuit(){
  closeModal();
  try{document.fullscreenElement&&document.exitFullscreen()}catch(e){}
  try{document.exitPointerLock&&document.exitPointerLock()}catch(e){}
  try{window.close()}catch(e){}            /* faqat skript ochgan oynada ishlaydi */
  start.style.display="none";              /* oyna yopilmasa — xayrlashuv ekrani */
  bye.classList.add("show");
}
function openQuit(){
  showModal("O‘YINDAN CHIQISH",
   '<p>Haqiqatan ham chiqmoqchimisiz?</p><p>Tizim sizni kutib turadi…</p>',
   [btn("QOLISH",closeModal),btn("CHIQISH",doQuit,"hh-red")]);
}
el("hhAgain").onclick=()=>location.reload();

/* ---------- tugmalarni ulash ---------- */
el("hhSet").onclick=openSettings;
el("hhGuide").onclick=openGuide;
el("hhQuit").onclick=openQuit;
})();

/* ==========================================================
 * Modul: js/input/keyboard-refocus.js
 * Brauzer oynasidan qaytganda klaviatura
 * ========================================================== */
/* ---------- brauzer oynasidan qaytganda klaviatura ---------- */
function refocusKb(){if(!seated||mobile||LF.sleeping)return;if(document.activeElement!==ta)ta.focus({preventScroll:true})}
addEventListener("focus",()=>{for(const k in keysDown)keysDown[k]=false;setTimeout(()=>{refocusKb();dirty=true},30)});
addEventListener("blur",()=>{for(const k in keysDown)keysDown[k]=false});
document.addEventListener("visibilitychange",()=>{if(!document.hidden)setTimeout(refocusKb,50)});
addEventListener("keydown",e=>{if(seated&&!mobile&&document.activeElement!==ta&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.code!=="Escape")ta.focus({preventScroll:true})},true);

/* ==========================================================
 * Modul: js/input/keyboard-auto.js
 * Klaviatura yozish tuyg'usi va avtomatik klaviatura
 * ========================================================== */
/* ---------- klaviatura: yozish tuyg'usi ---------- */
function klight(ch){const i=keyIdx(ch||"x");keys.setColorAt(i,new T.Color(1.4,4,5));keys.instanceColor.needsUpdate=true;setTimeout(()=>{keys.setColorAt(i,new T.Color(1,1,1));keys.instanceColor.needsUpdate=true},110)}
function wantsKb(){if(S.stage===2)return true;if(S.stage!==3)return false;if(DSK.edit)return true;if(menuOpen)return true;const w=wins.find(w=>w.id===focusId&&!w.min);if(!w)return false;return w.id==="terminal"||w.id==="editor"||w.id==="ide"||(w.id==="files"&&!!w.edit)}
function kbAuto(){if(!mobile||!seated)return;if(wantsKb()){if(document.activeElement!==ta)ta.focus({preventScroll:true})}else if(document.activeElement===ta)ta.blur()}
